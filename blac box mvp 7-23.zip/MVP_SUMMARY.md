# LabCopy MVP — Verified End-to-End, 2026-07-24

## What was proven
Installed the actual wheels (`iteration_wallet-2.5.0a2`, `bbx1_iteration_wallet_plugin-0.6.0a1`) into a clean venv and ran the real CLI/server — not a mock — through the full custody lifecycle:

`create-project → create-section → add-candidate → start-session → labcopy-export (HMAC-signed .iwlab) → external "tool" round trip → labcopy-reenter → promote → chain/custody verification`

Both re-entry outcomes were reproduced against the live system:
- **Unmodified return → `no_op_identical_hash`** (matches `installed_e2e.log`'s `identical_disposition`)
- **Modified return → `new_candidate` (`labcand-...`)** routed through quarantine as an Intake Capsule, then promoted to Prime

Final state each run: `iw chain` → `ok: true`, 0 errors; `iw custody` → `incident_count: 0`. Ran this twice (once reusing a live server/state, once with a fresh server) — same clean result both times.

## One real bug found in the shipped wheels
The two `.whl` filenames use underscores instead of dots in the version segment (`iteration_wallet-2_5_0a2-...`), which violates the wheel filename spec — `pip install` rejects them outright with "invalid version." **Fix:** rebuild/rename with dots (`2.5.0a2`) before publishing. The demo script works around this by renaming a local copy; it doesn't touch your build.

## One real UX gap, not a bug
`labcopy-reenter` silently demotes to `unlinked_raw_source` if `--manifest` is omitted — even when re-entering the exact untouched `.iwlab` you just exported. That's correct per `quarantine-spec.md`'s "missing manifest → demote" rule, but the CLI gives no hint that `--manifest` is required for linkage to work, and passing the `.iwlab` *container* itself as `result_file` (instead of the extracted `payload/` file) also silently produces a "new" candidate, since the CLI hashes whatever file you point it at. Worth a `--help` line or a doctor-style warning.

## What's genuinely unverified still
- `oubliette-inspect` / `oubliette-quarantine` / `oubliette-admit-derivative` (the older Oubliette pathway) — status showed `Oubliette: unavailable (disabled)` throughout; this demo only exercised the newer `labcopy-export`/`labcopy-reenter` pair.
- Crash-recovery / stale-quarantine sweep behavior (`sweep_stale()` in your `quarantine.py` reference) — not exercised, since nothing crashed mid-stage in this run.
- Multi-user / concurrent `export_id` collision handling.

## Suggested next steps to a "finished, credited" deliverable
1. **Fix the wheel filenames** at build time (trivial, confirmed root cause above).
2. **Decide Oubliette's fate** — the snapshot's own README already flags it as the open question ("finish to narrow spec, or revert"). This demo didn't touch it, so that decision is still outstanding.
3. **Add a CI smoke test** = literally `mvp_demo.sh`, run against a fresh venv on every wheel build, asserting `chain.ok`, `custody.incident_count == 0`, and both re-entry dispositions. Turns this manual verification into a repeatable gate.
4. **Credit/attribution**: if you want a written report (vs. this script) for a stakeholder audience, I can turn this into a formal Word/PDF writeup with the receipts, hashes, and chain output as an appendix — say the word and I'll build it.

## Files
- `mvp_demo.sh` — runnable, reproducible script for the whole flow above (`bash mvp_demo.sh <wheels_dir> <workdir>`)
