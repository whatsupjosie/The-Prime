#!/usr/bin/env bash
# ==============================================================================
# Iteration Wallet 2.5.0a2 + BlackBox 0.6.0a1 — LabCopy MVP end-to-end demo
#
# Proves the real intake pipeline works against the built wheels:
#   install -> doctor -> project/section/candidate -> session
#   -> labcopy-export (HMAC-signed) -> external "tool" round trip
#   -> labcopy-reenter (unchanged -> no-op, changed -> new candidate)
#   -> promote to Prime -> chain/custody verification
#
# Usage: bash mvp_demo.sh /path/to/wheels_dir /path/to/workdir
#   wheels_dir must contain:
#     bbx1_iteration_wallet_plugin-0_6_0a1-py3-none-any.whl
#     iteration_wallet-2_5_0a2-py3-none-any.whl
# ==============================================================================
set -euo pipefail

WHEELS_DIR="${1:?Usage: mvp_demo.sh <wheels_dir> <workdir>}"
WORKDIR="${2:?Usage: mvp_demo.sh <wheels_dir> <workdir>}"

mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "== 1. venv + fixed wheel filenames =="
# The uploaded wheel filenames use underscores in the version segment
# (bbx1_iteration_wallet_plugin-0_6_0a1-...), which is not a valid wheel
# filename per PEP 427/PEP 440 (pip rejects it as "invalid version").
# Copy them to dot-separated names before installing.
mkdir -p fixed_wheels
cp "$WHEELS_DIR"/bbx1_iteration_wallet_plugin-0_6_0a1-py3-none-any.whl \
   fixed_wheels/bbx1_iteration_wallet_plugin-0.6.0a1-py3-none-any.whl
cp "$WHEELS_DIR"/iteration_wallet-2_5_0a2-py3-none-any.whl \
   fixed_wheels/iteration_wallet-2.5.0a2-py3-none-any.whl

python3 -m venv venv
. venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet \
  fixed_wheels/bbx1_iteration_wallet_plugin-0.6.0a1-py3-none-any.whl \
  fixed_wheels/iteration_wallet-2.5.0a2-py3-none-any.whl

echo "== 2. doctor (package ownership + BlackBox compatibility) =="
export IW_HOME="$WORKDIR/iw_home"
mkdir -p "$IW_HOME"
iw doctor

echo "== 3. start server =="
setsid nohup iw serve > server.log 2>&1 < /dev/null &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT
for i in $(seq 1 20); do
  curl -s -o /dev/null http://127.0.0.1:7432/docs && break
  sleep 0.5
done

echo "== 4. project / section / candidate / session =="
PROJECT_ID=$(iw create-project "MVP Demo" | grep -o '([a-f0-9]*)' | tr -d '()')
SECTION_ID=$(iw create-section "$PROJECT_ID" "Main" --description "MVP demo section" | grep -o '([a-f0-9]*)' | tr -d '()')

mkdir -p demo_files
cat > demo_files/candidate_v1.py <<'EOF'
def hello():
    return "hello from candidate v1"
EOF
CAND_ID=$(iw add-candidate "$PROJECT_ID" "$SECTION_ID" demo_files/candidate_v1.py --notes "initial candidate" | grep -oE '\([a-f0-9]+\)' | tr -d '()')

SESSION_ID=$(iw start-session demo-actor --confirm "I AM HERE" | grep -oE '[0-9a-f]{24}')

echo "== 5. labcopy-export (HMAC-signed .iwlab package) =="
mkdir -p demo_files/lab_out
iw labcopy-export "$PROJECT_ID" "$SECTION_ID" "$CAND_ID" demo_files/lab_out \
  --actor-id demo-actor --session-id "$SESSION_ID" \
  --reason "MVP demo export" --confirm "EXPORT" --open-confirm "OPEN"
LABFILE=$(ls demo_files/lab_out/*.iwlab)

echo "== 6a. re-enter UNCHANGED payload -> expect no_op_identical_hash =="
mkdir -p demo_files/external_tool_A
(cd demo_files/external_tool_A && unzip -o -q "../lab_out/$(basename "$LABFILE")")
iw labcopy-reenter "$PROJECT_ID" "$SECTION_ID" \
  demo_files/external_tool_A/payload/candidate_v1.py \
  --manifest demo_files/external_tool_A/manifest.json \
  --actor-id demo-actor --session-id "$SESSION_ID" \
  --reason "unchanged return" --confirm "ADMIT" --open-confirm "OPEN"

echo "== 6b. re-enter MODIFIED payload -> expect new candidate via quarantine =="
mkdir -p demo_files/external_tool_B
(cd demo_files/external_tool_B && unzip -o -q "../lab_out/$(basename "$LABFILE")")
cat >> demo_files/external_tool_B/payload/candidate_v1.py <<'EOF'

def goodbye():
    return "goodbye from candidate v1, improved externally"
EOF
REENTER_OUT=$(iw labcopy-reenter "$PROJECT_ID" "$SECTION_ID" \
  demo_files/external_tool_B/payload/candidate_v1.py \
  --manifest demo_files/external_tool_B/manifest.json \
  --actor-id demo-actor --session-id "$SESSION_ID" \
  --reason "improved externally" --confirm "ADMIT" --open-confirm "OPEN")
echo "$REENTER_OUT"
NEW_CAND_ID=$(echo "$REENTER_OUT" | grep '^Candidate:' | awk '{print $2}')

echo "== 7. promote new candidate to Prime =="
iw promote "$PROJECT_ID" "$SECTION_ID" "$NEW_CAND_ID" \
  --actor-id demo-actor --session-id "$SESSION_ID" \
  --reason "MVP demo promotion" --confirm "PROMOTE" --open-confirm "OPEN"

echo "== 8. verify =="
iw ls
iw chain
iw custody
iw status

echo
echo "MVP demo complete."
