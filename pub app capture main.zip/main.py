"""
PubCast AI — main.py  (Phase 1 hardened)
Subsystems: Hub (WS/chat), CameraManager, RecordingService, Avatar.
Import style: from modules.X — files must be in modules/ package.
Run setup_modules() below if you haven't moved files yet.
"""
from __future__ import annotations
import logging, uuid, time
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, Form, Request, Response, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.websockets import WebSocketState

# ── Module imports (files live in modules/ package) ──────────────────────────
from modules.hub         import Hub
from modules.persistence import (allowed_upload_extension, append_jsonl,
                                  ensure_dirs, read_json, sanitize_filename, write_json)
from modules.models      import ProductionState, UserState
from modules.cameras     import CameraManager, create_default_cameras
from modules.recording   import RecordingService, ContainerFormat, RecordingArtifact, create_recording_service
from modules.avatar      import load_avatar, save_avatar, list_presets as list_avatar_presets
from modules.capture     import FFmpegCaptureEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).resolve().parent
DATA_DIR   = BASE_DIR / "data"
ASSETS_DIR = BASE_DIR / "assets"
STATIC_DIR = BASE_DIR / "static"

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="PubCast AI", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")
templates = Jinja2Templates(directory=str(STATIC_DIR))

# ── Singletons (instantiated once at startup) ─────────────────────────────────
ensure_dirs(DATA_DIR, ASSETS_DIR)
hub:       Hub              = Hub(DATA_DIR)
cameras:   CameraManager    = create_default_cameras()
recording: RecordingService = create_recording_service(DATA_DIR / "media", cameras)
capture:   FFmpegCaptureEngine = FFmpegCaptureEngine()

# ── Helpers ───────────────────────────────────────────────────────────────────
def _uid(request: Request, response: Response) -> str:
    uid = request.cookies.get("pubcast_uid")
    if not uid:
        uid = str(uuid.uuid4())
        user_file = DATA_DIR / "users" / f"{uid}.json"
        if not user_file.exists():
            write_json(user_file, UserState(user_id=uid).dict())
        response.set_cookie("pubcast_uid", uid, max_age=60*60*24*365)
    return uid

def _cam_dict(src) -> Dict[str, Any]:
    st = cameras.status(src.source_id)
    return {
        "source_id": src.source_id, "name": src.name,
        "description": src.description, "location": src.location,
        "transport": src.transport.value, "endpoint": src.endpoint,
        "tags": src.tags, "is_private": src.is_private,
        "position": src.position, "rotation": src.rotation, "fov": src.fov,
        "video": src.video_enabled, "audio": src.audio_enabled,
        "status": {
            "online":     st.online     if st else False,
            "latency_ms": st.latency_ms if st else None,
            "frame_rate": st.frame_rate if st else None,
            "last_check": st.last_check if st else None,
            "notes":      st.notes      if st else None,
        },
    }

# ── Graceful shutdown ─────────────────────────────────────────────────────────
@app.on_event("shutdown")
async def on_shutdown():
    await capture.shutdown()

# ═════════════════════════════════════════════════════════════════════════════
#  PAGE ROUTES
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/",          response_class=HTMLResponse)
async def index(req: Request, res: Response):
    _uid(req, res); return templates.TemplateResponse("index.html",    {"request": req})

@app.get("/control",   response_class=HTMLResponse)
async def control_page(req: Request, res: Response):
    _uid(req, res); return templates.TemplateResponse("control.html",  {"request": req})

@app.get("/admin",     response_class=HTMLResponse)
async def admin_page(req: Request):
    return templates.TemplateResponse("admin.html", {"request": req})

@app.get("/dressing",  response_class=HTMLResponse)
async def dressing_page(req: Request, res: Response):
    _uid(req, res); return templates.TemplateResponse("dressing.html", {"request": req})

# ═════════════════════════════════════════════════════════════════════════════
#  USER / IDENTITY
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/me")
async def get_me(req: Request, res: Response):
    uid = _uid(req, res)
    f = DATA_DIR / "users" / f"{uid}.json"
    return JSONResponse(read_json(f) if f.exists() else {"user_id": uid, "display_name": "New User"})

@app.get("/api/state/user")
async def read_user_state(req: Request, res: Response):
    uid = _uid(req, res)
    f = DATA_DIR / "users" / f"{uid}.json"
    return read_json(f) if f.exists() else {"user_id": uid, "display_name": "New User"}

@app.post("/api/state/user")
async def save_user_state(req: Request, res: Response, payload: Dict[str, Any]):
    uid = _uid(req, res)
    user_file = DATA_DIR / "users" / f"{uid}.json"
    current = read_json(user_file) if user_file.exists() else {}
    current.update(payload or {})
    write_json(user_file, current)
    await hub.broadcast_presence_update(uid, current.get("display_name", "User"))
    return {"ok": True}

# ═════════════════════════════════════════════════════════════════════════════
#  PRODUCTION STATE
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/state/production")
async def get_production_state():
    return hub.get_production_state()

@app.post("/api/state/production")
async def set_production_state(payload: Dict[str, Any]):
    updated = hub.update_production_state(payload)
    await hub.broadcast_system_event({"type": "production_state", "payload": updated})
    return {"ok": True, "state": updated}

# ═════════════════════════════════════════════════════════════════════════════
#  FILE UPLOAD
# ═════════════════════════════════════════════════════════════════════════════
@app.post("/api/upload")
async def upload_file(req: Request, res: Response,
                      file: UploadFile = File(...), target: Optional[str] = Form(None)):
    uid = _uid(req, res)
    filename = sanitize_filename(file.filename)
    if not allowed_upload_extension(filename):
        return JSONResponse({"ok": False, "error": "Unsupported file type."}, status_code=400)
    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        return JSONResponse({"ok": False, "error": "File too large (limit 5MB)."}, status_code=400)
    dst_dir = ASSETS_DIR / "vod" if target == "vod" else ASSETS_DIR / "uploads" / uid
    dst_dir.mkdir(parents=True, exist_ok=True)
    (dst_dir / filename).write_bytes(content)
    return {"ok": True, "path": str((dst_dir / filename).relative_to(BASE_DIR)).replace("\\", "/")}

# ═════════════════════════════════════════════════════════════════════════════
#  CAMERAS
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/cameras")
async def list_cameras():
    return [_cam_dict(s) for s in cameras.list_sources()]

@app.get("/api/cameras/program")
async def get_program_camera():
    src = cameras.get_program_source()
    return _cam_dict(src) if src else JSONResponse({"error": "No program source"}, status_code=404)

@app.get("/api/cameras/preview")
async def get_preview_camera():
    src = cameras.get_preview_source()
    return _cam_dict(src) if src else JSONResponse({"error": "No preview source"}, status_code=404)

@app.post("/api/cameras/program/{source_id}")
async def set_program_camera(source_id: str):
    if not cameras.set_program_source(source_id):
        return JSONResponse({"error": f"Unknown source '{source_id}'"}, status_code=404)
    src = cameras.get_program_source()
    await hub.broadcast_system_event(
        {"type": "camera_switch", "payload": {"slot": "program", "source": _cam_dict(src)}})
    return {"ok": True, "program": _cam_dict(src)}

@app.post("/api/cameras/preview/{source_id}")
async def set_preview_camera(source_id: str):
    if not cameras.set_preview_source(source_id):
        return JSONResponse({"error": f"Unknown source '{source_id}'"}, status_code=404)
    src = cameras.get_preview_source()
    await hub.broadcast_system_event(
        {"type": "camera_switch", "payload": {"slot": "preview", "source": _cam_dict(src)}})
    return {"ok": True, "preview": _cam_dict(src)}

@app.post("/api/cameras/cut")
async def cut_cameras():
    pgm = cameras.get_program_source()
    pvw = cameras.get_preview_source()
    if pgm and pvw:
        cameras.set_program_source(pvw.source_id)
        cameras.set_preview_source(pgm.source_id)
    new_pgm = cameras.get_program_source()
    new_pvw = cameras.get_preview_source()
    ev = {"type": "camera_cut", "payload": {
        "program": _cam_dict(new_pgm) if new_pgm else None,
        "preview": _cam_dict(new_pvw) if new_pvw else None,
    }}
    await hub.broadcast_system_event(ev)
    return {"ok": True, **ev["payload"]}

@app.put("/api/cameras/{source_id}/status")
async def update_camera_status(source_id: str, body: Dict[str, Any]):
    try:
        cameras.set_status(source_id,
            online=body.get("online"), latency_ms=body.get("latency_ms"),
            frame_rate=body.get("frame_rate"), notes=body.get("notes"))
    except KeyError as e:
        return JSONResponse({"error": str(e)}, status_code=404)
    return {"ok": True, "source_id": source_id}

# ═════════════════════════════════════════════════════════════════════════════
#  RECORDING
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/recording/profiles")
async def list_recording_profiles():
    return [{"profile_id": p.profile_id, "name": p.name, "container": p.container.value,
             "video_codec": p.video_codec, "audio_codec": p.audio_codec,
             "resolution": p.resolution, "frame_rate": p.frame_rate,
             "description": p.description, "is_audio_only": p.is_audio_only}
            for p in recording.list_profiles()]

@app.get("/api/recording/sessions")
async def list_sessions():
    return [s.to_dict() for s in recording.list_sessions()]

@app.get("/api/recording/sessions/{session_id}")
async def get_session(session_id: str):
    try:    return recording.get_session(session_id).to_dict()
    except KeyError: return JSONResponse({"error": "Session not found"}, status_code=404)

@app.post("/api/recording/sessions")
async def start_recording(req: Request, res: Response, body: Dict[str, Any]):
    uid        = _uid(req, res)
    sources    = body.get("sources", [])
    profile_id = body.get("profile_id", "broadcast_mp4")
    countdown  = int(body.get("countdown_seconds", 5))
    host_ov    = bool(body.get("host_override", False))

    if not sources:
        pgm = cameras.get_program_source()
        sources = [pgm.source_id] if pgm else []
    if not sources:
        return JSONResponse({"error": "No sources available."}, status_code=400)

    try:
        session = recording.start_session(
            session_id=None, sources=sources, profile_id=profile_id,
            operator=uid, countdown_seconds=countdown, host_override=host_ov)
    except (ValueError, PermissionError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)

    # Broadcast immediately so the UI shows COUNTDOWN state
    await hub.broadcast_system_event({"type": "recording_started", "payload": session.to_dict()})

    # Launch the countdown+capture sequence as a background task
    # so the HTTP response returns right away
    asyncio.create_task(_countdown_then_capture(session.session_id, countdown))

    return session.to_dict()


async def _countdown_then_capture(session_id: str, countdown: int) -> None:
    """
    Wait for the countdown, activate the session, then spawn FFmpeg.
    Runs as an asyncio background task — never blocks the event loop.
    """
    if countdown > 0:
        # Broadcast tick events so the UI can show a countdown clock
        for remaining in range(countdown, 0, -1):
            await hub.broadcast_system_event({
                "type": "recording_countdown",
                "payload": {"session_id": session_id, "remaining": remaining}
            })
            await asyncio.sleep(1)

    # Activate session state in RecordingService
    try:
        session = recording.activate_session(session_id)
    except (KeyError, ValueError) as e:
        logger.error("Cannot activate session %s: %s", session_id, e)
        return

    # Resolve live CameraSource objects
    cam_sources = [cameras.get(sid) for sid in session.sources if cameras.get(sid)]
    if not cam_sources:
        logger.error("Session %s: no resolvable camera sources — aborting capture.", session_id)
        return

    try:
        profile  = recording.get_profile(session.profile_id)
        out_paths = await capture.start(
            session_id, cam_sources, profile,
            recording._session_dir(session_id)
        )
        # Register output paths as artifacts
        for p in out_paths:
            session.artifacts.append(RecordingArtifact(
                name=p.name,
                format=ContainerFormat(p.suffix.lstrip(".")),
                file_path=p,
                size_bytes=0,
            ))
        recording._write_metadata(session)
    except Exception as e:
        logger.error("Capture start failed for session %s: %s", session_id, e)
        return

    # Broadcast that we are truly ACTIVE now
    await hub.broadcast_system_event({
        "type": "recording_active",
        "payload": session.to_dict()
    })
    logger.info("Session %s is now recording.", session_id)

@app.post("/api/recording/sessions/{session_id}/stop")
async def stop_recording(session_id: str):
    try:    session = recording.stop_session(session_id)
    except KeyError: return JSONResponse({"error": "Session not found"}, status_code=404)

    # Stop FFmpeg and update artifact sizes
    finished_paths = await capture.stop(session_id)
    for art in session.artifacts:
        if art.file_path.exists():
            art.size_bytes = art.file_path.stat().st_size
    recording._write_metadata(session)

    await hub.broadcast_system_event({"type": "recording_stopped", "payload": session.to_dict()})
    return session.to_dict()

@app.post("/api/recording/sessions/{session_id}/pause")
async def pause_recording(session_id: str, body: Dict[str, Any]):
    paused = bool(body.get("paused", True))
    try:    session = recording.pause_session(session_id, paused)
    except (KeyError, ValueError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    if paused:
        await capture.pause(session_id)
    else:
        await capture.resume(session_id)
    ev_type = "recording_paused" if paused else "recording_resumed"
    await hub.broadcast_system_event({"type": ev_type, "payload": session.to_dict()})
    return session.to_dict()

@app.post("/api/recording/sessions/{session_id}/marker")
async def add_marker(session_id: str, req: Request, res: Response, body: Dict[str, Any]):
    uid = _uid(req, res)
    try:    marker = recording.mark_moment(session_id, body.get("label", "mark"), operator=uid)
    except KeyError: return JSONResponse({"error": "Session not found"}, status_code=404)
    return {"timestamp": marker.timestamp, "label": marker.label}

@app.post("/api/recording/sessions/{session_id}/archive")
async def archive_session(session_id: str):
    try:    session = recording.archive_session(session_id)
    except (KeyError, ValueError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return session.to_dict()

@app.get("/api/recording/sessions/{session_id}/export")
async def export_session(session_id: str, fmt: str = "mp4"):
    container = {"mp4": ContainerFormat.MP4, "webm": ContainerFormat.WEBM,
                 "mov": ContainerFormat.MOV, "wav": ContainerFormat.WAV}.get(fmt.lower(), ContainerFormat.MP4)
    try:    zip_path = recording.export_session(session_id, container=container)
    except (KeyError, ValueError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return FileResponse(str(zip_path), media_type="application/zip", filename=zip_path.name)

@app.get("/api/recording/storage")
async def recording_storage():
    return recording.storage_status()

@app.get("/api/recording/privacy")
async def recording_privacy():
    return recording.privacy_matrix()

# ═════════════════════════════════════════════════════════════════════════════
#  AVATARS
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/avatars/presets")
async def get_avatar_presets():
    return [p.dict() for p in list_avatar_presets()]

@app.get("/api/avatars/me")
async def get_my_avatar(req: Request, res: Response):
    uid = _uid(req, res)
    return load_avatar(DATA_DIR, uid).dict()

@app.post("/api/avatars/me")
async def save_my_avatar(req: Request, res: Response, body: Dict[str, Any]):
    uid = _uid(req, res)
    try:    av_state = save_avatar(DATA_DIR, uid, body)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    await hub.broadcast_system_event(
        {"type": "avatar_update", "payload": {"user_id": uid, "avatar": av_state.dict()}})
    return av_state.dict()

@app.get("/api/avatars/{user_id}")
async def get_user_avatar(user_id: str):
    return load_avatar(DATA_DIR, user_id).dict()

# ═════════════════════════════════════════════════════════════════════════════
#  HEALTH & VOD
# ═════════════════════════════════════════════════════════════════════════════
@app.get("/api/health")
async def health():
    pgm = cameras.get_program_source()
    pvw = cameras.get_preview_source()
    active = [s for s in recording.list_sessions() if s.state.value == "active"]
    return {
        "ok": True, "ts": time.time(),
        "cameras": {"total": len(cameras.list_sources()),
                    "program": pgm.source_id if pgm else None,
                    "preview": pvw.source_id if pvw else None},
        "recording": {"sessions_total": len(recording.list_sessions()),
                      "sessions_active": len(active), **recording.storage_status()},
        "hub": {"rooms_active": len([r for r, c in hub.rooms.items() if c])},
        "capture": {"ffmpeg_available": capture.available, "active_sessions": capture.active_sessions()},
    }

@app.get("/api/vod")
async def list_vod():
    vod_dir = ASSETS_DIR / "vod"
    if not vod_dir.exists(): return []
    return [{"name": f.name, "url": f"/assets/vod/{f.name}", "size": f.stat().st_size}
            for f in sorted(vod_dir.iterdir()) if f.is_file()]

# ═════════════════════════════════════════════════════════════════════════════
#  WEBSOCKET
# ═════════════════════════════════════════════════════════════════════════════
@app.websocket("/ws/{room}")
async def websocket_endpoint(ws: WebSocket, room: str):
    await hub.connect(ws, room)
    try:
        while True:
            msg = await ws.receive_text()
            await hub.handle_message(ws, room, msg)
    except WebSocketDisconnect:
        await hub.disconnect(ws, room)
    except Exception:
        if ws.application_state == WebSocketState.CONNECTED:
            await ws.close(code=1011)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
