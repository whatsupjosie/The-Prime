/**
 * PubCast AI — app.js (Phase 1 hardened)
 * Cameras, recording, avatars, production state, chat all wired.
 * onWsEvent exposed on window so control_stations.js can hook it.
 */
import { WSHub } from '/static/ws.js';
import { switchView, setupDrawer } from '/static/ui.js';

const state = { me: null, avatar: null, prod: null, room: 'dressing', ws: null,
                cameras: [], sessions: [] };

// ── Boot ─────────────────────────────────────────────────────────────────────
(async function boot() {
  setupDrawer();
  switchView('view-dressing');

  try { state.me     = await apiFetch('/api/me');                  applyMe();              } catch(e) { console.warn('identity failed', e); }
  try { state.avatar = await apiFetch('/api/avatars/me');          applyAvatarToUI(state.avatar); } catch(e) { console.warn('avatar failed', e); }
  try { state.prod   = await apiFetch('/api/state/production');    applyProductionEverywhere(); } catch(e) { console.warn('prod state failed', e); }

  await refreshCameras();

  state.ws = new WSHub(state.room, onWsEvent);
  state.ws.connect();
  // Expose so control_stations.js timer hooks can call it
  window.__pubcastWS = state.ws;

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const k = btn.dataset.room;
      state.room = k;
      switchView('view-' + k);
      state.ws.changeRoom(k);
      if (k === 'control')  onEnterControl();
      if (k === 'green')    applyProductionToGreen();
      if (k === 'studio')   applyProductionToStudio();
      if (k === 'dressing') refreshAvatarPresets();
    });
  });
})();

// ── API util ─────────────────────────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  const r = await fetch(url, { headers: {'Content-Type':'application/json',...(opts.headers||{})}, ...opts });
  if (!r.ok) { const e = await r.json().catch(() => ({error: r.statusText})); throw new Error(e.error||r.statusText); }
  return r.json();
}
function apiPost(url, body) { return apiFetch(url, {method:'POST', body:JSON.stringify(body)}); }

// ── Identity ──────────────────────────────────────────────────────────────────
function applyMe() {
  const m = state.me || {};
  setVal('displayName', m.display_name||'User'); setVal('avatarColor', m.avatar_color||'#00e0ff');
  setVal('badge', m.badge||''); setText('name-preview', m.display_name||'User');
  setBg('avatar-preview', m.avatar_color||'#00e0ff');
}

document.getElementById('wardrobe-form')?.addEventListener('submit', async e => {
  e.preventDefault();
  const display_name = getVal('displayName')||'User', avatar_color = getVal('avatarColor')||'#00e0ff', badge = getVal('badge')||'';
  try {
    await apiPost('/api/state/user', {display_name, avatar_color, badge});
    state.me = {...state.me, display_name, avatar_color, badge};
    setText('name-preview', display_name); setBg('avatar-preview', avatar_color);
    sysChat(`Profile saved as ${display_name}.`);
  } catch(e) { sysChat('Save failed: '+e.message); }
});
['displayName','avatarColor'].forEach(id => {
  document.getElementById(id)?.addEventListener('input', () => {
    if (id==='displayName') setText('name-preview', getVal(id));
    if (id==='avatarColor') setBg('avatar-preview', getVal(id));
  });
});

// ── Avatar ────────────────────────────────────────────────────────────────────
async function refreshAvatarPresets() {
  try { renderPresets(await apiFetch('/api/avatars/presets')); } catch(e) { console.warn('presets failed',e); }
}
function renderPresets(presets) {
  const c = document.getElementById('avatar-presets'); if (!c) return; c.innerHTML = '';
  presets.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'ghost preset-btn';
    btn.style.borderLeft = `4px solid ${p.base_state.primary_color}`;
    btn.innerHTML = `<strong>${p.name}</strong><br><small>${p.description}</small>`;
    btn.onclick = () => applyPreset(p);
    c.appendChild(btn);
  });
}
async function applyPreset(preset) {
  try {
    const s = await apiPost('/api/avatars/me', preset.base_state);
    state.avatar = s; applyAvatarToUI(s); sysChat(`Avatar → ${preset.name}.`);
  } catch(e) { sysChat('Preset failed: '+e.message); }
}
function applyAvatarToUI(av) {
  if (!av) return;
  setBg('avatar-preview', av.primary_color);
  setText('name-preview', av.display_name || state.me?.display_name || 'User');
  const cp = document.getElementById('avatarColor'); if (cp) cp.value = av.primary_color||'#00e0ff';
  const de = document.getElementById('avatar-detail');
  if (de) de.innerHTML = `<div style="font-size:.85em;color:#888;margin-top:6px;">Mood: <strong>${av.mood}</strong> &nbsp;|&nbsp; Voice: <strong>${av.voice_profile}</strong> &nbsp;|&nbsp; ID: <strong>${av.preset_id}</strong></div>`;
}
document.getElementById('avatar-save-btn')?.addEventListener('click', async () => {
  try {
    const s = await apiPost('/api/avatars/me', {
      primary_color: getVal('avatarColor')||'#00e0ff',
      mood:          getVal('avatar-mood') ||'neutral',
      voice_profile: getVal('avatar-voice')||'default',
    });
    state.avatar = s; applyAvatarToUI(s); sysChat('Avatar saved.');
  } catch(e) { sysChat('Avatar save failed: '+e.message); }
});

// ── Upload ────────────────────────────────────────────────────────────────────
document.getElementById('upload-form')?.addEventListener('submit', async e => {
  e.preventDefault();
  const f = document.getElementById('uploadFile')?.files[0]; if (!f) return;
  const form = new FormData(); form.append('file', f);
  const t = getVal('uploadTarget'); if (t) form.append('target', t);
  try {
    const resp = await fetch('/api/upload',{method:'POST',body:form}).then(r=>r.json());
    const out = document.getElementById('upload-result');
    if (out) out.innerText = resp.ok ? `Uploaded: ${resp.path}` : `Error: ${resp.error}`;
    if (resp.ok) sysChat(`Uploaded: ${resp.path}`);
  } catch(e) { sysChat('Upload failed: '+e.message); }
});

// ── Control room ──────────────────────────────────────────────────────────────
async function onEnterControl() {
  refreshProdJSON();
  await refreshCameras();
  await refreshSessions();
}

async function refreshCameras() {
  try { state.cameras = await apiFetch('/api/cameras'); renderCameraList(); await syncPVWPGM(); }
  catch(e) { console.warn('cameras failed',e); }
}
function renderCameraList() {
  const g = document.getElementById('cam-list'); if (!g) return; g.innerHTML = '';
  state.cameras.forEach(cam => {
    const el = document.createElement('div');
    el.className = 'cam-thumb'; el.dataset.sourceId = cam.source_id;
    el.innerHTML = `<div class="cam-video-slot" data-sid="${cam.source_id}" style="width:100%;aspect-ratio:16/9;background:#111;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#555;font-size:.75em;border:2px solid transparent;">${cam.name}</div>
      <div style="display:flex;gap:4px;margin-top:4px;">
        <button class="ghost" style="flex:1;font-size:.7em;" onclick="setCamPVW('${cam.source_id}')">PVW</button>
        <button class="ghost" style="flex:1;font-size:.7em;" onclick="setCamPGM('${cam.source_id}')">PGM</button>
      </div>
      <div style="font-size:.65em;color:#888;margin-top:2px;">${cam.transport} · ${cam.status.online?'🟢':'⚫'}</div>`;
    g.appendChild(el);
  });
}
async function syncPVWPGM() {
  try { const p = await apiFetch('/api/cameras/program'); highlightCam(p.source_id,'program'); setText('pgm-label',p.name||p.source_id); } catch(_){}
  try { const p = await apiFetch('/api/cameras/preview'); highlightCam(p.source_id,'preview'); setText('pvw-label',p.name||p.source_id); } catch(_){}
}
function highlightCam(sid, slot) {
  document.querySelectorAll('.cam-video-slot').forEach(el => {
    if (el.dataset.sid === sid) el.style.border = slot==='program' ? '2px solid #e33' : '2px solid #39f';
  });
}
window.setCamPVW = async sid => {
  try { await apiPost(`/api/cameras/preview/${sid}`,{}); highlightCam(sid,'preview'); setText('pvw-label',sid); sysChat(`PVW → ${sid}`); }
  catch(e) { sysChat('PVW failed: '+e.message); }
};
window.setCamPGM = async sid => {
  try { await apiPost(`/api/cameras/program/${sid}`,{}); highlightCam(sid,'program'); setText('pgm-label',sid); sysChat(`PGM → ${sid}`); }
  catch(e) { sysChat('PGM failed: '+e.message); }
};
document.getElementById('vm-cut')?.addEventListener('click', async () => {
  try {
    const r = await apiPost('/api/cameras/cut',{});
    if (r.program) { highlightCam(r.program.source_id,'program'); setText('pgm-label',r.program.name); }
    if (r.preview) { highlightCam(r.preview.source_id,'preview'); setText('pvw-label',r.preview.name); }
    sysChat('CUT.');
  } catch(e) { sysChat('Cut failed: '+e.message); }
});
document.getElementById('vm-take')?.addEventListener('click', async () => {
  sysChat(`FADE ${getVal('vm-mix')||400}ms`);
  try { await apiPost('/api/cameras/cut',{}); } catch(_){}
});

// Quick macros
const MACROS = {
  'qx-open':       {mode:'LIVE',   on_air:true,  lower_third:''},
  'qx-interview':  {camera:'medium_shot', lighting:'warm', lower_third:'Guest'},
  'qx-commercial': {on_air:false,  mode:'REPLAY'},
  'qx-end':        {on_air:false,  lower_third:'Thanks for watching!'},
};
Object.entries(MACROS).forEach(([id,patch]) => {
  document.getElementById(id)?.addEventListener('click', async () => {
    try { const r = await apiPost('/api/state/production',patch); state.prod=r.state; applyProductionEverywhere(); sysChat(`Macro: ${id}`); }
    catch(e) { sysChat('Macro failed: '+e.message); }
  });
});
document.getElementById('qx-bleep')?.addEventListener('click', () => {
  const ms = parseInt(getVal('qx-bleep-ms')||'800',10);
  const ctx = new (window.AudioContext||window.webkitAudioContext)();
  const osc = ctx.createOscillator(), g = ctx.createGain();
  osc.type='sine'; osc.frequency.value=1000; g.gain.value=0.5;
  osc.connect(g); g.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime+ms/1000);
  sysChat(`BLEEP ${ms}ms`);
});
document.getElementById('qx-ohshit')?.addEventListener('click', async () => {
  await apiPost('/api/state/production',{on_air:false,lower_third:''});
  sysChat('⚠ EMERGENCY: off-air.');
});
document.getElementById('control-form')?.addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const r = await apiPost('/api/state/production',{
      mode:getVal('prod-mode'), on_air:getVal('prod-onair')==='true',
      replay_asset:getVal('prod-replay')||'', lower_third:getVal('prod-lower')||'',
      camera:getVal('prod-camera'), lighting:getVal('prod-lighting'),
    });
    state.prod=r.state; applyProductionEverywhere(); sysChat('Program updated.');
  } catch(e) { sysChat('Update failed: '+e.message); }
});

// ── Recording ─────────────────────────────────────────────────────────────────
async function refreshSessions() {
  try { state.sessions = await apiFetch('/api/recording/sessions'); renderSessionList(); }
  catch(e) { console.warn('sessions failed',e); }
}
function renderSessionList() {
  const el = document.getElementById('rec-session-list'); if (!el) return;
  if (!state.sessions.length) { el.innerHTML='<div class="muted small">No sessions yet.</div>'; return; }
  el.innerHTML = state.sessions.map(s => `
    <div style="border:1px solid #333;border-radius:6px;padding:8px 10px;margin-bottom:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span class="small">${s.session_id.slice(0,12)}… <em>${s.state}</em></span>
        <span class="muted small">${s.sources.join(', ')}</span>
      </div>
      <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap;">
        ${s.state==='active'  ? `<button class="ghost" style="font-size:.72em;" onclick="recStop('${s.session_id}')">■ Stop</button><button class="ghost" style="font-size:.72em;" onclick="recPause('${s.session_id}',true)">⏸ Pause</button>` : ''}
        ${s.state==='paused'  ? `<button class="ghost" style="font-size:.72em;" onclick="recPause('${s.session_id}',false)">▶ Resume</button>` : ''}
        ${s.state==='stopped' ? `<button class="ghost" style="font-size:.72em;" onclick="recExport('${s.session_id}')">⬇ Export</button>` : ''}
        <button class="ghost" style="font-size:.72em;" onclick="recMark('${s.session_id}')">🏁 Mark</button>
      </div>
    </div>`).join('');
}
document.getElementById('rec-start-btn')?.addEventListener('click', async () => {
  try {
    const session = await apiPost('/api/recording/sessions',{
      profile_id:getVal('rec-profile')||'broadcast_mp4',
      countdown_seconds:parseInt(getVal('rec-countdown')||'5',10),
    });
    state.sessions.unshift(session); renderSessionList();
    sysChat(`Recording started: ${session.session_id.slice(0,12)}`);
    // notify stations for timer
    dispatchRecEvent('recording_started', session);
  } catch(e) { sysChat('Record start failed: '+e.message); }
});
window.recStop = async sid => {
  try { const s = await apiPost(`/api/recording/sessions/${sid}/stop`,{}); _updateSess(s); dispatchRecEvent('recording_stopped',s); sysChat('Stopped.'); }
  catch(e) { sysChat('Stop failed: '+e.message); }
};
window.recPause = async (sid, paused) => {
  try { const s = await apiPost(`/api/recording/sessions/${sid}/pause`,{paused}); _updateSess(s); dispatchRecEvent(paused?'recording_paused':'recording_resumed',s); sysChat(paused?'Paused.':'Resumed.'); }
  catch(e) { sysChat('Pause failed: '+e.message); }
};
window.recExport = sid => window.open(`/api/recording/sessions/${sid}/export?fmt=mp4`,'_blank');
window.recMark = async sid => {
  const label = prompt('Marker label:','mark')||'mark';
  try { await apiPost(`/api/recording/sessions/${sid}/marker`,{label}); sysChat(`Marked: ${label}`); }
  catch(e) { sysChat('Mark failed: '+e.message); }
};
function _updateSess(s) { const i=state.sessions.findIndex(x=>x.session_id===s.session_id); if(i>=0) state.sessions[i]=s; renderSessionList(); }

// Shared recording event dispatcher so control_stations.js timer can react
function dispatchRecEvent(type, payload) {
  const handler = window.__pubcastRecHandler;
  if (typeof handler === 'function') handler({type, payload});
}

// ── WS events ─────────────────────────────────────────────────────────────────
function onWsEvent(ev) {
  // Let control_stations hook in
  if (typeof window.__pubcastStationsHook === 'function') window.__pubcastStationsHook(ev);

  switch(ev.type) {
    case 'history': ev.payload.forEach(p => appendChat({user:p.user,text:p.text})); break;
    case 'chat': appendChat({user:ev.payload.user,text:ev.payload.text}); break;
    case 'presence': setText('presence',`${ev.payload.count} online`); break;
    case 'production_state':
      state.prod = ev.payload; applyProductionEverywhere(); break;
    case 'camera_switch':
    case 'camera_cut': {
      const d = ev.payload;
      if (d.program) { highlightCam(d.program.source_id,'program'); setText('pgm-label',d.program.name||d.program.source_id); }
      if (d.preview) { highlightCam(d.preview.source_id,'preview'); setText('pvw-label',d.preview.name||d.preview.source_id); }
      break;
    }
    case 'recording_started': case 'recording_stopped':
    case 'recording_paused':  case 'recording_resumed':
    case 'recording_active':
      _updateSess(ev.payload); dispatchRecEvent(ev.type, ev.payload);
      sysChat(`Recording: ${ev.type.replace('recording_','')}.`); break;
    case 'recording_countdown': {
      const rem = ev.payload.remaining;
      const badge = document.getElementById('rec-status-badge');
      if (badge) { badge.innerText = `${rem}…`; badge.style.background = '#a80'; }
      sysChat(`Recording in ${rem}…`);
      break;
    }
    case 'avatar_update':
      if (ev.payload.user_id === state.me?.user_id) { state.avatar=ev.payload.avatar; applyAvatarToUI(ev.payload.avatar); } break;
  }
}

// ── Production rendering ──────────────────────────────────────────────────────
function applyProductionEverywhere() {
  refreshProdJSON(); applyProductionToGreen(); applyProductionToStudio();
  const s = state.prod||{};
  setVal('prod-mode',s.mode||'LIVE'); setVal('prod-onair',String(!!s.on_air));
  setVal('prod-replay',s.replay_asset||''); setVal('prod-lower',s.lower_third||'');
  setVal('prod-camera',s.camera||'wide'); setVal('prod-lighting',s.lighting||'normal');
}
function refreshProdJSON() { const e=document.getElementById('prod-json'); if(e) e.textContent=JSON.stringify(state.prod||{},null,2); }
function applyProductionToGreen() {
  const s=state.prod||{};
  const badge=document.getElementById('program-badge'), live=document.getElementById('live-banner'),
        lower=document.getElementById('lower-third'),  video=document.getElementById('replay-video');
  if (!badge) return;
  if (s.mode==='REPLAY'&&s.replay_asset) {
    badge.innerText='REPLAY'; live?.classList.add('hidden');
    if(video){video.classList.remove('hidden'); video.src=s.replay_asset.startsWith('assets/')?'/'+s.replay_asset:'/assets/vod/'+s.replay_asset;}
  } else {
    badge.innerText='LIVE'; video?.classList.add('hidden'); live?.classList.toggle('hidden',!s.on_air);
  }
  if(lower) lower.innerText=s.lower_third||'';
}
function applyProductionToStudio() {
  const s=state.prod||{};
  document.getElementById('studio-onair')?.classList.toggle('hidden',!s.on_air);
  const lt=document.getElementById('studio-lower-third'); if(lt) lt.innerText=s.lower_third||'';
  const cm=document.getElementById('camera-mode');   if(cm) cm.innerText=s.camera||'wide';
  const lm=document.getElementById('lighting-mode'); if(lm) lm.innerText=s.lighting||'normal';
}

// ── Chat ──────────────────────────────────────────────────────────────────────
function appendChat(msg) {
  const log=document.getElementById('chat-log'); if(!log) return;
  const el=document.createElement('div');
  el.className=msg.system?'sys':''; el.innerText=msg.system?msg.text:`[${msg.user}] ${msg.text}`;
  log.appendChild(el); log.scrollTop=log.scrollHeight;
}
function sysChat(text) { appendChat({system:true,text}); }
document.getElementById('chat-form')?.addEventListener('submit', e => {
  e.preventDefault();
  const inp=document.getElementById('chat-input'), txt=inp?.value.trim(); if(!txt) return;
  state.ws.send({type:'chat',text:txt,user:state.me?.display_name||'User'});
  if(inp) inp.value='';
});

// ── DOM helpers ───────────────────────────────────────────────────────────────
function getVal(id){return document.getElementById(id)?.value;}
function setVal(id,v){const e=document.getElementById(id);if(e)e.value=v;}
function setText(id,t){const e=document.getElementById(id);if(e)e.innerText=t;}
function setBg(id,c){const e=document.getElementById(id);if(e)e.style.background=c;}
