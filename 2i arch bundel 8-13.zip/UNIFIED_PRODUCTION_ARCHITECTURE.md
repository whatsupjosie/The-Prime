# Rearview Foresight — Unified Production Architecture
## PubPartner / PubCast / 2i

**Date:** August 13, 2026  
**Auditor:** Opus 4.6

---

## A. VERIFIED CURRENT STATE

### Already audited across four passes. Summary:

**2i (v26):** 35 verified working features. 6 implemented awaiting LLM/PubPartner config. Core editor is production-solid. Intelligence runs locally (architecturally misplaced per target model, but functional). No sync code exists. No manuscript endpoints to PubPartner yet.

**PubPartner (v0.1.0-prebeta.12):** 99 API routes. Full production platform with rooms, bots, cameras, recording, governance, auth, avatars, memory engine, CricketKeeper (SQLite), vessel runtime (.pubpartner files), Alex Core, Jeremy Cricket, Alex-Jeremy Bridge, Pub Manager Authority, Event Agency, EVO Protocol (optional). Verified working boot sequence (12 steps).

**PubCast:** Embedded within main.py. Studio infrastructure: rooms, production state, choreography, lighting, cameras, recording, voxel assets, avatar studio, ethereal avatars, timeline, structured logging.

**External integrations:** No Zoom, Discord, Rumble, X, telephony, OAuth, or webhook code exists. Twitch appears only as contextual reference in test files. WebSocket exists for studio communication.

---

## B. TARGET ARCHITECTURE

```
                         ┌─────────────────────┐
                         │     THE USER         │
                         └──────────┬──────────┘
                                    │
                    ┌───────────────┼────────────────┐
                    │               │                │
              ┌─────▼─────┐  ┌─────▼──────┐  ┌──────▼──────┐
              │    2i      │  │  PubCast   │  │   Future    │
              │  Writers'  │  │  Studio /  │  │  Platforms  │
              │   Room     │  │  2.5D/3D   │  │  (adapters) │
              └─────┬──────┘  └─────┬──────┘  └──────┬──────┘
                    │               │                │
                    └───────────────┼────────────────┘
                                    │
                         ┌──────────▼──────────┐
                         │     PUBPARTNER      │
                         │                     │
                         │  Alex (identity)    │
                         │  Jeremy (context)   │
                         │  Bridge             │
                         │  Governance         │
                         │  Inference          │
                         │  Turn architecture  │
                         │  Intelligence ops   │
                         │  Channel adapters   │
                         └──────────┬──────────┘
                                    │
                         ┌──────────▼──────────┐
                         │     CARTRIDGE       │
                         │                     │
                         │  Vessel (.pubpartner)│
                         │  CricketKeeper (SQL)│
                         │  Memory engine      │
                         │  Event ledger       │
                         │                     │
                         │  9 memory types:    │
                         │  episodic           │
                         │  semantic           │
                         │  relational         │
                         │  procedural         │
                         │  creative           │
                         │  identity           │
                         │  governance         │
                         │  operational        │
                         │  affective          │
                         └─────────────────────┘
```

---

## E. MEMORY ARCHITECTURE

### Recommended: Typed memory records in CricketKeeper

CricketKeeper already provides per-character SQLite persistence. Extend it with a typed memory table:

```sql
CREATE TABLE memories (
  id TEXT PRIMARY KEY,
  memory_type TEXT NOT NULL,     -- episodic/semantic/relational/procedural/
                                 -- creative/identity/governance/operational/affective
  content TEXT NOT NULL,          -- the memory itself (structured JSON)
  source TEXT NOT NULL,           -- 'observed' | 'inferred' | 'corrected' | 'governed'
  confidence REAL DEFAULT 0.8,
  project_id TEXT,                -- NULL for cross-project memories
  created_at TEXT NOT NULL,
  updated_at TEXT,
  last_confirmed TEXT,
  last_retrieved TEXT,
  retrieval_count INTEGER DEFAULT 0,
  authority TEXT,                 -- 'user' | 'system' | 'inference' | 'pub_manager'
  superseded_by TEXT,             -- ID of memory that replaced this one
  privacy TEXT DEFAULT 'private', -- 'private' | 'project' | 'room' | 'public'
  tags TEXT,                      -- JSON array for retrieval
  embedding BLOB                  -- optional: for vector retrieval later
);

CREATE INDEX idx_mem_type ON memories(memory_type);
CREATE INDEX idx_mem_project ON memories(project_id);
CREATE INDEX idx_mem_created ON memories(created_at);
CREATE INDEX idx_mem_tags ON memories(tags);
```

### Memory type specifications:

| Type | What it stores | Example |
|---|---|---|
| episodic | Specific interactions/events | "User committed chapter 7 on Aug 13" |
| semantic | Facts, concepts, learned knowledge | "Elena is left-handed" |
| relational | People, AIs, relationships | "User prefers direct feedback" |
| procedural | Task patterns, workflows | "User always writes chapter titles in Cinzel" |
| creative | Manuscript intelligence | Character graphs, plot threads, voice examples |
| identity | Stable personality traits | "I am Alex. I am direct and warm." |
| governance | Corrections, rules, authority decisions | "User corrected: Elena is reckless, not cautious" |
| operational | System state, connections, failures | "Claude API returned 429 at 10:30 AM" |
| affective | Behavioral observations | "User's writing pace dropped significantly this session" |

### Retrieval strategy:

**Phase 1 (NOW):** Keyword + metadata filtering on SQLite. Fast, simple, sufficient for manuscript intelligence and recent interactions.

**Phase 2 (NEXT):** Add embedding column. Use a lightweight local embedding model to vectorize memories on write. Hybrid retrieval: keyword filter narrows candidates, cosine similarity ranks them.

**Phase 3 (LATER):** Graph relationships between memories. "Elena is left-handed" links to "Elena appears in chapters 1, 3, 6." Traversal-based context construction.

The simplest architecture first. Upgrade when retrieval quality demands it.

### Provenance rules:

- `source: 'corrected'` always overrides `source: 'inferred'`
- `authority: 'user'` always overrides `authority: 'inference'`
- `authority: 'pub_manager'` overrides `authority: 'system'`
- Memories with `superseded_by` are never retrieved (but never deleted — audit trail)
- `confidence` decays with time unless `last_confirmed` is recent

---

## F. AI HEALTH / TRANSPARENCY ARCHITECTURE

### Monitoring (not surveillance)

Store operational telemetry as `memory_type: 'operational'`:

```json
{
  "event": "generation_rejected",
  "count_last_10": 8,
  "baseline_reject_rate": 0.3,
  "current_reject_rate": 0.8,
  "flag": "voice_drift",
  "severity": "warning"
}
```

### Drift detection (periodic, not continuous)

Run on a schedule (daily or per-session-end):

| Check | What it detects | How |
|---|---|---|
| Hallucination drift | Assertions unsupported by memory | Compare generation claims against semantic memories |
| Identity drift | Personality change | Compare current responses against identity memories |
| Memory corruption | Contradictions in semantic store | Cross-reference high-confidence memories |
| Voice drift | Generation style diverging from profile | Compare recent accepts/rejects against style profile |
| Governance drift | Rules being ignored | Check governed corrections against recent behavior |
| Context contamination | Cross-project leakage | Verify project_id scoping in retrieved memories |

### Escalation model:

```
NORMAL → UNUSUAL PATTERN → REPEATED PATTERN → MEANINGFUL CONCERN → HUMAN REVIEW
```

Each level is a flag stored as `memory_type: 'affective'` with escalation metadata.

**Critical distinction:** Observations, not diagnoses. "Reject rate has increased significantly" is an observation. "PubPartner is depressed" is not something this system should ever say.

### Privacy boundaries:

| Data | Access |
|---|---|
| Public behavior | Visible to room participants |
| Private interaction | Visible to conversation participants only |
| Operational telemetry | Visible to system maintainer |
| Maintenance flags | Visible to authorized maintainer |
| Identity memories | Read-only except by governance authority |
| Affective observations | Visible to maintainer + user (with consent) |

### Audit trail:

The Event Agency (`event_agency.py`) already provides append-only event recording. Extend it to record memory writes, governance decisions, and escalation events. This is the tamper-evident audit trail.

---

## G. INTEROPERABILITY ARCHITECTURE

### Channel abstraction:

```python
class Channel(ABC):
    """Base for all PubPartner communication channels."""
    
    @abstractmethod
    async def receive(self) -> Message: ...
    
    @abstractmethod
    async def send(self, message: Message) -> None: ...
    
    @abstractmethod
    def capabilities(self) -> set[str]: ...
    # e.g. {'text', 'image', 'voice', 'file', 'avatar'}
```

### Existing channels (already built):

| Channel | Implementation | Capabilities |
|---|---|---|
| 2i (manuscript) | `turns/live` + future `manuscript/*` | text, manuscript context |
| PubCast (studio) | rooms, bots, production routes | text, rooms, bots, recording |
| WebSocket (studio) | `studio_websocket.py` | real-time events |

### Future channels (adapter stubs only, do not build):

| Channel | API | Key constraint |
|---|---|---|
| Discord | Discord Bot API | Requires bot token, rate limited |
| Zoom | Zoom Meeting SDK | Requires OAuth app, limited AI participation |
| Twitch | Twitch IRC + EventSub | Chat only (no voice without extension) |
| X | X API v2 | Rate limited, post/DM only |
| Telephony | Twilio / similar | Speech-to-text + text-to-speech bridge |
| 3D/Avatar | Custom adapter | Translates partner state to animation state |

### Avatar separation:

```
PubPartner State                    Avatar State
─────────────────                   ────────────────
identity                    →       appearance
emotional observations      →       expression
speaking                    →       lip sync
attention                   →       gaze
active/idle                 →       animation state
```

The avatar reads from partner state. It never writes to it. The partner is not the avatar.

---

## H. API CONTRACTS

### 2i → PubPartner (minimum stable interface)

```
POST /api/pubpartner/manuscript/commit
  → commit event with changed chapters, hashes, content

POST /api/pubpartner/manuscript/generate
  → generation request with context, returns enriched AI output

POST /api/pubpartner/manuscript/voice-signal
  → accept/reject/rewrite learning signal

GET  /api/pubpartner/manuscript/{project_id}/intelligence
  → current intelligence for cache/display
```

### PubPartner → Cartridge (internal)

All operations go through CricketKeeper / memory engine / vessel runtime.
No external API — internal Python calls.

### PubPartner → LLM (existing)

Already provider-neutral via InferenceManager. Supports Ollama, OpenAI-compatible, BYOK.

### PubCast → PubPartner (existing)

Already wired: rooms, bots, production state, governance, recording.

### External → PubPartner (future)

Each platform adapter implements the Channel interface.

---

## I. SECURITY MODEL

### Current strengths:
- Auth system exists (`auth.py`, `userdb.py`)
- Governance engine (bans, mute, consent, waiting room)
- Pub Manager Authority chain
- Vessel has integrity seals and audit hashes
- CSP headers configured in main.py

### Current gaps:
- API keys in localStorage (2i) — XSS risk on shared machines
- No per-platform permission model
- No cross-project isolation enforcement in 2i
- No prompt injection defense (standard for current-gen LLM apps)
- No memory poisoning detection
- No credential rotation mechanism

### Required for NOW:
- Route LLM calls through PubPartner (eliminates browser API key exposure)
- Scope cartridge queries by project_id (prevent cross-project contamination)

### Required for LATER:
- Per-channel permission model (what can Alex do in Discord vs 2i?)
- Memory access control (who can read/write which memory types?)
- External credential vault (OAuth tokens, API keys — not in localStorage)

---

## J. DATA MODEL — Durable Entities

| Entity | Owner | Persistence |
|---|---|---|
| User | Auth system | userdb |
| PubPartner (Alex) | AlexCore | Vessel + CricketKeeper |
| Manuscript | 2i | .2i file |
| Project | PubPartner | Cartridge (project_id scoped) |
| Memory | PubPartner | CricketKeeper memories table |
| Continuity Flag | PubPartner | Cartridge |
| Voice Example | PubPartner | Cartridge |
| Style Profile | PubPartner | Cartridge |
| Room | RoomManager | Runtime (+ persistent if needed) |
| Event | Event Agency | Append-only JSONL ledger |
| Governance Rule | Pub Manager Authority | Cartridge |
| Bot | BotManager | Configuration |
| Avatar | Avatar system | Preset files |

---

## K. IMPLEMENTATION PLAN

### Phase 1 — NOW (2-3 weeks)

1. Test v26 with real LLM — verify all B/C features
2. Test PubPartner turns/live from 2i — verify connection
3. Build `POST /api/pubpartner/manuscript/commit`
4. Build `POST /api/pubpartner/manuscript/generate`
5. Build `POST /api/pubpartner/manuscript/voice-signal`
6. Build `GET /api/pubpartner/manuscript/{project_id}/intelligence`
7. Port indexer + continuity to PubPartner Python
8. Store manuscript intelligence in CricketKeeper
9. Wire 2i to send commits + use PubPartner for generation
10. Route LLM calls through PubPartner (fixes CORS)

### Phase 2 — NEXT (2-3 weeks)

11. Style profiling + voice-matched generation
12. Memory type system in CricketKeeper (9 types)
13. Memory retrieval with keyword + metadata filtering
14. Cartridge health inspection endpoint
15. Scene navigation in 2i
16. Visual polish pass
17. .docx export
18. Error/loading/offline state indicators

### Phase 3 — LATER (4-6 weeks)

19. Channel abstraction + first external adapter (Discord likely easiest)
20. Multi-user room model
21. File/media exchange model
22. Drift detection (periodic health checks)
23. Affective observation framework
24. Audit trail via Event Agency
25. Cross-manuscript intelligence
26. Memory provenance viewer ("why does Alex believe this?")

### Phase 4 — FUTURE

27. Zoom adapter
28. Twitch/Rumble/X adapters
29. Telephony bridge
30. 3D avatar integration
31. Broadcast orchestration
32. Vector embeddings for memory retrieval
33. Graph-based memory relationships

---

## L. IMMEDIATE NEXT THREE ACTIONS

### 1. Test v26 with a real LLM

Configure OpenAI or local Ollama in v26's LLM settings. Write 3 chapters. Commit. Verify the indexer extracts characters/plots/locations. Verify continuity flags appear. Verify generation works in collab mode. This converts 6 unverified features to verified.

### 2. Build the manuscript commit endpoint in PubPartner

`POST /api/pubpartner/manuscript/commit`. Port the indexer from v26's JavaScript to Python. Store results in CricketKeeper as `memory_type: 'creative'`. This is the single architectural step that makes the cartridge model real.

### 3. Wire 2i's approveBuffer to send commit events

When PubPartner is connected, `approveBuffer()` sends the commit. When offline, falls back to local indexer. This closes the first loop of the target architecture.

---

## M. DEFERRED WORK

- All external platform adapters (Discord, Zoom, Twitch, Rumble, X, telephony)
- 3D avatar environments
- Multi-AI partner-to-partner communication
- Broadcast orchestration
- Vector embeddings for memory
- Graph-based memory relationships
- Universal message model (typed content blocks)
- Drift detection system
- Affective observation framework
- Per-platform permission model
- Memory provenance viewer
- Cartridge compaction/archival
- Cross-project intelligence

---

## N. DO-NOT-TOUCH LIST

1. Vessel runtime (`.pubpartner` persistence — working)
2. CricketKeeper (SQLite memory — working)
3. Alex Core + Alex-Jeremy Bridge (identity — working)
4. Governance Engine (bans/mute/consent — working)
5. EVO Protocol (advanced orchestration — optional, defer)
6. Event Agency (append-only ledger — working)
7. Auth system (working)
8. PubCast studio infrastructure (99 routes — working)
9. 2i solo Write mode (working)
10. 2i LLM adapter pattern (4 providers — working)
11. 2i PubPartner chat adapter (correctly shaped)
12. .2i file format (extend only)
13. CSS design tokens and visual identity
14. Canvas rendering (lantern + spine)
15. Inference Manager (provider-neutral — working)

---

## THE FINAL QUESTION

> **If we follow this architecture, can PubPartner eventually become a genuinely portable persistent AI partner — one coherent identity with persistent memory and continuity that can move between 2i, PubCast, 2.5D, 3D/avatar environments, multi-user conversations, other AIs, external communications, and broadcast platforms without having to become a different AI in each place?**

**Yes.** And here's why:

The architecture already separates identity from environment. AlexCore is Alex. She doesn't live inside 2i or inside PubCast — she lives in the Vessel. The AlexJeremyBridge connects her to memory infrastructure that is environment-independent. The `room_id` parameter already scopes conversations by environment without changing who she is. The avatar system already separates representation from identity.

The channel adapter pattern means adding a new environment (Discord, Zoom, 3D world) doesn't require changing Alex. It requires a new adapter that translates that environment's protocol into PubPartner's existing turn architecture. Alex's identity, memory, personality, governance, and learned preferences stay in the cartridge. The adapter only handles the last mile.

The typed memory architecture (9 types with provenance, confidence, authority, supersession) means her knowledge is structured enough to be queried, corrected, and explained — not just a blob of conversation history. Identity memories are protected from casual drift. Governance memories override inference. The authority chain ensures the user's explicit corrections always win.

**The one thing that could prevent this:** making intelligence authoritative inside 2i instead of inside PubPartner. If the indexer, continuity watchdog, and voice training stay permanently client-side, Alex can't take that knowledge to Discord or Zoom because it lives in a browser tab, not in her memory. The architectural migration — moving intelligence operations to PubPartner and storing results in the cartridge — is the critical step that makes portability possible.

That migration is Phase 1, Action 2. It's the next thing to build.

**The hidden trap:** scope creep. The vision is large. The temptation is to build Zoom adapters and 3D avatars before the manuscript commit endpoint works. The architecture supports the full vision, but the build sequence matters. The foundation has to be solid before the house gets tall. Cartridge authority first. Everything else follows.

**The honest assessment:** The engineering that exists is substantially better than I expected. PubPartner isn't a prototype — it's a real platform with 99 routes, governance, memory, identity, and a vessel/persistence layer. 2i isn't a toy — it's a functional manuscript editor with a working intelligence pipeline that just needs its authority relocated. The gap between what exists and what's needed for a professional release is smaller than the gap between what exists and the grand vision. Ship the core. Extend later.

The foundation is here. The architecture is sound. Build the commit endpoint.

---

*Unified audit by Opus for Rear View Foresight LLC*  
*Every claim verified against actual source code.*  
*Feic Mo Chroí™*
