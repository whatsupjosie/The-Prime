"""
Tray Requirements — content-driven tray sizing.
© 2024-2026 Rear View Foresight LLC — "Feic Mo Chroí"

A tray's silhouette must be dictated by what goes inside it. Generating a
pretty shape and hoping the module fits is how you end up trying to put a
tiger in a fishbowl.

The contract runs content -> shape, never shape -> content:

    1. Each module type declares what it needs: a minimum usable content box,
       and whether that box must be one solid uninterrupted block (a text
       editor) or may be broken up (an icon cluster).
    2. `largest_inscribed_rect()` measures what a candidate silhouette can
       actually hold — its bounding box is NOT the usable area, because
       chamfers and rounded corners eat into it.
    3. `fit_tray()` grows the silhouette (and rejects families that waste too
       much area) until the measured usable box satisfies the requirement.
    4. If no compliant shape can hold the module, it raises rather than
       shipping a tray the content overflows.

This module owns fit. polygon_shape_library owns the design rules.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from polygonal_tray_engine import Point2D
from polygon_shape_library import (
    ALLOWED_FAMILIES,
    Silhouette,
    generate,
)


class TrayFitError(ValueError):
    """Raised when no compliant silhouette can hold the module's content."""


# ── Requirements ────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TrayRequirement:
    """
    What a module needs from whatever tray it is placed in.

    Deliberately says nothing about shape. A module declares the *space* it
    needs — never the silhouette it wants. Any family that can genuinely
    provide that space is a valid answer, which is what keeps visual variety
    alive instead of pinning each module to a shape someone chose once.
    """
    module: str
    min_content_w: float          # px, the usable block the module cannot go below
    min_content_h: float
    solid_block: bool = True      # True = needs one uninterrupted rectangle
    preferred_aspect: Optional[float] = None   # w/h the module reads best at
    label: str = ""

    def area(self) -> float:
        return self.min_content_w * self.min_content_h


# Registry. Numbers are the honest minimums for each module to be usable —
# a manuscript needs real line length; a quick-action cluster does not.
# Nothing here names a polygon: space is the contract, shape is the outcome.
MODULE_REQUIREMENTS: Dict[str, TrayRequirement] = {
    "manuscript_editor": TrayRequirement(
        "manuscript_editor", 520, 340, True, 1.55, "Live manuscript"),
    "live_preview": TrayRequirement(
        "live_preview", 460, 300, True, 1.60, "Live preview"),
    "conversation": TrayRequirement(
        "conversation", 260, 380, True, 0.68, "Conversation"),
    "file_browser": TrayRequirement(
        "file_browser", 420, 190, False, 2.20, "Project files"),
    "work_output": TrayRequirement(
        "work_output", 400, 240, True, 1.70, "Work output"),
    "status_panel": TrayRequirement(
        "status_panel", 240, 170, False, 1.40, "System status"),
    "memory_cluster": TrayRequirement(
        "memory_cluster", 230, 220, False, 1.05, "Memory / wardrobe"),
    "tool_cluster": TrayRequirement(
        "tool_cluster", 175, 210, False, 0.85, "Tools"),
    "quick_actions": TrayRequirement(
        "quick_actions", 165, 150, False, 1.10, "Quick actions"),
}


# ── Usable-area measurement ─────────────────────────────────────────────────

def _point_in_polygon(x: float, y: float, vs: Sequence[Point2D]) -> bool:
    """Ray casting; handles the non-convex silhouettes the sweep can produce."""
    inside = False
    n = len(vs)
    for i in range(n):
        a, b = vs[i], vs[(i + 1) % n]
        if (a.y > y) != (b.y > y):
            t = (y - a.y) / ((b.y - a.y) or 1e-12)
            if x < a.x + t * (b.x - a.x):
                inside = not inside
    return inside


def _rect_inside(x0: float, y0: float, x1: float, y1: float,
                 vs: Sequence[Point2D], edge_samples: int = 4) -> bool:
    """
    A rectangle is inside if its corners and sampled edge points are inside.
    Sampling the edges (not just corners) is what catches a concave notch
    biting into the middle of a side.
    """
    pts: List[Tuple[float, float]] = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    for k in range(1, edge_samples):
        t = k / edge_samples
        pts.append((x0 + (x1 - x0) * t, y0))
        pts.append((x0 + (x1 - x0) * t, y1))
        pts.append((x0, y0 + (y1 - y0) * t))
        pts.append((x1, y0 + (y1 - y0) * t))
    return all(_point_in_polygon(px, py, vs) for px, py in pts)


def largest_inscribed_rect(
    vs: Sequence[Point2D],
    aspect: Optional[float] = None,
    grid: int = 18,
) -> Dict[str, float]:
    """
    Largest axis-aligned rectangle that fits inside the polygon.

    This — not the bounding box — is a tray's real capacity. If `aspect`
    (w/h) is given, only rectangles at that ratio are considered, which is
    what you want when the module has a natural reading shape.

    Grid search: coarse but deterministic and dependency-free. `grid` trades
    accuracy for speed; 26 lands within a few percent of optimal on these
    silhouettes.
    """
    # With no required aspect, sweep a range of ratios and keep the best —
    # searching a single ratio would only ever find squares, which badly
    # under-reports what a wide shape can actually hold.
    if aspect is None:
        best_any = {"x": 0.0, "y": 0.0, "width": 0.0, "height": 0.0, "area": 0.0}
        for trial in (0.7, 1.0, 1.5, 2.3):
            r = largest_inscribed_rect(vs, trial, grid)
            if r["area"] > best_any["area"]:
                best_any = r
        return best_any

    xs = [v.x for v in vs]
    ys = [v.y for v in vs]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    best = {"x": 0.0, "y": 0.0, "width": 0.0, "height": 0.0, "area": 0.0}

    for i in range(grid):
        cx = minx + (maxx - minx) * (i + 0.5) / grid
        for j in range(grid):
            cy = miny + (maxy - miny) * (j + 0.5) / grid
            if not _point_in_polygon(cx, cy, vs):
                continue
            # Expand a rectangle around this centre by binary search on scale.
            lo, hi = 0.0, max(maxx - minx, maxy - miny)
            for _ in range(14):
                mid = (lo + hi) / 2
                if aspect:
                    hw, hh = mid * aspect / 2, mid / 2
                else:
                    hw = hh = mid / 2
                if _rect_inside(cx - hw, cy - hh, cx + hw, cy + hh, vs):
                    lo = mid
                else:
                    hi = mid
            if aspect:
                w, h = lo * aspect, lo
            else:
                w = h = lo
            if w * h > best["area"]:
                best = {"x": cx - w / 2, "y": cy - h / 2,
                        "width": w, "height": h, "area": w * h}
    return best


def rect_fit_position(vs: Sequence[Point2D], w: float, h: float,
                      grid: int = 16) -> Optional[Dict[str, float]]:
    """
    Where a w x h rectangle fits inside the polygon, or None.

    Returns the placement so callers can report the *exact* content box they
    verified, rather than re-deriving it with `largest_inscribed_rect` — whose
    grid search under-reports (it found 459x287 for a silhouette that provably
    holds 460x300, because it only samples rectangles centred on grid points).
    """
    xs = [v.x for v in vs]
    ys = [v.y for v in vs]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    if w > (maxx - minx) or h > (maxy - miny):
        return None

    span_x, span_y = (maxx - minx) - w, (maxy - miny) - h
    # Search from the centre outwards — a centred block reads better than one
    # jammed into whichever corner the sweep happened to try first.
    order = sorted(range(grid + 1), key=lambda k: abs(k - grid / 2))
    for i in order:
        x0 = minx + span_x * i / grid
        for j in order:
            y0 = miny + span_y * j / grid
            if _rect_inside(x0, y0, x0 + w, y0 + h, vs):
                return {"x": x0, "y": y0, "width": w, "height": h, "area": w * h}
    return None


def rect_fits(vs: Sequence[Point2D], w: float, h: float, grid: int = 16) -> bool:
    """
    Does a w x h axis-aligned rectangle fit anywhere inside the polygon?

    This is the question fitting actually asks, and it is far cheaper than
    computing the largest inscribed rectangle: it can stop at the first
    position that works instead of maximising over every candidate. Used for
    the search; `largest_inscribed_rect` is reserved for reporting the winner.
    """
    xs = [v.x for v in vs]
    ys = [v.y for v in vs]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    if w > (maxx - minx) or h > (maxy - miny):
        return False

    # Sweep the rectangle's top-left corner over the free span.
    span_x, span_y = (maxx - minx) - w, (maxy - miny) - h
    for i in range(grid + 1):
        x0 = minx + span_x * i / grid
        for j in range(grid + 1):
            y0 = miny + span_y * j / grid
            if _rect_inside(x0, y0, x0 + w, y0 + h, vs):
                return True
    return False


def usable_efficiency(sil: Silhouette, aspect: Optional[float] = None) -> float:
    """Fraction of the bounding box the module can actually use."""
    r = largest_inscribed_rect(sil.vertices, aspect)
    bbox = sil.width * sil.height
    return (r["area"] / bbox) if bbox else 0.0


# ── Fitting ─────────────────────────────────────────────────────────────────

@dataclass
class FittedTray:
    module: str
    requirement: TrayRequirement
    silhouette: Silhouette
    content_box: Dict[str, float]
    scale: float
    efficiency: float

    def summary(self) -> str:
        r = self.content_box
        return (f"{self.module:18s} {self.silhouette.family:9s} "
                f"box={self.silhouette.width:.0f}x{self.silhouette.height:.0f} "
                f"usable={r['width']:.0f}x{r['height']:.0f} "
                f"(need {self.requirement.min_content_w:.0f}x{self.requirement.min_content_h:.0f}) "
                f"eff={self.efficiency*100:.0f}%")


# Never grow a tray past this multiple of the module's minimum content box —
# beyond it the shape is eating the counter to satisfy one module.
MAX_GROWTH = 3.2
GROWTH_STEP = 1.10

# How much larger than the tightest-fitting shape a candidate may be and still
# stay in the running. Above this it is wasting counter space to satisfy one
# module, so it is dropped even though it technically "fits".
#
# Tuned against measured cost: for a large solid-block module a circle fits at
# ~1.1x, a trapezoid ~1.5x, and pentagon/hexagon/heptagon ~1.95x. A tolerance
# below ~1.8 therefore admits only the near-circular shapes and quietly
# collapses the whole counter onto one silhouette. 1.85 keeps the expressive
# families in play while still excluding the genuinely wasteful ones (a
# rhombus needing 2.6x to hold a manuscript).
WASTE_TOLERANCE = 1.85


def fit_tray(
    module: str,
    seed: Optional[str] = None,
    family: Optional[str] = None,
    corner_style: str = "mixed",
) -> FittedTray:
    """
    Find a silhouette whose *usable* rectangle satisfies the module's space
    requirement, growing it until it does.

    The module never names a shape. Every allowed family is a candidate; the
    ones that cannot hold the content at a sane size simply fail to qualify.
    Family order is seeded per-module, so two trays needing similar space
    still land on different shapes instead of all converging on whichever
    family happens to be most efficient.

    `family` is an optional override for callers who want to pin one
    deliberately (tests, or a user choosing a shape by hand).

    Raises TrayFitError if nothing can hold it — a loud failure beats a tray
    the content overflows.
    """
    if module not in MODULE_REQUIREMENTS:
        raise TrayFitError(f"no requirement registered for module '{module}'")
    req = MODULE_REQUIREMENTS[module]

    if family is not None and family not in ALLOWED_FAMILIES:
        raise TrayFitError(f"'{family}' is not an allowed family")

    # Every allowed family is a candidate. Seeded shuffle keeps variety.
    if family:
        candidates = [family]
    else:
        candidates = list(ALLOWED_FAMILIES)
        random.Random(f"order:{seed or module}").shuffle(candidates)

    aspect = req.preferred_aspect if req.solid_block else None
    base_w, base_h = req.min_content_w, req.min_content_h

    # Qualify every candidate, then choose — rather than taking the first that
    # happens to fit. Returning the first lets a wasteful family "succeed" by
    # inflating until its usable rectangle is big enough, which produces a
    # tray several times larger than the content needs.
    qualified: List[FittedTray] = []
    failures: List[str] = []
    for fam in candidates:
        scale = 1.0
        while scale <= MAX_GROWTH:
            w, h = base_w * scale, base_h * scale
            try:
                sil = generate(fam, w, h, seed=f"{seed or module}:{fam}",
                               corner_style=corner_style)
            except Exception as exc:                      # family can't generate here
                failures.append(f"{fam}: {exc}")
                break
            # Cheap decision during the search: can this silhouette hold the
            # required block at all? Computing the *largest* rectangle here
            # instead made fitting hundreds of times slower for no benefit —
            # the winner gets measured precisely below.
            if rect_fits(sil.vertices, req.min_content_w, req.min_content_h):
                qualified.append(FittedTray(
                    module=module, requirement=req, silhouette=sil,
                    content_box={}, scale=scale, efficiency=0.0,
                ))
                break
            scale *= GROWTH_STEP
        else:
            failures.append(f"{fam}: needed >{MAX_GROWTH:.1f}x growth")

    if not qualified:
        raise TrayFitError(
            f"cannot fit '{module}' (needs {req.min_content_w:.0f}x"
            f"{req.min_content_h:.0f} of usable space) in any allowed shape — "
            + "; ".join(failures[:4])
        )

    # Report the exact block we verified fits, not a re-approximation.
    for q in qualified:
        placed = rect_fit_position(q.silhouette.vertices,
                                   req.min_content_w, req.min_content_h)
        q.content_box = placed or {"x": 0.0, "y": 0.0,
                                   "width": req.min_content_w,
                                   "height": req.min_content_h,
                                   "area": req.area()}
        q.efficiency = q.content_box["area"] / (
            q.silhouette.width * q.silhouette.height)

    # Keep every shape that is close to the tightest fit, then pick among them
    # by seed. Variety survives; gross waste does not.
    tightest = min(q.scale for q in qualified)
    shortlist = [q for q in qualified if q.scale <= tightest * WASTE_TOLERANCE]
    shortlist.sort(key=lambda q: q.silhouette.family)     # deterministic order
    return random.Random(f"pick:{seed or module}").choice(shortlist)


def fit_all(corner_style: str = "mixed") -> Dict[str, FittedTray]:
    return {m: fit_tray(m, corner_style=corner_style) for m in MODULE_REQUIREMENTS}


if __name__ == "__main__":
    for _, t in fit_all().items():
        print(t.summary())
