"""
Compliance tests for the Tray Design Rules.

These assert the *rules*, not the implementation: banned silhouettes must be
rejected, and every generated tray must satisfy every stated constraint.
"""

import math
import unittest

from polygonal_tray_engine import Point2D
from polygon_shape_library import (
    ALLOWED_FAMILIES,
    FEATHER_RADIUS_RANGE,
    TRAY_FAMILIES,
    TRIANGLE_MIN_BASE_RATIO,
    ShapeRuleViolation,
    _interior_angles_deg,
    _side_lengths,
    build_tray_silhouettes,
    generate,
    is_valid,
    validate,
)


def P(pairs):
    return [Point2D(float(x), float(y)) for x, y in pairs]


class BannedShapes(unittest.TestCase):
    """Squares, rectangles and regular polygons must be refused."""

    def test_square_rejected(self):
        square = P([(0, 0), (100, 0), (100, 100), (0, 100)])
        with self.assertRaises(ShapeRuleViolation):
            validate(square, "trapezoid")

    def test_rectangle_rejected(self):
        rect = P([(0, 0), (360, 0), (360, 280), (0, 280)])
        with self.assertRaises(ShapeRuleViolation):
            validate(rect, "trapezoid")

    def test_near_square_rejected(self):
        near = P([(0, 0), (100, 1), (101, 100), (1, 99)])
        with self.assertRaises(ShapeRuleViolation):
            validate(near, "rhombus")

    def test_equilateral_pentagon_rejected(self):
        vs = [Point2D(100 + 80 * math.cos(i * math.tau / 5),
                      100 + 80 * math.sin(i * math.tau / 5)) for i in range(5)]
        with self.assertRaises(ShapeRuleViolation):
            validate(vs, "pentagon")

    def test_regular_hexagon_rejected(self):
        vs = [Point2D(100 + 80 * math.cos(i * math.tau / 6),
                      100 + 80 * math.sin(i * math.tau / 6)) for i in range(6)]
        with self.assertRaises(ShapeRuleViolation):
            validate(vs, "hexagon")

    def test_pointed_triangle_rejected(self):
        # Tall and narrow — a spike, not a usable tray.
        spike = P([(50, 0), (100, 300), (0, 300)])
        with self.assertRaises(ShapeRuleViolation):
            validate(spike, "triangle")

    def test_unknown_family_rejected(self):
        with self.assertRaises(ShapeRuleViolation):
            validate(P([(0, 0), (10, 0), (5, 9)]), "octagon")


class AllowedShapes(unittest.TestCase):
    def test_irregular_trapezoid_accepted(self):
        # One pair of parallel sides (top/bottom), and all four side lengths
        # clearly distinct: 140, 291, 360, 313.
        t = P([(140, 0), (280, 0), (360, 280), (0, 280)])
        self.assertTrue(is_valid(t, "trapezoid"), "irregular trapezoid should pass")

    def test_trapezoid_with_matching_legs_rejected(self):
        # Symmetric legs read as regular — the irregularity rule must catch it.
        sym = P([(100, 0), (260, 0), (360, 280), (0, 280)])
        self.assertFalse(is_valid(sym, "trapezoid"),
                         "symmetric trapezoid legs should be rejected as too regular")

    def test_circle_always_accepted(self):
        validate(P([(0, 0), (10, 0), (10, 10), (0, 10)]), "circle")  # no raise


class GeneratedTraysComply(unittest.TestCase):
    """Every generated silhouette must satisfy every rule."""

    def setUp(self):
        self.trays = build_tray_silhouettes({k: (360.0, 280.0) for k in TRAY_FAMILIES})

    def test_all_families_allowed(self):
        for tid, s in self.trays.items():
            self.assertIn(s.family, ALLOWED_FAMILIES, f"{tid} uses banned family")

    def test_all_generated_shapes_validate(self):
        for tid, s in self.trays.items():
            try:
                validate(s.vertices, s.family)
            except ShapeRuleViolation as e:
                self.fail(f"{tid} ({s.family}) violates the rules: {e}")

    def test_no_matching_side_lengths(self):
        for tid, s in self.trays.items():
            if s.family == "circle":
                continue
            sides = _side_lengths(s.vertices)
            for i in range(len(sides)):
                for j in range(i + 1, len(sides)):
                    ref = max(sides[i], sides[j])
                    self.assertGreaterEqual(
                        abs(sides[i] - sides[j]) / ref, 0.06,
                        f"{tid}: sides {i}/{j} match — not irregular")

    def test_angles_not_all_uniform(self):
        for tid, s in self.trays.items():
            if s.family == "circle":
                continue
            a = _interior_angles_deg(s.vertices)
            self.assertGreater(max(a) - min(a), 4.0, f"{tid}: all angles uniform")

    def test_feather_within_spec(self):
        lo, hi = FEATHER_RADIUS_RANGE
        for tid, s in self.trays.items():
            self.assertGreaterEqual(s.feather, lo, f"{tid} feather below spec")
            self.assertLessEqual(s.feather, hi, f"{tid} feather above spec")

    def test_triangle_is_wide_based_with_bulbous_peak(self):
        s = generate("triangle", 360, 280, seed="tri-test")
        xs = [v.x for v in s.vertices]
        ys = [v.y for v in s.vertices]
        self.assertGreaterEqual((max(xs) - min(xs)) / (max(ys) - min(ys)),
                                TRIANGLE_MIN_BASE_RATIO, "triangle too pointed")
        peak = min(range(len(s.vertices)), key=lambda i: s.vertices[i].y)
        self.assertGreater(s.corner_radii[peak], 0, "triangle peak must be rounded/bulbous")

    def test_svg_path_is_closed(self):
        for tid, s in self.trays.items():
            p = s.to_svg_path()
            self.assertTrue(p.startswith("M"), f"{tid} path must start with M")
            self.assertTrue(p.rstrip().endswith("Z"), f"{tid} path must close")

    def test_content_inset_is_usable(self):
        for tid, s in self.trays.items():
            box = s.inner_inset(16.0)
            self.assertGreater(box["width"], 0, f"{tid} has no usable content width")
            self.assertGreater(box["height"], 0, f"{tid} has no usable content height")


class VariationAndContract(unittest.TestCase):
    """Form varies. Function stays."""

    def test_same_type_trays_differ_visually(self):
        # chat and memory are both hexagons — same contract, different silhouette.
        a = generate("hexagon", 360, 280, seed="chat")
        b = generate("hexagon", 360, 280, seed="memory")
        self.assertEqual(a.family, b.family, "functional family must be stable")
        self.assertNotEqual(a.to_points(), b.to_points(),
                            "same-type trays should not be identical")

    def test_seed_is_stable_across_runs(self):
        a = generate("pentagon", 360, 280, seed="status")
        b = generate("pentagon", 360, 280, seed="status")
        self.assertEqual(a.to_points(), b.to_points(),
                         "a tray must keep its shape across reloads")

    def test_functional_family_pinned_per_tray(self):
        first = build_tray_silhouettes({k: (360.0, 280.0) for k in TRAY_FAMILIES})
        again = build_tray_silhouettes({k: (400.0, 300.0) for k in TRAY_FAMILIES})
        for tid in TRAY_FAMILIES:
            self.assertEqual(first[tid].family, again[tid].family,
                             f"{tid} changed family when resized — contract broken")

    def test_mixed_corners_possible(self):
        # Across many seeds, mixed style must produce both sharp and rounded.
        seen_sharp = seen_round = False
        for i in range(40):
            s = generate("pentagon", 360, 280, seed=f"s{i}", corner_style="mixed")
            seen_sharp |= any(r == 0 for r in s.corner_radii)
            seen_round |= any(r > 0 for r in s.corner_radii)
        self.assertTrue(seen_sharp and seen_round, "mixed must yield sharp and rounded vertices")

    def test_sharp_and_rounded_styles_are_pure(self):
        sharp = generate("pentagon", 360, 280, seed="x", corner_style="sharp")
        self.assertTrue(all(r == 0 for r in sharp.corner_radii))
        rounded = generate("pentagon", 360, 280, seed="x", corner_style="rounded")
        self.assertTrue(all(r > 0 for r in rounded.corner_radii))


if __name__ == "__main__":
    unittest.main(verbosity=2)
