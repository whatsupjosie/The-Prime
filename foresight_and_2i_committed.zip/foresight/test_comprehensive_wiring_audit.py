import unittest
import json
from fastapi.testclient import TestClient
from editor_server import app as editor_app
from control_room_server import app as control_app
from editor_core.engine import PubCastEditorEngine
from editor_core.plothole import PlotHoleChecker
from editor_core.annotations import AnnotationKind, Severity
from polygonal_tray_engine import Point2D, PolygonTray

class TestComprehensiveWiringAudit(unittest.TestCase):

    def setUp(self):
        self.editor_client = TestClient(editor_app)
        self.control_client = TestClient(control_app)

    # -------------------------------------------------------------
    # 1. WORD PROCESSOR WIRING AUDIT: ENDPOINTS & BUTTONS
    # -------------------------------------------------------------
    def test_word_processor_ui_html_rendering(self):
        """Audit GET / on Word Processor UI."""
        res = self.editor_client.get("/")
        self.assertEqual(res.status_code, 200)
        self.assertIn("PubCast Word Processor & Collaborative Engine", res.text)
        self.assertIn("Check Manuscript", res.text)
        self.assertIn("Format -> Screenplay", res.text)
        self.assertIn("Format -> Stage Play", res.text)
        self.assertIn("Style Analytics", res.text)
        self.assertIn("Query Assistant", res.text)

    def test_word_processor_check_endpoint(self):
        """Audit /api/check endpoint for real-time critique scanning."""
        payload = {"text": "King Arthur held his sword tight and proclaimed victory."}
        res = self.editor_client.post("/api/check", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("annotations", data)
        self.assertIsInstance(data["annotations"], list)

    def test_word_processor_query_router_endpoint(self):
        """Audit /api/query endpoint for On-Demand Assistant."""
        queries = [
            "synonym for victory",
            "rhyme with tight"
        ]
        for q in queries:
            res = self.editor_client.post("/api/query", json={"query": q})
            self.assertEqual(res.status_code, 200)
            self.assertIn("results", res.json())

    def test_word_processor_transform_endpoint(self):
        """Audit /api/transform endpoint for screenplay & stage play conversion."""
        prose_text = "JOHN\nI am standing here in the rain."
        res1 = self.editor_client.post("/api/transform", json={"text": prose_text, "target_format": "screenplay"})
        self.assertEqual(res1.status_code, 200)
        self.assertIn("result", res1.json())

        res2 = self.editor_client.post("/api/transform", json={"text": prose_text, "target_format": "stage_play"})
        self.assertEqual(res2.status_code, 200)
        self.assertIn("result", res2.json())

    # -------------------------------------------------------------
    # 2. AI COLLABORATION & MODEL ATTACHMENT
    # -------------------------------------------------------------
    def test_ai_model_attachment_and_collaboration(self):
        """Test attaching an external AI model caller to the PlotHoleChecker & Engine."""
        ai_calls = []

        def mock_ai_chat_caller(prompt: str):
            ai_calls.append(prompt)
            return {
                "contradiction": "AI Detected: Arthur cannot hold his sword if his hand was severed in Chapter 1.",
                "quote": "King Arthur held his sword",
                "suggestion": "Revise scene or restore Arthur's hand."
            }

        engine_with_ai = PubCastEditorEngine(chat_caller=mock_ai_chat_caller)
        manuscript = "Chapter 1: King Arthur's hand was severed in battle.\n\nChapter 2: King Arthur held his sword tight and proclaimed victory."
        
        # Extracted facts should identify the death/hand state, and the attached AI model is invoked
        anns = engine_with_ai.check_manuscript(manuscript, established_facts=["King Arthur hand was severed"])
        
        self.assertTrue(len(ai_calls) > 0, "AI model caller was not invoked during manuscript scan.")
        self.assertIn("Facts:", ai_calls[0])
        
        ai_anns = [a for a in anns if "AI Detected" in a.message]
        self.assertEqual(len(ai_anns), 1)
        self.assertEqual(ai_anns[0].kind, AnnotationKind.CONTINUITY)
        self.assertTrue(ai_anns[0].span_found)

    # -------------------------------------------------------------
    # 3. PRE-BUFFER MODIFICATION & DOWNSTREAM CONTEXT RE-READING
    # -------------------------------------------------------------
    def test_pre_buffer_text_change_context_propagation(self):
        """
        Test that modifying text before a finalized buffer zone forces 
        the engine to re-extract facts and adjust downstream continuity context.
        """
        engine = PubCastEditorEngine()

        # Step 1: Initial manuscript version
        initial_text = (
            "Arthur was slain in the grand battle.\n\n"
            "Many years later, the kingdom remembered Arthur's bravery."
        )
        anns_1 = engine.check_manuscript(initial_text)
        # Verify Arthur is recorded as dead
        facts_1 = engine.fact_extractor.extract_facts(initial_text)
        self.assertIn("Arthur is dead", facts_1)

        # Step 2: Edit text BEFORE finalized buffer zone (changing 'slain' to 'victorious')
        # This alters the upstream premise/fact base for everything below it.
        modified_text = (
            "Arthur was victorious in the grand battle.\n\n"
            "Arthur walked into the castle hall to celebrate."
        )
        anns_2 = engine.check_manuscript(modified_text)
        facts_2 = engine.fact_extractor.extract_facts(modified_text)

        # Verify dead fact is cleared and no false continuity error is thrown
        self.assertNotIn("Arthur is dead", facts_2)
        critical_errs = [a for a in anns_2 if a.severity == Severity.CRITICAL]
        self.assertEqual(len(critical_errs), 0, "Pre-buffer text modification resulted in stale continuity errors.")

        # Step 3: Re-introduce a contradiction upstream and verify downstream adaptation
        contradictory_text = (
            "Arthur was slain in the grand battle.\n\n"
            "Arthur walked into the castle hall to celebrate."
        )
        anns_3 = engine.check_manuscript(contradictory_text)
        critical_errs_3 = [a for a in anns_3 if a.severity == Severity.CRITICAL]
        self.assertEqual(len(critical_errs_3), 1, "Engine failed to catch downstream continuity contradiction after upstream change.")
        self.assertIn("Arthur is dead, but Arthur performs action", critical_errs_3[0].message)

    # -------------------------------------------------------------
    # 4. CONTROL ROOM & POLYGONAL TRAY MESH ENGINE
    # -------------------------------------------------------------
    def test_control_room_ui_html_rendering(self):
        """Audit GET / on Control Room UI."""
        res = self.control_client.get("/")
        self.assertEqual(res.status_code, 200)
        self.assertIn("PubCast Control Room - Polygonal Tray Interface", res.text)
        self.assertIn("LIVE VIEWPORT & CAMERA SWITCHER", res.text)
        self.assertIn("PASSKEY GATE & AUTHORITY", res.text)
        self.assertIn("TELEMETRY & SYSTEM LOG", res.text)
        self.assertIn("ASSETS & RECORDING LIBRARY", res.text)

    def test_polygonal_tray_reshaping_and_reforming(self):
        """Test that trays can move, reshape, reform, and update bounding/inset math."""
        # Initial 4-point rectangle
        tray = PolygonTray(
            id="dynamic_tray_1",
            title="DYNAMIC TRAY",
            vertices=[Point2D(0, 0), Point2D(200, 0), Point2D(200, 100), Point2D(0, 100)],
            module_type="viewport"
        )
        self.assertEqual(tray.to_svg_polygon_points(), "0.00,0.00 200.00,0.00 200.00,100.00 0.00,100.00")

        # Reshape & reform into an irregular 5-vertex polygon (chamfered corner)
        tray.vertices = [
            Point2D(10, 0),
            Point2D(250, 0),
            Point2D(300, 50),
            Point2D(250, 150),
            Point2D(10, 150)
        ]
        min_p, max_p = tray.get_bounding_box()
        self.assertEqual((min_p.x, min_p.y), (10, 0))
        self.assertEqual((max_p.x, max_p.y), (300, 150))

        # Recalculate inner viewport inset for reformed shape
        inset = tray.calculate_inner_viewport_inset(margin=15.0)
        self.assertEqual(inset["x"], 25.0)
        self.assertEqual(inset["y"], 15.0)
        self.assertEqual(inset["width"], 260.0)
        self.assertEqual(inset["height"], 120.0)

    def test_control_room_layout_persistence_api(self):
        """Test saving and retrieving reformed tray layouts via API."""
        reformed_layout = {
            "trays": [
                {
                    "id": "tray-reformed-1",
                    "title": "REFORMED VIEWPORT",
                    "vertices": [{"x": 10.0, "y": 10.0}, {"x": 500.0, "y": 10.0}, {"x": 480.0, "y": 300.0}],
                    "module_type": "live_viewport",
                    "status": "ACTIVE"
                }
            ]
        }
        post_res = self.control_client.post("/api/layout", json=reformed_layout)
        self.assertEqual(post_res.status_code, 200)
        self.assertEqual(post_res.json()["status"], "success")

        get_res = self.control_client.get("/api/layout")
        self.assertEqual(get_res.status_code, 200)
        saved_trays = get_res.json()["trays"]
        self.assertTrue(any(t["id"] == "tray-reformed-1" for t in saved_trays))

if __name__ == "__main__":
    unittest.main()
