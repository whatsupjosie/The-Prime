"""
Export spec-compliant tray silhouettes + an organic layout for the Foresight UI.

The Python library stays the authority on the Tray Design Rules (it is the
thing with the tests); this emits its output as JSON for the browser so the
UI never re-derives geometry and never drifts from the rules.

Layout is deliberately NOT a grid: trays are placed on an irregular scatter
with varied sizes, per "no rows and columns, no stacked rectangles".
"""

import json
from typing import Dict

from polygon_shape_library import TRAY_FAMILIES, build_tray_silhouettes, validate

# Organic placement, in viewport percentages. Sizes vary per tray so nothing
# reads as a repeated module. Values chosen to echo the reference composition:
# tall conversation column at left, large preview up top-centre, circular
# memory cluster at right, wide output slab across the bottom.
LAYOUT: Dict[str, Dict[str, float]] = {
    "preview": {"x": 24.0, "y": 6.0,  "w": 40.0, "h": 34.0, "z": 3},
    "status":  {"x": 71.0, "y": 5.0,  "w": 26.0, "h": 22.0, "z": 4},
    "memory":  {"x": 69.0, "y": 30.0, "w": 29.0, "h": 27.0, "z": 3},
    "chat":    {"x": 2.0,  "y": 30.0, "w": 21.0, "h": 40.0, "z": 5},
    "files":   {"x": 25.0, "y": 43.0, "w": 42.0, "h": 22.0, "z": 2},
    "output":  {"x": 21.0, "y": 68.0, "w": 37.0, "h": 26.0, "z": 3},
    "tools":   {"x": 2.0,  "y": 73.0, "w": 17.0, "h": 24.0, "z": 4},
    "quick":   {"x": 72.0, "y": 72.0, "w": 25.0, "h": 23.0, "z": 4},
}

# Nominal pixel box each silhouette is generated inside. The SVG scales via
# viewBox, so these only set the aspect ratio the shape is drawn for.
NOMINAL = {tid: (600.0, 600.0 * (v["h"] / v["w"]) * 0.62) for tid, v in LAYOUT.items()}


def build() -> Dict[str, dict]:
    sils = build_tray_silhouettes(NOMINAL, corner_style="mixed")
    out: Dict[str, dict] = {}
    for tid, place in LAYOUT.items():
        s = sils[tid]
        validate(s.vertices, s.family)  # refuse to export anything non-compliant
        w, h = NOMINAL[tid]
        out[tid] = {
            "family": s.family,
            "path": s.to_svg_path(),
            "viewBox": f"0 0 {w:.0f} {h:.0f}",
            "feather": round(s.feather, 3),
            "inset": {k: round(v, 2) for k, v in s.inner_inset(26.0).items()},
            "nominal": {"w": round(w, 1), "h": round(h, 1)},
            "place": place,
            "sharpCorners": sum(1 for r in s.corner_radii if r == 0),
            "roundedCorners": sum(1 for r in s.corner_radii if r > 0),
        }
    return out


if __name__ == "__main__":
    data = build()
    with open("tray_silhouettes.json", "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1)
    print(f"exported {len(data)} compliant tray silhouettes -> tray_silhouettes.json")
    for tid, d in data.items():
        print(f"  {tid:8s} {d['family']:9s} "
              f"sharp={d['sharpCorners']} rounded={d['roundedCorners']} "
              f"feather={d['feather']}px  path={len(d['path'])} chars")
