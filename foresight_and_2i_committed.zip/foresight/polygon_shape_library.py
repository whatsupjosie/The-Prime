"""
Polygon Shape Library — Tray Design Rules
© 2024-2026 Rear View Foresight LLC — "Feic Mo Chroí"

Generates and validates tray silhouettes against the Tray Design Rules.

Philosophy encoded here: "Functional contract is binding. Visual expression
breathes." Shape generation is deliberately varied and seeded per-tray, while
the surface treatment (stroke recipe, glow, gradient, light) is left entirely
to CSS so every family reads as one set.

Rules enforced by `validate()`:
  * Allowed families only — triangle, pentagon, hexagon, heptagon, trapezoid,
    rhombus, circle/ellipse.
  * Banned — squares, rectangles (two pairs of parallel sides), and any
    regular/equilateral polygon.
  * Irregularity — no side length may match another.
  * Angles may repeat, but must not all be uniform.

Extends polygonal_tray_engine (Point2D / PolygonTray) rather than replacing it.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from polygonal_tray_engine import Point2D, PolygonTray

# ── Rule constants ──────────────────────────────────────────────────────────

ALLOWED_FAMILIES = (
    "triangle", "pentagon", "hexagon", "heptagon",
    "trapezoid", "rhombus", "circle",
)

# Triangles must be soft and wide-based: base at least this multiple of height,
# so a tray never becomes a narrow spike that can't hold UI.
#
# Bounded by the tray box itself — a 360x280 tray tops out at 1.29, so anything
# at or above that is unsatisfiable. 1.25 keeps triangles decisively wide while
# still rejecting spikes (a 100x300 triangle scores 0.33).
TRIANGLE_MIN_BASE_RATIO = 1.25

# Two sides count as "matching" (and therefore too regular) within this
# fraction of their own length.
SIDE_MATCH_TOLERANCE = 0.06

# Angles within this many degrees are considered equal when checking that a
# shape is not uniform. Repeated angles are allowed; *all* angles equal is not.
ANGLE_MATCH_TOLERANCE_DEG = 4.0

# Two edges are parallel within this angular tolerance (rectangle detection).
PARALLEL_TOLERANCE_DEG = 6.0

# Gaussian feather applied to the perimeter stroke, per the spec's 0.6–0.8px.
FEATHER_RADIUS_RANGE = (0.6, 0.8)

VERTEX_COUNTS = {
    "triangle": 3,
    "trapezoid": 4,
    "rhombus": 4,
    "pentagon": 5,
    "hexagon": 6,
    "heptagon": 7,
}


class ShapeRuleViolation(ValueError):
    """Raised when a silhouette breaks the Tray Design Rules."""


# ── Geometry helpers ────────────────────────────────────────────────────────

def _side_lengths(vs: List[Point2D]) -> List[float]:
    n = len(vs)
    return [math.dist(vs[i].to_tuple(), vs[(i + 1) % n].to_tuple()) for i in range(n)]


def _interior_angles_deg(vs: List[Point2D]) -> List[float]:
    n, out = len(vs), []
    for i in range(n):
        prev, cur, nxt = vs[(i - 1) % n], vs[i], vs[(i + 1) % n]
        a = (prev.x - cur.x, prev.y - cur.y)
        b = (nxt.x - cur.x, nxt.y - cur.y)
        na = math.hypot(*a) or 1e-9
        nb = math.hypot(*b) or 1e-9
        cos = max(-1.0, min(1.0, (a[0] * b[0] + a[1] * b[1]) / (na * nb)))
        out.append(math.degrees(math.acos(cos)))
    return out


def _edge_bearings_deg(vs: List[Point2D]) -> List[float]:
    n, out = len(vs), []
    for i in range(n):
        p, q = vs[i], vs[(i + 1) % n]
        out.append(math.degrees(math.atan2(q.y - p.y, q.x - p.x)) % 180.0)
    return out


def _parallel_pair_count(vs: List[Point2D]) -> int:
    bearings = _edge_bearings_deg(vs)
    n, pairs = len(bearings), 0
    for i in range(n):
        for j in range(i + 1, n):
            d = abs(bearings[i] - bearings[j]) % 180.0
            d = min(d, 180.0 - d)
            if d <= PARALLEL_TOLERANCE_DEG:
                pairs += 1
    return pairs


# ── Validation ──────────────────────────────────────────────────────────────

def validate(vs: List[Point2D], family: str) -> None:
    """Raise ShapeRuleViolation if the silhouette breaks the design rules."""
    if family not in ALLOWED_FAMILIES:
        raise ShapeRuleViolation(f"'{family}' is not an allowed family")

    if family == "circle":
        return  # circles and ellipses are always acceptable

    expected = VERTEX_COUNTS[family]
    if len(vs) != expected:
        raise ShapeRuleViolation(f"{family} needs {expected} vertices, got {len(vs)}")

    sides = _side_lengths(vs)

    # Irregularity: no side length may match another.
    for i in range(len(sides)):
        for j in range(i + 1, len(sides)):
            ref = max(sides[i], sides[j]) or 1e-9
            if abs(sides[i] - sides[j]) / ref < SIDE_MATCH_TOLERANCE:
                raise ShapeRuleViolation(
                    f"{family}: sides {i} and {j} match "
                    f"({sides[i]:.1f} vs {sides[j]:.1f}) — shape is too regular"
                )

    # Not equilateral / not uniform: angles may repeat, but not all of them.
    angles = _interior_angles_deg(vs)
    if max(angles) - min(angles) < ANGLE_MATCH_TOLERANCE_DEG:
        raise ShapeRuleViolation(f"{family}: all interior angles uniform — regular polygon banned")

    # Squares and rectangles: a quad with two pairs of parallel sides.
    if len(vs) == 4 and _parallel_pair_count(vs) >= 2:
        raise ShapeRuleViolation(
            "four-sided shape has two pairs of parallel sides — rectangle/square banned"
        )

    # Triangles must be wide-based and usable.
    if family == "triangle":
        xs = [v.x for v in vs]
        ys = [v.y for v in vs]
        base, height = max(xs) - min(xs), max(ys) - min(ys)
        if height and base / height < TRIANGLE_MIN_BASE_RATIO:
            raise ShapeRuleViolation(
                f"triangle base/height {base / height:.2f} < {TRIANGLE_MIN_BASE_RATIO} — too pointed"
            )


def is_valid(vs: List[Point2D], family: str) -> bool:
    try:
        validate(vs, family)
        return True
    except ShapeRuleViolation:
        return False


# ── Generation ──────────────────────────────────────────────────────────────

@dataclass
class Silhouette:
    """A generated tray outline plus its per-vertex corner treatment."""
    family: str
    vertices: List[Point2D]
    corner_radii: List[float]      # 0 == sharp vertex; >0 == rounded
    feather: float                 # gaussian blur radius for the stroke
    width: float
    height: float

    def to_svg_path(self) -> str:
        """Closed path; rounded vertices become quadratic curves into the corner."""
        return _rounded_path(self.vertices, self.corner_radii)

    def to_points(self) -> str:
        return " ".join(f"{v.x:.2f},{v.y:.2f}" for v in self.vertices)

    def inner_inset(self, margin: float = 16.0) -> Dict[str, float]:
        """Safe rectangular content box, reusing the engine's inset maths."""
        tray = PolygonTray(id="_", title="_", vertices=self.vertices, module_type="_")
        return tray.calculate_inner_viewport_inset(margin)


def _rounded_path(vs: List[Point2D], radii: List[float]) -> str:
    """Build an SVG path, rounding vertices whose radius > 0."""
    n = len(vs)
    parts: List[str] = []
    for i in range(n):
        prev, cur, nxt = vs[(i - 1) % n], vs[i], vs[(i + 1) % n]
        r = radii[i]
        if r <= 0.01:
            parts.append(("M" if i == 0 else "L") + f"{cur.x:.2f},{cur.y:.2f}")
            continue
        # Pull back along both incident edges, then curve through the vertex.
        def pull(frm: Point2D, to: Point2D, dist: float) -> Tuple[float, float]:
            d = math.dist(frm.to_tuple(), to.to_tuple()) or 1e-9
            t = min(0.45, dist / d)
            return (to.x + (frm.x - to.x) * t, to.y + (frm.y - to.y) * t)
        ax, ay = pull(prev, cur, r)
        bx, by = pull(nxt, cur, r)
        parts.append(("M" if i == 0 else "L") + f"{ax:.2f},{ay:.2f}")
        parts.append(f"Q{cur.x:.2f},{cur.y:.2f} {bx:.2f},{by:.2f}")
    return " ".join(parts) + " Z"


def _jitter(rng: random.Random, base: float, amount: float) -> float:
    return base * (1.0 + rng.uniform(-amount, amount))


def generate(
    family: str,
    width: float,
    height: float,
    seed: Optional[str] = None,
    corner_style: str = "mixed",
) -> Silhouette:
    """
    Generate a spec-compliant silhouette.

    `seed` makes generation deterministic per tray id — two trays of the same
    functional type get different silhouettes, but each keeps its own shape
    across reloads (which matters because layout state is persisted).

    `corner_style` is 'sharp', 'rounded', or 'mixed' — the spec explicitly
    allows a single polygon to carry both.
    """
    if family not in ALLOWED_FAMILIES:
        raise ShapeRuleViolation(f"'{family}' is not an allowed family")

    rng = random.Random(seed if seed is not None else family)

    for _ in range(400):  # regenerate until the rules are satisfied
        vs = _emit(family, width, height, rng)
        if family == "circle" or is_valid(vs, family):
            break
    else:
        raise ShapeRuleViolation(f"could not generate a compliant {family}")

    n = len(vs)
    if corner_style == "sharp":
        radii = [0.0] * n
    elif corner_style == "rounded":
        radii = [_jitter(rng, min(width, height) * 0.12, 0.35) for _ in range(n)]
    else:  # mixed — some sharp, some rounded, per the spec
        radii = [
            0.0 if rng.random() < 0.4 else _jitter(rng, min(width, height) * 0.12, 0.35)
            for _ in range(n)
        ]

    # Triangles get a rounded, bulbous peak regardless of corner style.
    if family == "triangle":
        peak = min(range(n), key=lambda i: vs[i].y)
        radii[peak] = max(radii[peak], min(width, height) * 0.26)

    return Silhouette(
        family=family,
        vertices=vs,
        corner_radii=radii,
        feather=rng.uniform(*FEATHER_RADIUS_RANGE),
        width=width,
        height=height,
    )


def _emit(family: str, w: float, h: float, rng: random.Random) -> List[Point2D]:
    """Emit raw vertices for a family, irregular by construction."""
    j = lambda v, a=0.13: _jitter(rng, v, a)  # noqa: E731

    if family == "circle":
        return [Point2D(0, 0), Point2D(w, 0), Point2D(w, h), Point2D(0, h)]

    if family == "triangle":
        # Wide base with the apex pushed decisively off-centre. A centred apex
        # makes the two flanks near-equal, which the irregularity rule rejects,
        # so bias to one side rather than sampling across the middle.
        side = rng.choice((-1, 1))
        apex = w * (0.5 + side * rng.uniform(0.16, 0.30))
        return [
            Point2D(apex, j(h * 0.05, 0.45)),
            Point2D(j(w, 0.03), j(h, 0.02)),
            Point2D(j(w * 0.02, 0.5), h),
        ]

    if family == "trapezoid":
        # One pair of parallel sides only — top inset asymmetrically.
        return [
            Point2D(w * rng.uniform(0.14, 0.26), 0),
            Point2D(w * rng.uniform(0.74, 0.9), 0),
            Point2D(j(w, 0.04), h),
            Point2D(j(w * 0.03, 0.6), j(h, 0.03)),
        ]

    if family == "rhombus":
        # Offset diamond; skewed so opposite sides are not parallel.
        return [
            Point2D(w * rng.uniform(0.4, 0.6), 0),
            Point2D(w, h * rng.uniform(0.34, 0.5)),
            Point2D(w * rng.uniform(0.38, 0.58), h),
            Point2D(0, h * rng.uniform(0.5, 0.68)),
        ]

    # Pentagon / hexagon / heptagon: irregular radial sweep.
    #
    # Kept deliberately PLUMP — near-convex, filling most of the box. Wider
    # radius and angle variance produces spiky, crescent silhouettes whose
    # usable rectangle collapses (measured: ~28% of the bounding box, versus
    # ~60% for a plump one). Irregularity comes from no two sides matching,
    # not from making the shape gaunt.
    n = VERTEX_COUNTS[family]
    cx, cy, rx, ry = w / 2, h / 2, w / 2, h / 2
    start = rng.uniform(0, math.tau)
    # Uneven angular steps guarantee unequal sides without gouging the outline.
    #
    # Variance scales with vertex count: a heptagon has 21 side-pairs that must
    # all stay distinct versus a pentagon's 10, so it needs more angular spread
    # to satisfy the irregularity rule. Widening the angles (rather than the
    # radii) buys that distinctness while keeping the silhouette plump.
    extra = 0.04 * (n - 5)
    steps = [rng.uniform(0.84 - extra, 1.20 + extra * 2) for _ in range(n)]
    total = sum(steps)

    # Radii are spread deliberately rather than sampled independently. With
    # only 7 vertices in a narrow plump band, independent samples land close
    # together and the irregularity rule rejects every attempt. An even spread
    # (shuffled, then jittered) keeps the outline plump AND guarantees the
    # variation the rules require.
    spread = [0.86 + 0.14 * (i / max(1, n - 1)) for i in range(n)]
    rng.shuffle(spread)
    radii = [min(1.0, max(0.80, r + rng.uniform(-0.02, 0.02))) for r in spread]

    vs, ang = [], start
    for s, rr in zip(steps, radii):
        vs.append(Point2D(cx + math.cos(ang) * rx * rr, cy + math.sin(ang) * ry * rr))
        ang += (s / total) * math.tau
    return vs


# ── Tray assignment ─────────────────────────────────────────────────────────
# Functional contract is binding: each tray type keeps a stable family so it
# stays recognisable. Visual expression breathes: the seed varies the silhouette.

TRAY_FAMILIES: Dict[str, str] = {
    "preview":  "heptagon",
    "status":   "pentagon",
    "chat":     "hexagon",
    "files":    "trapezoid",
    "memory":   "hexagon",
    "tools":    "pentagon",
    "output":   "trapezoid",
    "quick":    "rhombus",
    "fan":      "circle",
}


def build_tray_silhouettes(
    sizes: Dict[str, Tuple[float, float]],
    corner_style: str = "mixed",
) -> Dict[str, Silhouette]:
    """Generate one silhouette per tray, keyed by tray id."""
    out: Dict[str, Silhouette] = {}
    for tray_id, (w, h) in sizes.items():
        family = TRAY_FAMILIES.get(tray_id, "pentagon")
        out[tray_id] = generate(family, w, h, seed=tray_id, corner_style=corner_style)
    return out


if __name__ == "__main__":
    demo = build_tray_silhouettes({k: (360.0, 280.0) for k in TRAY_FAMILIES})
    for tid, s in demo.items():
        sharp = sum(1 for r in s.corner_radii if r == 0)
        print(f"{tid:9s} {s.family:9s} verts={len(s.vertices)} "
              f"sharp={sharp} rounded={len(s.corner_radii) - sharp} "
              f"feather={s.feather:.2f}px")
