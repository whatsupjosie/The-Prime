"""
Polygonal Tray Control Room UI - Core Mesh Engine & Data Model
Defines 2D vertex coordinate math, tessellated layout structures,
bounding box calculations, and design tokens for the 4-pillar aesthetic.
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any
import math
import json

@dataclass
class Point2D:
    x: float
    y: float

    def to_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

@dataclass
class PolygonTray:
    id: str
    title: str
    vertices: List[Point2D]  # Ordered counter-clockwise/clockwise vertices
    module_type: str  # e.g., 'live_viewport', 'passkey_gate', 'prompt_editor', 'asset_manager', 'telemetry_log'
    style_variant: str = "default"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_bounding_box(self) -> Tuple[Point2D, Point2D]:
        """Calculates axis-aligned min and max points for content clipping/insetting."""
        min_x = min(v.x for v in self.vertices)
        max_x = max(v.x for v in self.vertices)
        min_y = min(v.y for v in self.vertices)
        max_y = max(v.y for v in self.vertices)
        return Point2D(min_x, min_y), Point2D(max_x, max_y)

    def calculate_inner_viewport_inset(self, margin: float = 12.0) -> Dict[str, float]:
        """
        Calculates the safe inner rectangular region for nested HTML/canvas elements,
        accounting for polygonal chamfers/angles.
        """
        min_p, max_p = self.get_bounding_box()
        return {
            "x": min_p.x + margin,
            "y": min_p.y + margin,
            "width": max(0.0, (max_p.x - min_p.x) - (margin * 2)),
            "height": max(0.0, (max_p.y - min_p.y) - (margin * 2))
        }

    def to_svg_polygon_points(self) -> str:
        """Converts vertices to SVG points string attribute."""
        return " ".join(f"{v.x:.2f},{v.y:.2f}" for v in self.vertices)


# Aesthetic Design Tokens (Gatsby, Tech Noir, LCARS, Raw Copper)
AESTHETIC_TOKENS = {
    "colors": {
        "obsidian_backdrop": "#0a0a0c",
        "smoked_glass": "rgba(18, 18, 24, 0.85)",
        "gatsby_gold_brass": "#d4af37",
        "gatsby_champagne": "#f3e5ab",
        "tech_noir_cyan": "#00f0ff",
        "tech_noir_magenta": "#ff007f",
        "lcars_orange": "#ff9900",
        "lcars_purple": "#cc99cc",
        "lcars_blue": "#9999cc",
        "raw_copper": "#b87333",
        "solder_silver": "#a8a8a8",
        "status_active": "#00ff66",
        "status_warning": "#ffcc00",
        "status_error": "#ff3333"
    },
    "effects": {
        "glass_blur": "backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);",
        "gold_glow": "box-shadow: 0 0 12px rgba(212, 175, 55, 0.4);",
        "cyan_neon": "box-shadow: 0 0 15px rgba(0, 240, 255, 0.6);"
    }
}

if __name__ == "__main__":
    # Test polygon tray initialization
    sample_tray = PolygonTray(
        id="tray_live_view",
        title="LIVE VIEWPORT / SWITCHER",
        vertices=[
            Point2D(0.0, 0.0),
            Point2D(600.0, 0.0),
            Point2D(580.0, 400.0),
            Point2D(20.0, 400.0)
        ],
        module_type="live_viewport"
    )
    print(f"Sample Tray SVG Points: {sample_tray.to_svg_polygon_points()}")
    print(f"Sample Tray Inset: {sample_tray.calculate_inner_viewport_inset()}")
