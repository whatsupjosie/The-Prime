"""
Unit and Integration Test Suite for Polygonal Tray Control Room Engine & FastAPI Server
Includes Edge Cases for Degenerate Polygons and Malformed Requests
"""

import unittest
from polygonal_tray_engine import Point2D, PolygonTray, AESTHETIC_TOKENS
from control_room_server import app
from fastapi.testclient import TestClient

class TestPolygonalTrayEngine(unittest.TestCase):

    def setUp(self):
        self.tray = PolygonTray(
            id="test_tray_1",
            title="TEST_TRAY",
            vertices=[
                Point2D(10.0, 10.0),
                Point2D(300.0, 10.0),
                Point2D(280.0, 200.0),
                Point2D(10.0, 200.0)
            ],
            module_type="test_module"
        )

    def test_bounding_box(self):
        min_p, max_p = self.tray.get_bounding_box()
        self.assertEqual((min_p.x, min_p.y), (10.0, 10.0))
        self.assertEqual((max_p.x, max_p.y), (300.0, 200.0))

    def test_inner_inset_calculation(self):
        inset = self.tray.calculate_inner_viewport_inset(margin=10.0)
        self.assertEqual(inset["x"], 20.0)
        self.assertEqual(inset["y"], 20.0)
        self.assertEqual(inset["width"], 270.0)
        self.assertEqual(inset["height"], 170.0)

    def test_svg_points_formatting(self):
        pts = self.tray.to_svg_polygon_points()
        self.assertEqual(pts, "10.00,10.00 300.00,10.00 280.00,200.00 10.00,200.00")

    def test_design_tokens_presence(self):
        self.assertIn("gatsby_gold_brass", AESTHETIC_TOKENS["colors"])
        self.assertIn("tech_noir_cyan", AESTHETIC_TOKENS["colors"])
        self.assertIn("raw_copper", AESTHETIC_TOKENS["colors"])

    def test_excessive_margin_inset(self):
        # Edge case: Margin greater than polygon dimensions
        inset = self.tray.calculate_inner_viewport_inset(margin=500.0)
        self.assertEqual(inset["width"], 0.0)
        self.assertEqual(inset["height"], 0.0)


class TestControlRoomServer(unittest.TestCase):

    def setUp(self):
        self.client = TestClient(app)

    def test_get_ui_endpoint(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("PubCast Control Room", response.text)

    def test_get_layout_api(self):
        response = self.client.get("/api/layout")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("trays", data)

    def test_post_layout_api_validation(self):
        # Test valid POST request
        payload = {
            "trays": [
                {
                    "id": "tray-1",
                    "title": "TRAY 1",
                    "vertices": [{"x": 0.0, "y": 0.0}, {"x": 100.0, "y": 0.0}],
                    "module_type": "test",
                    "status": "ACTIVE"
                }
            ]
        }
        response = self.client.post("/api/layout", json=payload)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "success")

if __name__ == "__main__":
    unittest.main()
