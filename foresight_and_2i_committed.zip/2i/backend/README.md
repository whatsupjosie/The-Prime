# Pubcast 2i — Backend Proxy

Minimal Express server that solves two things flagged in the v20 HANDOFF.md:

1. **Claude CORS / key exposure** — the app currently calls Anthropic directly
   from the browser, which only works in dev and puts your key in
   localStorage. This proxy keeps the key server-side.
2. **Thesaurus / rhyme / word-finder** — per Gemini's note, these are "just
   standard API calls" once a backend exists. This ships a working
   `/api/thesaurus` route today (backed by Datamuse, free, no key needed) so
   there's something real to plug the frontend into, not just a stub.

## Setup

```bash
cd backend
cp .env.example .env
# edit .env, set ANTHROPIC_API_KEY=sk-ant-...
npm install
npm start
```

Server runs at `http://localhost:8787` by default (override with `PORT` in `.env`).

## Routes

### `GET /api/health`
Quick check that the server is up and whether a Claude key is configured.

### `POST /api/claude`
Body: `{ model, max_tokens, messages, system? }` — same shape the frontend's
`callLLM` already builds. Returns Anthropic's raw response JSON.

### `GET /api/thesaurus?word=happy&mode=synonyms`
`mode` is one of `synonyms` | `rhymes` | `related` | `means-like`.
Returns `{ word, mode, results: [{ word, score }] }`.

Swap the Datamuse call inside `server.js` for a different provider later
(Merriam-Webster, WordsAPI, etc.) without changing the frontend contract —
same request/response shape either way.

## Wiring it into the frontend (not done yet)

The v22 HTML app's `LLM_ADAPTERS.claude.send()` currently calls
`https://api.anthropic.com/v1/messages` directly with
`anthropic-dangerous-direct-browser-access`. To use this proxy instead:

1. Point that adapter's URL at `http://localhost:8787/api/claude`.
2. Drop the `x-api-key` and `anthropic-dangerous-direct-browser-access`
   headers from the frontend call — the key now lives only in `.env` here.
3. For the thesaurus, add a small right-click or toolbar action in the app
   that calls `GET /api/thesaurus?word=...&mode=synonyms` and shows results
   in a popover.

That frontend wiring is the next piece — this proxy is the foundation it needs.

## Known limitations

- No auth on these routes. Fine for local/dev use; **do not deploy publicly
  as-is** — add an API key check or session auth before that.
- Not deployed or live-tested in this environment (sandboxed, no outbound
  network access). Verify with `npm start` + `curl` on your machine before
  wiring the frontend to it.
- Rhyme/related-word quality depends entirely on Datamuse's free index —
  fine for a first pass, may want a dedicated rhyme API later for poetry-
  heavy manuscripts.
