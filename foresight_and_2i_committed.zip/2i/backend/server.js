// Pubcast 2i — Backend Proxy
//
// Two jobs:
//   1. /api/claude    — proxies calls to Anthropic's API so the key never
//                        lives in the browser (fixes the CORS limitation
//                        noted in the v20 HANDOFF.md).
//   2. /api/thesaurus  — word-lookup passthrough (synonyms, rhymes, related
//                        words). Wired to Datamuse (free, no key required)
//                        as a working default. Swap providers later by
//                        editing only this route.
//
// Run:
//   cp .env.example .env   # fill in ANTHROPIC_API_KEY
//   npm install
//   npm start
//
// Point the app's LLM settings at http://localhost:8787/api/claude
// instead of calling Anthropic directly from the browser.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 8787;

app.use(cors());
app.use(express.json({ limit: '2mb' }));

// ── Health check ────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    claudeConfigured: Boolean(process.env.ANTHROPIC_API_KEY),
    time: new Date().toISOString()
  });
});

// ── Claude proxy ────────────────────────────────────────────────────
// Body shape matches what the frontend's LLM adapter already sends:
// { model, max_tokens, messages }
app.post('/api/claude', async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY not set on server. See .env.example.' });
  }
  const { model, max_tokens, messages, system } = req.body || {};
  if (!Array.isArray(messages) || !messages.length) {
    return res.status(400).json({ error: 'messages[] is required' });
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: model || 'claude-sonnet-4-6',
        max_tokens: max_tokens || 1000,
        messages,
        ...(system ? { system } : {})
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || 'Anthropic API error', detail: data });
    }
    res.json(data);
  } catch (err) {
    console.error('Claude proxy error:', err);
    res.status(502).json({ error: 'Failed to reach Anthropic API', detail: String(err) });
  }
});

// ── Thesaurus / word-finder ─────────────────────────────────────────
// mode: "synonyms" | "rhymes" | "related" | "means-like" (default: synonyms)
// Backed by Datamuse (https://api.datamuse.com) — free, no API key, good
// enough to ship today. Swap the fetch URL below if you later move to a
// paid provider (Merriam-Webster, WordsAPI, etc.) — the response shape
// returned to the frontend stays the same either way.
app.get('/api/thesaurus', async (req, res) => {
  const { word, mode = 'synonyms' } = req.query;
  if (!word || typeof word !== 'string') {
    return res.status(400).json({ error: 'word query param is required' });
  }

  const paramByMode = {
    synonyms: `rel_syn=${encodeURIComponent(word)}`,
    rhymes: `rel_rhy=${encodeURIComponent(word)}`,
    related: `ml=${encodeURIComponent(word)}`,      // "means like" — broader associative matches
    'means-like': `ml=${encodeURIComponent(word)}`
  };
  const qs = paramByMode[mode] || paramByMode.synonyms;

  try {
    const upstream = await fetch(`https://api.datamuse.com/words?${qs}&max=20`);
    if (!upstream.ok) throw new Error(`Datamuse ${upstream.status}`);
    const raw = await upstream.json();
    res.json({
      word,
      mode,
      results: raw.map(r => ({ word: r.word, score: r.score }))
    });
  } catch (err) {
    console.error('Thesaurus proxy error:', err);
    res.status(502).json({ error: 'Failed to reach word-lookup provider', detail: String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`Pubcast 2i backend running on http://localhost:${PORT}`);
  console.log(`  Claude proxy:    POST http://localhost:${PORT}/api/claude`);
  console.log(`  Thesaurus proxy: GET  http://localhost:${PORT}/api/thesaurus?word=happy&mode=synonyms`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn('  ⚠ ANTHROPIC_API_KEY not set — /api/claude will return 500 until you add it to .env');
  }
});
