# PEQ Clinical Evidence Alignment

This registry is intentionally small and conservative. It is a seed for a larger evidence registry, not a clinical knowledge base pretending to be complete.

## Design rule

A cluster of observed signs may support a **working hypothesis about an interaction pattern**. It does not establish a diagnosis.

The system can test whether a low-risk, reversible response strategy predicted by that hypothesis appears helpful for this individual. A positive response updates the interaction hypothesis; it does not create a diagnosis.

## Current sourced patterns

### Trauma-related stress-response pattern

The registry tracks re-experiencing/intrusive symptoms, avoidance, hyperarousal/startle, vigilance/guardedness, sleep disruption, negative mood/detachment, concentration difficulty, and reminder-linked distress. NIMH describes PTSD as a clinical diagnosis requiring a particular symptom pattern, duration, impairment, and trauma exposure; it also notes that many people experience trauma and stress reactions without developing PTSD. The registry therefore treats these observations as pattern evidence only.

Response principles are drawn from VA/DoD patient-centered care, SAMHSA trauma-informed care, VA National Center for PTSD material on trauma reminders, and conditional grounding guidance. These sources support attention to safety, transparency, collaboration, agency, avoidance of retraumatization, and cautious use of grounding when a person appears disoriented or in a flashback-like state.

### Suspiciousness / threat-interpretation pattern

The registry tracks suspiciousness, paranoid ideas, difficulty separating interpretations from external evidence, social withdrawal, unusually intense threat ideas, disorganized communication, and functional decline as a cluster that may justify a working threat-interpretation hypothesis. NIMH lists these as possible warning signs associated with psychosis, but they are not specific enough to establish a diagnosis.

Response principles draw on APA psychosis/schizophrenia guidance: maintain an empathic, nonthreatening relationship; use guided questions and proportionate examination of beliefs; preserve the person's perspective without automatically converting an unverified belief into a fact. The system must also separately test whether an external threat is actually present.

## Provenance / limitations

Every source is stored with an organization, title, source type, year, URL, evidentiary role, and limitations. The current set contains federal/public-health guidance and professional practice-guideline material. It is not yet a systematic review of the full clinical literature.

The next data-expansion step should add independent systematic reviews/meta-analyses and validated assessment literature, retaining disagreements and source-specific scope rather than averaging all findings into a single “truth” number.
