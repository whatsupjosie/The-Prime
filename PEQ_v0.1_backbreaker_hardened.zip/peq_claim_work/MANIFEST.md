# CRE-EQ v0.1 Package Manifest

- `README.md` — concise package overview and run instructions
- `HANDOFF_CRE-EQ_v0.1.md` — full engineering handoff
- `AUDIT_NOTES.md` — prior adversarial self-audit and known limitations
- `cre_eq/models.py` — data contracts
- `cre_eq/engine.py` — reasoning implementation
- `cre_eq/__init__.py` — public exports
- `demo.py` — executable demo
- `tests/test_cre_eq.py` — regression suite

No runtime caches or bytecode files are intended to ship in the archive.
