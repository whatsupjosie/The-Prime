# Primary research and professional sources represented in PEQ v0.1 scientific expansion

## Population datasets and surveys

- CDC BRFSS — https://www.cdc.gov/brfss/
- CDC NHANES — https://www.cdc.gov/nchs/nhanes/about/index.html
- UK Biobank — https://www.ukbiobank.ac.uk/about-our-data/
- NIH All of Us — https://www.allofus.nih.gov/
- Pew American Trends Panel methodology — https://www.pewresearch.org/methods/

## Professional clinical frameworks / measures

- APA DSM-5-TR — https://www.psychiatry.org/psychiatrists/practice/dsm/about-dsm
- APA DSM-5-TR assessment measures / PID-5 — https://www.psychiatry.org/psychiatrists/practice/dsm/educational-resources/assessment-measures
- WHO mhGAP Intervention Guide v2.0 — https://www.who.int/publications/i/item/9789241549790

## Peer-reviewed measurement / psychometric literature

- PHQ-9 — PMID 11556941 — https://pubmed.ncbi.nlm.nih.gov/11556941/
- GAD-7 general-population validation — PMID 18388841 — https://pubmed.ncbi.nlm.nih.gov/18388841/
- PCL-5 development/psychometrics — PMID 26606250 — https://pubmed.ncbi.nlm.nih.gov/26606250/
- CAPS-5 initial psychometrics — PMID 28493729 — https://pubmed.ncbi.nlm.nih.gov/28493729/
- CAPS-5 reliability generalization meta-analysis — PMID 39184938 — https://pubmed.ncbi.nlm.nih.gov/39184938/
- PANSS COSMIN systematic review/meta-analysis — PMID 40255437 — https://pubmed.ncbi.nlm.nih.gov/40255437/
- PANSS-6 COSMIN review — PMID 40056666 — https://pubmed.ncbi.nlm.nih.gov/40056666/
- DERS meta-analysis — PMID 38630901 — https://pubmed.ncbi.nlm.nih.gov/38630901/
- WHO-5 systematic review — PMID 25831962 — https://pubmed.ncbi.nlm.nih.gov/25831962/
- WHO-5 2025 systematic review — PMID 40506676 — https://pubmed.ncbi.nlm.nih.gov/40506676/

## Peer-reviewed personality / emotion-regulation evidence

- AMPD comprehensive review — PMID 31410585 — https://pubmed.ncbi.nlm.nih.gov/31410585/
- AMPD clinical utility — PMID 35787123 — https://pubmed.ncbi.nlm.nih.gov/35787123/
- AMPD 2024 assessment/convergent/discriminant validity — PMID 38211624 — https://pubmed.ncbi.nlm.nih.gov/38211624/
- AMPD 2025 validity/reliability/clinical utility — PMID 40948060 — https://pubmed.ncbi.nlm.nih.gov/40948060/
- Personality traits and emotion regulation — PMID 31961180 — https://pubmed.ncbi.nlm.nih.gov/31961180/
- Emotion-regulation strategies meta-analysis — PMID 20015584 — https://pubmed.ncbi.nlm.nih.gov/20015584/
- Emotion-regulation strategy structure meta-analysis — PMID 28301202 — https://pubmed.ncbi.nlm.nih.gov/28301202/

## Peer-reviewed treatment evidence

- PTSD psychological treatments meta-analysis — PMID 26574151 — https://pubmed.ncbi.nlm.nih.gov/26574151/
- PTSD medication vs trauma-focused psychotherapy — PMID 31690461 — https://pubmed.ncbi.nlm.nih.gov/31690461/
- Psychosis clinical-high-risk prevention meta-analysis — PMID 39953286 — https://pubmed.ncbi.nlm.nih.gov/39953286/
- Depression cognitive restructuring/behavioral activation/CBT NMA — PMID 34264703 — https://pubmed.ncbi.nlm.nih.gov/34264703/
- Depression psychotherapy NMA — PMID 34002502 — https://pubmed.ncbi.nlm.nih.gov/34002502/
- GAD psychotherapy systematic review/NMA — PMID 37851421 — https://pubmed.ncbi.nlm.nih.gov/37851421/
- GAD CBT delivery-format NMA — PMID 40506439 — https://pubmed.ncbi.nlm.nih.gov/40506439/
- Panic psychosocial treatment umbrella review — PMID 35063924 — https://pubmed.ncbi.nlm.nih.gov/35063924/
- Therapeutic alliance meta-analysis — PMID 29792475 — https://pubmed.ncbi.nlm.nih.gov/29792475/

## Clinical guideline / practice sources

- NICE PTSD guideline NG116 — https://www.nice.org.uk/guidance/ng116/chapter/Recommendations
- NICE psychosis and schizophrenia guideline CG178 — https://www.nice.org.uk/Guidance/CG178/chapter/recommendations
- NICE depression guideline NG222 — https://www.nice.org.uk/guidance/ng222/chapter/Recommendations
- WHO mhGAP Evidence Resource Centre — https://www.who.int/teams/mental-health-and-substance-use/treatment-care/mental-health-gap-action-programme/evidence-centre
