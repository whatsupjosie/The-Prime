
SCIENTIFIC BRIDGE HARDENING
===========================
- Retrieved scientific sources remain reference-only by default.
- Explicit promotion requires a verified proposition and state-specific directions.
- Promotion preserves provenance and uses GENERAL_KNOWLEDGE domain.
- Non-finite state directions are ignored; all-nonfinite inputs fail closed.
- Public PEQSystem API exposes explicit promotion.

Verification: 52 tests passed; compilation passed.
