# PEQ Scientific Evidence Expansion — 2026-08-14

## Purpose

This expansion adds a curated evidence registry for Probabilistic EQ (PEQ). It is deliberately **not** a diagnostic database and does not authorize autonomous clinical treatment.

The registry separates:

1. Population datasets and surveys used for population priors and context.
2. Validated measurement instruments used as construct references.
3. Peer-reviewed systematic reviews/meta-analyses used for evidence strength and uncertainty.
4. Clinical-practice guidelines used for professionally recognized response and treatment principles.
5. Interaction/process evidence (for example therapeutic alliance and emotion-regulation strategy literature).

Every source is retained with provenance and limitations. Evidence is not flattened into a single truth score.

## Population / cohort anchors

- CDC BRFSS — annual U.S. health/behavior surveillance; >400,000 adult interviews/year. It is useful for population prevalence and self-reported health/behavior context, not direct momentary emotion inference.
- CDC NHANES — nationally representative U.S. health survey with interviews plus physical/laboratory examination; approximately 5,000 participants/year. Richer objective health measures, smaller annual sample.
- UK Biobank — approximately 500,000 UK participants; questionnaire, psychosocial, lifestyle, physical, imaging and linked health-record data. Strong longitudinal/individual-difference resource, but recruited participants were 40–69 at baseline and selection effects matter.
- NIH All of Us — designed to include at least 1 million diverse people in the U.S.; links health, lifestyle, environment and biological information. Excellent for diversity and individual-difference research, but participation/linkage/missingness must be considered.
- Pew American Trends Panel — probability-based, nationally representative U.S. adult panel with repeated surveys and population weighting. Useful for self-reported attitudes, experiences and social context; subject to survey wording, panel attrition and self-report limitations.

## Clinical / dimensional construct anchors

- DSM-5-TR — formal clinical classification and diagnostic framework. PEQ may use it to understand clinical constructs, symptom organization, prevalence, course and differential considerations, but DSM diagnosis remains a trained-professional function.
- PID-5 / DSM-5 dimensional personality model — 25 maladaptive trait facets across five domains. Useful as a structured reference for stable individual differences, not as a momentary emotion classifier.
- AMPD reviews (2019, 2022, 2024, 2025) — substantial evidence for dimensional personality-trait reliability/validity and clinical utility, alongside continuing questions about factor overlap and model refinement.
- Big Five / emotion-regulation review — peer-reviewed synthesis connecting personality traits with stages and styles of emotion regulation. Useful as an individual-difference modifier, not a deterministic mapping.

## Validated measures retained as construct references

- PHQ-9 — depressive symptom severity.
- GAD-7 — anxiety symptom measurement, including general-population validation.
- PCL-5 — PTSD symptom measurement with strong psychometric evidence.
- CAPS-5 — clinician-administered PTSD interview with strong reliability evidence; trained administration required.
- PANSS / PANSS-6 — psychosis symptom measurement; 2025 COSMIN reviews document both strengths and structural/content-validity limitations.
- DERS / DERS-32 — multidimensional emotion-regulation difficulty measurement.
- WHO-5 — subjective well-being and treatment-outcome measure with a large literature.

These instruments are **not used as hidden-state truth meters**. A self-report score is evidence about a person's reported experience; a clinician measure is evidence about a structured clinical assessment; neither automatically establishes a current latent emotional state for PEQ.

## Response / therapy evidence

### Trauma-related patterns

- Trauma-focused CBT approaches (including cognitive processing therapy, cognitive therapy, prolonged exposure and narrative exposure) have strong evidence/guideline support for PTSD treatment.
- EMDR has guideline support for PTSD when delivered in structured, trained, supervised clinical practice.
- Evidence comparing trauma-focused psychotherapy with SSRI/SNRI medication is more limited and heterogeneous than the existence of either treatment modality might suggest.

### Psychosis / suspiciousness-related patterns

- NICE supports CBT and family intervention for psychosis/schizophrenia, with structured, collaborative, monitored delivery.
- For people at clinical high risk of psychosis, a 2025 updated meta-analysis of 24 RCTs (3,236 participants) found no sustained robust effect of investigated interventions on transition to psychosis. This is valuable **negative evidence** and prevents PEQ from assuming that an apparent threat-related pattern has a proven preventative treatment response.

### Depression

- Network meta-analysis supports CBT, cognitive restructuring and behavioral activation relative to usual care/waiting list, without evidence that one is universally superior.
- Broader psychotherapy network meta-analysis supports multiple evidence-based psychological treatments; comparative efficacy depends on context and study design.

### Anxiety / panic

- Network meta-analysis supports CBT and several third-wave CBT approaches for GAD, with moderate certainty for some comparisons and important delivery-format differences.
- Umbrella review generally supports CBT for panic disorder, but many underlying reviews were rated critically low quality. PEQ therefore preserves the treatment family as evidence with a quality caveat rather than treating it as settled fact.

### Emotion regulation and relationship process

- Meta-analytic literature shows systematic relationships among acceptance, reappraisal, problem solving, avoidance, rumination and suppression, but the usefulness of any strategy depends on context and individual differences.
- A 295-study meta-analysis involving more than 30,000 psychotherapy patients found therapeutic alliance is robustly associated with outcome. For PEQ, this is best interpreted as strong evidence for the value of collaboration, responsiveness, shared goals and transparent partnership—not as a universal interpersonal formula.

## PEQ use policy

A clinical or personality pattern may create a **working hypothesis**.

A working hypothesis may generate **low-risk, reversible response candidates**.

A response outcome may update the person's **interaction model**.

A response outcome does **not** establish a diagnosis.

Formal therapy procedures, medication recommendations, diagnostic interviews, and crisis clinical decisions remain outside autonomous PEQ execution and are retained only as professionally documented evidence/context.

## Core statistical precaution

PEQ must not count every paper or dataset as an independent vote. Sources can share samples, methods, labels, raters, or theoretical assumptions. Source dependence, sampling frame, measurement method, population, cultural scope, naturalistic-vs-acted context, self-report-vs-observer-vs-clinician status, and replication history must remain attached to the evidence item.

The purpose of the registry is therefore to answer:

> **What does this source actually establish, for whom, under what measurement conditions, and with what uncertainty?**

rather than:

> **How many sources say the same thing?**
