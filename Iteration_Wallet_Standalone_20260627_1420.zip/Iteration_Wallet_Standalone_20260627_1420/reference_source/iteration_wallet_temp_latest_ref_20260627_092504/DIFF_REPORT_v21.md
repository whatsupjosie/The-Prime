# Build Report — Iteration Wallet v2.2.1 Human Intent Receipts

## Summary

Built v2.2.1 from v2.2.0 as the next workbook step after the closed catalog and BlackBox evidence surface.

This patch adds durable Human Intent Receipts for protected custody actions. A receipt is an evidence artifact, not an access token. It proves that a protected action completed after a human-intent gate passed, and it binds that action to the immediately preceding BlackBox custody event hash.

## Product rule implemented

AI may request. Humans decide. BlackBox records. Protected custody actions now produce receipts that say which live human session completed the action, what action was completed, what object was affected, and which BlackBox event hash the receipt is tied to.

## Files changed

- `iteration_wallet/blackbox.py`
- `iteration_wallet/server.py`
- `iteration_wallet/__init__.py`
- `setup.py`
- `tests/test_human_intent_receipts_v221.py`

## Major additions

### BlackBox receipt store

Added receipt storage under:

```text
<vault_root>/blackbox/receipts/
```

Each receipt includes:

- `receipt_id`
- `receipt_type`
- `issued_at`
- `action_key`
- `action_label`
- `project_id`
- `section_id`
- `object_id`
- `object_name`
- `custody_state`
- `actor_id`
- `actor_kind`
- `session_id`
- `device_id`
- `verified_methods`
- `linked_blackbox_event_hash`
- `linked_blackbox_event_id`
- `receipt_hash`
- `receipt_event_id`
- `receipt_event_hash`
- `result_summary`

The receipt intentionally does not store ceremony tokens or unlock secrets.

### Receipt verification

Added:

```python
BlackBox.verify_human_intent_receipt(receipt_id)
```

It verifies:

- the receipt exists
- the receipt payload hash still matches
- the linked custody BlackBox event hash exists
- the receipt-issued BlackBox event hash exists
- the BlackBox chain verifies

### Receipt reporting

Added:

```python
BlackBox.list_human_intent_receipts(...)
BlackBox.get_human_intent_receipt(receipt_id)
BlackBox.build_human_intent_receipt_report(...)
```

### Protected route integration

The following protected v2.1 routes now return a `human_intent_receipt` envelope after successful completion:

- remove from active use
- restore to active use
- release from custody
- quarantine
- promote Candidate to Prime
- export working copy

The receipt is issued only after the human intent gate passes and the custody action completes.

### Receipt API endpoints

Added:

```text
GET /api/v21/blackbox/receipts
GET /api/v21/blackbox/receipts/report
GET /api/v21/blackbox/receipts/{receipt_id}
```

## Tests added

Added `tests/test_human_intent_receipts_v221.py`.

Test coverage includes:

- BlackBox issues receipt tied to prior custody event hash
- receipt rejects bot identity
- receipt rejects human session without intent proof
- receipt tamper detection catches changed receipt payload
- protected remove route returns a verified Human Intent Receipt
- receipt listing and detail endpoints work
- ceremony token does not appear in receipt JSON

## Verification

From clean working package:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
95 passed in 3.50s
```

## Remaining limits

- Receipts are local JSON artifacts tied to a local hash chain. They are tamper-evident, not externally sealed.
- Real authentication providers are still future work; sessions are local provider-neutral records.
- Receipt route responses now use `{result, human_intent_receipt}` envelopes for protected actions. UI/clients should adapt to this shape.
- Receipts do not yet have printable/exportable human-facing layouts.

## Next recommended step

IW-TASK-006 — Implement ceremony token lifecycle hardening.

Focus: ensure ceremony tokens are scoped, single-use where appropriate, action-bound, short-lived, and always BlackBox-recorded without storing the raw token.
