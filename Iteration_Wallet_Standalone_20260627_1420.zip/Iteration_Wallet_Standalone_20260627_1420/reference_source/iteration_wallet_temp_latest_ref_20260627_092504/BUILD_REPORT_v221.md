# Iteration Wallet v2.1.6 — Human Intent Gatekeeper Patch

## Goal

Address the shortcomings identified in the v2.1.5 self-report without adding unrelated features.

v2.1.6 focuses on making the Human Intent layer more real:

- Head User/admin approval is enforced, not just recorded.
- Bot/AI/tool requests are still request-only.
- Repeated bot pressure collapses into BlackBox incident bundles.
- Request thresholds are counted inside a rolling time window.
- BlackBox events are hash-chained to make tampering visible.
- Critical/intrusion alerts can displace low-priority alerts instead of being lost.
- Existing protected v2.1 custody routes now call a Human Intent gate before protected actions.

## Main files changed

- `iteration_wallet/notification_manager.py`
- `iteration_wallet/server.py`
- `iteration_wallet/__init__.py`
- `setup.py`
- `tests/test_human_intent_gatekeeper_v216.py`

## What was added

### 1. Role / authority enforcement

Added local role configuration:

- `configure_vault_roles()`
- `get_vault_roles()`
- `is_head_user_or_admin()`

Approval decisions are now blocked unless `decision_by` is the configured Head User or admin, with fallback to the approval request's Head User.

Unauthorized approval attempts are logged as `UNAUTHORIZED_APPROVAL_DECISION_BLOCKED` BlackBox events.

### 2. Rolling request window

Request pressure is now counted inside `request_window_minutes`, default 60 minutes, instead of all historical requests forever.

This makes 20/50/100/1000 meaningful as access pressure, not merely lifetime count.

### 3. Incident bundling / request collapse

Repeated requests no longer create endless normal approval objects.

At unusual/suspicious/intrusion/flood thresholds, the request stream is collapsed into a BlackBox incident bundle under:

`blackbox/incidents/`

The bundle stores:

- incident id
- vault/object/action/requester/tool family
- classification
- matching request count
- raw request ids
- current status
- summary

This preserves evidence without letting bots overload approval storage or humans.

### 4. Hash-chained BlackBox events

BlackBox events now include:

- `previous_event_hash`
- `chain_index`
- `event_hash`

The manager writes `blackbox/chain_head.json` and includes `verify_blackbox_chain()`.

This is not final cryptographic sealing, but it is no longer loose JSON. Basic tampering is visible.

### 5. Priority notification behavior

If a recipient has 5 unread low-priority alerts, a critical/intrusion alert can suppress one lower-priority unread alert so the serious warning gets through.

If the system-wide notification cap is full, critical/intrusion alerts may remove a lower-priority notification file. BlackBox remains the complete record.

### 6. Protected route gate

The following existing protected v2.1 routes now call `require_human_intent()` before custody action:

- remove from active use
- restore to active use
- release from custody
- quarantine
- promote Candidate to Prime
- export working copy

Bots/tools/AI cannot pass this gate by setting `actor_kind` to bot/tool/ai. Human actions require `human_ceremony_passed`.

## Verification

Ran compile check:

```text
python -m compileall -q iteration_wallet
compile_ok
```

Ran new v2.1.6 tests:

```text
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q tests/test_human_intent_gatekeeper_v216.py
..... [100%]
5 passed
```

Ran v2.1.5 notification tests:

```text
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q tests/test_notification_manager_v215.py
.............. [100%]
14 passed in 26.48s
```

Ran existing vault/no-delete/no-execute tests:

```text
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q tests/test_vault.py tests/test_vault_v21.py tests/test_vault_v211_improvements.py tests/test_vault_v212_no_delete_rule.py tests/test_vault_v213_no_execute_rule.py
..................................................... [100%]
53 passed in 1.87s
```

Total verified in grouped runs: 72 tests passed.

## Honest remaining limits

- Real authentication is still not implemented; role checks rely on caller/user IDs supplied by the app layer.
- Camera/liveness/email providers are not implemented here.
- Hash chaining is tamper-evident, not tamper-proof storage.
- Full route hardening still needs broader review across old v2 routes and UI affordances.
- Incident bundling is local-file based and should eventually be optimized for very large hostile floods.

## Product status

This is a stronger internal alpha of the Human Intent Gatekeeper.

v2.1.5 was the first control-layer skeleton. v2.1.6 moves the lock closer to the door.
