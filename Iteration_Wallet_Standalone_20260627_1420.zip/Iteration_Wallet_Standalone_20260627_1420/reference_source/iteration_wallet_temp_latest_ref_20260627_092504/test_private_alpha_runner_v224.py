import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from iteration_wallet.blackbox import BlackBox, BlackBoxError
from iteration_wallet.identity import LocalIdentityProvider
from iteration_wallet.notification_manager import ActorKind, NotificationManager
from iteration_wallet.vault_v21 import VaultEngine
from iteration_wallet import server


def _source(tmp_path: Path, name: str, text: str) -> Path:
    path = tmp_path / name
    path.write_text(text, encoding="utf-8")
    return path


def test_blackbox_issues_receipt_tied_to_prior_custody_event_hash(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    provider = LocalIdentityProvider(tmp_path)
    identity = provider.issue_session(
        "josie",
        "human",
        device_id="laptop-1",
        verified_methods=["human_ceremony", "typing_challenge"],
    )
    custody_event = blackbox.write_custody_event(
        "WORKING_COPY_EXPORTED",
        "candidate exported",
        project_id="project",
        section_id="section",
        file_id="file",
        state="candidate",
    )

    receipt = blackbox.issue_human_intent_receipt(
        action_key="export_working_copy",
        action_label="export working copy",
        actor_identity=identity,
        project_id="project",
        section_id="section",
        object_id="file",
        object_name="candidate.py",
        custody_state="candidate",
        result_summary="working copy exported for outside experiments",
        linked_event_hash=custody_event["event_hash"],
        linked_event_id=custody_event["event_id"],
    )

    assert receipt["receipt_type"] == "human_intent_receipt"
    assert receipt["actor_id"] == "josie"
    assert receipt["session_id"] == identity.session_id
    assert receipt["linked_blackbox_event_hash"] == custody_event["event_hash"]
    assert receipt["receipt_hash"]
    assert blackbox.verify_human_intent_receipt(receipt["receipt_id"])["ok"] is True
    assert blackbox.verify_chain()["ok"] is True

    receipt_files = list((tmp_path / "blackbox" / "receipts").glob("*.json"))
    assert len(receipt_files) == 1
    events = list(blackbox.iter_events())
    assert any(e["event_type"] == "HUMAN_INTENT_RECEIPT_ISSUED" for e in events)


def test_receipt_rejects_bot_or_human_without_intent_proof(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    provider = LocalIdentityProvider(tmp_path)
    event = blackbox.write_custody_event("FILE_STAGED_FOR_REMOVAL", "removed", file_id="file")
    bot = provider.issue_session("tool", "bot", verified_methods=["api_token"])
    unproved_human = provider.issue_session("human", "human", verified_methods=[])

    with pytest.raises(BlackBoxError):
        blackbox.issue_human_intent_receipt(
            action_key="remove_from_active",
            action_label="remove from active use",
            actor_identity=bot,
            object_id="file",
            linked_event_hash=event["event_hash"],
        )

    with pytest.raises(BlackBoxError):
        blackbox.issue_human_intent_receipt(
            action_key="remove_from_active",
            action_label="remove from active use",
            actor_identity=unproved_human,
            object_id="file",
            linked_event_hash=event["event_hash"],
        )

    assert blackbox.list_human_intent_receipts() == []


def test_receipt_tamper_detection(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    provider = LocalIdentityProvider(tmp_path)
    identity = provider.issue_session("head", "human", verified_methods=["human_ceremony"])
    event = blackbox.write_custody_event("FILE_QUARANTINED", "quarantined", file_id="file")
    receipt = blackbox.issue_human_intent_receipt(
        action_key="quarantine",
        action_label="quarantine file",
        actor_identity=identity,
        object_id="file",
        linked_event_hash=event["event_hash"],
    )
    path = tmp_path / "blackbox" / "receipts" / f"{receipt['receipt_id']}.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data["actor_id"] = "attacker"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    result = blackbox.verify_human_intent_receipt(receipt["receipt_id"])
    assert result["ok"] is False
    assert result["reason"] == "receipt hash mismatch"


def test_server_protected_remove_route_returns_human_intent_receipt(tmp_path: Path):
    old_vault = server.vault21
    old_blackbox = server.blackbox21
    old_human_access = server.human_access
    try:
        blackbox = BlackBox(tmp_path)
        server.blackbox21 = blackbox
        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox)
        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
        client = TestClient(server.app)

        project = client.post("/api/v21/projects", json={"name": "Receipt Project"}).json()
        section = client.post(f"/api/v21/projects/{project['id']}/sections", json={"name": "Core"}).json()
        src = _source(tmp_path, "candidate.txt", "receipt protected")
        candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(src), "notes": "closed note"},
        ).json()
        session = server.human_access.issue_identity_session(
            "josie",
            ActorKind.HUMAN,
            device_id="laptop-1",
            verified_methods=["human_ceremony"],
        )
        token = client.post("/api/v21/vault/open").json()["ceremony_token"]

        response = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
            json={
                "ceremony_token": token,
                "actor_kind": "human",
                "session_id": session.session_id,
                "human_ceremony_passed": True,
            },
        )

        assert response.status_code == 200, response.text
        body = response.json()
        assert body["result"]["state"] == "staging"
        receipt = body["human_intent_receipt"]
        assert receipt["action_key"] == "remove_from_active"
        assert receipt["object_id"] == candidate["id"]
        assert receipt["actor_id"] == "josie"
        assert receipt["linked_blackbox_event_hash"]
        assert receipt["receipt_hash"]
        assert "ceremony_token" not in json.dumps(receipt)
        assert blackbox.verify_human_intent_receipt(receipt["receipt_id"])["ok"] is True

        listed = client.get("/api/v21/blackbox/receipts").json()["receipts"]
        assert len(listed) == 1
        detail = client.get(f"/api/v21/blackbox/receipts/{receipt['receipt_id']}").json()
        assert detail["verification"]["ok"] is True
    finally:
        server.vault21 = old_vault
        server.blackbox21 = old_blackbox
        server.human_access = old_human_access
