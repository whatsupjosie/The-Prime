# Iteration Wallet v2.1.7 — Protected Action Registry Build Report

## Purpose

This patch implements **IW-TASK-002: Centralize protected action definitions** from the task book.

The goal is to prevent protected custody routes from drifting into scattered, route-specific checks. Every protected action must now be registered in one policy registry and evaluated through the Human Intent Gatekeeper.

Product law reinforced:

> AI may request. Humans decide. BlackBox records. Bots do not directly fetch protected custody.

## Re-verification of v2.1.6 first

Before making changes, the latest v2.1.6 package was extracted cleanly and tested:

```text
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
72 passed in 11.88s
```

This satisfied IW-TASK-001 before starting the registry task.

## Files added

```text
iteration_wallet/gatekeeper.py
tests/test_protected_action_registry_v217.py
BUILD_REPORT_v217.md
README_v217.md
DIFF_REPORT_v217.patch
```

## Files changed

```text
iteration_wallet/server.py
```

## New module: iteration_wallet/gatekeeper.py

The new module defines:

```text
ProtectedActionPolicy
ProtectedActionError
PROTECTED_ACTIONS
get_protected_action_policy()
list_protected_action_policies()
evaluate_protected_action()
require_protected_action()
```

## Registered protected actions

```text
remove_from_active
restore_to_active
release_from_custody
quarantine
promote_candidate_to_prime
export_working_copy
open_vault
open_cradle
```

Each policy defines:

```text
action_key
label
requires_human
requires_vault_open
requires_cradle_unlock
allows_bot_direct_access
requires_head_user_approval_when_configured
allowed_fallbacks
blackbox_event_type
```

## Fail-closed behavior

Unknown protected action keys now fail closed.

A route cannot invent a new protected action name and quietly bypass the registry. If a developer adds a protected route but forgets to add it to `PROTECTED_ACTIONS`, the gatekeeper raises `ProtectedActionError`.

The FastAPI helper converts that into an HTTP 500 because it is a developer/configuration error, not a user error.

## Server wiring

The v2.1 protected routes now call `require_human_intent()` using registry keys instead of free-text action labels:

```text
remove_from_active
restore_to_active
release_from_custody
quarantine
promote_candidate_to_prime
export_working_copy
```

The helper now calls `evaluate_protected_action()` from the centralized gatekeeper.

A diagnostic endpoint was added:

```text
GET /api/v21/protected-actions
```

This returns the current policy registry for UI/debug visibility.

## Tests added

New test file:

```text
tests/test_protected_action_registry_v217.py
```

It proves:

```text
all expected protected actions are registered
all expected protected actions disallow direct bot access
unknown protected action keys fail closed
bot/AI access is denied for registered protected actions
human ceremony access is allowed for registered protected actions
explicit vault closed / cradle locked state denies when supplied
server helper uses the registry and fails closed for unregistered action keys
```

## Verification

```text
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q tests/test_protected_action_registry_v217.py
5 passed in 2.24s

PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
77 passed in 13.83s
```

## Remaining limits

This patch centralizes protected action definitions and route checks. It does not yet complete IW-TASK-003.

Remaining next work:

```text
Bind actor_id/session_id/device_id to a real identity/session interface.
Use session identity instead of caller-supplied strings.
Move more BlackBox behavior into a dedicated blackbox.py module later.
Build closed catalog view and Human Intent Receipts after the gate is stable.
```

## Status

v2.1.7 completes IW-TASK-001 and IW-TASK-002 from the task book.

Next task should be:

```text
IW-TASK-003 — Bind roles to an auth/session interface
```
