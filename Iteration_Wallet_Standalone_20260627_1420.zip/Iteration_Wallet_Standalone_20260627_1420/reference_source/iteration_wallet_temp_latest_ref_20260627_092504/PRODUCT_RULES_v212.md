diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/.gitignore IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/.gitignore
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/.gitignore	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/.gitignore	2026-06-25 12:20:29.457061779 +0000
@@ -0,0 +1,2 @@
+# Created by pytest automatically.
+*
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/CACHEDIR.TAG IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/CACHEDIR.TAG
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/CACHEDIR.TAG	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/CACHEDIR.TAG	2026-06-25 12:20:29.457618627 +0000
@@ -0,0 +1,4 @@
+Signature: 8a477f597d28d172789f06886806bc55
+# This file is a cache directory tag created by pytest.
+# For information about cache directory tags, see:
+#	https://bford.info/cachedir/spec.html
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/README.md IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/README.md
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/README.md	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/README.md	2026-06-25 12:20:29.456344986 +0000
@@ -0,0 +1,8 @@
+# pytest cache directory #
+
+This directory contains data from the pytest's cache plugin,
+which provides the `--lf` and `--ff` options, as well as the `cache` fixture.
+
+**Do not** commit this to version control.
+
+See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/v/cache/nodeids IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/v/cache/nodeids
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/v/cache/nodeids	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/v/cache/nodeids	2026-06-25 12:27:31.362962269 +0000
@@ -0,0 +1,100 @@
+[
+  "tests/test_blackbox_v219.py::test_blackbox_is_standalone_module_and_notification_manager_uses_it",
+  "tests/test_blackbox_v219.py::test_server_uses_one_shared_blackbox_for_vault_and_human_access",
+  "tests/test_blackbox_v219.py::test_vault_custody_events_write_to_same_blackbox_chain",
+  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_hash_mismatch_to_blackbox",
+  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_missing_prime_to_blackbox",
+  "tests/test_ceremony_tokens_v222.py::test_scoped_ceremony_token_is_hashed_not_stored_raw_and_single_use",
+  "tests/test_ceremony_tokens_v222.py::test_server_protected_remove_requires_action_bound_token_and_consumes_it",
+  "tests/test_ceremony_tokens_v222.py::test_wrong_action_wrong_session_expired_and_lock_revoked_tokens_fail_closed",
+  "tests/test_closed_catalog_v220.py::test_closed_catalog_includes_safe_blackbox_evidence_surface",
+  "tests/test_closed_catalog_v220.py::test_closed_catalog_route_returns_safe_view",
+  "tests/test_closed_catalog_v220.py::test_closed_section_view_exposes_catalog_only_and_preserves_closed_note",
+  "tests/test_closed_catalog_v220.py::test_open_section_view_still_returns_full_records_for_authorized_open_vault",
+  "tests/test_human_intent_gatekeeper_v216.py::test_blackbox_events_are_hash_chained_and_tamper_visible",
+  "tests/test_human_intent_gatekeeper_v216.py::test_head_user_or_admin_required_for_approval_decision",
+  "tests/test_human_intent_gatekeeper_v216.py::test_intrusion_alert_can_displace_low_priority_unread_messages",
+  "tests/test_human_intent_gatekeeper_v216.py::test_repeated_requests_collapse_into_incident_bundle",
+  "tests/test_human_intent_gatekeeper_v216.py::test_request_count_uses_time_window",
+  "tests/test_human_intent_receipts_v221.py::test_blackbox_issues_receipt_tied_to_prior_custody_event_hash",
+  "tests/test_human_intent_receipts_v221.py::test_receipt_rejects_bot_or_human_without_intent_proof",
+  "tests/test_human_intent_receipts_v221.py::test_receipt_tamper_detection",
+  "tests/test_human_intent_receipts_v221.py::test_server_protected_remove_route_returns_human_intent_receipt",
+  "tests/test_identity_session_v218.py::test_approval_decision_uses_session_identity_not_arbitrary_string",
+  "tests/test_identity_session_v218.py::test_bot_session_with_head_user_id_cannot_approve_without_human_intent",
+  "tests/test_identity_session_v218.py::test_gatekeeper_accepts_human_identity_session_and_denies_bot_identity",
+  "tests/test_identity_session_v218.py::test_local_identity_session_shape_and_human_intent_methods",
+  "tests/test_identity_session_v218.py::test_server_protected_routes_require_identity_session_when_route_requests_it",
+  "tests/test_notification_manager_v215.py::test_access_request_logs_blackbox_and_sends_capped_alerts",
+  "tests/test_notification_manager_v215.py::test_approval_request_expiration_exists_and_works",
+  "tests/test_notification_manager_v215.py::test_bot_cannot_directly_access_protected_custody",
+  "tests/test_notification_manager_v215.py::test_flood_threshold_causes_emergency_lockout_with_small_config",
+  "tests/test_notification_manager_v215.py::test_head_user_approval_decision_updates_status_and_notifies_requester",
+  "tests/test_notification_manager_v215.py::test_message_length_limit_rejects_long_alert",
+  "tests/test_notification_manager_v215.py::test_per_recipient_limit_is_five_unread_messages",
+  "tests/test_notification_manager_v215.py::test_repeated_bot_requests_become_possible_intrusion_evidence",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1-RequestClassification.NORMAL]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[100-RequestClassification.PROBABLE_INTRUSION]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1000-RequestClassification.ACTIVE_FLOOD]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[20-RequestClassification.UNUSUAL_PRESSURE]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[50-RequestClassification.SUSPICIOUS_PATTERN]",
+  "tests/test_notification_manager_v215.py::test_system_limit_is_two_hundred_messages",
+  "tests/test_protected_action_registry_v217.py::test_registered_action_denies_bot_and_allows_human_ceremony",
+  "tests/test_protected_action_registry_v217.py::test_registry_state_requirements_fail_when_explicitly_false",
+  "tests/test_protected_action_registry_v217.py::test_required_protected_actions_are_registered",
+  "tests/test_protected_action_registry_v217.py::test_server_protected_helper_uses_registry_and_fails_closed",
+  "tests/test_protected_action_registry_v217.py::test_unknown_protected_action_fails_closed",
+  "tests/test_vault.py::TestAPI::test_create_project",
+  "tests/test_vault.py::TestAPI::test_error_handling",
+  "tests/test_vault.py::TestAPI::test_get_drives",
+  "tests/test_vault.py::TestAPI::test_get_events",
+  "tests/test_vault.py::TestAPI::test_get_state",
+  "tests/test_vault.py::TestAPI::test_list_projects",
+  "tests/test_vault.py::TestAPI::test_ui_served",
+  "tests/test_vault.py::TestAPI::test_vault_open_lock",
+  "tests/test_vault.py::TestCommitGuard::test_guard_initialization",
+  "tests/test_vault.py::TestCommitGuard::test_pattern_matching",
+  "tests/test_vault.py::TestIntegration::test_full_workflow",
+  "tests/test_vault.py::TestVaultEngine::test_add_file",
+  "tests/test_vault.py::TestVaultEngine::test_add_nonexistent_file",
+  "tests/test_vault.py::TestVaultEngine::test_create_project",
+  "tests/test_vault.py::TestVaultEngine::test_get_drives",
+  "tests/test_vault.py::TestVaultEngine::test_list_projects",
+  "tests/test_vault.py::TestVaultEngine::test_no_delete_method_surface",
+  "tests/test_vault.py::TestVaultEngine::test_project_duplicate_guard",
+  "tests/test_vault.py::TestVaultEngine::test_promote_version",
+  "tests/test_vault.py::TestVaultEngine::test_remove_file",
+  "tests/test_vault.py::TestVaultEngine::test_restore_file",
+  "tests/test_vault.py::TestVaultEngine::test_state_persistence",
+  "tests/test_vault.py::TestVaultEngine::test_vault_open_close",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_lock_vault_invalidates_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_no_delete_operation_surface_even_with_valid_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_open_vault_generates_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_valid_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_vault_open",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_with_valid_token",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_archives_old_prime",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_candidate_to_prime",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_requires_token",
+  "tests/test_vault_v21.py::TestSectionModel::test_add_candidate",
+  "tests/test_vault_v21.py::TestSectionModel::test_add_raw_source",
+  "tests/test_vault_v21.py::TestSectionModel::test_create_project",
+  "tests/test_vault_v21.py::TestSectionModel::test_create_section",
+  "tests/test_vault_v21.py::TestSectionView::test_section_view_shows_all_compartments",
+  "tests/test_vault_v211_improvements.py::test_export_working_copy_does_not_mutate_vault_copy",
+  "tests/test_vault_v211_improvements.py::test_removed_file_cannot_be_exported",
+  "tests/test_vault_v211_improvements.py::test_restore_from_removed_returns_candidate_to_candidates",
+  "tests/test_vault_v211_improvements.py::test_review_candidate_records_metadata_without_promoting",
+  "tests/test_vault_v211_improvements.py::test_review_rejects_invalid_verdict_and_non_candidate",
+  "tests/test_vault_v212_no_delete_rule.py::test_live_person_release_changes_custody_state_without_destroying_file",
+  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_method_exists_and_candidate_copy_is_preserved",
+  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_rule_constant_is_primary_product_law",
+  "tests/test_vault_v212_no_delete_rule.py::test_quarantine_is_isolation_not_deletion",
+  "tests/test_vault_v212_no_delete_rule.py::test_remove_still_preserves_removed_copy_and_no_delete_surface",
+  "tests/test_vault_v213_no_execute_rule.py::test_custodied_candidate_is_marked_non_executable_on_ingest",
+  "tests/test_vault_v213_no_execute_rule.py::test_export_working_copy_is_allowed_but_execution_surface_absent_in_vault",
+  "tests/test_vault_v213_no_execute_rule.py::test_external_results_attach_without_running_candidate",
+  "tests/test_vault_v213_no_execute_rule.py::test_no_execute_rule_constant_is_primary_product_law",
+  "tests/test_vault_v213_no_execute_rule.py::test_no_execution_method_surface_exists",
+  "tests/test_vault_v213_no_execute_rule.py::test_v21_api_refuses_run_execute_open_and_requires_real_release_confirmation"
+]
\ No newline at end of file
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/BUILD_REPORT_v222.md IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v222.md
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/BUILD_REPORT_v222.md	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v222.md	2026-06-25 12:28:16.887159096 +0000
@@ -0,0 +1,142 @@
+# Iteration Wallet v2.2.2 — Ceremony Token Lifecycle Hardening
+
+## Purpose
+
+v2.2.2 hardens the ceremony token layer that sits between a verified human session and protected custody actions.
+
+Before this patch, protected HTTP routes required a human identity session, but the custody token itself was still a loose Vault-open token. That was useful for early alpha work, but too reusable and too broad for the Human Intent model.
+
+This patch adds scoped ceremony tokens that are:
+
+- action-bound
+- session-bound
+- object/context-bound where supplied
+- short-lived
+- single-use
+- revoked on Vault lock
+- stored only as hashes, never as raw token secrets
+- recorded in BlackBox when issued, consumed, denied, or revoked
+
+## Files Added
+
+- `iteration_wallet/ceremony.py`
+- `tests/test_ceremony_tokens_v222.py`
+- `BUILD_REPORT_v222.md`
+- `README_v222.md`
+- `DIFF_REPORT_v222.patch`
+
+## Files Changed
+
+- `iteration_wallet/vault_v21.py`
+- `iteration_wallet/server.py`
+- `iteration_wallet/__init__.py`
+- `setup.py`
+
+## What Changed
+
+### 1. New CeremonyTokenLedger
+
+Added `CeremonyTokenLedger` in `iteration_wallet/ceremony.py`.
+
+It issues action-scoped ceremony tokens in the format:
+
+```text
+iwct_<token_id>_<secret>
+```
+
+Only the token hash is stored in `ceremony_tokens/<token_id>.json`. The raw secret is returned once and never persisted.
+
+### 2. Strict Ceremony Mode
+
+`VaultEngine` now supports:
+
+```python
+VaultEngine(root, blackbox=blackbox, strict_ceremony_tokens=True)
+```
+
+The FastAPI v2.1 server uses strict mode. Older direct engine tests keep backward-compatible behavior unless they opt into strict mode.
+
+### 3. Action-Bound Tokens
+
+Tokens are issued for a single `action_key`, such as:
+
+- `remove_from_active`
+- `restore_to_active`
+- `release_from_custody`
+- `quarantine`
+- `promote_candidate_to_prime`
+- `export_working_copy`
+
+A token issued for one action cannot be used for another.
+
+### 4. Session-Bound Tokens
+
+Tokens are bound to an identity session. A token issued for one session cannot be consumed by another session.
+
+### 5. Object/Context-Bound Tokens
+
+Tokens may be bound to:
+
+- project ID
+- section ID
+- object/file/candidate ID
+
+If those are supplied, mismatches fail closed.
+
+### 6. Single-Use Consumption
+
+Protected actions consume the token. Reusing the token fails.
+
+### 7. Expiry and Revocation
+
+Tokens expire after a short TTL, defaulting to 300 seconds and capped to a max of 900 seconds.
+
+Locking the Vault revokes unconsumed tokens associated with the current open session.
+
+### 8. API Surface
+
+Added:
+
+```text
+POST /api/v21/ceremony/tokens
+GET  /api/v21/ceremony/tokens
+POST /api/v21/ceremony/tokens/revoke
+```
+
+Protected routes now require a scoped token in strict server mode.
+
+### 9. BlackBox Evidence
+
+BlackBox records:
+
+- `CEREMONY_TOKEN_ISSUED`
+- `CEREMONY_TOKEN_CONSUMED`
+- `CEREMONY_TOKEN_DENIED`
+- `CEREMONY_TOKEN_REVOKED`
+- `CEREMONY_TOKENS_REVOKED`
+
+## Verification
+
+Clean command run:
+
+```bash
+python -m compileall -q iteration_wallet
+PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
+```
+
+Result:
+
+```text
+98 passed in 7.15s
+```
+
+## Limits Still Present
+
+- This is still a local alpha identity/session layer, not OAuth/passkey/biometric auth.
+- The raw ceremony token is shown once at issue time; secure UI handling is still future work.
+- The v2.1 direct engine keeps backward-compatible legacy open-token behavior unless strict mode is enabled.
+- Full camera/liveness challenge providers are not implemented yet.
+
+## Product Result
+
+This patch makes protected HTTP custody actions meaningfully harder to misuse. A verified human session alone is not enough; the action also needs a short-lived scoped ceremony token that matches the action, session, and object.
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/DIFF_REPORT_v222.patch IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v222.patch
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/DIFF_REPORT_v222.patch	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v222.patch	2026-06-25 12:28:16.938843577 +0000
@@ -0,0 +1,277 @@
+diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/.gitignore IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/.gitignore
+--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/.gitignore	1970-01-01 00:00:00.000000000 +0000
++++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/.gitignore	2026-06-25 12:20:29.457061779 +0000
+@@ -0,0 +1,2 @@
++# Created by pytest automatically.
++*
+diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/CACHEDIR.TAG IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/CACHEDIR.TAG
+--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/CACHEDIR.TAG	1970-01-01 00:00:00.000000000 +0000
++++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/CACHEDIR.TAG	2026-06-25 12:20:29.457618627 +0000
+@@ -0,0 +1,4 @@
++Signature: 8a477f597d28d172789f06886806bc55
++# This file is a cache directory tag created by pytest.
++# For information about cache directory tags, see:
++#	https://bford.info/cachedir/spec.html
+diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/README.md IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/README.md
+--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/README.md	1970-01-01 00:00:00.000000000 +0000
++++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/README.md	2026-06-25 12:20:29.456344986 +0000
+@@ -0,0 +1,8 @@
++# pytest cache directory #
++
++This directory contains data from the pytest's cache plugin,
++which provides the `--lf` and `--ff` options, as well as the `cache` fixture.
++
++**Do not** commit this to version control.
++
++See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.
+diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/v/cache/nodeids IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/v/cache/nodeids
+--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/.pytest_cache/v/cache/nodeids	1970-01-01 00:00:00.000000000 +0000
++++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/.pytest_cache/v/cache/nodeids	2026-06-25 12:27:31.362962269 +0000
+@@ -0,0 +1,100 @@
++[
++  "tests/test_blackbox_v219.py::test_blackbox_is_standalone_module_and_notification_manager_uses_it",
++  "tests/test_blackbox_v219.py::test_server_uses_one_shared_blackbox_for_vault_and_human_access",
++  "tests/test_blackbox_v219.py::test_vault_custody_events_write_to_same_blackbox_chain",
++  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_hash_mismatch_to_blackbox",
++  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_missing_prime_to_blackbox",
++  "tests/test_ceremony_tokens_v222.py::test_scoped_ceremony_token_is_hashed_not_stored_raw_and_single_use",
++  "tests/test_ceremony_tokens_v222.py::test_server_protected_remove_requires_action_bound_token_and_consumes_it",
++  "tests/test_ceremony_tokens_v222.py::test_wrong_action_wrong_session_expired_and_lock_revoked_tokens_fail_closed",
++  "tests/test_closed_catalog_v220.py::test_closed_catalog_includes_safe_blackbox_evidence_surface",
++  "tests/test_closed_catalog_v220.py::test_closed_catalog_route_returns_safe_view",
++  "tests/test_closed_catalog_v220.py::test_closed_section_view_exposes_catalog_only_and_preserves_closed_note",
++  "tests/test_closed_catalog_v220.py::test_open_section_view_still_returns_full_records_for_authorized_open_vault",
++  "tests/test_human_intent_gatekeeper_v216.py::test_blackbox_events_are_hash_chained_and_tamper_visible",
++  "tests/test_human_intent_gatekeeper_v216.py::test_head_user_or_admin_required_for_approval_decision",
++  "tests/test_human_intent_gatekeeper_v216.py::test_intrusion_alert_can_displace_low_priority_unread_messages",
++  "tests/test_human_intent_gatekeeper_v216.py::test_repeated_requests_collapse_into_incident_bundle",
++  "tests/test_human_intent_gatekeeper_v216.py::test_request_count_uses_time_window",
++  "tests/test_human_intent_receipts_v221.py::test_blackbox_issues_receipt_tied_to_prior_custody_event_hash",
++  "tests/test_human_intent_receipts_v221.py::test_receipt_rejects_bot_or_human_without_intent_proof",
++  "tests/test_human_intent_receipts_v221.py::test_receipt_tamper_detection",
++  "tests/test_human_intent_receipts_v221.py::test_server_protected_remove_route_returns_human_intent_receipt",
++  "tests/test_identity_session_v218.py::test_approval_decision_uses_session_identity_not_arbitrary_string",
++  "tests/test_identity_session_v218.py::test_bot_session_with_head_user_id_cannot_approve_without_human_intent",
++  "tests/test_identity_session_v218.py::test_gatekeeper_accepts_human_identity_session_and_denies_bot_identity",
++  "tests/test_identity_session_v218.py::test_local_identity_session_shape_and_human_intent_methods",
++  "tests/test_identity_session_v218.py::test_server_protected_routes_require_identity_session_when_route_requests_it",
++  "tests/test_notification_manager_v215.py::test_access_request_logs_blackbox_and_sends_capped_alerts",
++  "tests/test_notification_manager_v215.py::test_approval_request_expiration_exists_and_works",
++  "tests/test_notification_manager_v215.py::test_bot_cannot_directly_access_protected_custody",
++  "tests/test_notification_manager_v215.py::test_flood_threshold_causes_emergency_lockout_with_small_config",
++  "tests/test_notification_manager_v215.py::test_head_user_approval_decision_updates_status_and_notifies_requester",
++  "tests/test_notification_manager_v215.py::test_message_length_limit_rejects_long_alert",
++  "tests/test_notification_manager_v215.py::test_per_recipient_limit_is_five_unread_messages",
++  "tests/test_notification_manager_v215.py::test_repeated_bot_requests_become_possible_intrusion_evidence",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1-RequestClassification.NORMAL]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[100-RequestClassification.PROBABLE_INTRUSION]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1000-RequestClassification.ACTIVE_FLOOD]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[20-RequestClassification.UNUSUAL_PRESSURE]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[50-RequestClassification.SUSPICIOUS_PATTERN]",
++  "tests/test_notification_manager_v215.py::test_system_limit_is_two_hundred_messages",
++  "tests/test_protected_action_registry_v217.py::test_registered_action_denies_bot_and_allows_human_ceremony",
++  "tests/test_protected_action_registry_v217.py::test_registry_state_requirements_fail_when_explicitly_false",
++  "tests/test_protected_action_registry_v217.py::test_required_protected_actions_are_registered",
++  "tests/test_protected_action_registry_v217.py::test_server_protected_helper_uses_registry_and_fails_closed",
++  "tests/test_protected_action_registry_v217.py::test_unknown_protected_action_fails_closed",
++  "tests/test_vault.py::TestAPI::test_create_project",
++  "tests/test_vault.py::TestAPI::test_error_handling",
++  "tests/test_vault.py::TestAPI::test_get_drives",
++  "tests/test_vault.py::TestAPI::test_get_events",
++  "tests/test_vault.py::TestAPI::test_get_state",
++  "tests/test_vault.py::TestAPI::test_list_projects",
++  "tests/test_vault.py::TestAPI::test_ui_served",
++  "tests/test_vault.py::TestAPI::test_vault_open_lock",
++  "tests/test_vault.py::TestCommitGuard::test_guard_initialization",
++  "tests/test_vault.py::TestCommitGuard::test_pattern_matching",
++  "tests/test_vault.py::TestIntegration::test_full_workflow",
++  "tests/test_vault.py::TestVaultEngine::test_add_file",
++  "tests/test_vault.py::TestVaultEngine::test_add_nonexistent_file",
++  "tests/test_vault.py::TestVaultEngine::test_create_project",
++  "tests/test_vault.py::TestVaultEngine::test_get_drives",
++  "tests/test_vault.py::TestVaultEngine::test_list_projects",
++  "tests/test_vault.py::TestVaultEngine::test_no_delete_method_surface",
++  "tests/test_vault.py::TestVaultEngine::test_project_duplicate_guard",
++  "tests/test_vault.py::TestVaultEngine::test_promote_version",
++  "tests/test_vault.py::TestVaultEngine::test_remove_file",
++  "tests/test_vault.py::TestVaultEngine::test_restore_file",
++  "tests/test_vault.py::TestVaultEngine::test_state_persistence",
++  "tests/test_vault.py::TestVaultEngine::test_vault_open_close",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_lock_vault_invalidates_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_no_delete_operation_surface_even_with_valid_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_open_vault_generates_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_valid_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_vault_open",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_with_valid_token",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_archives_old_prime",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_candidate_to_prime",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_requires_token",
++  "tests/test_vault_v21.py::TestSectionModel::test_add_candidate",
++  "tests/test_vault_v21.py::TestSectionModel::test_add_raw_source",
++  "tests/test_vault_v21.py::TestSectionModel::test_create_project",
++  "tests/test_vault_v21.py::TestSectionModel::test_create_section",
++  "tests/test_vault_v21.py::TestSectionView::test_section_view_shows_all_compartments",
++  "tests/test_vault_v211_improvements.py::test_export_working_copy_does_not_mutate_vault_copy",
++  "tests/test_vault_v211_improvements.py::test_removed_file_cannot_be_exported",
++  "tests/test_vault_v211_improvements.py::test_restore_from_removed_returns_candidate_to_candidates",
++  "tests/test_vault_v211_improvements.py::test_review_candidate_records_metadata_without_promoting",
++  "tests/test_vault_v211_improvements.py::test_review_rejects_invalid_verdict_and_non_candidate",
++  "tests/test_vault_v212_no_delete_rule.py::test_live_person_release_changes_custody_state_without_destroying_file",
++  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_method_exists_and_candidate_copy_is_preserved",
++  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_rule_constant_is_primary_product_law",
++  "tests/test_vault_v212_no_delete_rule.py::test_quarantine_is_isolation_not_deletion",
++  "tests/test_vault_v212_no_delete_rule.py::test_remove_still_preserves_removed_copy_and_no_delete_surface",
++  "tests/test_vault_v213_no_execute_rule.py::test_custodied_candidate_is_marked_non_executable_on_ingest",
++  "tests/test_vault_v213_no_execute_rule.py::test_export_working_copy_is_allowed_but_execution_surface_absent_in_vault",
++  "tests/test_vault_v213_no_execute_rule.py::test_external_results_attach_without_running_candidate",
++  "tests/test_vault_v213_no_execute_rule.py::test_no_execute_rule_constant_is_primary_product_law",
++  "tests/test_vault_v213_no_execute_rule.py::test_no_execution_method_surface_exists",
++  "tests/test_vault_v213_no_execute_rule.py::test_v21_api_refuses_run_execute_open_and_requires_real_release_confirmation"
++]
+\ No newline at end of file
+diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/BUILD_REPORT_v222.md IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v222.md
+--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/BUILD_REPORT_v222.md	1970-01-01 00:00:00.000000000 +0000
++++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v222.md	2026-06-25 12:28:16.887159096 +0000
+@@ -0,0 +1,142 @@
++# Iteration Wallet v2.2.2 — Ceremony Token Lifecycle Hardening
++
++## Purpose
++
++v2.2.2 hardens the ceremony token layer that sits between a verified human session and protected custody actions.
++
++Before this patch, protected HTTP routes required a human identity session, but the custody token itself was still a loose Vault-open token. That was useful for early alpha work, but too reusable and too broad for the Human Intent model.
++
++This patch adds scoped ceremony tokens that are:
++
++- action-bound
++- session-bound
++- object/context-bound where supplied
++- short-lived
++- single-use
++- revoked on Vault lock
++- stored only as hashes, never as raw token secrets
++- recorded in BlackBox when issued, consumed, denied, or revoked
++
++## Files Added
++
++- `iteration_wallet/ceremony.py`
++- `tests/test_ceremony_tokens_v222.py`
++- `BUILD_REPORT_v222.md`
++- `README_v222.md`
++- `DIFF_REPORT_v222.patch`
++
++## Files Changed
++
++- `iteration_wallet/vault_v21.py`
++- `iteration_wallet/server.py`
++- `iteration_wallet/__init__.py`
++- `setup.py`
++
++## What Changed
++
++### 1. New CeremonyTokenLedger
++
++Added `CeremonyTokenLedger` in `iteration_wallet/ceremony.py`.
++
++It issues action-scoped ceremony tokens in the format:
++
++```text
++iwct_<token_id>_<secret>
++```
++
++Only the token hash is stored in `ceremony_tokens/<token_id>.json`. The raw secret is returned once and never persisted.
++
++### 2. Strict Ceremony Mode
++
++`VaultEngine` now supports:
++
++```python
++VaultEngine(root, blackbox=blackbox, strict_ceremony_tokens=True)
++```
++
++The FastAPI v2.1 server uses strict mode. Older direct engine tests keep backward-compatible behavior unless they opt into strict mode.
++
++### 3. Action-Bound Tokens
++
++Tokens are issued for a single `action_key`, such as:
++
++- `remove_from_active`
++- `restore_to_active`
++- `release_from_custody`
++- `quarantine`
++- `promote_candidate_to_prime`
++- `export_working_copy`
++
++A token issued for one action cannot be used for another.
++
++### 4. Session-Bound Tokens
++
++Tokens are bound to an identity session. A token issued for one session cannot be consumed by another session.
++
++### 5. Object/Context-Bound Tokens
++
++Tokens may be bound to:
++
++- project ID
++- section ID
++- object/file/candidate ID
++
++If those are supplied, mismatches fail closed.
++
++### 6. Single-Use Consumption
++
++Protected actions consume the token. Reusing the token fails.
++
++### 7. Expiry and Revocation
++
++Tokens expire after a short TTL, defaulting to 300 seconds and capped to a max of 900 seconds.
++
++Locking the Vault revokes unconsumed tokens associated with the current open session.
++
++### 8. API Surface
++
++Added:
++
++```text
++POST /api/v21/ceremony/tokens
++GET  /api/v21/ceremony/tokens
++POST /api/v21/ceremony/tokens/revoke
++```
++
++Protected routes now require a scoped token in strict server mode.
++
++### 9. BlackBox Evidence
++
++BlackBox records:
++
++- `CEREMONY_TOKEN_ISSUED`
++- `CEREMONY_TOKEN_CONSUMED`
++- `CEREMONY_TOKEN_DENIED`
++- `CEREMONY_TOKEN_REVOKED`
++- `CEREMONY_TOKENS_REVOKED`
++
++## Verification
++
++Clean command run:
++
++```bash
++python -m compileall -q iteration_wallet
++PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
++```
++
++Result:
++
++```text
++98 passed in 7.15s
++```
++
++## Limits Still Present
++
++- This is still a local alpha identity/session layer, not OAuth/passkey/biometric auth.
++- The raw ceremony token is shown once at issue time; secure UI handling is still future work.
++- The v2.1 direct engine keeps backward-compatible legacy open-token behavior unless strict mode is enabled.
++- Full camera/liveness challenge providers are not implemented yet.
++
++## Product Result
++
++This patch makes protected HTTP custody actions meaningfully harder to misuse. A verified human session alone is not enough; the action also needs a short-lived scoped ceremony token that matches the action, session, and object.
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/README_v222.md IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v222.md
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/README_v222.md	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v222.md	2026-06-25 12:28:16.908958723 +0000
@@ -0,0 +1,62 @@
+# Iteration Wallet v2.2.2 — Ceremony Token Lifecycle
+
+v2.2.2 hardens ceremony tokens for protected custody actions.
+
+## Product Rule
+
+A ceremony token is not a loose permission slip. It is a short-lived proof that a verified human session is intentionally performing one protected custody action.
+
+## New Behavior
+
+Protected server routes now require scoped ceremony tokens.
+
+A scoped token is:
+
+- tied to one action
+- tied to one identity session
+- optionally tied to project/section/object context
+- short-lived
+- single-use
+- revoked when the Vault locks
+- stored only as a hash
+- logged in BlackBox
+
+## Issue a Token
+
+```http
+POST /api/v21/ceremony/tokens
+```
+
+Payload:
+
+```json
+{
+  "action_key": "remove_from_active",
+  "session_id": "<human-session-id>",
+  "project_id": "<project-id>",
+  "section_id": "<section-id>",
+  "object_id": "<file-id>",
+  "ttl_seconds": 300
+}
+```
+
+Use the returned `ceremony_token` once in the protected action request.
+
+## Protected Actions Covered
+
+- remove from active use
+- restore to active use
+- release from custody
+- quarantine
+- promote Candidate to Prime
+- export working copy
+
+## Verification
+
+```text
+98 passed in 7.15s
+```
+
+## Next Step
+
+IW-TASK-007 should focus on full private-alpha flow testing or ceremony-token UI ergonomics, depending on the workbook priority.
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__init__.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__init__.py	2026-06-25 05:19:08.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py	2026-06-25 12:26:16.600405977 +0000
@@ -7,11 +7,11 @@
 "Feic Mo Chroí — See My Heart."
 """
 
-__version__ = "2.2.1"
+__version__ = "2.2.2"
 __author__ = "Josie Curtsey Cobbley"
 __license__ = "Proprietary"
 
-# v2.2.1 Human Intent Receipts
+# v2.2.2 Ceremony Token Lifecycle
 try:
     from .identity import ActorIdentity, IdentityError, LocalIdentityProvider
     from .blackbox import BlackBox, BlackBoxError
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/__init__.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/__init__.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/blackbox.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/blackbox.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/ceremony.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/ceremony.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/gatekeeper.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/gatekeeper.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/guard.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/guard.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/identity.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/identity.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/notification_manager.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/notification_manager.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/server.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/server.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/vault.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/vault.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/__pycache__/vault_v21.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__pycache__/vault_v21.cpython-313.pyc differ
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/ceremony.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/ceremony.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/ceremony.py	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/ceremony.py	2026-06-25 12:23:36.103594189 +0000
@@ -0,0 +1,260 @@
+"""
+Iteration Wallet v2.2.2 — Ceremony Token Lifecycle
+===================================================
+
+Action-bound ceremony tokens are short-lived, session-bound, and single-use.
+They are not receipts, passwords, or permissions by themselves. They are the
+small intentional-action proof that links a live human session to one protected
+custody action.
+
+Product law:
+- Protected custody actions must not accept a loose reusable token at the API gate.
+- Tokens are scoped to action/session/object context and expire quickly.
+- Raw token secrets are never persisted; only token hashes are stored.
+- Consumed, expired, revoked, wrong-action, wrong-session, or wrong-object tokens fail closed.
+"""
+
+from __future__ import annotations
+
+import hashlib
+import json
+import secrets
+import uuid
+from datetime import datetime, timedelta
+from pathlib import Path
+from typing import Any, Dict, List, Optional
+
+from iteration_wallet.blackbox import BlackBox
+
+
+class CeremonyTokenError(Exception):
+    """Raised for expected ceremony token lifecycle failures."""
+
+
+class CeremonyTokenLedger:
+    """File-backed ledger for scoped ceremony tokens.
+
+    Token records live under `<vault_root>/ceremony_tokens`. The raw token is
+    returned once on issue and is never written to disk. Validation recomputes
+    the hash, checks scope, and consumes the token atomically.
+    """
+
+    TOKEN_PREFIX = "iwct"
+
+    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None):
+        self.vault_root = Path(vault_root)
+        self.blackbox = blackbox
+        self.token_dir = self.vault_root / "ceremony_tokens"
+        self.token_dir.mkdir(parents=True, exist_ok=True)
+
+    @staticmethod
+    def now() -> datetime:
+        return datetime.now()
+
+    @staticmethod
+    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
+        path.parent.mkdir(parents=True, exist_ok=True)
+        tmp = path.with_suffix(path.suffix + ".tmp")
+        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
+        tmp.replace(path)
+
+    @staticmethod
+    def token_hash(raw_token: str) -> str:
+        return hashlib.sha256(str(raw_token).encode("utf-8")).hexdigest()
+
+    @classmethod
+    def parse_token_id(cls, raw_token: str) -> str:
+        parts = str(raw_token or "").split("_", 2)
+        if len(parts) != 3 or parts[0] != cls.TOKEN_PREFIX or not parts[1] or not parts[2]:
+            raise CeremonyTokenError("Invalid ceremony token format")
+        return parts[1]
+
+    def _path(self, token_id: str) -> Path:
+        return self.token_dir / f"{token_id}.json"
+
+    def _load_record(self, token_id: str) -> Dict[str, Any]:
+        path = self._path(token_id)
+        if not path.exists():
+            raise CeremonyTokenError("Unknown ceremony token")
+        try:
+            return json.loads(path.read_text(encoding="utf-8"))
+        except Exception as exc:
+            raise CeremonyTokenError(f"Unreadable ceremony token record: {exc}") from exc
+
+    def _save_record(self, record: Dict[str, Any]) -> None:
+        self._write_json_atomic(self._path(record["token_id"]), record)
+
+    def write_event(self, event_type: str, summary: str, **extra: Any) -> None:
+        if self.blackbox:
+            self.blackbox.write_event(event_type, summary, **extra)
+
+    def issue_token(
+        self,
+        *,
+        action_key: str,
+        session_id: str,
+        open_session_id: str,
+        actor_id: Optional[str] = None,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+        ttl_seconds: int = 300,
+    ) -> Dict[str, Any]:
+        if not action_key:
+            raise CeremonyTokenError("action_key is required")
+        if not session_id:
+            raise CeremonyTokenError("session_id is required")
+        if not open_session_id:
+            raise CeremonyTokenError("Vault must be open before issuing a ceremony token")
+        ttl_seconds = max(5, min(int(ttl_seconds or 300), 900))
+        issued_at = self.now()
+        expires_at = issued_at + timedelta(seconds=ttl_seconds)
+        token_id = uuid.uuid4().hex[:16]
+        secret = secrets.token_urlsafe(32)
+        raw_token = f"{self.TOKEN_PREFIX}_{token_id}_{secret}"
+        record = {
+            "token_id": token_id,
+            "token_hash": self.token_hash(raw_token),
+            "action_key": action_key,
+            "session_id": session_id,
+            "actor_id": actor_id,
+            "project_id": project_id,
+            "section_id": section_id,
+            "object_id": object_id,
+            "open_session_id": open_session_id,
+            "issued_at": issued_at.isoformat(),
+            "expires_at": expires_at.isoformat(),
+            "consumed_at": None,
+            "consumed_by_action": None,
+            "revoked_at": None,
+            "revoked_reason": None,
+        }
+        self._save_record(record)
+        self.write_event(
+            "CEREMONY_TOKEN_ISSUED",
+            f"Ceremony token issued for {action_key}",
+            token_id=token_id,
+            action_key=action_key,
+            session_id=session_id,
+            actor_id=actor_id,
+            project_id=project_id,
+            section_id=section_id,
+            file_id=object_id,
+            expires_at=record["expires_at"],
+        )
+        public = dict(record)
+        public.pop("token_hash", None)
+        public["ceremony_token"] = raw_token
+        return public
+
+    def validate_and_consume(
+        self,
+        raw_token: str,
+        *,
+        action_key: str,
+        session_id: Optional[str] = None,
+        open_session_id: Optional[str] = None,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+    ) -> Dict[str, Any]:
+        token_id = self.parse_token_id(raw_token)
+        record = self._load_record(token_id)
+        now = self.now()
+
+        def deny(reason: str) -> None:
+            self.write_event(
+                "CEREMONY_TOKEN_DENIED",
+                f"Ceremony token denied for {action_key}: {reason}",
+                token_id=token_id,
+                action_key=action_key,
+                session_id=session_id,
+                project_id=project_id,
+                section_id=section_id,
+                file_id=object_id,
+                reason=reason,
+            )
+            raise CeremonyTokenError(reason)
+
+        if record.get("token_hash") != self.token_hash(raw_token):
+            deny("Ceremony token secret mismatch")
+        if record.get("revoked_at"):
+            deny("Ceremony token has been revoked")
+        if record.get("consumed_at"):
+            deny("Ceremony token has already been used")
+        expires_at = datetime.fromisoformat(record["expires_at"])
+        if now > expires_at:
+            deny("Ceremony token has expired")
+        if record.get("action_key") != action_key:
+            deny("Ceremony token is not valid for this action")
+        if session_id and record.get("session_id") != session_id:
+            deny("Ceremony token is not valid for this identity session")
+        if open_session_id and record.get("open_session_id") != open_session_id:
+            deny("Ceremony token is not valid for the current open Vault session")
+        for key, expected in (("project_id", project_id), ("section_id", section_id), ("object_id", object_id)):
+            recorded = record.get(key)
+            if recorded is not None and expected is not None and recorded != expected:
+                deny(f"Ceremony token is not valid for this {key}")
+
+        record["consumed_at"] = now.isoformat()
+        record["consumed_by_action"] = action_key
+        self._save_record(record)
+        self.write_event(
+            "CEREMONY_TOKEN_CONSUMED",
+            f"Ceremony token consumed for {action_key}",
+            token_id=token_id,
+            action_key=action_key,
+            session_id=record.get("session_id"),
+            actor_id=record.get("actor_id"),
+            project_id=project_id or record.get("project_id"),
+            section_id=section_id or record.get("section_id"),
+            file_id=object_id or record.get("object_id"),
+        )
+        safe = dict(record)
+        safe.pop("token_hash", None)
+        return safe
+
+    def revoke_token(self, raw_token: str, reason: str = "manual revocation") -> Dict[str, Any]:
+        token_id = self.parse_token_id(raw_token)
+        record = self._load_record(token_id)
+        record["revoked_at"] = self.now().isoformat()
+        record["revoked_reason"] = reason
+        self._save_record(record)
+        self.write_event("CEREMONY_TOKEN_REVOKED", f"Ceremony token revoked: {reason}", token_id=token_id, action_key=record.get("action_key"))
+        safe = dict(record)
+        safe.pop("token_hash", None)
+        return safe
+
+    def revoke_for_open_session(self, open_session_id: str, reason: str = "vault locked") -> int:
+        if not open_session_id:
+            return 0
+        count = 0
+        for path in self.token_dir.glob("*.json"):
+            try:
+                record = json.loads(path.read_text(encoding="utf-8"))
+            except Exception:
+                continue
+            if record.get("open_session_id") != open_session_id:
+                continue
+            if record.get("consumed_at") or record.get("revoked_at"):
+                continue
+            record["revoked_at"] = self.now().isoformat()
+            record["revoked_reason"] = reason
+            self._save_record(record)
+            count += 1
+        if count:
+            self.write_event("CEREMONY_TOKENS_REVOKED", f"{count} ceremony token(s) revoked: {reason}", open_session_id=open_session_id, count=count)
+        return count
+
+    def list_tokens(self, *, include_hashes: bool = False) -> List[Dict[str, Any]]:
+        records: List[Dict[str, Any]] = []
+        for path in self.token_dir.glob("*.json"):
+            try:
+                record = json.loads(path.read_text(encoding="utf-8"))
+            except Exception:
+                continue
+            if not include_hashes:
+                record.pop("token_hash", None)
+            records.append(record)
+        records.sort(key=lambda r: (r.get("issued_at", ""), r.get("token_id", "")))
+        return records
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/server.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/server.py	2026-06-25 05:18:56.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py	2026-06-25 12:25:29.906951554 +0000
@@ -267,7 +267,7 @@
 
 _v21_root = Path.home() / ".iteration_wallet_v21"
 blackbox21 = BlackBox(_v21_root)
-vault21 = VaultEngineV21(_v21_root, blackbox=blackbox21)
+vault21 = VaultEngineV21(_v21_root, blackbox=blackbox21, strict_ceremony_tokens=True)
 human_access = NotificationManager(_v21_root, blackbox=blackbox21)
 
 class CreateSectionRequest(BaseModel):
@@ -302,6 +302,7 @@
 
 class ExportWorkingCopyRequest(BaseModel):
     output_dir: str
+    ceremony_token: str
     actor_kind: Optional[str] = "human"
     actor_id: Optional[str] = None
     session_id: Optional[str] = None
@@ -373,6 +374,18 @@
     source: Optional[str] = "external"
     artifacts: Optional[List[str]] = []
 
+class CeremonyTokenIssueRequest(BaseModel):
+    action_key: str
+    session_id: str
+    project_id: Optional[str] = None
+    section_id: Optional[str] = None
+    object_id: Optional[str] = None
+    ttl_seconds: Optional[int] = 300
+
+class CeremonyTokenRevokeRequest(BaseModel):
+    ceremony_token: str
+    reason: Optional[str] = "manual revocation"
+
 @app.get("/api/v21/state")
 async def v21_state():
     return vault21.get_state()
@@ -459,11 +472,44 @@
     await notify("v21_vault_locked")
     return result
 
+@app.post("/api/v21/ceremony/tokens", status_code=201)
+async def v222_issue_ceremony_token(req: CeremonyTokenIssueRequest):
+    try:
+        identity = human_access.require_identity_session(req.session_id)
+        if not identity.has_human_intent_proof():
+            raise HTTPException(403, "Ceremony token requires a human identity session with intent proof.")
+        result = vault21.issue_ceremony_token(
+            req.action_key,
+            req.session_id,
+            actor_id=identity.actor_id,
+            project_id=req.project_id,
+            section_id=req.section_id,
+            object_id=req.object_id,
+            ttl_seconds=req.ttl_seconds or 300,
+        )
+        await notify("v222_ceremony_token_issued")
+        return result
+    except VaultErrorV21 as e:
+        raise HTTPException(400, str(e))
+    except IdentityError as e:
+        raise HTTPException(403, f"Valid identity session required: {e}")
+
+@app.get("/api/v21/ceremony/tokens")
+async def v222_list_ceremony_tokens():
+    return {"tokens": vault21.list_ceremony_tokens()}
+
+@app.post("/api/v21/ceremony/tokens/revoke")
+async def v222_revoke_ceremony_token(req: CeremonyTokenRevokeRequest):
+    try:
+        return vault21.revoke_ceremony_token(req.ceremony_token, reason=req.reason or "manual revocation")
+    except VaultErrorV21 as e:
+        raise HTTPException(400, str(e))
+
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/remove")
 async def v21_remove_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
         decision = require_human_intent("remove_from_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        record = vault21.remove_file(project_id, section_id, file_id, req.ceremony_token)
+        record = vault21.remove_file(project_id, section_id, file_id, req.ceremony_token, session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="remove_from_active",
@@ -482,7 +528,7 @@
 async def v21_restore_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
         decision = require_human_intent("restore_to_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        record = vault21.restore_file(project_id, section_id, file_id, req.ceremony_token)
+        record = vault21.restore_file(project_id, section_id, file_id, req.ceremony_token, session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="restore_to_active",
@@ -510,7 +556,7 @@
         if (req.confirmation or "") != "RELEASE":
             raise VaultErrorV21("Release from custody requires you to type RELEASE confirmation.")
         decision = require_human_intent("release_from_custody", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        record = vault21.release_from_custody(project_id, section_id, file_id, req.ceremony_token, req.confirmation or '')
+        record = vault21.release_from_custody(project_id, section_id, file_id, req.ceremony_token, req.confirmation or '', session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="release_from_custody",
@@ -529,7 +575,7 @@
 async def v21_quarantine_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
         decision = require_human_intent("quarantine", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        record = vault21.quarantine_file(project_id, section_id, file_id, req.ceremony_token, reason="manual quarantine")
+        record = vault21.quarantine_file(project_id, section_id, file_id, req.ceremony_token, reason="manual quarantine", session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="quarantine",
@@ -566,7 +612,7 @@
 async def v21_promote_candidate(project_id: str, section_id: str, candidate_id: str, req: PromotePrimeRequest):
     try:
         decision = require_human_intent("promote_candidate_to_prime", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        record = vault21.promote_to_prime(project_id, section_id, candidate_id, req.ceremony_token, req.reason or "")
+        record = vault21.promote_to_prime(project_id, section_id, candidate_id, req.ceremony_token, req.reason or "", session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="promote_candidate_to_prime",
@@ -585,7 +631,7 @@
 async def v21_export_working_copy(project_id: str, section_id: str, file_id: str, req: ExportWorkingCopyRequest):
     try:
         decision = require_human_intent("export_working_copy", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
-        result = vault21.export_working_copy(project_id, section_id, file_id, req.output_dir)
+        result = vault21.export_working_copy(project_id, section_id, file_id, req.output_dir, ceremony_token=req.ceremony_token, session_id=req.session_id)
         receipt = issue_human_intent_receipt(
             decision=decision,
             action_key="export_working_copy",
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/vault_v21.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/vault_v21.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/iteration_wallet/vault_v21.py	2026-06-25 03:20:02.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/vault_v21.py	2026-06-25 12:25:02.556799222 +0000
@@ -43,6 +43,7 @@
 from typing import Any, Dict, Optional, List
 
 from iteration_wallet.blackbox import BlackBox
+from iteration_wallet.ceremony import CeremonyTokenLedger, CeremonyTokenError
 
 
 NO_DELETE_RULE = "Iteration Wallet never deletes user-custodied material. Use REMOVE, QUARANTINE/BAN, or live-person RELEASE from custody instead."
@@ -61,18 +62,23 @@
     live-person custody ceremonies, and the hard no-delete rule.
     """
 
-    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None):
+    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None, *, strict_ceremony_tokens: bool = False, ceremony_token_ttl_seconds: int = 300):
         self.root = Path(vault_root)
         self.state_file = self.root / "state_v21.json"
         self.root.mkdir(parents=True, exist_ok=True)
         self.blackbox = blackbox
+        self.strict_ceremony_tokens = bool(strict_ceremony_tokens)
+        self.ceremony_token_ttl_seconds = max(5, min(int(ceremony_token_ttl_seconds or 300), 900))
+        self.ceremony_ledger = CeremonyTokenLedger(self.root, blackbox=blackbox)
         self._is_open = False
         self._ceremony_token: Optional[str] = None
+        self._open_session_id: Optional[str] = None
         self._state: Dict[str, Any] = self._load()
 
     def attach_blackbox(self, blackbox: BlackBox) -> None:
         """Attach shared BlackBox evidence writer after construction."""
         self.blackbox = blackbox
+        self.ceremony_ledger.blackbox = blackbox
 
     # ─── persistence ──────────────────────────────────────────────────────
 
@@ -221,10 +227,52 @@
         shutil.copy2(src, dst)
         return dst
 
-    def _require_open_token(self, token: str) -> None:
+    def _require_open_token(
+        self,
+        token: str,
+        *,
+        action_key: Optional[str] = None,
+        session_id: Optional[str] = None,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+        consume: bool = False,
+    ) -> None:
         if not self._is_open:
             raise VaultError("Vault must be open")
+        # In strict mode, protected custody actions must use scoped action tokens.
+        if action_key and self.strict_ceremony_tokens:
+            try:
+                self.ceremony_ledger.validate_and_consume(
+                    token,
+                    action_key=action_key,
+                    session_id=session_id,
+                    open_session_id=self._open_session_id,
+                    project_id=project_id,
+                    section_id=section_id,
+                    object_id=object_id,
+                )
+                return
+            except CeremonyTokenError as exc:
+                raise VaultError(str(exc)) from exc
+        # Backward-compatible engine-level token path for older direct tests and
+        # local private-alpha callers. Server routes use strict mode.
         if not token or token != self._ceremony_token:
+            # Non-strict callers may still pass a scoped token; validate it if an action was supplied.
+            if action_key:
+                try:
+                    self.ceremony_ledger.validate_and_consume(
+                        token,
+                        action_key=action_key,
+                        session_id=session_id,
+                        open_session_id=self._open_session_id,
+                        project_id=project_id,
+                        section_id=section_id,
+                        object_id=object_id,
+                    )
+                    return
+                except CeremonyTokenError:
+                    pass
             raise VaultError("Invalid ceremony token")
 
     # ─── lookup ───────────────────────────────────────────────────────────
@@ -294,14 +342,63 @@
     def open_vault(self) -> Dict[str, Any]:
         self._is_open = True
         self._ceremony_token = secrets.token_urlsafe(24)
-        self._log("VAULT_OPENED", "Vault opened; ceremony token issued")
-        return {"is_open": True, "ceremony_token": self._ceremony_token}
+        self._open_session_id = uuid.uuid4().hex[:16]
+        self._log("VAULT_OPENED", "Vault opened; open session started")
+        return {
+            "is_open": True,
+            "ceremony_token": self._ceremony_token,
+            "open_session_id": self._open_session_id,
+            "strict_ceremony_tokens": self.strict_ceremony_tokens,
+        }
 
     def lock_vault(self) -> Dict[str, Any]:
+        revoked = self.ceremony_ledger.revoke_for_open_session(self._open_session_id or "", reason="vault locked")
         self._is_open = False
         self._ceremony_token = None
-        self._log("VAULT_LOCKED", "Vault locked; ceremony token invalidated")
-        return {"is_open": False}
+        self._open_session_id = None
+        self._log("VAULT_LOCKED", "Vault locked; ceremony tokens invalidated", revoked_tokens=revoked)
+        return {"is_open": False, "revoked_ceremony_tokens": revoked}
+
+    def issue_ceremony_token(
+        self,
+        action_key: str,
+        session_id: str,
+        *,
+        actor_id: Optional[str] = None,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+        ttl_seconds: Optional[int] = None,
+    ) -> Dict[str, Any]:
+        """Issue a short-lived action/session-bound ceremony token.
+
+        The raw token is returned once and never persisted. The token is scoped
+        to one protected action and consumed by that action.
+        """
+        if not self._is_open or not self._open_session_id:
+            raise VaultError("Vault must be open before issuing a ceremony token")
+        try:
+            return self.ceremony_ledger.issue_token(
+                action_key=action_key,
+                session_id=session_id,
+                actor_id=actor_id,
+                project_id=project_id,
+                section_id=section_id,
+                object_id=object_id,
+                open_session_id=self._open_session_id,
+                ttl_seconds=ttl_seconds or self.ceremony_token_ttl_seconds,
+            )
+        except CeremonyTokenError as exc:
+            raise VaultError(str(exc)) from exc
+
+    def revoke_ceremony_token(self, ceremony_token: str, reason: str = "manual revocation") -> Dict[str, Any]:
+        try:
+            return self.ceremony_ledger.revoke_token(ceremony_token, reason=reason)
+        except CeremonyTokenError as exc:
+            raise VaultError(str(exc)) from exc
+
+    def list_ceremony_tokens(self) -> List[Dict[str, Any]]:
+        return self.ceremony_ledger.list_tokens(include_hashes=False)
 
     # ─── adding materials ─────────────────────────────────────────────────
 
@@ -365,8 +462,8 @@
 
     # ─── removal / release / quarantine ceremony ──────────────────────────
 
-    def remove_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str) -> Dict[str, Any]:
-        self._require_open_token(ceremony_token)
+    def remove_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str, session_id: Optional[str] = None) -> Dict[str, Any]:
+        self._require_open_token(ceremony_token, action_key="remove_from_active", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
         record = self._find_file(project_id, section_id, file_id)
         if record.get("released"):
             raise VaultError("File has been released from Iteration Wallet custody")
@@ -400,6 +497,7 @@
         file_id: str,
         ceremony_token: str,
         human_confirmation: str,
+        session_id: Optional[str] = None,
     ) -> Dict[str, Any]:
         """Live-person release from Iteration Wallet custody.
 
@@ -407,9 +505,9 @@
         into the released compartment with a manifest state change. A human must
         explicitly type RELEASE. Iteration Wallet never deletes the file.
         """
-        self._require_open_token(ceremony_token)
         if human_confirmation != "RELEASE":
             raise VaultError("Release requires live-person confirmation: type RELEASE")
+        self._require_open_token(ceremony_token, action_key="release_from_custody", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
         record = self._find_file(project_id, section_id, file_id)
         if record.get("state") == "prime":
             raise VaultError("Prime cannot be released directly; relieve it from the Cradle first")
@@ -439,9 +537,10 @@
         ceremony_token: str,
         reason: str = "",
         ban: bool = False,
+        session_id: Optional[str] = None,
     ) -> Dict[str, Any]:
         """Isolate an item and refuse to open/run/use it. No destruction."""
-        self._require_open_token(ceremony_token)
+        self._require_open_token(ceremony_token, action_key="quarantine", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
         record = self._find_file(project_id, section_id, file_id)
         if record.get("state") == "prime":
             raise VaultError("Prime cannot be quarantined directly; relieve it from the Cradle first")
@@ -474,8 +573,9 @@
         candidate_id: str,
         ceremony_token: str,
         reason: str = "",
+        session_id: Optional[str] = None,
     ) -> Dict[str, Any]:
-        self._require_open_token(ceremony_token)
+        self._require_open_token(ceremony_token, action_key="promote_candidate_to_prime", session_id=session_id, project_id=project_id, section_id=section_id, object_id=candidate_id, consume=True)
         section = self.get_section(project_id, section_id)
         candidate = self._find_file(project_id, section_id, candidate_id)
         if candidate.get("state") not in ("candidate", "raw"):
@@ -522,13 +622,13 @@
 
 
 
-    def restore_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str) -> Dict[str, Any]:
+    def restore_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str, session_id: Optional[str] = None) -> Dict[str, Any]:
         """Restore a staged Removed file back to its previous compartment.
 
         Removed is a reversible staging area. Iteration Wallet has no DELETE step.
         Prime is not normally removable, so restore targets raw/candidate/archive.
         """
-        self._require_open_token(ceremony_token)
+        self._require_open_token(ceremony_token, action_key="restore_to_active", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
         record = self._find_file(project_id, section_id, file_id)
         if record.get("state") != "staging":
             raise VaultError("Only files in Removed staging can be restored")
@@ -594,12 +694,14 @@
         self._log("CANDIDATE_REVIEWED", f"{candidate['name']} reviewed: {verdict}", project_id=project_id, section_id=section_id, file_id=candidate_id, verdict=verdict)
         return review
 
-    def export_working_copy(self, project_id: str, section_id: str, file_id: str, output_dir: str) -> Dict[str, Any]:
+    def export_working_copy(self, project_id: str, section_id: str, file_id: str, output_dir: str, ceremony_token: Optional[str] = None, session_id: Optional[str] = None) -> Dict[str, Any]:
         """Copy a vault-held file out to a workspace/sandbox without mutating custody.
 
         This is how experiments leave the clean-room storage. The Vault keeps its
         controlled copy; the user gets a working copy elsewhere.
         """
+        if self.strict_ceremony_tokens:
+            self._require_open_token(ceremony_token or "", action_key="export_working_copy", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
         record = self._find_file(project_id, section_id, file_id)
         if record.get("state") in ("staging", "released", "quarantined", "banned"):
             raise VaultError("Cannot export a Removed, released, quarantined, or banned file")
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/setup.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/setup.py	2026-06-25 05:19:08.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py	2026-06-25 12:26:00.139781120 +0000
@@ -10,7 +10,7 @@
 
 setup(
     name="iteration-wallet",
-    version="2.2.1",
+    version="2.2.2",
     description="Cross-platform project vault for AI developers",
     long_description=long_description,
     long_description_content_type="text/markdown",
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/__init__.cpython-313.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/__init__.cpython-313.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_blackbox_v219.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_blackbox_v219.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_ceremony_tokens_v222.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_ceremony_tokens_v222.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_closed_catalog_v220.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_closed_catalog_v220.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_human_intent_gatekeeper_v216.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_human_intent_gatekeeper_v216.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_identity_session_v218.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_identity_session_v218.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_notification_manager_v215.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_notification_manager_v215.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_protected_action_registry_v217.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_protected_action_registry_v217.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_vault.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_vault.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_vault_v21.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_vault_v21.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_vault_v211_improvements.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_vault_v211_improvements.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_vault_v212_no_delete_rule.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_vault_v212_no_delete_rule.cpython-313-pytest-9.0.2.pyc differ
Binary files iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/__pycache__/test_vault_v213_no_execute_rule.cpython-313-pytest-9.0.2.pyc and IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/__pycache__/test_vault_v213_no_execute_rule.cpython-313-pytest-9.0.2.pyc differ
diff -ruN iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/test_ceremony_tokens_v222.py IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_ceremony_tokens_v222.py
--- iw222_original/IterationWallet_v2_2_1_HUMAN_INTENT_RECEIPTS_PATCH/tests/test_ceremony_tokens_v222.py	1970-01-01 00:00:00.000000000 +0000
+++ IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_ceremony_tokens_v222.py	2026-06-25 12:26:59.926977730 +0000
@@ -0,0 +1,181 @@
+import json
+import time
+from pathlib import Path
+
+import pytest
+from fastapi.testclient import TestClient
+
+from iteration_wallet.blackbox import BlackBox
+from iteration_wallet.ceremony import CeremonyTokenError, CeremonyTokenLedger
+from iteration_wallet.notification_manager import ActorKind, NotificationManager
+from iteration_wallet.vault_v21 import VaultEngine, VaultError
+from iteration_wallet import server
+
+
+def _source(tmp_path: Path, name: str = "candidate.txt", text: str = "candidate") -> Path:
+    p = tmp_path / name
+    p.write_text(text, encoding="utf-8")
+    return p
+
+
+def _strict_vault_with_candidate(tmp_path: Path):
+    blackbox = BlackBox(tmp_path)
+    vault = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True, ceremony_token_ttl_seconds=60)
+    project = vault.create_project("Ceremony Project")
+    section = vault.create_section(project["id"], "Core")
+    candidate = vault.add_candidate(project["id"], section["id"], str(_source(tmp_path)))
+    vault.open_vault()
+    return blackbox, vault, project, section, candidate
+
+
+def test_scoped_ceremony_token_is_hashed_not_stored_raw_and_single_use(tmp_path: Path):
+    blackbox, vault, project, section, candidate = _strict_vault_with_candidate(tmp_path)
+    token = vault.issue_ceremony_token(
+        "remove_from_active",
+        "session-1",
+        actor_id="josie",
+        project_id=project["id"],
+        section_id=section["id"],
+        object_id=candidate["id"],
+    )
+    raw = token["ceremony_token"]
+    token_file = tmp_path / "ceremony_tokens" / f"{token['token_id']}.json"
+    stored = token_file.read_text(encoding="utf-8")
+    assert raw not in stored
+    assert "token_hash" in json.loads(stored)
+
+    removed = vault.remove_file(project["id"], section["id"], candidate["id"], raw, session_id="session-1")
+    assert removed["state"] == "staging"
+
+    with pytest.raises(VaultError, match="already been used"):
+        vault.remove_file(project["id"], section["id"], candidate["id"], raw, session_id="session-1")
+
+    event_types = [e["event_type"] for e in blackbox.iter_events()]
+    assert "CEREMONY_TOKEN_ISSUED" in event_types
+    assert "CEREMONY_TOKEN_CONSUMED" in event_types
+
+
+def test_wrong_action_wrong_session_expired_and_lock_revoked_tokens_fail_closed(tmp_path: Path):
+    blackbox, vault, project, section, candidate = _strict_vault_with_candidate(tmp_path)
+    token = vault.issue_ceremony_token(
+        "remove_from_active",
+        "session-1",
+        actor_id="josie",
+        project_id=project["id"],
+        section_id=section["id"],
+        object_id=candidate["id"],
+    )["ceremony_token"]
+
+    with pytest.raises(VaultError, match="not valid for this action"):
+        vault.quarantine_file(project["id"], section["id"], candidate["id"], token, session_id="session-1")
+    with pytest.raises(VaultError, match="not valid for this identity session"):
+        vault.remove_file(project["id"], section["id"], candidate["id"], token, session_id="session-2")
+
+    short = vault.issue_ceremony_token(
+        "remove_from_active",
+        "session-1",
+        actor_id="josie",
+        project_id=project["id"],
+        section_id=section["id"],
+        object_id=candidate["id"],
+        ttl_seconds=5,
+    )["ceremony_token"]
+    rec = vault.ceremony_ledger._load_record(CeremonyTokenLedger.parse_token_id(short))
+    rec["expires_at"] = "2000-01-01T00:00:00"
+    vault.ceremony_ledger._save_record(rec)
+    with pytest.raises(VaultError, match="expired"):
+        vault.remove_file(project["id"], section["id"], candidate["id"], short, session_id="session-1")
+
+    live = vault.issue_ceremony_token(
+        "remove_from_active",
+        "session-1",
+        actor_id="josie",
+        project_id=project["id"],
+        section_id=section["id"],
+        object_id=candidate["id"],
+    )["ceremony_token"]
+    vault.lock_vault()
+    vault.open_vault()
+    with pytest.raises(VaultError, match="revoked"):
+        vault.remove_file(project["id"], section["id"], candidate["id"], live, session_id="session-1")
+
+    assert any(e["event_type"] == "CEREMONY_TOKEN_DENIED" for e in blackbox.iter_events())
+    assert blackbox.verify_chain()["ok"] is True
+
+
+def test_server_protected_remove_requires_action_bound_token_and_consumes_it(tmp_path: Path):
+    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
+    try:
+        blackbox = BlackBox(tmp_path)
+        server.blackbox21 = blackbox
+        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
+        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
+        client = TestClient(server.app)
+
+        project = client.post("/api/v21/projects", json={"name": "API Ceremony"}).json()
+        section = client.post(f"/api/v21/projects/{project['id']}/sections", json={"name": "Core"}).json()
+        src = _source(tmp_path, "api_candidate.txt", "api")
+        candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(src), "notes": "api note"},
+        ).json()
+        session = server.human_access.issue_identity_session(
+            "josie",
+            ActorKind.HUMAN,
+            verified_methods=["human_ceremony", "typing_challenge"],
+        )
+        client.post("/api/v21/vault/open")
+
+        loose = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
+            json={
+                "ceremony_token": "not-a-scoped-token",
+                "actor_kind": "human",
+                "session_id": session.session_id,
+                "human_ceremony_passed": True,
+            },
+        )
+        assert loose.status_code == 400
+
+        issued = client.post(
+            "/api/v21/ceremony/tokens",
+            json={
+                "action_key": "remove_from_active",
+                "session_id": session.session_id,
+                "project_id": project["id"],
+                "section_id": section["id"],
+                "object_id": candidate["id"],
+                "ttl_seconds": 300,
+            },
+        )
+        assert issued.status_code == 201, issued.text
+        token = issued.json()["ceremony_token"]
+
+        ok = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
+            json={
+                "ceremony_token": token,
+                "actor_kind": "human",
+                "session_id": session.session_id,
+                "human_ceremony_passed": True,
+            },
+        )
+        assert ok.status_code == 200, ok.text
+        body = ok.json()
+        assert body["result"]["state"] == "staging"
+        assert body["human_intent_receipt"]["action_key"] == "remove_from_active"
+        assert "ceremony_token" not in json.dumps(body["human_intent_receipt"])
+
+        reused = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
+            json={
+                "ceremony_token": token,
+                "actor_kind": "human",
+                "session_id": session.session_id,
+                "human_ceremony_passed": True,
+            },
+        )
+        assert reused.status_code == 400
+        assert "already been used" in reused.text
+    finally:
+        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human
