diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md	1970-01-01 00:00:00.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md	2026-06-25 16:26:15.255464564 +0000
@@ -0,0 +1,124 @@
+# Iteration Wallet v2.2.3 Build Report
+## Private Alpha Flow + Integration Polish
+
+## Goal
+
+Implement the next workbook step in a safe two-part shape:
+
+1. Build a real private-alpha end-to-end flow test.
+2. Fix or polish integration seams revealed by that flow.
+
+The patch intentionally avoids feature stacking. It does not begin Oubliette, camera/liveness, hardware keys, or email. It proves the current Iteration Wallet path works coherently.
+
+## Implemented
+
+### 1. Private-alpha flow test
+
+Added:
+
+```text
+tests/test_private_alpha_flow_v223.py
+```
+
+The test exercises the real FastAPI route layer and proves:
+
+- Project and Section creation work.
+- Raw Sources and Candidates can enter custody.
+- Closed catalog view exposes safe metadata only.
+- Human identity sessions with intent proof work.
+- Strict ceremony-token mode is active.
+- Action-bound ceremony tokens are issued and raw secrets are not exposed in token listing.
+- Candidate promotion to Prime works and produces a Human Intent Receipt.
+- Working copy export works and produces a Human Intent Receipt.
+- Remove and restore work without deletion and produce receipts.
+- Quarantine works without deletion and produces a receipt.
+- Release from custody requires explicit RELEASE confirmation and produces a receipt.
+- Receipt verification passes for every receipt in the flow.
+- BlackBox chain verification passes after all events.
+- Custody integrity verification passes after all operations.
+- Locking the Vault returns section view to closed catalog mode.
+- Closed catalog does not leak protected fields after work has happened.
+
+### 2. Private-alpha status endpoint
+
+Added:
+
+```text
+GET /api/v21/private-alpha/status
+```
+
+This endpoint is status-only. It does not unlock custody or expose secrets.
+
+It reports:
+
+- version
+- strict ceremony token status
+- current Vault open/closed state
+- BlackBox chain status
+- custody integrity status
+- receipt count
+- receipt report chain status
+- protected action count
+- protected action registry
+- ready_for_private_alpha_flow
+
+### 3. Version update
+
+Updated package version to:
+
+```text
+2.2.3
+```
+
+## Verification
+
+Commands run:
+
+```bash
+python -m compileall -q iteration_wallet
+PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
+```
+
+Result:
+
+```text
+100 passed in 4.56s
+```
+
+## Files changed
+
+```text
+iteration_wallet/server.py
+iteration_wallet/__init__.py
+setup.py
+tests/test_private_alpha_flow_v223.py
+README_v223.md
+BUILD_REPORT_v223.md
+DIFF_REPORT_v223.patch
+```
+
+## Known limits
+
+- Real authentication is still local session binding, not a production identity provider.
+- Oubliette external-lab workflow is not implemented yet.
+- Camera/liveness and read-aloud verification are still future work.
+- Hash chaining remains local tamper-evident storage, not external cryptographic sealing.
+- UI does not yet expose the full private-alpha flow cleanly.
+
+## Next recommended step
+
+Move to the next workbook section only after preserving this test as the regression spine.
+
+Recommended next patch:
+
+```text
+v2.2.4 — Private Alpha Flow Runner / Developer Script
+```
+
+or, if prioritizing product behavior over tooling:
+
+```text
+v2.2.4 — Oubliette Export-Lab-Reimport Adapter Inventory
+```
+
+The safer next move is likely a developer script that runs the proven private-alpha flow outside pytest and produces a human-readable report, because that will help unfamiliar builders prove the system before changing it.
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md	2026-06-25 05:20:06.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md	2026-06-25 16:26:17.150881294 +0000
@@ -192,3 +192,13 @@
 - Added receipt verification, listing, detail, and report APIs.
 - Added tests for receipt creation, bot rejection, human-without-proof rejection, tamper detection, route integration, and token non-leakage.
 - Verified: 95 passed.
+
+## v2.2.3 — Private Alpha Flow + Integration Polish
+
+- Added full private-alpha end-to-end API flow test.
+- Added `/api/v21/private-alpha/status` readiness endpoint.
+- Proved closed catalog privacy before and after protected custody work.
+- Proved human identity sessions, scoped ceremony tokens, receipts, custody integrity, and BlackBox chain verification work together.
+- Updated version to 2.2.3.
+- Verified: 100 passed.
+
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v223.patch iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v223.patch
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v223.patch	1970-01-01 00:00:00.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/DIFF_REPORT_v223.patch	2026-06-25 16:26:40.146142060 +0000
@@ -0,0 +1,145 @@
+diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md
+--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md	1970-01-01 00:00:00.000000000 +0000
++++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/BUILD_REPORT_v223.md	2026-06-25 16:26:15.255464564 +0000
+@@ -0,0 +1,124 @@
++# Iteration Wallet v2.2.3 Build Report
++## Private Alpha Flow + Integration Polish
++
++## Goal
++
++Implement the next workbook step in a safe two-part shape:
++
++1. Build a real private-alpha end-to-end flow test.
++2. Fix or polish integration seams revealed by that flow.
++
++The patch intentionally avoids feature stacking. It does not begin Oubliette, camera/liveness, hardware keys, or email. It proves the current Iteration Wallet path works coherently.
++
++## Implemented
++
++### 1. Private-alpha flow test
++
++Added:
++
++```text
++tests/test_private_alpha_flow_v223.py
++```
++
++The test exercises the real FastAPI route layer and proves:
++
++- Project and Section creation work.
++- Raw Sources and Candidates can enter custody.
++- Closed catalog view exposes safe metadata only.
++- Human identity sessions with intent proof work.
++- Strict ceremony-token mode is active.
++- Action-bound ceremony tokens are issued and raw secrets are not exposed in token listing.
++- Candidate promotion to Prime works and produces a Human Intent Receipt.
++- Working copy export works and produces a Human Intent Receipt.
++- Remove and restore work without deletion and produce receipts.
++- Quarantine works without deletion and produces a receipt.
++- Release from custody requires explicit RELEASE confirmation and produces a receipt.
++- Receipt verification passes for every receipt in the flow.
++- BlackBox chain verification passes after all events.
++- Custody integrity verification passes after all operations.
++- Locking the Vault returns section view to closed catalog mode.
++- Closed catalog does not leak protected fields after work has happened.
++
++### 2. Private-alpha status endpoint
++
++Added:
++
++```text
++GET /api/v21/private-alpha/status
++```
++
++This endpoint is status-only. It does not unlock custody or expose secrets.
++
++It reports:
++
++- version
++- strict ceremony token status
++- current Vault open/closed state
++- BlackBox chain status
++- custody integrity status
++- receipt count
++- receipt report chain status
++- protected action count
++- protected action registry
++- ready_for_private_alpha_flow
++
++### 3. Version update
++
++Updated package version to:
++
++```text
++2.2.3
++```
++
++## Verification
++
++Commands run:
++
++```bash
++python -m compileall -q iteration_wallet
++PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
++```
++
++Result:
++
++```text
++100 passed in 4.56s
++```
++
++## Files changed
++
++```text
++iteration_wallet/server.py
++iteration_wallet/__init__.py
++setup.py
++tests/test_private_alpha_flow_v223.py
++README_v223.md
++BUILD_REPORT_v223.md
++DIFF_REPORT_v223.patch
++```
++
++## Known limits
++
++- Real authentication is still local session binding, not a production identity provider.
++- Oubliette external-lab workflow is not implemented yet.
++- Camera/liveness and read-aloud verification are still future work.
++- Hash chaining remains local tamper-evident storage, not external cryptographic sealing.
++- UI does not yet expose the full private-alpha flow cleanly.
++
++## Next recommended step
++
++Move to the next workbook section only after preserving this test as the regression spine.
++
++Recommended next patch:
++
++```text
++v2.2.4 — Private Alpha Flow Runner / Developer Script
++```
++
++or, if prioritizing product behavior over tooling:
++
++```text
++v2.2.4 — Oubliette Export-Lab-Reimport Adapter Inventory
++```
++
++The safer next move is likely a developer script that runs the proven private-alpha flow outside pytest and produces a human-readable report, because that will help unfamiliar builders prove the system before changing it.
+diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md
+--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md	2026-06-25 05:20:06.000000000 +0000
++++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/CHANGELOG.md	2026-06-25 16:26:17.150881294 +0000
+@@ -192,3 +192,13 @@
+ - Added receipt verification, listing, detail, and report APIs.
+ - Added tests for receipt creation, bot rejection, human-without-proof rejection, tamper detection, route integration, and token non-leakage.
+ - Verified: 95 passed.
++
++## v2.2.3 — Private Alpha Flow + Integration Polish
++
++- Added full private-alpha end-to-end API flow test.
++- Added `/api/v21/private-alpha/status` readiness endpoint.
++- Proved closed catalog privacy before and after protected custody work.
++- Proved human identity sessions, scoped ceremony tokens, receipts, custody integrity, and BlackBox chain verification work together.
++- Updated version to 2.2.3.
++- Verified: 100 passed.
++
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v223.md iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v223.md
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v223.md	1970-01-01 00:00:00.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/README_v223.md	2026-06-25 16:26:15.241511394 +0000
@@ -0,0 +1,77 @@
+# Iteration Wallet v2.2.3 — Private Alpha Flow + Integration Polish
+
+v2.2.3 proves the current private-alpha path as one coherent product flow rather than a pile of isolated unit-tested pieces.
+
+## What this patch adds
+
+- End-to-end private-alpha workflow test from the public FastAPI v2.1 API surface.
+- A private-alpha status endpoint that summarizes readiness without unlocking custody or leaking secrets.
+- Verification that closed catalog views remain safe before and after protected custody work.
+- Verification that human identity sessions, scoped ceremony tokens, protected actions, receipts, custody integrity, and the shared BlackBox chain work together.
+
+## New API
+
+```text
+GET /api/v21/private-alpha/status
+```
+
+This is a status-only surface. It does not open the Vault, issue a ceremony token, expose file contents, or authorize any custody action.
+
+It reports:
+
+```text
+version
+strict_ceremony_tokens
+vault_open
+blackbox_chain_ok
+custody_integrity_ok
+receipt_count
+receipt_report_chain_ok
+protected_action_count
+protected_actions
+ready_for_private_alpha_flow
+```
+
+## New tests
+
+```text
+tests/test_private_alpha_flow_v223.py
+```
+
+The primary test proves this flow:
+
+1. Create project and section.
+2. Add Raw Source and multiple Candidates.
+3. Verify closed catalog exposes only safe metadata.
+4. Issue a human identity session with intent proof.
+5. Open Vault.
+6. Issue scoped ceremony tokens.
+7. Promote Candidate to Prime.
+8. Export a working copy outside the Vault.
+9. Remove and restore a Candidate without deletion.
+10. Quarantine a Candidate without deletion.
+11. Release a Candidate from custody by explicit ceremony.
+12. Verify all protected actions produced Human Intent Receipts.
+13. Verify every receipt.
+14. Verify BlackBox chain integrity.
+15. Verify custody integrity.
+16. Lock Vault and verify section view returns to closed catalog mode without leaking protected fields.
+
+## Verification
+
+Clean local verification command:
+
+```bash
+python -m compileall -q iteration_wallet
+PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
+```
+
+Result:
+
+```text
+100 passed in 4.56s
+```
+
+## Honest scope
+
+This patch does not add Oubliette integration, camera liveness, email providers, hardware keys, or external cryptographic sealing. It proves the current private-alpha custody chain works as an end-to-end flow and adds a safe status surface for that readiness.
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py	2026-06-25 12:26:16.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/__init__.py	2026-06-25 16:26:15.027309784 +0000
@@ -7,11 +7,11 @@
 "Feic Mo Chroí — See My Heart."
 """
 
-__version__ = "2.2.2"
+__version__ = "2.2.3"
 __author__ = "Josie Curtsey Cobbley"
 __license__ = "Proprietary"
 
-# v2.2.2 Ceremony Token Lifecycle
+# v2.2.3 Private Alpha Flow + Integration Polish
 try:
     from .identity import ActorIdentity, IdentityError, LocalIdentityProvider
     from .blackbox import BlackBox, BlackBoxError
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py	2026-06-25 12:25:29.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/iteration_wallet/server.py	2026-06-25 16:24:57.497537012 +0000
@@ -401,6 +401,40 @@
 async def v219_blackbox_chain_status():
     return blackbox21.verify_chain()
 
+@app.get("/api/v21/private-alpha/status")
+async def v223_private_alpha_status():
+    """Private-alpha readiness snapshot.
+
+    This endpoint is intentionally a status surface, not an unlock surface. It
+    summarizes whether the current local package can prove the core private
+    alpha custody chain: strict ceremony tokens, protected action registry,
+    BlackBox chain integrity, custody integrity, and Human Intent Receipts.
+    """
+    chain = blackbox21.verify_chain()
+    custody = vault21.verify_custody_integrity()
+    receipts = blackbox21.list_human_intent_receipts(limit=1000)
+    receipt_report = blackbox21.build_human_intent_receipt_report(limit=1000)
+    protected_actions = list_protected_action_policies()
+    return {
+        "status_type": "private_alpha_status",
+        "version": "2.2.3",
+        "strict_ceremony_tokens": bool(getattr(vault21, "strict_ceremony_tokens", False)),
+        "vault_open": bool(vault21.get_state().get("is_vault_open")),
+        "blackbox_chain_ok": bool(chain.get("ok")),
+        "custody_integrity_ok": bool(custody.get("ok")),
+        "receipt_count": len(receipts),
+        "receipt_report_chain_ok": bool(receipt_report.get("chain", {}).get("ok")),
+        "protected_action_count": len(protected_actions),
+        "protected_actions": protected_actions,
+        "ready_for_private_alpha_flow": bool(
+            getattr(vault21, "strict_ceremony_tokens", False)
+            and chain.get("ok")
+            and custody.get("ok")
+            and receipt_report.get("chain", {}).get("ok")
+            and len(protected_actions) >= 8
+        ),
+    }
+
 @app.get("/api/v21/protected-actions")
 async def v21_protected_actions():
     return {"protected_actions": list_protected_action_policies()}
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py	2026-06-25 12:26:00.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/setup.py	2026-06-25 16:26:15.027902636 +0000
@@ -10,7 +10,7 @@
 
 setup(
     name="iteration-wallet",
-    version="2.2.2",
+    version="2.2.3",
     description="Cross-platform project vault for AI developers",
     long_description=long_description,
     long_description_content_type="text/markdown",
diff -ruN '--exclude=__pycache__' '--exclude=.pytest_cache' iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_private_alpha_flow_v223.py iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_private_alpha_flow_v223.py
--- iw223_base/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_private_alpha_flow_v223.py	1970-01-01 00:00:00.000000000 +0000
+++ iw223_work/IterationWallet_v2_2_2_CEREMONY_TOKEN_LIFECYCLE_PATCH/tests/test_private_alpha_flow_v223.py	2026-06-25 16:25:12.491286191 +0000
@@ -0,0 +1,269 @@
+"""
+Iteration Wallet v2.2.3 — Private Alpha Flow Integration Test
+==============================================================
+
+This test proves the current private-alpha custody path as one coherent flow:
+closed catalog, human identity session, scoped ceremony tokens, protected
+custody movement, human intent receipts, shared BlackBox chain, and custody
+integrity verification.
+"""
+
+from __future__ import annotations
+
+import json
+from pathlib import Path
+
+from fastapi.testclient import TestClient
+
+from iteration_wallet import server
+from iteration_wallet.blackbox import BlackBox
+from iteration_wallet.notification_manager import NotificationManager
+from iteration_wallet.vault_v21 import VaultEngine
+
+
+PROTECTED_LEAK_FIELDS = {
+    "vault_path",
+    "original_path",
+    "hash",
+    "notes",
+    "reviews",
+    "external_test_results",
+    "contents",
+    "preview",
+    "open_url",
+    "export_url",
+    "run_url",
+}
+
+
+def _make_source(tmp_path: Path, name: str, text: str) -> Path:
+    path = tmp_path / name
+    path.write_text(text, encoding="utf-8")
+    return path
+
+
+
+
+def _assert_no_secret_token_keys(value):
+    if isinstance(value, dict):
+        assert "ceremony_token" not in value
+        for child in value.values():
+            _assert_no_secret_token_keys(child)
+    elif isinstance(value, list):
+        for child in value:
+            _assert_no_secret_token_keys(child)
+
+
+def _assert_no_closed_view_leaks(value):
+    if isinstance(value, dict):
+        leaked = PROTECTED_LEAK_FIELDS.intersection(value.keys())
+        assert not leaked, f"closed view leaked protected fields: {sorted(leaked)}"
+        for child in value.values():
+            _assert_no_closed_view_leaks(child)
+    elif isinstance(value, list):
+        for child in value:
+            _assert_no_closed_view_leaks(child)
+
+
+def test_private_alpha_end_to_end_flow_from_api(tmp_path: Path):
+    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
+    try:
+        blackbox = BlackBox(tmp_path)
+        server.blackbox21 = blackbox
+        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
+        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
+        client = TestClient(server.app)
+
+        # 1. Project + section + materials enter custody. No open Vault needed.
+        project = client.post("/api/v21/projects", json={"name": "Private Alpha"}).json()
+        section = client.post(
+            f"/api/v21/projects/{project['id']}/sections",
+            json={"name": "Core", "description": "alpha section"},
+        ).json()
+        raw = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/raw-sources",
+            json={"path": str(_make_source(tmp_path, "raw.txt", "original source")), "notes": "closed raw note"},
+        ).json()
+        promote_candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(_make_source(tmp_path, "prime_candidate.txt", "candidate A")), "notes": "candidate for prime"},
+        ).json()
+        removable_candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(_make_source(tmp_path, "remove_restore.txt", "candidate B")), "notes": "remove restore candidate"},
+        ).json()
+        quarantine_candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(_make_source(tmp_path, "quarantine.txt", "candidate C")), "notes": "quarantine candidate"},
+        ).json()
+        release_candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(_make_source(tmp_path, "release.txt", "candidate D")), "notes": "release candidate"},
+        ).json()
+        assert raw["state"] == "raw"
+
+        # 2. Closed catalog reveals safe catalog metadata, not contents/paths/hashes.
+        closed = client.get(f"/api/v21/projects/{project['id']}/sections/{section['id']}/closed-catalog")
+        assert closed.status_code == 200, closed.text
+        closed_body = closed.json()
+        assert closed_body["view_mode"] == "closed_catalog"
+        assert closed_body["protected_contents_visible"] is False
+        _assert_no_closed_view_leaks(closed_body)
+        assert closed_body["raw_sources"][0]["closed_view_note"] == "closed raw note"
+
+        # 3. A human identity session with intent proof opens the protected path.
+        session_resp = client.post(
+            "/api/v21/identity/sessions",
+            json={
+                "actor_id": "josie",
+                "actor_kind": "human",
+                "device_id": "local-test-device",
+                "verified_methods": ["human_ceremony", "typing_challenge"],
+                "role_claims": {"head_user": True},
+            },
+        )
+        assert session_resp.status_code == 201, session_resp.text
+        session_id = session_resp.json()["session_id"]
+        open_resp = client.post("/api/v21/vault/open")
+        assert open_resp.status_code == 200, open_resp.text
+        assert open_resp.json()["strict_ceremony_tokens"] is True
+
+        def issue_token(action_key: str, object_id: str):
+            response = client.post(
+                "/api/v21/ceremony/tokens",
+                json={
+                    "action_key": action_key,
+                    "session_id": session_id,
+                    "project_id": project["id"],
+                    "section_id": section["id"],
+                    "object_id": object_id,
+                    "ttl_seconds": 300,
+                },
+            )
+            assert response.status_code == 201, response.text
+            token_body = response.json()
+            assert "ceremony_token" in token_body
+            # The raw secret is returned once, but listing must not reveal raw secrets.
+            listed = client.get("/api/v21/ceremony/tokens").json()["tokens"]
+            assert all("ceremony_token" not in item for item in listed)
+            return token_body["ceremony_token"]
+
+        def protected_payload(token: str, **extra):
+            body = {
+                "ceremony_token": token,
+                "actor_kind": "human",
+                "session_id": session_id,
+                "human_ceremony_passed": True,
+            }
+            body.update(extra)
+            return body
+
+        # 4. Promote a Candidate to Prime; receipt proves human intent.
+        promote_token = issue_token("promote_candidate_to_prime", promote_candidate["id"])
+        promoted = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates/{promote_candidate['id']}/promote",
+            json=protected_payload(promote_token, reason="best accepted so far"),
+        )
+        assert promoted.status_code == 200, promoted.text
+        promoted_body = promoted.json()
+        assert promoted_body["result"]["state"] == "prime"
+        assert promoted_body["human_intent_receipt"]["action_key"] == "promote_candidate_to_prime"
+        assert "ceremony_token" not in json.dumps(promoted_body["human_intent_receipt"])
+
+        # 5. Export Prime outside the Vault; Vault keeps custody, working copy is separate.
+        export_dir = tmp_path / "external_workbench"
+        export_token = issue_token("export_working_copy", promote_candidate["id"])
+        exported = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{promote_candidate['id']}/export-working-copy",
+            json=protected_payload(export_token, output_dir=str(export_dir)),
+        )
+        assert exported.status_code == 200, exported.text
+        exported_body = exported.json()
+        assert Path(exported_body["result"]["output_path"]).exists()
+        assert exported_body["human_intent_receipt"]["action_key"] == "export_working_copy"
+
+        # 6. Remove then restore a separate Candidate; no deletion, both actions receipt.
+        remove_token = issue_token("remove_from_active", removable_candidate["id"])
+        removed = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{removable_candidate['id']}/remove",
+            json=protected_payload(remove_token),
+        )
+        assert removed.status_code == 200, removed.text
+        assert removed.json()["result"]["state"] == "staging"
+        restore_token = issue_token("restore_to_active", removable_candidate["id"])
+        restored = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{removable_candidate['id']}/restore",
+            json=protected_payload(restore_token),
+        )
+        assert restored.status_code == 200, restored.text
+        assert restored.json()["result"]["state"] == "candidate"
+
+        # 7. Quarantine and release separate objects; both are protected custody actions.
+        quarantine_token = issue_token("quarantine", quarantine_candidate["id"])
+        quarantined = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{quarantine_candidate['id']}/quarantine",
+            json=protected_payload(quarantine_token),
+        )
+        assert quarantined.status_code == 200, quarantined.text
+        assert quarantined.json()["result"]["state"] == "quarantined"
+
+        release_token = issue_token("release_from_custody", release_candidate["id"])
+        released = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{release_candidate['id']}/release",
+            json=protected_payload(release_token, confirmation="RELEASE"),
+        )
+        assert released.status_code == 200, released.text
+        assert released.json()["result"]["state"] == "released"
+
+        # 8. Evidence surfaces prove the flow rather than merely completing actions.
+        receipts = client.get("/api/v21/blackbox/receipts").json()["receipts"]
+        action_keys = {r["action_key"] for r in receipts}
+        assert {
+            "promote_candidate_to_prime",
+            "export_working_copy",
+            "remove_from_active",
+            "restore_to_active",
+            "quarantine",
+            "release_from_custody",
+        }.issubset(action_keys)
+        for receipt in receipts:
+            verification = client.get(f"/api/v21/blackbox/receipts/{receipt['receipt_id']}").json()["verification"]
+            assert verification["ok"] is True
+
+        chain = client.get("/api/v21/blackbox/chain").json()
+        assert chain["ok"] is True
+        custody = client.get("/api/v21/custody/verify").json()
+        assert custody["ok"] is True
+
+        # 9. Lock closes the Vault; section view returns catalog-only again.
+        lock_resp = client.post("/api/v21/vault/lock")
+        assert lock_resp.status_code == 200, lock_resp.text
+        closed_again = client.get(f"/api/v21/projects/{project['id']}/sections/{section['id']}").json()
+        assert closed_again["view_mode"] == "closed_catalog"
+        _assert_no_closed_view_leaks(closed_again)
+    finally:
+        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human
+
+
+def test_private_alpha_status_endpoint_reports_readiness_without_unlocking(tmp_path: Path):
+    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
+    try:
+        blackbox = BlackBox(tmp_path)
+        server.blackbox21 = blackbox
+        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
+        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
+        client = TestClient(server.app)
+
+        status = client.get("/api/v21/private-alpha/status")
+        assert status.status_code == 200, status.text
+        body = status.json()
+        assert body["status_type"] == "private_alpha_status"
+        assert body["version"] == "2.2.3"
+        assert body["strict_ceremony_tokens"] is True
+        assert body["blackbox_chain_ok"] is True
+        assert body["custody_integrity_ok"] is True
+        assert body["ready_for_private_alpha_flow"] is True
+        _assert_no_secret_token_keys(body)
+        assert "promote_candidate_to_prime" in body["protected_actions"]
+    finally:
+        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human
