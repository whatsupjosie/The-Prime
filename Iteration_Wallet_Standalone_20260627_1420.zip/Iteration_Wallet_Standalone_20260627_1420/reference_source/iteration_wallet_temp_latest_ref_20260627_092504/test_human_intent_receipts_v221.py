import json
from pathlib import Path

from iteration_wallet.blackbox import BlackBox
from iteration_wallet.notification_manager import ActorKind, NotificationManager
from iteration_wallet.vault_v21 import VaultEngine
from iteration_wallet import server


def _write_source(tmp_path: Path, name: str, text: str) -> Path:
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return p


def test_blackbox_is_standalone_module_and_notification_manager_uses_it(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    nm = NotificationManager(tmp_path, blackbox=blackbox)

    req = nm.create_access_request(
        vault_id="vault",
        object_id="prime",
        action="export_working_copy",
        requester_id="bot-a",
        requester_kind=ActorKind.BOT,
        claimed_purpose="compare",
        recipients=["head"],
        head_user_id="head",
    )

    assert req.request_id
    assert nm.blackbox is blackbox
    assert nm.verify_blackbox_chain()["ok"] is True
    event_types = [e["event_type"] for e in blackbox.iter_events()]
    assert "PROTECTED_ACCESS_REQUEST_LOGGED" in event_types


def test_vault_custody_events_write_to_same_blackbox_chain(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox)
    nm = NotificationManager(tmp_path, blackbox=blackbox)

    project = vault.create_project("Project")
    section = vault.create_section(project["id"], "Core")
    raw = vault.add_raw_source(project["id"], section["id"], str(_write_source(tmp_path, "raw.txt", "raw")))
    candidate = vault.add_candidate(project["id"], section["id"], str(_write_source(tmp_path, "candidate.txt", "candidate")))
    token = vault.open_vault()["ceremony_token"]
    vault.promote_to_prime(project["id"], section["id"], candidate["id"], token, "better")
    vault.remove_file(project["id"], section["id"], raw["id"], token)

    # Same chain must contain both Vault custody events and Human Intent events.
    nm.create_access_request("vault", candidate["id"], "export_working_copy", "bot", "compare", ActorKind.BOT, ["head"], "head")
    assert blackbox.verify_chain()["ok"] is True
    event_types = [e["event_type"] for e in blackbox.iter_events()]
    assert "PROJECT_CREATED" in event_types
    assert "SECTION_CREATED" in event_types
    assert "RAW_SOURCE_ADDED" in event_types
    assert "CANDIDATE_ADDED" in event_types
    assert "PRIME_PROMOTED" in event_types
    assert "FILE_STAGED_FOR_REMOVAL" in event_types
    assert "PROTECTED_ACCESS_REQUEST_LOGGED" in event_types


def test_vault_integrity_check_reports_hash_mismatch_to_blackbox(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox)
    project = vault.create_project("Project")
    section = vault.create_section(project["id"], "Core")
    raw = vault.add_raw_source(project["id"], section["id"], str(_write_source(tmp_path, "raw.txt", "raw")))

    Path(raw["vault_path"]).write_text("tampered", encoding="utf-8")
    result = vault.verify_custody_integrity()

    assert result["ok"] is False
    assert result["incidents"][0]["type"] == "HASH_MISMATCH"
    assert blackbox.verify_chain()["ok"] is True
    assert any(e["event_type"] == "HASH_MISMATCH" for e in blackbox.iter_events())


def test_vault_integrity_check_reports_missing_prime_to_blackbox(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox)
    project = vault.create_project("Project")
    section = vault.create_section(project["id"], "Core")
    candidate = vault.add_candidate(project["id"], section["id"], str(_write_source(tmp_path, "candidate.txt", "candidate")))
    token = vault.open_vault()["ceremony_token"]
    prime = vault.promote_to_prime(project["id"], section["id"], candidate["id"], token, "best")

    Path(prime["vault_path"]).unlink()
    result = vault.verify_custody_integrity()

    assert result["ok"] is False
    assert result["incidents"][0]["type"] == "MISSING_PRIME_OBJECT"
    assert any(e["event_type"] == "MISSING_PRIME_OBJECT" for e in blackbox.iter_events())


def test_server_uses_one_shared_blackbox_for_vault_and_human_access():
    assert server.vault21.blackbox is server.human_access.blackbox
    assert server.blackbox21 is server.human_access.blackbox
