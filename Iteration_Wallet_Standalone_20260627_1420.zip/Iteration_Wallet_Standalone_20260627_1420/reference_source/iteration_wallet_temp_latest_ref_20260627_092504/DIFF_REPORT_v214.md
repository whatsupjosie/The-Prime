# Changelog

## v2.2.4 — Private Alpha Flow Runner

- Added developer-facing private-alpha flow runner.
- Added JSON and Markdown report generation for the private-alpha custody spine.
- Added report scrubbing so raw ceremony-token secrets and protected custody fields do not leak.
- Added persistent temp-run behavior when no run root is provided.
- Added `iw-private-alpha-flow` console command.
- Added v2.2.4 runner tests.


## v2.2.0 — Closed Catalog + BlackBox Evidence Surface

- Added closed catalog view for closed Vault/Cradle state.
- Closed view exposes only safe metadata: name, state, size, created date, last accessed, accessed by, closed-view note, and safe BlackBox summary.
- Closed view hides vault paths, original paths, hashes, notes, reviews, external results, contents, previews, and action surfaces.
- Added safe BlackBox evidence summaries for closed views.
- Added closed catalog and closed BlackBox summary API routes.
- Added tests for closed catalog privacy and evidence summaries.
- Repaired NotificationManager notification loading performance with an in-memory manager cache.
- Verified full suite: 91 passed.

# Oubliette Changelog

## v2.1.9 — BlackBox Extraction + Vault Coupling

- Added standalone `iteration_wallet/blackbox.py`.
- Refactored NotificationManager to use shared BlackBox.
- Wired `vault_v21` custody events into the shared BlackBox hash chain.
- Added custody integrity verification for missing objects and hash mismatches.
- Added server diagnostics for custody verification and BlackBox chain status.
- Added v2.1.9 tests; verified 87 passing.

## Version 2.0.0-COMMERCIAL (January 2026)

### 🚨 CRITICAL SECURITY FIXES

**10 Critical Vulnerabilities Patched:**

1. **Config Path Crash Vulnerability (CVE-TBD)**
   - **Issue**: Non-existent paths in configuration caused complete system crashes
   - **Impact**: System unavailability, DoS potential
   - **Fix**: Added comprehensive error handling and path validation
   - **Files**: `config.py:_validate_paths()`

2. **Hash Verification Logic Flaw (CVE-TBD)**
   - **Issue**: Tamper detection always failed due to hash overwrite bug
   - **Impact**: Security bypass, tampered configs undetected
   - **Fix**: Implemented proper hash comparison without side effects
   - **Files**: `config.py:verify_integrity()`

3. **Symlink Resolve Exception Bypass (CVE-TBD)**
   - **Issue**: Uncaught exceptions during symlink resolution bypassed security
   - **Impact**: Security validation bypass, potential privilege escalation
   - **Fix**: Added comprehensive exception handling in symlink analysis
   - **Files**: `marker.py:_analyze_symlink_chain()`

4. **macOS Sandbox Profile Injection (CVE-TBD)**
   - **Issue**: Unsanitized paths allowed arbitrary sandbox profile code injection
   - **Impact**: Complete sandbox escape, arbitrary code execution
   - **Fix**: Input sanitization and dangerous character filtering
   - **Files**: `enforcer.py:prepare_execution()`

5. **Windows Job Object Structure Corruption (CVE-TBD)**
   - **Issue**: Incorrect structure definitions caused memory corruption
   - **Impact**: System crashes, potential arbitrary code execution
   - **Fix**: Proper Windows API structure definitions with correct field types
   - **Files**: `enforcer.py:_create_job_object()`

6. **Linux Command Injection Vulnerability (CVE-TBD)**
   - **Issue**: Unsanitized paths in bubblewrap arguments
   - **Impact**: Sandbox escape, arbitrary command execution
   - **Fix**: Path validation and dangerous character filtering
   - **Files**: `enforcer.py:prepare_execution()`

7. **Directory Resolve Crash Vulnerability (CVE-TBD)**
   - **Issue**: Failed path resolution crashed validation functions
   - **Impact**: System crashes, security bypass
   - **Fix**: Comprehensive error handling for all path operations
   - **Files**: `marker.py:validate_marker_location()`

8. **Resource Exhaustion DoS Attack (CVE-TBD)**
   - **Issue**: Unlimited line processing in marker files
   - **Impact**: Memory exhaustion, denial of service
   - **Fix**: Limits on lines processed (1000 max) and line length (1000 chars)
   - **Files**: `marker.py:_parse_marker_directives()`

9. **TOCTOU Race Condition (CVE-TBD)**
   - **Issue**: Time-of-check-time-of-use vulnerability in config creation
   - **Impact**: Inconsistent security policies, race condition exploits
   - **Fix**: Atomic operations using stat() instead of exists()
   - **Files**: `config.py:_create_default_config()`

10. **Command Argument Injection (CVE-TBD)**
    - **Issue**: User commands could inject bubblewrap arguments to escape sandbox
    - **Impact**: Complete sandbox bypass, arbitrary system access
    - **Fix**: Command validation blocking dangerous flags and arguments
    - **Files**: `enforcer.py:prepare_execution()`

### 🛡️ SECURITY ENHANCEMENTS

- **Input Validation**: Comprehensive validation of all user inputs
- **Resource Limits**: Protection against DoS attacks and resource exhaustion
- **Error Handling**: Graceful handling of all error conditions
- **Audit Logging**: Enhanced security event logging and monitoring
- **Cross-Platform Hardening**: Platform-specific security improvements

### ✨ NEW FEATURES

- **Professional CLI**: Complete command-line interface with professional branding
- **Configuration Management**: Secure configuration with tamper detection
- **Multi-Platform Support**: Native support for Linux, macOS, and Windows
- **Comprehensive Scanning**: Advanced marker discovery and validation
- **Resource Monitoring**: Real-time resource usage tracking (where supported)

### 📦 PACKAGING & DISTRIBUTION

- **Production Setup**: Complete Python packaging with proper dependencies
- **Installation Scripts**: Platform-specific installation automation
- **Documentation**: Comprehensive user and developer documentation
- **Commercial Licensing**: Professional licensing and support structure

### 🧪 TESTING & VALIDATION

- **Security Audit**: Complete security audit with vulnerability assessment
- **Cross-Platform Testing**: Verified functionality on all supported platforms
- **Performance Testing**: Resource usage and performance validation
- **Integration Testing**: End-to-end workflow validation

### 🔧 TECHNICAL IMPROVEMENTS

- **Code Quality**: Professional-grade code with comprehensive error handling
- **Architecture**: Clean separation of concerns with modular design  
- **Performance**: Optimized scanning and execution performance
- **Compatibility**: Python 3.8+ support with modern packaging standards

### 📋 KNOWN LIMITATIONS

- **Windows**: Limited to resource controls and process isolation
- **macOS**: Uses deprecated sandbox-exec (still functional)
- **Testing**: Some platform combinations may need additional validation
- **Dependencies**: Requires platform-specific security tools for full functionality

### 🚀 DEPLOYMENT NOTES

- **Recommended**: Test thoroughly in your environment before production use
- **Platform Tools**: Ensure bubblewrap (Linux) or sandbox-exec (macOS) are available
- **Permissions**: May require elevated permissions for some security features
- **Integration**: Review integration patterns for your specific use case

---

## Previous Versions

### Version 1.7.1-ATOMIC
- Initial implementation with basic functionality
- Linux-only support with bubblewrap integration
- Basic marker scanning and validation
- **DEPRECATED**: Contains 10 critical security vulnerabilities

---

*For technical support or commercial licensing inquiries, contact josie@pubcast.ai*

**"Feic Mo Chroí" - See My Heart**  
© 2024-2025 Josie Curtsey Cobbley / Rear View Foresight LLC

## v2.1.3 — No Execute Rule Patch

- Hard-coded primary rule: Iteration Wallet never executes user-custodied material.
- Added disabled run/execute/launch/open stubs in v2 and v2.1 engines.
- Added API refusal routes for run/execute/open-file.
- Added external-result attachment for observational Candidate review.
- Fixed v2.1 release API so missing confirmation does not auto-release.
- Added tests proving no-execute behavior.

## v2.1.7 — Protected Action Registry

- Added centralized `iteration_wallet/gatekeeper.py` protected action registry.
- Registered current protected custody actions with policy metadata.
- Updated v2.1 protected routes to use registry action keys.
- Added fail-closed behavior for unregistered protected action keys.
- Added `/api/v21/protected-actions` diagnostic endpoint.
- Added tests for registry coverage, bot denial, human ceremony approval, state denial, and server fail-closed behavior.
- Verified full suite: 77 passed.

## v2.1.8 — Identity Session Binding

- Added local identity/session interface for Human Intent Gatekeeper.
- Added `ActorIdentity` and `LocalIdentityProvider`.
- Bound approval decisions to optional `decision_session_id`.
- Protected v2.1 custody routes require identity sessions when route-level gate is active.
- Added BlackBox logging for invalid/mismatched/non-human approval sessions.
- Added identity API endpoints for private-alpha session issuance and lookup.
- Added v2.1.8 identity/session tests.
- Verified full suite: 82 passed.
## v2.2.1 — Human Intent Receipts

- Added durable Human Intent Receipts under BlackBox.
- Receipts bind protected custody actions to the preceding BlackBox custody event hash.
- Protected custody routes now return receipt envelopes after successful human-approved action completion.
- Added receipt verification, listing, detail, and report APIs.
- Added tests for receipt creation, bot rejection, human-without-proof rejection, tamper detection, route integration, and token non-leakage.
- Verified: 95 passed.

## v2.2.3 — Private Alpha Flow + Integration Polish

- Added full private-alpha end-to-end API flow test.
- Added `/api/v21/private-alpha/status` readiness endpoint.
- Proved closed catalog privacy before and after protected custody work.
- Proved human identity sessions, scoped ceremony tokens, receipts, custody integrity, and BlackBox chain verification work together.
- Updated version to 2.2.3.
- Verified: 100 passed.

