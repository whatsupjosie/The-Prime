"""
Iteration Wallet v2.1.9 — BlackBox Evidence Chain
==================================================

BlackBox is the tamper-evident evidence layer for Iteration Wallet.
It records custody events, human-intent decisions, bot/tool requests,
incident bundles, and verification failures without owning the user-facing
notification workflow.

Product law:
- BlackBox is not optional bookkeeping. It is load-bearing custody evidence.
- Vault custody events and Human Intent gate events must share one evidence chain.
- The chain is local and tamper-evident, not external cryptographic sealing.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


class BlackBoxError(Exception):
    """Raised for expected BlackBox evidence failures."""


class BlackBox:
    """Local tamper-evident BlackBox event store.

    The event chain lives under `<vault_root>/blackbox/events`. Each event records
    the previous event hash, its chain index, and its own hash. Verification
    recomputes every event hash in sequence and reports any mismatch.
    """

    def __init__(self, vault_root: Path):
        self.vault_root = Path(vault_root)
        self.blackbox_dir = self.vault_root / "blackbox"
        self.event_dir = self.blackbox_dir / "events"
        self.incident_dir = self.blackbox_dir / "incidents"
        self.request_dir = self.blackbox_dir / "requests"
        self.receipt_dir = self.blackbox_dir / "receipts"
        self.chain_file = self.blackbox_dir / "chain_head.json"
        for directory in (self.blackbox_dir, self.event_dir, self.incident_dir, self.request_dir, self.receipt_dir):
            directory.mkdir(parents=True, exist_ok=True)

    # ─── durable JSON helpers ────────────────────────────────────────────

    @staticmethod
    def now() -> datetime:
        return datetime.now()

    @staticmethod
    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def _canonical_json(data: Dict[str, Any]) -> str:
        return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def _current_chain_state(self) -> tuple[str, int]:
        if not self.chain_file.exists():
            return "GENESIS", 0
        try:
            data = json.loads(self.chain_file.read_text(encoding="utf-8"))
            return str(data.get("event_hash") or "GENESIS"), int(data.get("chain_index", 0))
        except Exception:
            return "GENESIS", 0

    def current_chain_head(self) -> str:
        return self._current_chain_state()[0]

    # ─── events ──────────────────────────────────────────────────────────

    def write_event(self, event_type: str, summary: str, **extra: Any) -> Dict[str, Any]:
        """Write a hash-chained BlackBox event."""
        event_id = uuid.uuid4().hex[:16]
        previous_event_hash, previous_chain_index = self._current_chain_state()
        event = {
            "event_id": event_id,
            "event_type": event_type,
            "summary": summary,
            "created_at": self.now().isoformat(),
            "previous_event_hash": previous_event_hash,
            "chain_index": previous_chain_index + 1,
            **extra,
        }
        event_hash = hashlib.sha256(
            (previous_event_hash + self._canonical_json(event)).encode("utf-8")
        ).hexdigest()
        event["event_hash"] = event_hash
        self._write_json_atomic(self.event_dir / f"{event_id}.json", event)
        self._write_json_atomic(
            self.chain_file,
            {
                "event_id": event_id,
                "event_hash": event_hash,
                "chain_index": event["chain_index"],
                "updated_at": event["created_at"],
            },
        )
        return event

    def iter_events(self) -> Iterable[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        for path in self.event_dir.glob("*.json"):
            try:
                events.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception as exc:
                raise BlackBoxError(f"unreadable event {path.name}: {exc}") from exc
        events.sort(key=lambda e: (int(e.get("chain_index", 0)), e.get("created_at", ""), e.get("event_id", "")))
        return events

    def verify_chain(self) -> Dict[str, Any]:
        """Verify local BlackBox chain integrity."""
        try:
            events = list(self.iter_events())
        except BlackBoxError as exc:
            return {"ok": False, "reason": str(exc)}

        previous = "GENESIS"
        expected_index = 1
        for event in events:
            if int(event.get("chain_index", 0)) != expected_index:
                return {"ok": False, "reason": "chain index gap", "event_id": event.get("event_id")}
            if event.get("previous_event_hash") != previous:
                return {"ok": False, "reason": "broken previous hash", "event_id": event.get("event_id")}
            payload = dict(event)
            supplied_hash = payload.pop("event_hash", None)
            expected_hash = hashlib.sha256((previous + self._canonical_json(payload)).encode("utf-8")).hexdigest()
            if supplied_hash != expected_hash:
                return {"ok": False, "reason": "event hash mismatch", "event_id": event.get("event_id")}
            previous = supplied_hash
            expected_index += 1

        return {"ok": True, "event_count": len(events), "chain_head": previous}

    # ─── request / incident bundles ───────────────────────────────────────

    @staticmethod
    def incident_key(*parts: Optional[str]) -> str:
        raw = "|".join(str(part or "") for part in parts)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def update_request_incident_bundle(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Collapse repeated request pressure into one BlackBox incident bundle."""
        incident_id = self.incident_key(
            request.get("vault_id"),
            request.get("object_id"),
            request.get("action"),
            request.get("requester_id"),
            request.get("tool_family"),
        )
        path = self.incident_dir / f"{incident_id}.json"
        if path.exists():
            try:
                incident = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                incident = {}
        else:
            incident = {
                "incident_id": incident_id,
                "incident_type": "BOT_REQUEST_PRESSURE",
                "created_at": self.now().isoformat(),
                "vault_id": request.get("vault_id"),
                "object_id": request.get("object_id"),
                "action": request.get("action"),
                "requester_id": request.get("requester_id"),
                "tool_family": request.get("tool_family"),
                "raw_request_ids": [],
            }

        classification = str(request.get("classification") or "normal")
        incident["updated_at"] = self.now().isoformat()
        incident["classification"] = classification
        incident["matching_request_count"] = int(request.get("matching_request_count") or 0)
        incident["status"] = request.get("status")
        incident.setdefault("raw_request_ids", []).append(request.get("request_id"))
        incident["summary"] = (
            "Possible hacking attempt / runaway automation"
            if classification in {"probable_intrusion_attempt", "active_flood_hostile_access_event"}
            else "Repeated protected access pressure"
        )
        self._write_json_atomic(path, incident)
        self.write_event("REQUEST_INCIDENT_BUNDLE_UPDATED", incident["summary"], incident=incident)
        return incident

    # ─── custody events / violation evidence ──────────────────────────────

    def write_custody_event(
        self,
        event_type: str,
        summary: str,
        *,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        file_id: Optional[str] = None,
        state: Optional[str] = None,
        **extra: Any,
    ) -> Dict[str, Any]:
        """Write a custody event from vault_v21 into the same BlackBox chain."""
        return self.write_event(
            event_type,
            summary,
            project_id=project_id,
            section_id=section_id,
            file_id=file_id,
            state=state,
            custody_event=True,
            **extra,
        )

    def write_violation_event(self, violation_type: str, summary: str, **extra: Any) -> Dict[str, Any]:
        """Write suspected custody break / violation evidence."""
        return self.write_event(
            violation_type,
            summary,
            custody_violation=True,
            possible_intrusion=True,
            **extra,
        )


    # ─── human intent receipts ────────────────────────────────────────────

    @staticmethod
    def _identity_value(identity: Any, name: str, default: Any = None) -> Any:
        return getattr(identity, name, default) if identity is not None else default

    @staticmethod
    def _identity_has_human_intent(identity: Any) -> bool:
        if identity is None:
            return False
        checker = getattr(identity, "has_human_intent_proof", None)
        if callable(checker):
            return bool(checker())
        return False

    @staticmethod
    def _receipt_core_hash(receipt: Dict[str, Any]) -> str:
        payload = dict(receipt)
        payload.pop("receipt_hash", None)
        payload.pop("receipt_event_id", None)
        payload.pop("receipt_event_hash", None)
        return hashlib.sha256(BlackBox._canonical_json(payload).encode("utf-8")).hexdigest()

    def issue_human_intent_receipt(
        self,
        *,
        action_key: str,
        action_label: str,
        actor_identity: Any,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
        object_name: Optional[str] = None,
        custody_state: Optional[str] = None,
        result_summary: Optional[str] = None,
        linked_event_hash: Optional[str] = None,
        linked_event_id: Optional[str] = None,
        approval_id: Optional[str] = None,
        request_id: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Issue a durable Human Intent Receipt for a completed protected action.

        A receipt is not a permission token and does not unlock custody. It is an
        evidence artifact that says: a named human session with human-intent proof
        completed a protected custody action, and this receipt is tied to the
        BlackBox event hash that immediately preceded it.
        """
        if not action_key:
            raise BlackBoxError("receipt action_key is required")
        if not self._identity_has_human_intent(actor_identity):
            raise BlackBoxError("human intent receipt requires a valid human identity with intent proof")
        linked_event_hash = linked_event_hash or self.current_chain_head()
        if not linked_event_hash or linked_event_hash == "GENESIS":
            raise BlackBoxError("human intent receipt requires a linked BlackBox event hash")

        receipt_id = uuid.uuid4().hex[:16]
        verified_methods = list(self._identity_value(actor_identity, "verified_methods", []) or [])
        receipt = {
            "receipt_id": receipt_id,
            "receipt_type": "human_intent_receipt",
            "issued_at": self.now().isoformat(),
            "action_key": action_key,
            "action_label": action_label,
            "project_id": project_id,
            "section_id": section_id,
            "object_id": object_id,
            "object_name": object_name,
            "custody_state": custody_state,
            "actor_id": self._identity_value(actor_identity, "actor_id"),
            "actor_kind": self._identity_value(actor_identity, "actor_kind"),
            "session_id": self._identity_value(actor_identity, "session_id"),
            "device_id": self._identity_value(actor_identity, "device_id"),
            "verified_methods": verified_methods,
            "linked_blackbox_event_hash": linked_event_hash,
            "linked_blackbox_event_id": linked_event_id,
            "approval_id": approval_id,
            "request_id": request_id,
            "result_summary": (result_summary or "")[:300],
            "protected_action": True,
            "intent_statement": "A live authorized human completed this protected custody action.",
        }
        if extra:
            # Extra receipt data is deliberately namespaced so it cannot be
            # mistaken for a custody secret or authority claim.
            receipt["extra"] = dict(extra)
        receipt["receipt_hash"] = self._receipt_core_hash(receipt)

        event = self.write_event(
            "HUMAN_INTENT_RECEIPT_ISSUED",
            f"Human intent receipt issued for {action_label}",
            receipt_id=receipt_id,
            receipt_hash=receipt["receipt_hash"],
            linked_blackbox_event_hash=linked_event_hash,
            linked_blackbox_event_id=linked_event_id,
            action_key=action_key,
            project_id=project_id,
            section_id=section_id,
            file_id=object_id,
            actor_id=receipt["actor_id"],
            session_id=receipt["session_id"],
            receipt_event=True,
        )
        receipt["receipt_event_id"] = event["event_id"]
        receipt["receipt_event_hash"] = event["event_hash"]
        self._write_json_atomic(self.receipt_dir / f"{receipt_id}.json", receipt)
        return receipt

    def get_human_intent_receipt(self, receipt_id: str) -> Optional[Dict[str, Any]]:
        if not receipt_id:
            return None
        path = self.receipt_dir / f"{receipt_id}.json"
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise BlackBoxError(f"unreadable receipt {receipt_id}: {exc}") from exc

    def list_human_intent_receipts(
        self,
        *,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        receipts: List[Dict[str, Any]] = []
        for path in self.receipt_dir.glob("*.json"):
            try:
                receipt = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                raise BlackBoxError(f"unreadable receipt {path.name}: {exc}") from exc
            if project_id and receipt.get("project_id") != project_id:
                continue
            if section_id and receipt.get("section_id") != section_id:
                continue
            if object_id and receipt.get("object_id") != object_id:
                continue
            receipts.append(receipt)
        receipts.sort(key=lambda r: (r.get("issued_at", ""), r.get("receipt_id", "")))
        return receipts[-max(0, int(limit)):]

    def verify_human_intent_receipt(self, receipt_id: str) -> Dict[str, Any]:
        receipt = self.get_human_intent_receipt(receipt_id)
        if not receipt:
            return {"ok": False, "reason": "receipt not found"}
        supplied_hash = receipt.get("receipt_hash")
        expected_hash = self._receipt_core_hash(receipt)
        if supplied_hash != expected_hash:
            return {"ok": False, "reason": "receipt hash mismatch", "receipt_id": receipt_id}
        linked_hash = receipt.get("linked_blackbox_event_hash")
        receipt_event_hash = receipt.get("receipt_event_hash")
        event_hashes = {event.get("event_hash") for event in self.iter_events()}
        if linked_hash not in event_hashes:
            return {"ok": False, "reason": "linked BlackBox event hash missing", "receipt_id": receipt_id}
        if receipt_event_hash not in event_hashes:
            return {"ok": False, "reason": "receipt BlackBox event hash missing", "receipt_id": receipt_id}
        chain = self.verify_chain()
        if not chain.get("ok"):
            return {"ok": False, "reason": "BlackBox chain invalid", "receipt_id": receipt_id, "chain": chain}
        return {"ok": True, "receipt_id": receipt_id, "receipt_hash": supplied_hash, "chain": chain}

    def build_human_intent_receipt_report(self, limit: int = 100) -> Dict[str, Any]:
        receipts = self.list_human_intent_receipts(limit=limit)
        return {
            "summary": "Human Intent Receipt report",
            "generated_at": self.now().isoformat(),
            "receipt_count_included": len(receipts),
            "receipts": receipts,
            "chain": self.verify_chain(),
        }


    def build_closed_evidence_summary(
        self,
        *,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        file_id: Optional[str] = None,
        limit: int = 5,
    ) -> Dict[str, Any]:
        """Return a safe BlackBox summary for closed Vault/Cradle catalog views.

        This deliberately omits event hashes, payload details, paths, expected/actual
        file hashes, and request bodies. Closed view is for inventory and evidence
        posture, not inspection of protected contents.
        """
        def matches(event: Dict[str, Any]) -> bool:
            if project_id and event.get("project_id") != project_id:
                return False
            if section_id and event.get("section_id") != section_id:
                return False
            if file_id and event.get("file_id") != file_id:
                return False
            return True

        matched = [event for event in self.iter_events() if matches(event)]
        matched.sort(key=lambda e: (int(e.get("chain_index", 0)), e.get("created_at", "")))
        recent = matched[-max(0, int(limit)):]
        chain = self.verify_chain()

        incident_count = 0
        for path in self.incident_dir.glob("*.json"):
            try:
                incident = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if file_id and incident.get("object_id") != file_id:
                continue
            # Incident bundles created from bot requests often do not include
            # project/section ids, so only filter them when present.
            if project_id and incident.get("project_id") and incident.get("project_id") != project_id:
                continue
            if section_id and incident.get("section_id") and incident.get("section_id") != section_id:
                continue
            incident_count += 1

        return {
            "chain_ok": bool(chain.get("ok")),
            "event_count": len(matched),
            "custody_event_count": len([e for e in matched if e.get("custody_event")]),
            "violation_count": len([e for e in matched if e.get("custody_violation")]),
            "incident_count": incident_count,
            "last_event_type": matched[-1].get("event_type") if matched else None,
            "last_event_at": matched[-1].get("created_at") if matched else None,
            "recent_events": [
                {
                    "event_type": e.get("event_type"),
                    "created_at": e.get("created_at"),
                    "summary": str(e.get("summary") or "")[:150],
                }
                for e in recent
            ],
        }

    def build_report(self, limit: int = 100) -> Dict[str, Any]:
        events = list(self.iter_events())[-limit:]
        incidents = []
        for path in self.incident_dir.glob("*.json"):
            try:
                incidents.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                pass
        return {
            "summary": "BlackBox custody evidence report",
            "generated_at": self.now().isoformat(),
            "event_count_included": len(events),
            "events": events,
            "incident_bundles": sorted(incidents, key=lambda i: i.get("updated_at", "")),
            "chain": self.verify_chain(),
        }
