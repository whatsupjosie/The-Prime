# Iteration Wallet v2.0

**Project Vault for AI Developers**

*"Feic Mo Chroí — See My Heart"*

© 2024–2025 Josie Curtsey Cobbley / Rear View Foresight LLC

---

## What it does

Iteration Wallet is a non-destructive version vault that protects canonical copies of your project states. Every file you add is locked into the vault. Nothing in Iteration Wallet is released. User-custodied material can be removed, quarantined, banned, or released from custody by a live-person ceremony.

Built for AI developers who iterate fast: protect your best model configs, prompt templates, fine-tune checkpoints, and conversation exports before the next experiment wipes them out.

---

## Quick start

```bash
# Install
pip install -r requirements.txt

# Launch
python app.py
```

Opens in your browser at `http://localhost:7432`

---

## How the vault works

1. **Create a Cradle** — a project container with its own vault
2. **Add files** — canonical copies are stored in the protected vault directory
3. **Open the Vault** — requires typing `OPEN` (paste is blocked — must be intentional)
4. **Remove a file** — moves it to holding (reversible), requires typing `REMOVE`
5. **Release from custody** — live-person ceremony after REMOVE; Iteration Wallet still does not destroy the file

Files in the vault cannot be overwritten, batch-released from custody, or accidentally modified.

---

## API

When running, the full REST API is available:

| Endpoint | Description |
|----------|-------------|
| `GET /api/state` | Full vault state |
| `POST /api/projects` | Create a new cradle |
| `POST /api/files` | Add a file to the vault |
| `POST /api/vault/open` | Open the vault |
| `POST /api/vault/lock` | Lock the vault |
| `POST /api/files/{id}/remove` | Move to holding |
| `POST /api/files/{id}/release` | Live-person release from custody after REMOVE; no destruction |
| `POST /api/files/{id}/restore` | Restore from archive |
| `GET /api/drives` | Detect external drives |
| `WS /ws` | Real-time state updates |

Interactive docs: `http://localhost:7432/docs`

---

## Vault directory layout

```
~/.iteration_wallet/
  state.json
  projects/
    {project_id}/
      vault/
        cradle/{version}/canonical/   ← protected copies
        archive/{version}/            ← demoted versions
      removed_files/                  ← staging area
      metadata/
```

---

## License

Proprietary commercial software.  
Contact: josie@pubcast.ai

## v2.1.3 Safety Rule: No Execution in the Vault

Iteration Wallet is controlled custody, not the workbench. It does not run,
launch, open-for-execution, or execute user-custodied files. To test or run a
Candidate, export a working copy and run it outside Iteration Wallet. Then attach
external results back to the Candidate as observational evidence.
