# Iteration Wallet v2.1.5 — Human Access + BlackBox Request Control Rules

## Core rule
AI, bots, tools, scripts, and autonomous agents may request protected custody access, but they may not directly open, fetch, export, promote, release, or alter Vault/Cradle contents.

Protected custody requires live authorized human ceremony and/or Head User approval according to the Vault configuration.

## Notification limits
- Per recipient/respondent: max 5 unread messages.
- Per message: max 150 characters.
- Across system: max 200 notification records.
- BlackBox stores full details; alerts are only for attention and decision.

## Request thresholds
- 20 requests: unusual access pressure.
- 50 requests: suspicious access pattern.
- 100 requests: probable intrusion attempt or runaway automation.
- 1000 requests: active flood / hostile access event.

At intrusion/flood levels, the request stream is treated as possible security evidence, not normal volume.

## Head User approval
Project/shared Vault actions may require a Head User / Vault Owner / Custody Lead. Approval and denial decisions are logged in BlackBox.

## Implemented module
`iteration_wallet/notification_manager.py`

Implements:
- `NotificationManager`
- short capped notifications
- Head User approvals
- bot protected-access requests
- BlackBox request/event records
- intrusion classification
- direct-access denial helper for bots/tools/AI

## Server API additions
- `POST /api/v21/blackbox/access-requests`
- `GET /api/v21/blackbox/access-requests`
- `GET /api/v21/blackbox/access-requests/{request_id}`
- `GET /api/v21/blackbox/report`
- `GET /api/v21/notifications/{recipient_id}`
- `POST /api/v21/approvals/{approval_id}/decision`
- `POST /api/v21/access/evaluate`
