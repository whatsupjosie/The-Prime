"""
Iteration Wallet — Test Suite
==============================
Comprehensive tests for vault, API, and CLI.

Run: pytest tests/ -v
"""

import json
import pytest
import tempfile
from pathlib import Path

from iteration_wallet.vault import VaultEngine, VaultError
from iteration_wallet.server import app
from fastapi.testclient import TestClient


# ─── fixtures ──────────────────────────────────────────────────────────────

@pytest.fixture
def temp_vault():
    """Temporary vault for testing."""
    with tempfile.TemporaryDirectory() as tmp:
        vault = VaultEngine(Path(tmp))
        yield vault


@pytest.fixture
def temp_file(tmp_path):
    """Create a temporary test file."""
    f = tmp_path / "test_file.txt"
    f.write_text("test content")
    return f


@pytest.fixture
def api_client(monkeypatch):
    """FastAPI test client with isolated temporary server vault."""
    import iteration_wallet.server as server
    with tempfile.TemporaryDirectory() as tmp:
        server.vault = VaultEngine(Path(tmp))
        yield TestClient(app)


# ─── vault engine tests ─────────────────────────────────────────────────────

class TestVaultEngine:
    """Test the core vault logic."""

    def test_create_project(self, temp_vault):
        """Can create a project."""
        p = temp_vault.create_project("Test Project", "/home/test")
        assert p["name"] == "Test Project"
        assert p["version"] == "V1"
        assert p["createdAt"]

    def test_project_duplicate_guard(self, temp_vault):
        """Cannot create duplicate project names."""
        temp_vault.create_project("Unique")
        with pytest.raises(VaultError, match="already exists"):
            temp_vault.create_project("Unique")

    def test_list_projects(self, temp_vault):
        """Can list all projects."""
        temp_vault.create_project("P1")
        temp_vault.create_project("P2")
        projects = temp_vault.list_projects()
        assert len(projects) == 2

    def test_add_file(self, temp_vault, temp_file):
        """Can add a file to the vault."""
        p = temp_vault.create_project("TestProj")
        f = temp_vault.add_file(str(temp_file), p["id"])
        assert f["name"] == "test_file.txt"
        assert f["status"] == "protected"
        assert f["hash"]
        assert f["createdAt"]

    def test_add_nonexistent_file(self, temp_vault):
        """Cannot add a file that doesn't exist."""
        p = temp_vault.create_project("TestProj")
        with pytest.raises(VaultError, match="not found"):
            temp_vault.add_file("/nonexistent/file.txt", p["id"])

    def test_vault_open_close(self, temp_vault):
        """Can open and lock the vault."""
        assert not temp_vault._is_open
        temp_vault.open_vault()
        assert temp_vault._is_open
        temp_vault.lock_vault()
        assert not temp_vault._is_open

    def test_remove_file(self, temp_vault, temp_file):
        """Can remove (move to holding) a protected file."""
        p = temp_vault.create_project("TestProj")
        f = temp_vault.add_file(str(temp_file), p["id"])
        
        # Must open vault first
        with pytest.raises(VaultError, match="Open the Vault"):
            temp_vault.remove_file(f["id"])

        temp_vault.open_vault()
        f_removed = temp_vault.remove_file(f["id"])
        assert f_removed["status"] == "staging"

    def test_no_delete_method_surface(self, temp_vault, temp_file):
        """There is no delete method in the product surface; staged files remain preserved."""
        p = temp_vault.create_project("TestProj")
        f = temp_vault.add_file(str(temp_file), p["id"])
        temp_vault.open_vault()
        temp_vault.remove_file(f["id"])
        staged_path = Path(f["vaultPath"])
        assert not hasattr(temp_vault, "delete_file")
        assert staged_path.exists()
        assert len([x for x in temp_vault._state["files"] if x["id"] == f["id"]]) == 1

    def test_promote_version(self, temp_vault, temp_file):
        """Can promote to a new version."""
        p = temp_vault.create_project("TestProj")
        f = temp_vault.add_file(str(temp_file), p["id"])
        
        # Promote V1 → V2
        p_promoted = temp_vault.promote_version(p["id"], "V2")
        assert p_promoted["version"] == "V2"
        
        # Old file should be marked as archive
        f_archived = next(x for x in temp_vault._state["files"] if x["id"] == f["id"])
        assert f_archived["isArchive"]

    def test_restore_file(self, temp_vault, temp_file):
        """Can restore an archived file."""
        p = temp_vault.create_project("TestProj")
        f = temp_vault.add_file(str(temp_file), p["id"])
        
        # Archive it
        temp_vault.promote_version(p["id"], "V2")
        f_archived = next(x for x in temp_vault._state["files"] if x["id"] == f["id"])
        
        # Restore
        f_restored = temp_vault.restore_file(f_archived["id"])
        assert not f_restored["isArchive"]
        assert f_restored["status"] == "protected"

    def test_state_persistence(self, temp_vault, temp_file):
        """State is saved to disk."""
        p = temp_vault.create_project("TestProj")
        temp_vault.add_file(str(temp_file), p["id"])
        
        # Create a new vault instance pointing to same directory
        vault2 = VaultEngine(temp_vault.root)
        projects2 = vault2.list_projects()
        
        # Should have the same project
        assert len(projects2) == 1
        assert projects2[0]["name"] == "TestProj"

    def test_get_drives(self, temp_vault):
        """Can detect drives."""
        drives = temp_vault.get_drives()
        assert isinstance(drives, list)
        # Should have at least one drive (root)
        assert len(drives) >= 0


# ─── API tests ──────────────────────────────────────────────────────────────

class TestAPI:
    """Test the FastAPI endpoints."""

    def test_get_state(self, api_client):
        """GET /api/state returns full state."""
        r = api_client.get("/api/state")
        assert r.status_code == 200
        state = r.json()
        assert "projects" in state
        assert "files" in state
        assert "events" in state

    def test_create_project(self, api_client):
        """POST /api/projects creates a project."""
        r = api_client.post("/api/projects", json={"name": "API Test"})
        assert r.status_code == 201
        p = r.json()
        assert p["name"] == "API Test"

    def test_list_projects(self, api_client):
        """GET /api/projects lists all."""
        api_client.post("/api/projects", json={"name": "P1"})
        api_client.post("/api/projects", json={"name": "P2"})
        
        r = api_client.get("/api/projects")
        assert r.status_code == 200
        projects = r.json()
        assert len(projects) >= 2

    def test_vault_open_lock(self, api_client):
        """Can open and lock vault via API."""
        r = api_client.post("/api/vault/open")
        assert r.status_code == 200
        assert r.json()["open"] is True
        
        r = api_client.post("/api/vault/lock")
        assert r.status_code == 200
        assert r.json()["open"] is False

    def test_get_drives(self, api_client):
        """GET /api/drives returns drive list."""
        r = api_client.get("/api/drives")
        assert r.status_code == 200
        assert "drives" in r.json()

    def test_get_events(self, api_client):
        """GET /api/events returns activity log."""
        r = api_client.get("/api/events")
        assert r.status_code == 200
        assert "events" in r.json()

    def test_ui_served(self, api_client):
        """GET / serves the UI."""
        r = api_client.get("/")
        assert r.status_code == 200
        assert "Iteration Wallet" in r.text

    def test_error_handling(self, api_client):
        """API returns proper errors."""
        # Missing project
        r = api_client.post("/api/projects", json={"name": ""})
        assert r.status_code == 400

        # There is no delete route in the product surface.
        r = api_client.delete("/api/files/nonexistent")
        assert r.status_code in (404, 405)


# ─── guard tests ────────────────────────────────────────────────────────────

class TestCommitGuard:
    """Test the git pre-commit hook."""

    def test_guard_initialization(self):
        """Guard can initialize."""
        from iteration_wallet.guard import CommitGuard
        
        # Should work even outside a git repo (just raises on run)
        # This is a smoke test
        try:
            guard = CommitGuard()
        except RuntimeError:
            # Expected if not in a git repo
            pass

    def test_pattern_matching(self):
        """Guard can detect blocked patterns."""
        from iteration_wallet.guard import CommitGuard, BLOCKED_PATTERNS
        
        import re
        
        # Test some patterns
        assert any(re.search(p, ".env") for p in BLOCKED_PATTERNS)
        assert any(re.search(p, "credentials.json") for p in BLOCKED_PATTERNS)
        assert any(re.search(p, "private_key.pem") for p in BLOCKED_PATTERNS)


# ─── integration tests ──────────────────────────────────────────────────────

class TestIntegration:
    """End-to-end workflow tests."""

    def test_full_workflow(self, temp_vault, temp_file):
        """Complete workflow: create, add, remove, promote; no delete."""
        # 1. Create project
        p = temp_vault.create_project("My App", "/home/app")
        assert p["version"] == "V1"

        # 2. Add file
        f = temp_vault.add_file(str(temp_file), p["id"])
        assert f["status"] == "protected"

        # 3. Open vault
        temp_vault.open_vault()
        assert temp_vault._is_open

        # 4. Remove file to holding
        f_removed = temp_vault.remove_file(f["id"])
        assert f_removed["status"] == "staging"

        # 5. Lock vault
        temp_vault.lock_vault()
        assert not temp_vault._is_open

        # 6. Promote version
        p_v2 = temp_vault.promote_version(p["id"], "V2")
        assert p_v2["version"] == "V2"

        # 7. Check state
        state = temp_vault.get_state()
        assert len(state["projects"]) == 1
        assert len(state["events"]) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
