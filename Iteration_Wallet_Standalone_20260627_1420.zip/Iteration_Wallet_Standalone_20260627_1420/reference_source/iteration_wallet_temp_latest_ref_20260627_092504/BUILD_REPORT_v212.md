import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from iteration_wallet.vault_v21 import VaultEngine, VaultError, NO_EXECUTE_RULE
import iteration_wallet.server as server


def _make_file(text='print("boom")', suffix='.py'):
    f = tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False)
    f.write(text)
    f.flush()
    f.close()
    return Path(f.name)


def _candidate(vault):
    project = vault.create_project('No Execute Project')
    section = vault.create_section(project['id'], 'Dangerous Candidate')
    src = _make_file('import os\nos.remove("everything")')
    try:
        cand = vault.add_candidate(project['id'], section['id'], str(src), notes='malicious if run')
    finally:
        src.unlink(missing_ok=True)
    return project, section, cand


def test_no_execute_rule_constant_is_primary_product_law():
    assert 'never executes' in NO_EXECUTE_RULE
    assert 'outside the Vault' in NO_EXECUTE_RULE


def test_custodied_candidate_is_marked_non_executable_on_ingest():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault = VaultEngine(Path(tmpdir))
        _, _, cand = _candidate(vault)
        assert cand['execution_allowed'] is False
        assert cand['execution_policy'] == 'never_execute_inside_iteration_wallet'


def test_no_execution_method_surface_exists():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault = VaultEngine(Path(tmpdir))
        _candidate(vault)
        for method_name in ('run_file', 'execute_file', 'launch_file', 'open_file'):
            assert not hasattr(vault, method_name)


def test_external_results_attach_without_running_candidate():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault = VaultEngine(Path(tmpdir))
        project, section, cand = _candidate(vault)
        result = vault.attach_external_test_results(
            project['id'], section['id'], cand['id'],
            summary='External sandbox run passed 12/12 tests',
            passed=True,
            source='codex external sandbox',
            artifacts=['pytest-output.txt'],
        )
        assert result['observational_only'] is True
        assert result['passed'] is True
        refreshed = vault._find_file(project['id'], section['id'], cand['id'])
        assert refreshed['external_test_results'][0]['source'] == 'codex external sandbox'
        assert refreshed['execution_allowed'] is False


def test_export_working_copy_is_allowed_but_execution_surface_absent_in_vault():
    with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as outdir:
        vault = VaultEngine(Path(tmpdir))
        project, section, cand = _candidate(vault)
        exported = vault.export_working_copy(project['id'], section['id'], cand['id'], outdir)
        assert Path(exported['output_path']).exists()
        assert not hasattr(vault, 'run_file')


def test_v21_api_refuses_run_execute_open_and_requires_real_release_confirmation():
    with tempfile.TemporaryDirectory() as tmpdir:
        old_vault21 = server.vault21
        server.vault21 = VaultEngine(Path(tmpdir))
        try:
            client = TestClient(server.app)
            p = client.post('/api/v21/projects', json={'name': 'API No Execute'}).json()
            sec = client.post(f"/api/v21/projects/{p['id']}/sections", json={'name': 'Core'}).json()
            src = _make_file('print("do not run")')
            try:
                cand = client.post(
                    f"/api/v21/projects/{p['id']}/sections/{sec['id']}/candidates",
                    json={'path': str(src), 'notes': 'api candidate'},
                ).json()
            finally:
                src.unlink(missing_ok=True)

            r = client.post(f"/api/v21/projects/{p['id']}/sections/{sec['id']}/files/{cand['id']}/run")
            assert r.status_code in (404, 405)

            opened = client.post('/api/v21/vault/open').json()
            # Missing confirmation should NOT default to RELEASE anymore.
            r = client.post(
                f"/api/v21/projects/{p['id']}/sections/{sec['id']}/files/{cand['id']}/release",
                json={'ceremony_token': opened['ceremony_token']},
            )
            assert r.status_code == 400
            assert 'type RELEASE' in r.text
        finally:
            server.vault21 = old_vault21
