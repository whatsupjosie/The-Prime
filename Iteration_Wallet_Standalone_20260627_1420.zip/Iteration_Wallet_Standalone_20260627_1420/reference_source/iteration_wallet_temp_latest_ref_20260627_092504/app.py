# Iteration Wallet v2.2.1 — Human Intent Receipts

v2.2.1 adds durable Human Intent Receipts for protected custody actions.

A receipt is not an unlock key and not permission. It is evidence: a live authorized human session completed a protected custody action, and that receipt is tied to the BlackBox event hash for the custody event that just happened.

## What receipts prove

A receipt records:

- who completed the action
- which session completed it
- what human-intent methods were present
- what protected action completed
- what object was affected
- when it happened
- which BlackBox event hash it is tied to
- the receipt's own payload hash
- the BlackBox event that issued the receipt

## Protected actions now issuing receipts

- remove from active use
- restore to active use
- release from custody
- quarantine
- promote Candidate to Prime
- export working copy

## New BlackBox APIs

```text
GET /api/v21/blackbox/receipts
GET /api/v21/blackbox/receipts/report
GET /api/v21/blackbox/receipts/{receipt_id}
```

## Safety properties

- Bots cannot receive human intent receipts.
- Humans without a verified human-intent method cannot receive receipts.
- Raw ceremony tokens are not stored in receipts.
- Receipt tampering is detected by receipt hash verification.
- Receipt evidence is also represented in the BlackBox event chain.

## Verification

```text
95 passed in 3.50s
```

## Next step

IW-TASK-006 — ceremony token lifecycle hardening.
