"""
Iteration Wallet — FastAPI Server
===================================
Serves the UI and exposes the vault API.
WebSocket broadcasts state changes to all connected clients.

Run:  python app.py
API:  http://localhost:7432/api/...
UI:   http://localhost:7432/
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import List, Optional, Set

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from iteration_wallet.vault import VaultEngine, VaultError

# ─── app ───────────────────────────────────────────────────────────────────

log = logging.getLogger("iw.server")

app = FastAPI(
    title="Iteration Wallet",
    version="2.0.0",
    description="Cross-platform project vault for AI developers",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

vault = VaultEngine()

# HTML is served from the static directory next to this file
_STATIC = Path(__file__).parent / "static"


# ─── WebSocket manager ─────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: Set[WebSocket] = set()

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self.active.add(ws)

    def disconnect(self, ws: WebSocket) -> None:
        self.active.discard(ws)

    async def broadcast(self, message: dict) -> None:
        dead = set()
        payload = json.dumps(message)
        for ws in self.active:
            try:
                await ws.send_text(payload)
            except Exception:
                dead.add(ws)
        self.active -= dead


manager = ConnectionManager()


async def notify(event_type: str) -> None:
    await manager.broadcast({"type": event_type})


# ─── request models ────────────────────────────────────────────────────────

class CreateProjectRequest(BaseModel):
    name: str
    path: Optional[str] = ""


class AddFileRequest(BaseModel):
    path: str
    project: str


class PromoteVersionRequest(BaseModel):
    newVersion: str


class MarkDriveRequest(BaseModel):
    drivePath: str


# ─── routes ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    html_path = _STATIC / "app.html"
    if not html_path.exists():
        raise HTTPException(500, "UI not found — static/app.html is missing.")
    return HTMLResponse(html_path.read_text(encoding="utf-8"))


# ── state ──────────────────────────────────────────────────────────────────

@app.get("/api/state")
async def get_state():
    return vault.get_state()


# ── projects ───────────────────────────────────────────────────────────────

@app.get("/api/projects")
async def list_projects():
    return vault.list_projects()


@app.post("/api/projects", status_code=201)
async def create_project(req: CreateProjectRequest):
    try:
        project = vault.create_project(req.name, req.path or "")
        await notify("state_updated")
        return project
    except VaultError as e:
        raise HTTPException(400, str(e))


# ── files ──────────────────────────────────────────────────────────────────

@app.post("/api/files", status_code=201)
async def add_file(req: AddFileRequest):
    try:
        f = vault.add_file(req.path, req.project)
        await notify("state_updated")
        return f
    except VaultError as e:
        raise HTTPException(400, str(e))


@app.post("/api/files/{file_id}/remove")
async def remove_file(file_id: str):
    try:
        f = vault.remove_file(file_id)
        await notify("state_updated")
        return f
    except VaultError as e:
        raise HTTPException(400, str(e))










@app.post("/api/files/{file_id}/release")
async def release_file(file_id: str, request: Request):
    try:
        body = await request.json()
        f = vault.release_file(file_id, body.get("confirmation", ""))
        await notify("state_updated")
        return f
    except VaultError as e:
        raise HTTPException(400, str(e))

@app.post("/api/files/{file_id}/restore")
async def restore_file(file_id: str):
    try:
        f = vault.restore_file(file_id)
        await notify("state_updated")
        return f
    except VaultError as e:
        raise HTTPException(400, str(e))


# ── vault open/lock ────────────────────────────────────────────────────────

@app.post("/api/vault/open")
async def open_vault():
    vault.open_vault()
    await notify("vault_opened")
    return {"open": True}


@app.post("/api/vault/lock")
async def lock_vault():
    vault.lock_vault()
    await notify("vault_locked")
    return {"open": False}


# ── version promotion ──────────────────────────────────────────────────────

@app.post("/api/projects/{project_id}/promote")
async def promote_version(project_id: str, req: PromoteVersionRequest):
    try:
        project = vault.promote_version(project_id, req.newVersion)
        await notify("state_updated")
        return project
    except VaultError as e:
        raise HTTPException(400, str(e))


# ── drives ─────────────────────────────────────────────────────────────────

@app.get("/api/drives")
async def get_drives():
    return {"drives": vault.get_drives()}


@app.post("/api/drives/mark")
async def mark_drive(req: MarkDriveRequest):
    try:
        vault.mark_drive(req.drivePath)
        await notify("state_updated")
        return {"marked": True}
    except Exception as e:
        raise HTTPException(400, str(e))


# ── events ─────────────────────────────────────────────────────────────────

@app.get("/api/events")
async def get_events():
    return {"events": vault._state.get("events", [])}


# ─── WebSocket ─────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            # Keep-alive ping; real messages go server → client only
            await asyncio.sleep(30)
            await ws.send_text(json.dumps({"type": "ping"}))
    except (WebSocketDisconnect, Exception):
        manager.disconnect(ws)

# ───────────────────────────────────────────────────────────────────────────
# v2.1 product-model API: Sections / Raw Sources / Candidates / Prime
# This is additive: the original v2 routes above remain intact.
# ───────────────────────────────────────────────────────────────────────────

from iteration_wallet.vault_v21 import VaultEngine as VaultEngineV21, VaultError as VaultErrorV21
from iteration_wallet.notification_manager import (
    ActorKind,
    NotificationError,
    NotificationManager,
    NotificationLevel,
)
from iteration_wallet.identity import IdentityError
from iteration_wallet.blackbox import BlackBox
from iteration_wallet.gatekeeper import (
    ProtectedActionError,
    evaluate_protected_action,
    list_protected_action_policies,
)

_v21_root = Path.home() / ".iteration_wallet_v21"
blackbox21 = BlackBox(_v21_root)
vault21 = VaultEngineV21(_v21_root, blackbox=blackbox21, strict_ceremony_tokens=True)
human_access = NotificationManager(_v21_root, blackbox=blackbox21)

class CreateSectionRequest(BaseModel):
    name: str
    description: Optional[str] = ""

class AddMaterialRequest(BaseModel):
    path: str
    notes: Optional[str] = ""

class CeremonyTokenRequest(BaseModel):
    ceremony_token: str
    confirmation: str | None = None
    actor_kind: Optional[str] = "human"
    actor_id: Optional[str] = None
    session_id: Optional[str] = None
    human_ceremony_passed: Optional[bool] = True

class PromotePrimeRequest(BaseModel):
    ceremony_token: str
    reason: Optional[str] = ""
    actor_kind: Optional[str] = "human"
    actor_id: Optional[str] = None
    session_id: Optional[str] = None
    human_ceremony_passed: Optional[bool] = True

class ReviewCandidateRequest(BaseModel):
    verdict: str
    summary: Optional[str] = ""
    strengths: Optional[List[str]] = []
    risks: Optional[List[str]] = []

class ExportWorkingCopyRequest(BaseModel):
    output_dir: str
    ceremony_token: str
    actor_kind: Optional[str] = "human"
    actor_id: Optional[str] = None
    session_id: Optional[str] = None
    human_ceremony_passed: Optional[bool] = True

def require_human_intent(
    action_key: str,
    actor_kind: Optional[str],
    human_ceremony_passed: Optional[bool],
    session_id: Optional[str] = None,
    require_identity_session: bool = False,
) -> dict:
    actor_identity = None
    if require_identity_session and not session_id:
        raise HTTPException(403, "Protected custody route requires an identity session.")
    if session_id:
        try:
            actor_identity = human_access.require_identity_session(session_id)
        except IdentityError as e:
            raise HTTPException(403, f"Valid identity session required: {e}")
    try:
        decision = evaluate_protected_action(
            action_key,
            actor_kind or "unknown",
            actor_identity=actor_identity,
            human_ceremony_passed=bool(human_ceremony_passed),
            gate=human_access,
        )
    except ProtectedActionError as e:
        raise HTTPException(500, str(e))
    if not decision.get("allowed"):
        raise HTTPException(403, decision.get("reason", "Protected custody requires human intent."))
    decision["_actor_identity"] = actor_identity
    return decision


def issue_human_intent_receipt(
    *,
    decision: dict,
    action_key: str,
    project_id: str,
    section_id: str,
    object_id: str,
    result: dict,
    result_summary: str,
) -> dict:
    actor_identity = decision.get("_actor_identity")
    receipt = blackbox21.issue_human_intent_receipt(
        action_key=action_key,
        action_label=decision.get("action") or action_key,
        actor_identity=actor_identity,
        project_id=project_id,
        section_id=section_id,
        object_id=object_id,
        object_name=(result or {}).get("name"),
        custody_state=(result or {}).get("state"),
        result_summary=result_summary,
        linked_event_hash=blackbox21.current_chain_head(),
    )
    return receipt


def with_human_intent_receipt(result: dict, receipt: dict) -> dict:
    return {"result": result, "human_intent_receipt": receipt}

class ExternalResultsRequest(BaseModel):
    summary: str
    passed: Optional[bool] = None
    source: Optional[str] = "external"
    artifacts: Optional[List[str]] = []

class CeremonyTokenIssueRequest(BaseModel):
    action_key: str
    session_id: str
    project_id: Optional[str] = None
    section_id: Optional[str] = None
    object_id: Optional[str] = None
    ttl_seconds: Optional[int] = 300

class CeremonyTokenRevokeRequest(BaseModel):
    ceremony_token: str
    reason: Optional[str] = "manual revocation"

@app.get("/api/v21/state")
async def v21_state():
    return vault21.get_state()

@app.get("/api/v21/custody/verify")
async def v219_verify_custody_integrity():
    try:
        return vault21.verify_custody_integrity()
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.get("/api/v21/blackbox/chain")
async def v219_blackbox_chain_status():
    return blackbox21.verify_chain()

@app.get("/api/v21/private-alpha/status")
async def v223_private_alpha_status():
    """Private-alpha readiness snapshot.

    This endpoint is intentionally a status surface, not an unlock surface. It
    summarizes whether the current local package can prove the core private
    alpha custody chain: strict ceremony tokens, protected action registry,
    BlackBox chain integrity, custody integrity, and Human Intent Receipts.
    """
    chain = blackbox21.verify_chain()
    custody = vault21.verify_custody_integrity()
    receipts = blackbox21.list_human_intent_receipts(limit=1000)
    receipt_report = blackbox21.build_human_intent_receipt_report(limit=1000)
    protected_actions = list_protected_action_policies()
    return {
        "status_type": "private_alpha_status",
        "version": "2.2.4",
        "strict_ceremony_tokens": bool(getattr(vault21, "strict_ceremony_tokens", False)),
        "vault_open": bool(vault21.get_state().get("is_vault_open")),
        "blackbox_chain_ok": bool(chain.get("ok")),
        "custody_integrity_ok": bool(custody.get("ok")),
        "receipt_count": len(receipts),
        "receipt_report_chain_ok": bool(receipt_report.get("chain", {}).get("ok")),
        "protected_action_count": len(protected_actions),
        "protected_actions": protected_actions,
        "ready_for_private_alpha_flow": bool(
            getattr(vault21, "strict_ceremony_tokens", False)
            and chain.get("ok")
            and custody.get("ok")
            and receipt_report.get("chain", {}).get("ok")
            and len(protected_actions) >= 8
        ),
    }

@app.get("/api/v21/protected-actions")
async def v21_protected_actions():
    return {"protected_actions": list_protected_action_policies()}

@app.post("/api/v21/projects", status_code=201)
async def v21_create_project(req: CreateProjectRequest):
    try:
        project = vault21.create_project(req.name, req.path or "")
        await notify("v21_state_updated")
        return project
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections", status_code=201)
async def v21_create_section(project_id: str, req: CreateSectionRequest):
    try:
        section = vault21.create_section(project_id, req.name, req.description or "")
        await notify("v21_state_updated")
        return section
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.get("/api/v21/projects/{project_id}/sections/{section_id}")
async def v21_section_view(project_id: str, section_id: str):
    try:
        return vault21.get_section_view(project_id, section_id)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))


@app.get("/api/v21/projects/{project_id}/sections/{section_id}/closed-catalog")
async def v220_closed_catalog_view(project_id: str, section_id: str):
    try:
        return vault21.get_closed_catalog_view(project_id, section_id)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.get("/api/v21/projects/{project_id}/sections/{section_id}/blackbox/closed-summary")
async def v220_section_blackbox_closed_summary(project_id: str, section_id: str):
    return blackbox21.build_closed_evidence_summary(project_id=project_id, section_id=section_id, limit=10)

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/raw-sources", status_code=201)
async def v21_add_raw_source(project_id: str, section_id: str, req: AddMaterialRequest):
    try:
        record = vault21.add_raw_source(project_id, section_id, req.path, req.notes or "")
        await notify("v21_state_updated")
        return record
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/candidates", status_code=201)
async def v21_add_candidate(project_id: str, section_id: str, req: AddMaterialRequest):
    try:
        record = vault21.add_candidate(project_id, section_id, req.path, req.notes or "")
        await notify("v21_state_updated")
        return record
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/vault/open")
async def v21_open_vault():
    result = vault21.open_vault()
    await notify("v21_vault_opened")
    return result

@app.post("/api/v21/vault/lock")
async def v21_lock_vault():
    result = vault21.lock_vault()
    await notify("v21_vault_locked")
    return result

@app.post("/api/v21/ceremony/tokens", status_code=201)
async def v222_issue_ceremony_token(req: CeremonyTokenIssueRequest):
    try:
        identity = human_access.require_identity_session(req.session_id)
        if not identity.has_human_intent_proof():
            raise HTTPException(403, "Ceremony token requires a human identity session with intent proof.")
        result = vault21.issue_ceremony_token(
            req.action_key,
            req.session_id,
            actor_id=identity.actor_id,
            project_id=req.project_id,
            section_id=req.section_id,
            object_id=req.object_id,
            ttl_seconds=req.ttl_seconds or 300,
        )
        await notify("v222_ceremony_token_issued")
        return result
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))
    except IdentityError as e:
        raise HTTPException(403, f"Valid identity session required: {e}")

@app.get("/api/v21/ceremony/tokens")
async def v222_list_ceremony_tokens():
    return {"tokens": vault21.list_ceremony_tokens()}

@app.post("/api/v21/ceremony/tokens/revoke")
async def v222_revoke_ceremony_token(req: CeremonyTokenRevokeRequest):
    try:
        return vault21.revoke_ceremony_token(req.ceremony_token, reason=req.reason or "manual revocation")
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/remove")
async def v21_remove_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
    try:
        decision = require_human_intent("remove_from_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        record = vault21.remove_file(project_id, section_id, file_id, req.ceremony_token, session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="remove_from_active",
            project_id=project_id,
            section_id=section_id,
            object_id=file_id,
            result=record,
            result_summary="File removed from active use into Removed staging.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(record, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/restore")
async def v21_restore_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
    try:
        decision = require_human_intent("restore_to_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        record = vault21.restore_file(project_id, section_id, file_id, req.ceremony_token, session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="restore_to_active",
            project_id=project_id,
            section_id=section_id,
            object_id=file_id,
            result=record,
            result_summary="File restored from Removed staging to active custody.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(record, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))





@app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/release")
async def v21_release_from_custody(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
    try:
        # Preserve the product-level release ceremony error before identity gating:
        # missing/incorrect RELEASE confirmation is a bad release request, not an
        # identity-session fallback path. No custody movement happens here.
        if (req.confirmation or "") != "RELEASE":
            raise VaultErrorV21("Release from custody requires you to type RELEASE confirmation.")
        decision = require_human_intent("release_from_custody", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        record = vault21.release_from_custody(project_id, section_id, file_id, req.ceremony_token, req.confirmation or '', session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="release_from_custody",
            project_id=project_id,
            section_id=section_id,
            object_id=file_id,
            result=record,
            result_summary="File released from Iteration Wallet custody by explicit human ceremony.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(record, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/quarantine")
async def v21_quarantine_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
    try:
        decision = require_human_intent("quarantine", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        record = vault21.quarantine_file(project_id, section_id, file_id, req.ceremony_token, reason="manual quarantine", session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="quarantine",
            project_id=project_id,
            section_id=section_id,
            object_id=file_id,
            result=record,
            result_summary="File moved into quarantine without deletion.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(record, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/candidates/{candidate_id}/review")
async def v21_review_candidate(project_id: str, section_id: str, candidate_id: str, req: ReviewCandidateRequest):
    try:
        review = vault21.review_candidate(project_id, section_id, candidate_id, req.verdict, req.summary or "", req.strengths or [], req.risks or [])
        await notify("v21_state_updated")
        return review
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/candidates/{candidate_id}/external-results")
async def v21_attach_external_results(project_id: str, section_id: str, candidate_id: str, req: ExternalResultsRequest):
    try:
        result = vault21.attach_external_test_results(project_id, section_id, candidate_id, req.summary, req.passed, req.source or "external", req.artifacts or [])
        await notify("v21_state_updated")
        return result
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/candidates/{candidate_id}/promote")
async def v21_promote_candidate(project_id: str, section_id: str, candidate_id: str, req: PromotePrimeRequest):
    try:
        decision = require_human_intent("promote_candidate_to_prime", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        record = vault21.promote_to_prime(project_id, section_id, candidate_id, req.ceremony_token, req.reason or "", session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="promote_candidate_to_prime",
            project_id=project_id,
            section_id=section_id,
            object_id=candidate_id,
            result=record,
            result_summary="Candidate promoted to Prime by human ceremony.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(record, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

@app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/export-working-copy")
async def v21_export_working_copy(project_id: str, section_id: str, file_id: str, req: ExportWorkingCopyRequest):
    try:
        decision = require_human_intent("export_working_copy", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
        result = vault21.export_working_copy(project_id, section_id, file_id, req.output_dir, ceremony_token=req.ceremony_token, session_id=req.session_id)
        receipt = issue_human_intent_receipt(
            decision=decision,
            action_key="export_working_copy",
            project_id=project_id,
            section_id=section_id,
            object_id=file_id,
            result={"id": file_id, "name": Path(result.get("output_path", "")).name, "state": "exported_working_copy"},
            result_summary="Working copy exported outside the Vault for external work.",
        )
        await notify("v21_state_updated")
        return with_human_intent_receipt(result, receipt)
    except VaultErrorV21 as e:
        raise HTTPException(400, str(e))

# ───────────────────────────────────────────────────────────────────────────
# v2.1.5 Human Access / BlackBox Request Control API
# Bots can request. Humans approve. BlackBox records. Bots do not fetch custody.
# ───────────────────────────────────────────────────────────────────────────

class ProtectedAccessRequestModel(BaseModel):
    vault_id: str
    object_id: str
    action: str
    requester_id: str
    claimed_purpose: str
    requester_kind: Optional[str] = "unknown"
    recipients: Optional[List[str]] = []
    head_user_id: Optional[str] = None
    section_id: Optional[str] = None
    tool_family: Optional[str] = None

class IdentitySessionRequest(BaseModel):
    actor_id: str
    actor_kind: str = "unknown"
    device_id: Optional[str] = None
    verified_methods: Optional[List[str]] = []
    role_claims: Optional[dict] = {}
    ttl_minutes: Optional[int] = 480

class ApprovalDecisionRequest(BaseModel):
    approved: bool
    decision_by: Optional[str] = None
    decision_session_id: Optional[str] = None
    reason: Optional[str] = None

class DirectAccessEvaluationRequest(BaseModel):
    actor_kind: str
    action: str
    protected: Optional[bool] = True
    human_ceremony_passed: Optional[bool] = False
    session_id: Optional[str] = None

@app.post("/api/v21/identity/sessions", status_code=201)
async def v218_issue_identity_session(req: IdentitySessionRequest):
    try:
        identity = human_access.issue_identity_session(
            actor_id=req.actor_id,
            actor_kind=req.actor_kind,
            device_id=req.device_id,
            verified_methods=req.verified_methods or [],
            role_claims=req.role_claims or {},
            ttl_minutes=int(req.ttl_minutes or 480),
        )
        await notify("v218_identity_session_issued")
        return identity.to_dict()
    except Exception as e:
        raise HTTPException(400, str(e))

@app.get("/api/v21/identity/sessions/{session_id}")
async def v218_get_identity_session(session_id: str):
    identity = human_access.get_identity_session(session_id)
    if not identity:
        raise HTTPException(404, "Identity session not found")
    return identity.to_dict()

@app.post("/api/v21/blackbox/access-requests", status_code=201)
async def v215_create_access_request(req: ProtectedAccessRequestModel):
    try:
        request = human_access.create_access_request(
            vault_id=req.vault_id,
            object_id=req.object_id,
            action=req.action,
            requester_id=req.requester_id,
            claimed_purpose=req.claimed_purpose,
            requester_kind=req.requester_kind or "unknown",
            recipients=req.recipients or [],
            head_user_id=req.head_user_id,
            section_id=req.section_id,
            tool_family=req.tool_family,
        )
        await notify("v215_blackbox_request_logged")
        return request.to_dict()
    except Exception as e:
        raise HTTPException(400, str(e))

@app.get("/api/v21/blackbox/access-requests")
async def v215_get_access_requests():
    return {"requests": human_access.get_all_access_requests()}

@app.get("/api/v21/blackbox/access-requests/{request_id}")
async def v215_get_access_request(request_id: str):
    request = human_access.get_access_request(request_id)
    if not request:
        raise HTTPException(404, "Request not found")
    return request.to_dict()

@app.get("/api/v21/blackbox/report")
async def v215_blackbox_request_report():
    return human_access.build_blackbox_request_report()

@app.get("/api/v21/blackbox/receipts")
async def v221_list_human_intent_receipts():
    return {"receipts": blackbox21.list_human_intent_receipts()}

@app.get("/api/v21/blackbox/receipts/report")
async def v221_human_intent_receipt_report():
    return blackbox21.build_human_intent_receipt_report()

@app.get("/api/v21/blackbox/receipts/{receipt_id}")
async def v221_get_human_intent_receipt(receipt_id: str):
    receipt = blackbox21.get_human_intent_receipt(receipt_id)
    if not receipt:
        raise HTTPException(404, "Human Intent Receipt not found")
    verification = blackbox21.verify_human_intent_receipt(receipt_id)
    return {"receipt": receipt, "verification": verification}

@app.get("/api/v21/notifications/{recipient_id}")
async def v215_get_notifications(recipient_id: str):
    return {"notifications": human_access.get_inbox(recipient_id)}

@app.post("/api/v21/approvals/{approval_id}/decision")
async def v215_submit_approval_decision(approval_id: str, req: ApprovalDecisionRequest):
    approval = human_access.submit_approval_decision(approval_id, req.approved, decision_by=req.decision_by, reason=req.reason, decision_session_id=req.decision_session_id)
    if not approval:
        raise HTTPException(404, "Approval not found")
    await notify("v215_approval_decided")
    return approval.to_dict()

@app.post("/api/v21/access/evaluate")
async def v215_evaluate_direct_access(req: DirectAccessEvaluationRequest):
    try:
        actor_identity = None
        if req.session_id:
            actor_identity = human_access.require_identity_session(req.session_id)
        return human_access.evaluate_direct_access(
            req.actor_kind,
            req.action,
            protected=bool(req.protected),
            human_ceremony_passed=bool(req.human_ceremony_passed),
            actor_identity=actor_identity,
        )
    except Exception as e:
        raise HTTPException(400, str(e))
