import json
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from iteration_wallet.blackbox import BlackBox
from iteration_wallet.ceremony import CeremonyTokenError, CeremonyTokenLedger
from iteration_wallet.notification_manager import ActorKind, NotificationManager
from iteration_wallet.vault_v21 import VaultEngine, VaultError
from iteration_wallet import server


def _source(tmp_path: Path, name: str = "candidate.txt", text: str = "candidate") -> Path:
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return p


def _strict_vault_with_candidate(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True, ceremony_token_ttl_seconds=60)
    project = vault.create_project("Ceremony Project")
    section = vault.create_section(project["id"], "Core")
    candidate = vault.add_candidate(project["id"], section["id"], str(_source(tmp_path)))
    vault.open_vault()
    return blackbox, vault, project, section, candidate


def test_scoped_ceremony_token_is_hashed_not_stored_raw_and_single_use(tmp_path: Path):
    blackbox, vault, project, section, candidate = _strict_vault_with_candidate(tmp_path)
    token = vault.issue_ceremony_token(
        "remove_from_active",
        "session-1",
        actor_id="josie",
        project_id=project["id"],
        section_id=section["id"],
        object_id=candidate["id"],
    )
    raw = token["ceremony_token"]
    token_file = tmp_path / "ceremony_tokens" / f"{token['token_id']}.json"
    stored = token_file.read_text(encoding="utf-8")
    assert raw not in stored
    assert "token_hash" in json.loads(stored)

    removed = vault.remove_file(project["id"], section["id"], candidate["id"], raw, session_id="session-1")
    assert removed["state"] == "staging"

    with pytest.raises(VaultError, match="already been used"):
        vault.remove_file(project["id"], section["id"], candidate["id"], raw, session_id="session-1")

    event_types = [e["event_type"] for e in blackbox.iter_events()]
    assert "CEREMONY_TOKEN_ISSUED" in event_types
    assert "CEREMONY_TOKEN_CONSUMED" in event_types


def test_wrong_action_wrong_session_expired_and_lock_revoked_tokens_fail_closed(tmp_path: Path):
    blackbox, vault, project, section, candidate = _strict_vault_with_candidate(tmp_path)
    token = vault.issue_ceremony_token(
        "remove_from_active",
        "session-1",
        actor_id="josie",
        project_id=project["id"],
        section_id=section["id"],
        object_id=candidate["id"],
    )["ceremony_token"]

    with pytest.raises(VaultError, match="not valid for this action"):
        vault.quarantine_file(project["id"], section["id"], candidate["id"], token, session_id="session-1")
    with pytest.raises(VaultError, match="not valid for this identity session"):
        vault.remove_file(project["id"], section["id"], candidate["id"], token, session_id="session-2")

    short = vault.issue_ceremony_token(
        "remove_from_active",
        "session-1",
        actor_id="josie",
        project_id=project["id"],
        section_id=section["id"],
        object_id=candidate["id"],
        ttl_seconds=5,
    )["ceremony_token"]
    rec = vault.ceremony_ledger._load_record(CeremonyTokenLedger.parse_token_id(short))
    rec["expires_at"] = "2000-01-01T00:00:00"
    vault.ceremony_ledger._save_record(rec)
    with pytest.raises(VaultError, match="expired"):
        vault.remove_file(project["id"], section["id"], candidate["id"], short, session_id="session-1")

    live = vault.issue_ceremony_token(
        "remove_from_active",
        "session-1",
        actor_id="josie",
        project_id=project["id"],
        section_id=section["id"],
        object_id=candidate["id"],
    )["ceremony_token"]
    vault.lock_vault()
    vault.open_vault()
    with pytest.raises(VaultError, match="revoked"):
        vault.remove_file(project["id"], section["id"], candidate["id"], live, session_id="session-1")

    assert any(e["event_type"] == "CEREMONY_TOKEN_DENIED" for e in blackbox.iter_events())
    assert blackbox.verify_chain()["ok"] is True


def test_server_protected_remove_requires_action_bound_token_and_consumes_it(tmp_path: Path):
    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
    try:
        blackbox = BlackBox(tmp_path)
        server.blackbox21 = blackbox
        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
        client = TestClient(server.app)

        project = client.post("/api/v21/projects", json={"name": "API Ceremony"}).json()
        section = client.post(f"/api/v21/projects/{project['id']}/sections", json={"name": "Core"}).json()
        src = _source(tmp_path, "api_candidate.txt", "api")
        candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(src), "notes": "api note"},
        ).json()
        session = server.human_access.issue_identity_session(
            "josie",
            ActorKind.HUMAN,
            verified_methods=["human_ceremony", "typing_challenge"],
        )
        client.post("/api/v21/vault/open")

        loose = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
            json={
                "ceremony_token": "not-a-scoped-token",
                "actor_kind": "human",
                "session_id": session.session_id,
                "human_ceremony_passed": True,
            },
        )
        assert loose.status_code == 400

        issued = client.post(
            "/api/v21/ceremony/tokens",
            json={
                "action_key": "remove_from_active",
                "session_id": session.session_id,
                "project_id": project["id"],
                "section_id": section["id"],
                "object_id": candidate["id"],
                "ttl_seconds": 300,
            },
        )
        assert issued.status_code == 201, issued.text
        token = issued.json()["ceremony_token"]

        ok = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
            json={
                "ceremony_token": token,
                "actor_kind": "human",
                "session_id": session.session_id,
                "human_ceremony_passed": True,
            },
        )
        assert ok.status_code == 200, ok.text
        body = ok.json()
        assert body["result"]["state"] == "staging"
        assert body["human_intent_receipt"]["action_key"] == "remove_from_active"
        assert "ceremony_token" not in json.dumps(body["human_intent_receipt"])

        reused = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
            json={
                "ceremony_token": token,
                "actor_kind": "human",
                "session_id": session.session_id,
                "human_ceremony_passed": True,
            },
        )
        assert reused.status_code == 400
        assert "already been used" in reused.text
    finally:
        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human
