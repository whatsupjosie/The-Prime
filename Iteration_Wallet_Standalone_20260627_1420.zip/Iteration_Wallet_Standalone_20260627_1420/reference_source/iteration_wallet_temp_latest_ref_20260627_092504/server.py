"""
Iteration Wallet v2.1.8 — Local Identity / Session Interface
=============================================================

This module gives the Human Intent Gatekeeper an internal identity shape without
pretending to be OAuth, SSO, passkeys, biometrics, or a full auth provider.

Product law:
- Protected custody decisions must be tied to a session identity, not only an
  arbitrary user_id string passed into a function.
- Real authentication providers can attach later by issuing the same session
  shape.
- A session can identify a human, bot, AI assistant, tool, script, system, or
  unknown actor.
- Human custody actions still require a verified human ceremony method.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence


class IdentityError(Exception):
    """Raised for expected identity/session failures."""


HUMAN_KIND = "human"
BOT_KINDS = {"ai_assistant", "bot", "tool", "script", "unknown"}
HUMAN_INTENT_METHODS = {
    "human_ceremony",
    "ceremony_token",
    "live_ceremony",
    "manual_ceremony",
    "camera_verification",
    "typing_challenge",
    "read_aloud_challenge",
    "head_user_approval",
}


@dataclass
class ActorIdentity:
    """One local session identity record.

    This is intentionally provider-neutral. A future real auth layer should
    produce this shape instead of letting routes trust raw actor_id strings.
    """

    actor_id: str
    actor_kind: str = "unknown"
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:24])
    device_id: Optional[str] = None
    verified_methods: List[str] = field(default_factory=list)
    role_claims: Dict[str, Any] = field(default_factory=dict)
    issued_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    revoked_at: Optional[datetime] = None

    def __post_init__(self) -> None:
        self.actor_kind = str(self.actor_kind or "unknown")
        self.verified_methods = list(dict.fromkeys(str(m) for m in (self.verified_methods or [])))
        if self.expires_at is None:
            self.expires_at = self.issued_at + timedelta(hours=8)

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        return bool(self.expires_at and (now or datetime.now()) > self.expires_at)

    def is_revoked(self) -> bool:
        return self.revoked_at is not None

    def is_valid(self, now: Optional[datetime] = None) -> bool:
        return bool(self.actor_id and not self.is_revoked() and not self.is_expired(now))

    def is_human(self) -> bool:
        return self.actor_kind == HUMAN_KIND

    def is_bot_like(self) -> bool:
        return self.actor_kind in BOT_KINDS

    def has_verified_method(self, method: str) -> bool:
        return method in set(self.verified_methods)

    def has_any_verified_method(self, methods: Iterable[str]) -> bool:
        mine = set(self.verified_methods)
        return any(m in mine for m in methods)

    def has_human_intent_proof(self) -> bool:
        return self.is_human() and self.has_any_verified_method(HUMAN_INTENT_METHODS)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "actor_id": self.actor_id,
            "actor_kind": self.actor_kind,
            "session_id": self.session_id,
            "device_id": self.device_id,
            "verified_methods": list(self.verified_methods),
            "role_claims": dict(self.role_claims),
            "issued_at": self.issued_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "revoked_at": self.revoked_at.isoformat() if self.revoked_at else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActorIdentity":
        return cls(
            actor_id=data["actor_id"],
            actor_kind=data.get("actor_kind", "unknown"),
            session_id=data.get("session_id") or uuid.uuid4().hex[:24],
            device_id=data.get("device_id"),
            verified_methods=list(data.get("verified_methods") or []),
            role_claims=dict(data.get("role_claims") or {}),
            issued_at=datetime.fromisoformat(data["issued_at"]),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            revoked_at=datetime.fromisoformat(data["revoked_at"]) if data.get("revoked_at") else None,
        )


class LocalIdentityProvider:
    """Minimal local identity/session provider for private alpha.

    It stores session records under the vault root. It does not authenticate by
    itself. It is the interface real auth can bind to later.
    """

    def __init__(self, vault_root: Path):
        self.vault_root = Path(vault_root)
        self.identity_dir = self.vault_root / "identity"
        self.session_dir = self.identity_dir / "sessions"
        self.session_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    def issue_session(
        self,
        actor_id: str,
        actor_kind: str,
        *,
        device_id: Optional[str] = None,
        verified_methods: Optional[Sequence[str]] = None,
        role_claims: Optional[Dict[str, Any]] = None,
        ttl_minutes: int = 480,
        session_id: Optional[str] = None,
    ) -> ActorIdentity:
        if not actor_id:
            raise IdentityError("actor_id is required")
        issued_at = datetime.now()
        identity = ActorIdentity(
            actor_id=actor_id,
            actor_kind=actor_kind,
            session_id=session_id or uuid.uuid4().hex[:24],
            device_id=device_id,
            verified_methods=list(verified_methods or []),
            role_claims=dict(role_claims or {}),
            issued_at=issued_at,
            expires_at=issued_at + timedelta(minutes=max(1, int(ttl_minutes))),
        )
        self._write_json_atomic(self.session_dir / f"{identity.session_id}.json", identity.to_dict())
        return identity

    def get_session(self, session_id: str) -> Optional[ActorIdentity]:
        if not session_id:
            return None
        path = self.session_dir / f"{session_id}.json"
        if not path.exists():
            return None
        try:
            return ActorIdentity.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def require_session(self, session_id: str) -> ActorIdentity:
        identity = self.get_session(session_id)
        if not identity:
            raise IdentityError("Unknown identity session")
        if identity.is_revoked():
            raise IdentityError("Identity session has been revoked")
        if identity.is_expired():
            raise IdentityError("Identity session has expired")
        return identity

    def revoke_session(self, session_id: str, reason: Optional[str] = None) -> Optional[ActorIdentity]:
        identity = self.get_session(session_id)
        if not identity:
            return None
        identity.revoked_at = datetime.now()
        claims = dict(identity.role_claims)
        if reason:
            claims["revoke_reason"] = reason
        identity.role_claims = claims
        self._write_json_atomic(self.session_dir / f"{identity.session_id}.json", identity.to_dict())
        return identity

    def list_sessions(self, actor_id: Optional[str] = None) -> List[Dict[str, Any]]:
        sessions: List[ActorIdentity] = []
        for p in self.session_dir.glob("*.json"):
            try:
                s = ActorIdentity.from_dict(json.loads(p.read_text(encoding="utf-8")))
                if actor_id is None or s.actor_id == actor_id:
                    sessions.append(s)
            except Exception:
                continue
        sessions.sort(key=lambda s: s.issued_at)
        return [s.to_dict() for s in sessions]
