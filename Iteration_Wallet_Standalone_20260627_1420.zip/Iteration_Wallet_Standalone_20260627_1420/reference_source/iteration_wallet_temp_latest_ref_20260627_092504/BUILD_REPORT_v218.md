# Iteration Wallet v2.1.3 — No Execute Rule Patch

## Product law implemented

Iteration Wallet is not the workbench. It is controlled clean-room custody.
It never executes user-custodied material.

## Changed behavior

- Added `NO_EXECUTE_RULE` to both `vault.py` and `vault_v21.py`.
- New custodied records are explicitly marked non-executable.
- Added disabled compatibility stubs: `run_file`, `execute_file`, `launch_file`, `open_file`.
- Any attempt to run/open/execute/launch a custodied object records `EXECUTION_REFUSED` and raises `VaultError`.
- Added observational external-result attachment: IW can attach results produced outside the Vault without running the object.
- Added API routes that refuse `/run`, `/execute`, and `/open-file` for v2 and v2.1 objects.
- Fixed v2.1 release endpoint so it no longer silently defaults missing confirmation to `RELEASE`.
- Added tests proving the rule.

## Still allowed

- Exporting a working copy to an outside workspace/sandbox.
- Attaching external test results or behavior reports.
- Static review, metadata review, hashes, notes, and candidate reviews.

## Still forbidden

- Deleting user-custodied material.
- Running user-custodied material.
- Treating Iteration Wallet as the experiment bench.
