#!/usr/bin/env python3
"""
Iteration Wallet — Commit Guard Hook
=====================================
Git pre-commit hook that snapshots your project before each commit.
Blocks dangerous patterns. Enforces intentional commits.

Install:  iw install-guard [--project NAME]
Uninstall: iw uninstall-guard
"""

import os
import sys
import json
import hashlib
import subprocess
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

# ─── configuration ──────────────────────────────────────────────────────────

VAULT_API = os.environ.get("IW_VAULT_API", "http://localhost:7432/api")
PROJECT_NAME = os.environ.get("IW_PROJECT", None)

# Patterns that block commits — regex checks on file paths
BLOCKED_PATTERNS = [
    r"\.env$",                      # secrets
    r"\.env\..*$",
    r"config\.secret",
    r"credentials\.json",
    r"aws_access_key",
    r"private_key",
    r"\.pem$",
    r"oauth.*token",
    r"password.*\.txt",
    r"__pycache__/",                # built artifacts
    r"node_modules/",
    r"\.pyc$",
    r"dist/",
    r"build/",
    r"\.DS_Store",
    r"Thumbs\.db",
]

# Patterns that warn but don't block
WARN_PATTERNS = [
    r"^large_model_.*\.bin$",       # large files
    r"^data/.*\.csv$",
    r"\.zip$",
    r"test_.*_backup",
]


class CommitGuard:
    """The enforcement engine."""

    def __init__(self):
        self.project = PROJECT_NAME or self._infer_project()
        self.git_root = self._find_git_root()
        self.vault_root = Path.home() / ".iteration_wallet"
        self.events: List[Dict[str, Any]] = []

    def _find_git_root(self) -> Path:
        try:
            root = subprocess.check_output(
                ["git", "rev-parse", "--show-toplevel"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            return Path(root)
        except subprocess.CalledProcessError:
            raise RuntimeError("Not in a git repository.")

    def _infer_project(self) -> str:
        """Use git repo name as project if not specified."""
        git_root = self._find_git_root()
        return git_root.name

    def _get_staged_files(self) -> List[str]:
        """Get list of staged files from git."""
        try:
            output = subprocess.check_output(
                ["git", "diff", "--cached", "--name-only"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            return output.split("\n") if output else []
        except subprocess.CalledProcessError:
            return []

    def _check_patterns(self, files: List[str]) -> tuple[List[str], List[str]]:
        """Check files against blocked and warn patterns."""
        import re

        blocked = []
        warned = []

        for f in files:
            for pattern in BLOCKED_PATTERNS:
                if re.search(pattern, f):
                    blocked.append(f)
                    break
            else:
                for pattern in WARN_PATTERNS:
                    if re.search(pattern, f):
                        warned.append(f)
                        break

        return blocked, warned

    def _compute_manifest(self, files: List[str]) -> Dict[str, Any]:
        """
        Build a manifest of the commit.
        In a real system, this would:
        - Hash each file
        - Detect component changes (frontend/backend/etc)
        - Compute risk score
        - Check against vault state
        """
        manifest = {
            "timestamp": datetime.now().isoformat(),
            "project": self.project,
            "commit_timestamp": datetime.now().isoformat(),
            "files_count": len(files),
            "files": files[:50],  # first 50 for display
            "git_user": self._get_git_user(),
            "git_branch": self._get_git_branch(),
            "riskLevel": "NORMAL",
            "blockedPatterns": [],
            "warnings": [],
        }
        return manifest

    def _get_git_user(self) -> str:
        try:
            return subprocess.check_output(
                ["git", "config", "user.name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except subprocess.CalledProcessError:
            return "unknown"

    def _get_git_branch(self) -> str:
        try:
            return subprocess.check_output(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except subprocess.CalledProcessError:
            return "unknown"

    def run(self) -> bool:
        """
        Main guard logic. Runs on pre-commit.
        Returns True to allow commit, False to block.
        """
        files = self._get_staged_files()
        if not files:
            return True

        blocked, warned = self._check_patterns(files)

        if blocked:
            print("\n❌ Commit Guard: BLOCKED")
            print(f"\n   {len(blocked)} file(s) match dangerous patterns:\n")
            for f in blocked[:10]:
                print(f"   ✗ {f}")
            if len(blocked) > 10:
                print(f"   ... and {len(blocked) - 10} more")
            print("\n   (Commit blocked — remove these files and try again.)")
            print("\n")
            return False

        if warned:
            print(f"\n⚠️  Commit Guard: {len(warned)} warning(s)")
            for f in warned[:5]:
                print(f"   ⚠ {f}")
            if len(warned) > 5:
                print(f"   ... and {len(warned) - 5} more")
            print("\n   (Warnings only — commit will proceed.)\n")

        manifest = self._compute_manifest(files)
        print(f"\n✓ Commit Guard: OK")
        print(f"  Project: {self.project}")
        print(f"  Files: {len(files)}")
        print(f"  Branch: {manifest['git_branch']}")
        print()

        return True


def main():
    try:
        guard = CommitGuard()
        allowed = guard.run()
        sys.exit(0 if allowed else 1)
    except Exception as e:
        print(f"\n❌ Commit Guard error: {e}\n", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
