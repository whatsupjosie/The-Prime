Only in IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH: BUILD_REPORT_v220.md
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/CHANGELOG.md IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/CHANGELOG.md	2026-06-24 19:43:32.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md	2026-06-25 03:25:04.110382676 +0000
@@ -1,3 +1,15 @@
+
+## v2.2.0 — Closed Catalog + BlackBox Evidence Surface
+
+- Added closed catalog view for closed Vault/Cradle state.
+- Closed view exposes only safe metadata: name, state, size, created date, last accessed, accessed by, closed-view note, and safe BlackBox summary.
+- Closed view hides vault paths, original paths, hashes, notes, reviews, external results, contents, previews, and action surfaces.
+- Added safe BlackBox evidence summaries for closed views.
+- Added closed catalog and closed BlackBox summary API routes.
+- Added tests for closed catalog privacy and evidence summaries.
+- Repaired NotificationManager notification loading performance with an in-memory manager cache.
+- Verified full suite: 91 passed.
+
 # Oubliette Changelog
 
 ## v2.1.9 — BlackBox Extraction + Vault Coupling
Only in IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH: DIFF_REPORT_v220.patch
Only in IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH: README_v220.md
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/__init__.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/__init__.py	2026-06-24 19:42:17.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py	2026-06-25 03:25:01.093776802 +0000
@@ -7,11 +7,11 @@
 "Feic Mo Chroí — See My Heart."
 """
 
-__version__ = "2.1.9"
+__version__ = "2.2.0"
 __author__ = "Josie Curtsey Cobbley"
 __license__ = "Proprietary"
 
-# v2.1.9 BlackBox extraction + vault custody coupling
+# v2.2.0 BlackBox extraction + vault custody coupling
 try:
     from .identity import ActorIdentity, IdentityError, LocalIdentityProvider
     from .blackbox import BlackBox, BlackBoxError
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/blackbox.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/blackbox.py	2026-06-24 19:41:24.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py	2026-06-25 03:18:03.448098767 +0000
@@ -224,6 +224,69 @@
             **extra,
         )
 
+
+    def build_closed_evidence_summary(
+        self,
+        *,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        file_id: Optional[str] = None,
+        limit: int = 5,
+    ) -> Dict[str, Any]:
+        """Return a safe BlackBox summary for closed Vault/Cradle catalog views.
+
+        This deliberately omits event hashes, payload details, paths, expected/actual
+        file hashes, and request bodies. Closed view is for inventory and evidence
+        posture, not inspection of protected contents.
+        """
+        def matches(event: Dict[str, Any]) -> bool:
+            if project_id and event.get("project_id") != project_id:
+                return False
+            if section_id and event.get("section_id") != section_id:
+                return False
+            if file_id and event.get("file_id") != file_id:
+                return False
+            return True
+
+        matched = [event for event in self.iter_events() if matches(event)]
+        matched.sort(key=lambda e: (int(e.get("chain_index", 0)), e.get("created_at", "")))
+        recent = matched[-max(0, int(limit)):]
+        chain = self.verify_chain()
+
+        incident_count = 0
+        for path in self.incident_dir.glob("*.json"):
+            try:
+                incident = json.loads(path.read_text(encoding="utf-8"))
+            except Exception:
+                continue
+            if file_id and incident.get("object_id") != file_id:
+                continue
+            # Incident bundles created from bot requests often do not include
+            # project/section ids, so only filter them when present.
+            if project_id and incident.get("project_id") and incident.get("project_id") != project_id:
+                continue
+            if section_id and incident.get("section_id") and incident.get("section_id") != section_id:
+                continue
+            incident_count += 1
+
+        return {
+            "chain_ok": bool(chain.get("ok")),
+            "event_count": len(matched),
+            "custody_event_count": len([e for e in matched if e.get("custody_event")]),
+            "violation_count": len([e for e in matched if e.get("custody_violation")]),
+            "incident_count": incident_count,
+            "last_event_type": matched[-1].get("event_type") if matched else None,
+            "last_event_at": matched[-1].get("created_at") if matched else None,
+            "recent_events": [
+                {
+                    "event_type": e.get("event_type"),
+                    "created_at": e.get("created_at"),
+                    "summary": str(e.get("summary") or "")[:150],
+                }
+                for e in recent
+            ],
+        }
+
     def build_report(self, limit: int = 100) -> Dict[str, Any]:
         events = list(self.iter_events())[-limit:]
         incidents = []
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/notification_manager.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/notification_manager.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/notification_manager.py	2026-06-24 19:43:30.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/notification_manager.py	2026-06-25 03:24:07.974680575 +0000
@@ -289,6 +289,7 @@
         for d in (self.notification_dir, self.approval_dir, self.request_dir, self.event_dir, self.incident_dir):
             d.mkdir(parents=True, exist_ok=True)
         self._limits = self._load_limits()
+        self._notification_cache: Optional[List[Notification]] = None
 
     # ─── basic helpers ──────────────────────────────────────────────────
 
@@ -449,6 +450,12 @@
 
     def _save_notification(self, notification: Notification) -> None:
         self._write_json_atomic(self.notification_dir / f"{notification.notification_id}.json", notification.to_dict())
+        if self._notification_cache is not None:
+            self._notification_cache = [
+                n for n in self._notification_cache if n.notification_id != notification.notification_id
+            ]
+            self._notification_cache.append(notification)
+            self._notification_cache.sort(key=lambda n: n.created_at)
 
     def _load_notification_file(self, path: Path) -> Optional[Notification]:
         try:
@@ -457,12 +464,14 @@
             return None
 
     def _get_all_notifications(self) -> List[Notification]:
-        notifications: List[Notification] = []
-        for p in self.notification_dir.glob("*.json"):
-            n = self._load_notification_file(p)
-            if n:
-                notifications.append(n)
-        return sorted(notifications, key=lambda n: n.created_at)
+        if self._notification_cache is None:
+            notifications: List[Notification] = []
+            for p in self.notification_dir.glob("*.json"):
+                n = self._load_notification_file(p)
+                if n:
+                    notifications.append(n)
+            self._notification_cache = sorted(notifications, key=lambda n: n.created_at)
+        return list(self._notification_cache)
 
     def _get_recipient_notifications(self, recipient_id: str, unread_only: bool = True) -> List[Notification]:
         notes = [n for n in self._get_all_notifications() if n.recipient_id == recipient_id]
@@ -501,6 +510,10 @@
                 path = self.notification_dir / f"{victim.notification_id}.json"
                 if path.exists():
                     path.unlink()
+                    if self._notification_cache is not None:
+                        self._notification_cache = [
+                            n for n in self._notification_cache if n.notification_id != victim.notification_id
+                        ]
                     changed = True
         return changed
 
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/server.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/server.py	2026-06-24 19:42:09.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py	2026-06-25 03:19:16.227871310 +0000
@@ -385,6 +385,18 @@
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
+
+@app.get("/api/v21/projects/{project_id}/sections/{section_id}/closed-catalog")
+async def v220_closed_catalog_view(project_id: str, section_id: str):
+    try:
+        return vault21.get_closed_catalog_view(project_id, section_id)
+    except VaultErrorV21 as e:
+        raise HTTPException(400, str(e))
+
+@app.get("/api/v21/projects/{project_id}/sections/{section_id}/blackbox/closed-summary")
+async def v220_section_blackbox_closed_summary(project_id: str, section_id: str):
+    return blackbox21.build_closed_evidence_summary(project_id=project_id, section_id=section_id, limit=10)
+
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/raw-sources", status_code=201)
 async def v21_add_raw_source(project_id: str, section_id: str, req: AddMaterialRequest):
     try:
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/vault_v21.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/vault_v21.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/iteration_wallet/vault_v21.py	2026-06-24 19:42:00.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/vault_v21.py	2026-06-25 03:20:02.469834257 +0000
@@ -115,6 +115,62 @@
                 h.update(chunk)
         return h.hexdigest()
 
+    @staticmethod
+    def _safe_size(path_text: str, fallback: int = 0) -> int:
+        try:
+            path = Path(path_text)
+            if path.exists() and path.is_file():
+                return int(path.stat().st_size)
+        except Exception:
+            pass
+        try:
+            return int(fallback or 0)
+        except Exception:
+            return 0
+
+    def _touch_access(self, record: Dict[str, Any], accessed_by: str = "system", action: str = "metadata") -> None:
+        record["last_accessed_at"] = self._now()
+        record["last_accessed_by"] = accessed_by or "system"
+        record["last_access_action"] = action or "metadata"
+
+    def _closed_catalog_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
+        project_id = record.get("project_id")
+        section_id = record.get("section_id")
+        file_id = record.get("id")
+        safe = {
+            "id": file_id,
+            "name": record.get("name"),
+            "state": record.get("state"),
+            "custody_state": record.get("state"),
+            "size_bytes": self._safe_size(record.get("vault_path", ""), record.get("size_bytes", 0)),
+            "created_at": record.get("created_at"),
+            "last_accessed_at": record.get("last_accessed_at") or record.get("created_at"),
+            "last_accessed_by": record.get("last_accessed_by") or "unknown",
+            "closed_view_note": record.get("closed_view_note", ""),
+            "access_level": record.get("access_level", "protected"),
+            "project_id": project_id,
+            "section_id": section_id,
+        }
+        if self.blackbox:
+            safe["blackbox"] = self.blackbox.build_closed_evidence_summary(
+                project_id=project_id,
+                section_id=section_id,
+                file_id=file_id,
+                limit=3,
+            )
+        else:
+            safe["blackbox"] = None
+        return safe
+
+    def _section_blackbox_summary(self, project_id: str, section_id: str) -> Optional[Dict[str, Any]]:
+        if not self.blackbox:
+            return None
+        return self.blackbox.build_closed_evidence_summary(
+            project_id=project_id,
+            section_id=section_id,
+            limit=5,
+        )
+
     def _log(self, event_type: str, desc: str, **extra: Any) -> None:
         event = {"type": event_type, "desc": desc, "ts": self._now(), **extra}
         self._state.setdefault("events", []).insert(0, event)
@@ -275,8 +331,14 @@
             "section_id": section_id,
             "state": state,
             "hash": self._sha256(dst),
+            "size_bytes": int(dst.stat().st_size),
             "created_at": self._now(),
+            "last_accessed_at": self._now(),
+            "last_accessed_by": "system:add_material",
+            "last_access_action": "ingest",
             "notes": notes,
+            "closed_view_note": notes,
+            "access_level": "protected",
             "staged": False,
             "released": False,
             "quarantined": False,
@@ -552,6 +614,7 @@
             dst = out / f"{Path(record['name']).stem}_{counter}{Path(record['name']).suffix}"
             counter += 1
         shutil.copy2(src, dst)
+        self._touch_access(record, accessed_by="human:export_working_copy", action="export_working_copy")
         self._log("WORKING_COPY_EXPORTED", f"{record['name']} exported as working copy", project_id=project_id, section_id=section_id, file_id=file_id, output_path=str(dst))
         return {"file_id": file_id, "output_path": str(dst), "hash": self._sha256(dst)}
 
@@ -665,6 +728,20 @@
     # ─── views ────────────────────────────────────────────────────────────
 
     def get_section_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
+        """Return section view with closed-state privacy enforcement.
+
+        When the Vault is closed, this returns a catalog-only view: names, state,
+        size, created/last-accessed metadata, who last accessed, and the explicit
+        closed-view note. It must not expose contents, vault paths, original paths,
+        file hashes, reviews, external results, or protected action surfaces.
+
+        When the Vault is open, existing callers receive the full compartment view.
+        """
+        if not self._is_open:
+            return self.get_closed_catalog_view(project_id, section_id)
+        return self.get_open_section_view(project_id, section_id)
+
+    def get_open_section_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
         section = self.get_section(project_id, section_id)
         files = section.setdefault("files", [])
         archive_ids = set(section.setdefault("archive", []))
@@ -672,6 +749,8 @@
             "project_id": project_id,
             "section_id": section_id,
             "name": section["name"],
+            "view_mode": "open_full",
+            "protected_contents_visible": True,
             "raw_sources": [f for f in files if f.get("state") == "raw"],
             "candidates": [f for f in files if f.get("state") == "candidate"],
             "cradle": self._find_file(project_id, section_id, section["prime"]) if section.get("prime") else None,
@@ -684,6 +763,51 @@
                 "description": section.get("description", ""),
                 "file_count": len(files),
             },
+            "blackbox": self._section_blackbox_summary(project_id, section_id),
+            "is_vault_open": self._is_open,
+        }
+
+    def get_closed_catalog_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
+        section = self.get_section(project_id, section_id)
+        files = section.setdefault("files", [])
+        archive_ids = set(section.setdefault("archive", []))
+
+        def safe(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
+            return [self._closed_catalog_record(record) for record in records]
+
+        return {
+            "project_id": project_id,
+            "section_id": section_id,
+            "name": section["name"],
+            "view_mode": "closed_catalog",
+            "protected_contents_visible": False,
+            "closed_view_policy": {
+                "allowed_fields": [
+                    "id",
+                    "name",
+                    "state",
+                    "size_bytes",
+                    "created_at",
+                    "last_accessed_at",
+                    "last_accessed_by",
+                    "closed_view_note",
+                    "access_level",
+                    "blackbox",
+                ],
+            },
+            "raw_sources": safe([f for f in files if f.get("state") == "raw"]),
+            "candidates": safe([f for f in files if f.get("state") == "candidate"]),
+            "cradle": self._closed_catalog_record(self._find_file(project_id, section_id, section["prime"])) if section.get("prime") else None,
+            "archive": safe([f for f in files if f.get("state") == "archived" or f.get("id") in archive_ids]),
+            "removed": safe([f for f in files if f.get("state") == "staging"]),
+            "quarantine": safe([f for f in files if f.get("state") in ("quarantined", "banned")]),
+            "released": safe([f for f in files if f.get("state") == "released"]),
+            "metadata": {
+                "created_at": section.get("created_at"),
+                "description": section.get("description", ""),
+                "file_count": len(files),
+            },
+            "blackbox": self._section_blackbox_summary(project_id, section_id),
             "is_vault_open": self._is_open,
         }
 
diff -ru base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/setup.py IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py
--- base_v219/IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH/setup.py	2026-06-24 19:42:17.000000000 +0000
+++ IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py	2026-06-25 03:25:01.094651828 +0000
@@ -10,7 +10,7 @@
 
 setup(
     name="iteration-wallet",
-    version="2.1.9",
+    version="2.2.0",
     description="Cross-platform project vault for AI developers",
     long_description=long_description,
     long_description_content_type="text/markdown",
Only in IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests: test_closed_catalog_v220.py
