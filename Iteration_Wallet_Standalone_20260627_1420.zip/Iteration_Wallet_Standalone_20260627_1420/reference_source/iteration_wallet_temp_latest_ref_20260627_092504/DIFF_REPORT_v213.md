# Iteration Wallet v2.2.4 Build Report
## Private Alpha Flow Runner

## Goal

Create a developer-facing runner that executes the private-alpha custody flow outside pytest and produces a human-readable report. The goal is to give an unfamiliar bot or engineer a fast, concrete way to prove the current product spine before touching code.

## Implemented

### 1. Private Alpha Runner module

Added:

```text
iteration_wallet/private_alpha_runner.py
```

The module provides:

```text
PrivateAlphaFlowRunner
PrivateAlphaFlowReport
FlowStep
run_private_alpha_flow()
main()
```

The runner uses the public FastAPI v2.1 route layer through `TestClient`, but it is not a pytest fixture. It is a developer/operator proof tool.

### 2. Isolated runtime

Each run creates or uses a supplied local run root and temporarily binds:

```text
server.blackbox21
server.vault21
server.human_access
```

to isolated instances. The original server globals are restored after the run.

### 3. Human-readable reports

The runner writes:

```text
private_alpha_flow_report.json
private_alpha_flow_report.md
```

The reports include step-by-step evidence for the private-alpha flow and verify:

```text
closed catalog safety
Human Intent Receipts
BlackBox chain integrity
custody integrity
private-alpha readiness status
```

### 4. Report scrubbing

Report output is scrubbed so it does not expose:

```text
raw ceremony-token secrets
protected vault paths
original paths
hashes
contents
previews
open/export/run URLs
```

### 5. Persistent temp behavior

If the runner is launched without `--run-root`, it creates a persistent temp directory with `tempfile.mkdtemp()` instead of `TemporaryDirectory()`. That avoids the embarrassing failure mode where the command prints a report path that disappears as soon as the process exits.

### 6. Tool script and console entry

Added:

```text
tools/private_alpha_flow_runner.py
```

Added console entry:

```text
iw-private-alpha-flow=iteration_wallet.private_alpha_runner:main
```

### 7. Version update

Updated package version to:

```text
2.2.4
```

Updated private-alpha status endpoint version response to `2.2.4`.

## Tests added

Added:

```text
tests/test_private_alpha_runner_v224.py
```

Tests prove:

```text
runner completes successfully
JSON report is written
Markdown report is written
report status is ready
report version is correct
Human Intent Receipts are present
protected keys are not exposed in report dictionaries
raw ceremony-token key is not written to Markdown as a JSON key
```

## Verification

Commands run:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
102 passed in 2.26s
```

Manual runner check:

```bash
python -m iteration_wallet.private_alpha_runner
```

Result:

```text
Private alpha flow PASS
Run root: /tmp/iw_private_alpha_...
Report: /tmp/iw_private_alpha_.../report/private_alpha_flow_report.md
```

The printed report path remains available after process exit.

## Files changed

```text
iteration_wallet/private_alpha_runner.py
iteration_wallet/server.py
iteration_wallet/__init__.py
setup.py
tools/private_alpha_flow_runner.py
tests/test_private_alpha_runner_v224.py
tests/test_private_alpha_flow_v223.py
README_v224.md
BUILD_REPORT_v224.md
DIFF_REPORT_v224.patch
```

## Honest limits

- This runner uses in-process FastAPI `TestClient`; it does not prove a deployed HTTP server or browser UI.
- This does not implement Oubliette export-lab-reimport.
- This does not implement camera/liveness, email, hardware keys, or external cryptographic sealing.
- Real authentication is still local identity/session binding, not a production identity provider.

## Next recommended step

Now that the private-alpha spine has a repeatable runner, the next product-behavior task should be:

```text
v2.2.5 — Candidate vs Prime Comparison Workflow
```

That should give AI and humans a structured way to compare Candidate against Prime without replacing Prime automatically.
