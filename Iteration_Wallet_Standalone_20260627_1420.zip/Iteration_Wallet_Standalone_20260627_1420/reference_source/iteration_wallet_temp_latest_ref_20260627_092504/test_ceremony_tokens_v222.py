"""
Iteration Wallet v2.1 — Section / Candidate / Prime Engine
==========================================================

This module adds the explicit Iteration Wallet product model without replacing
v2's existing vault.py runtime:

Vault
  Project
    Section
      Raw Sources
      Candidates
      Cradle / Prime
      Archive
      Removed
      Metadata

Simple Wallet Mode remains the default. There is no required password. The
ceremony token is an intentional-action token created by OPEN and invalidated by
LOCK. It is used for high-impact custody actions such as REMOVE, RELEASE,
QUARANTINE/BAN, and Prime promotion.

HARD RULE: Iteration Wallet never deletes user-custodied material. It may
remove items from active use, quarantine, ban, refuse to open/run, or perform a
live-person release from custody. It must not destroy a user-added file while
that item is inside Iteration Wallet custody.

HARD RULE: Iteration Wallet never executes user-custodied material. The Vault is
locked clean-room storage, not the workbench. Experiments, builds, tests, and
program execution happen outside Iteration Wallet. The engine may only inspect
metadata, hashes, static text, review notes, and externally supplied test results.
"""

from __future__ import annotations

import json
import shutil
import hashlib
import uuid
import secrets
from pathlib import Path
from datetime import datetime, date
from typing import Any, Dict, Optional, List

from iteration_wallet.blackbox import BlackBox
from iteration_wallet.ceremony import CeremonyTokenLedger, CeremonyTokenError


NO_DELETE_RULE = "Iteration Wallet never deletes user-custodied material. Use REMOVE, QUARANTINE/BAN, or live-person RELEASE from custody instead."
NO_EXECUTE_RULE = "Iteration Wallet never executes user-custodied material. Export a working copy and run experiments outside the Vault."


class VaultError(Exception):
    """Raised for expected Iteration Wallet operation failures."""


class VaultEngine:
    """Section-aware Iteration Wallet engine.

    This engine intentionally avoids mandatory password/authentication. Safety is
    provided first by custody layout, copy-not-mutate behavior, staged removal,
    live-person custody ceremonies, and the hard no-delete rule.
    """

    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None, *, strict_ceremony_tokens: bool = False, ceremony_token_ttl_seconds: int = 300):
        self.root = Path(vault_root)
        self.state_file = self.root / "state_v21.json"
        self.root.mkdir(parents=True, exist_ok=True)
        self.blackbox = blackbox
        self.strict_ceremony_tokens = bool(strict_ceremony_tokens)
        self.ceremony_token_ttl_seconds = max(5, min(int(ceremony_token_ttl_seconds or 300), 900))
        self.ceremony_ledger = CeremonyTokenLedger(self.root, blackbox=blackbox)
        self._is_open = False
        self._ceremony_token: Optional[str] = None
        self._open_session_id: Optional[str] = None
        self._state: Dict[str, Any] = self._load()

    def attach_blackbox(self, blackbox: BlackBox) -> None:
        """Attach shared BlackBox evidence writer after construction."""
        self.blackbox = blackbox
        self.ceremony_ledger.blackbox = blackbox

    # ─── persistence ──────────────────────────────────────────────────────

    def _load(self) -> Dict[str, Any]:
        if self.state_file.exists():
            try:
                data = json.loads(self.state_file.read_text(encoding="utf-8"))
                data.setdefault("projects", [])
                data.setdefault("events", [])
                return data
            except Exception as exc:
                raise VaultError(f"Could not load vault state: {exc}") from exc
        return {"schema": "iteration-wallet-v2.1", "projects": [], "events": []}

    def _save(self) -> None:
        tmp = self.state_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._state, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.state_file)

    # ─── helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _uid() -> str:
        return uuid.uuid4().hex[:12]

    @staticmethod
    def _now() -> str:
        return datetime.now().isoformat(timespec="seconds")

    @staticmethod
    def _today() -> str:
        # Portable across Linux/macOS/Windows; unlike %-d.
        return date.today().strftime("%d %b %Y").lstrip("0")

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    @staticmethod
    def _safe_size(path_text: str, fallback: int = 0) -> int:
        try:
            path = Path(path_text)
            if path.exists() and path.is_file():
                return int(path.stat().st_size)
        except Exception:
            pass
        try:
            return int(fallback or 0)
        except Exception:
            return 0

    def _touch_access(self, record: Dict[str, Any], accessed_by: str = "system", action: str = "metadata") -> None:
        record["last_accessed_at"] = self._now()
        record["last_accessed_by"] = accessed_by or "system"
        record["last_access_action"] = action or "metadata"

    def _closed_catalog_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        project_id = record.get("project_id")
        section_id = record.get("section_id")
        file_id = record.get("id")
        safe = {
            "id": file_id,
            "name": record.get("name"),
            "state": record.get("state"),
            "custody_state": record.get("state"),
            "size_bytes": self._safe_size(record.get("vault_path", ""), record.get("size_bytes", 0)),
            "created_at": record.get("created_at"),
            "last_accessed_at": record.get("last_accessed_at") or record.get("created_at"),
            "last_accessed_by": record.get("last_accessed_by") or "unknown",
            "closed_view_note": record.get("closed_view_note", ""),
            "access_level": record.get("access_level", "protected"),
            "project_id": project_id,
            "section_id": section_id,
        }
        if self.blackbox:
            safe["blackbox"] = self.blackbox.build_closed_evidence_summary(
                project_id=project_id,
                section_id=section_id,
                file_id=file_id,
                limit=3,
            )
        else:
            safe["blackbox"] = None
        return safe

    def _section_blackbox_summary(self, project_id: str, section_id: str) -> Optional[Dict[str, Any]]:
        if not self.blackbox:
            return None
        return self.blackbox.build_closed_evidence_summary(
            project_id=project_id,
            section_id=section_id,
            limit=5,
        )

    def _log(self, event_type: str, desc: str, **extra: Any) -> None:
        event = {"type": event_type, "desc": desc, "ts": self._now(), **extra}
        self._state.setdefault("events", []).insert(0, event)
        self._state["events"] = self._state["events"][:1000]
        self._save()
        self._blackbox_custody_event(event_type, desc, **extra)

    def _blackbox_custody_event(self, event_type: str, desc: str, **extra: Any) -> None:
        """Mirror custody events into BlackBox when attached.

        Local state remains a convenience/activity view. BlackBox is the
        tamper-evident custody evidence trail. Failure to write BlackBox should
        block custody-moving operations, because split evidence is dangerous.
        """
        if not self.blackbox:
            return
        self.blackbox.write_custody_event(
            event_type,
            desc,
            project_id=extra.get("project_id"),
            section_id=extra.get("section_id"),
            file_id=extra.get("file_id"),
            state=extra.get("state"),
            local_event=event_type,
            details=extra,
        )

    def _blackbox_violation_event(self, event_type: str, desc: str, **extra: Any) -> None:
        if not self.blackbox:
            return
        self.blackbox.write_violation_event(event_type, desc, details=extra, **extra)

    def _project_dir(self, project_id: str) -> Path:
        return self.root / "projects" / project_id

    def _section_dir(self, project_id: str, section_id: str) -> Path:
        return self._project_dir(project_id) / "sections" / section_id

    def _compartment_dir(self, project_id: str, section_id: str, compartment: str) -> Path:
        return self._section_dir(project_id, section_id) / compartment

    def _safe_copy_name(self, file_id: str, src: Path) -> str:
        return f"{file_id}_{src.name}"

    def _copy_into(self, src: Path, dst_dir: Path, file_id: str) -> Path:
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst = dst_dir / self._safe_copy_name(file_id, src)
        shutil.copy2(src, dst)
        return dst

    def _require_open_token(
        self,
        token: str,
        *,
        action_key: Optional[str] = None,
        session_id: Optional[str] = None,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
        consume: bool = False,
    ) -> None:
        if not self._is_open:
            raise VaultError("Vault must be open")
        # In strict mode, protected custody actions must use scoped action tokens.
        if action_key and self.strict_ceremony_tokens:
            try:
                self.ceremony_ledger.validate_and_consume(
                    token,
                    action_key=action_key,
                    session_id=session_id,
                    open_session_id=self._open_session_id,
                    project_id=project_id,
                    section_id=section_id,
                    object_id=object_id,
                )
                return
            except CeremonyTokenError as exc:
                raise VaultError(str(exc)) from exc
        # Backward-compatible engine-level token path for older direct tests and
        # local private-alpha callers. Server routes use strict mode.
        if not token or token != self._ceremony_token:
            # Non-strict callers may still pass a scoped token; validate it if an action was supplied.
            if action_key:
                try:
                    self.ceremony_ledger.validate_and_consume(
                        token,
                        action_key=action_key,
                        session_id=session_id,
                        open_session_id=self._open_session_id,
                        project_id=project_id,
                        section_id=section_id,
                        object_id=object_id,
                    )
                    return
                except CeremonyTokenError:
                    pass
            raise VaultError("Invalid ceremony token")

    # ─── lookup ───────────────────────────────────────────────────────────

    def get_project(self, project_id: str) -> Dict[str, Any]:
        for project in self._state["projects"]:
            if project["id"] == project_id:
                return project
        raise VaultError("Project not found")

    def get_section(self, project_id: str, section_id: str) -> Dict[str, Any]:
        project = self.get_project(project_id)
        for section in project.setdefault("sections", []):
            if section["id"] == section_id:
                return section
        raise VaultError("Section not found")

    def _find_file(self, project_id: str, section_id: str, file_id: str) -> Dict[str, Any]:
        section = self.get_section(project_id, section_id)
        for file_record in section.setdefault("files", []):
            if file_record["id"] == file_id:
                return file_record
        raise VaultError("File not found")

    # ─── projects and sections ────────────────────────────────────────────

    def create_project(self, name: str, path: str = "") -> Dict[str, Any]:
        name = name.strip()
        if not name:
            raise VaultError("Project name is required")
        project_id = self._uid()
        project = {
            "id": project_id,
            "name": name,
            "path": path.strip() or "",
            "created_at": self._now(),
            "sections": [],
        }
        (self._project_dir(project_id) / "metadata").mkdir(parents=True, exist_ok=True)
        self._state["projects"].append(project)
        self._log("PROJECT_CREATED", f"Project created: {name}", project_id=project_id)
        return project

    def create_section(self, project_id: str, name: str, description: str = "") -> Dict[str, Any]:
        project = self.get_project(project_id)
        name = name.strip()
        if not name:
            raise VaultError("Section name is required")
        section_id = self._uid()
        section = {
            "id": section_id,
            "name": name,
            "description": description.strip(),
            "created_at": self._now(),
            "files": [],
            "prime": None,
            "archive": [],
        }
        for compartment in ("raw_sources", "candidates", "cradle", "archive", "removed", "quarantine", "released", "metadata"):
            self._compartment_dir(project_id, section_id, compartment).mkdir(parents=True, exist_ok=True)
        project.setdefault("sections", []).append(section)
        self._log("SECTION_CREATED", f"Section created: {name}", project_id=project_id, section_id=section_id)
        return section

    # ─── open / lock ceremony ─────────────────────────────────────────────

    def open_vault(self) -> Dict[str, Any]:
        self._is_open = True
        self._ceremony_token = secrets.token_urlsafe(24)
        self._open_session_id = uuid.uuid4().hex[:16]
        self._log("VAULT_OPENED", "Vault opened; open session started")
        return {
            "is_open": True,
            "ceremony_token": self._ceremony_token,
            "open_session_id": self._open_session_id,
            "strict_ceremony_tokens": self.strict_ceremony_tokens,
        }

    def lock_vault(self) -> Dict[str, Any]:
        revoked = self.ceremony_ledger.revoke_for_open_session(self._open_session_id or "", reason="vault locked")
        self._is_open = False
        self._ceremony_token = None
        self._open_session_id = None
        self._log("VAULT_LOCKED", "Vault locked; ceremony tokens invalidated", revoked_tokens=revoked)
        return {"is_open": False, "revoked_ceremony_tokens": revoked}

    def issue_ceremony_token(
        self,
        action_key: str,
        session_id: str,
        *,
        actor_id: Optional[str] = None,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Issue a short-lived action/session-bound ceremony token.

        The raw token is returned once and never persisted. The token is scoped
        to one protected action and consumed by that action.
        """
        if not self._is_open or not self._open_session_id:
            raise VaultError("Vault must be open before issuing a ceremony token")
        try:
            return self.ceremony_ledger.issue_token(
                action_key=action_key,
                session_id=session_id,
                actor_id=actor_id,
                project_id=project_id,
                section_id=section_id,
                object_id=object_id,
                open_session_id=self._open_session_id,
                ttl_seconds=ttl_seconds or self.ceremony_token_ttl_seconds,
            )
        except CeremonyTokenError as exc:
            raise VaultError(str(exc)) from exc

    def revoke_ceremony_token(self, ceremony_token: str, reason: str = "manual revocation") -> Dict[str, Any]:
        try:
            return self.ceremony_ledger.revoke_token(ceremony_token, reason=reason)
        except CeremonyTokenError as exc:
            raise VaultError(str(exc)) from exc

    def list_ceremony_tokens(self) -> List[Dict[str, Any]]:
        return self.ceremony_ledger.list_tokens(include_hashes=False)

    # ─── adding materials ─────────────────────────────────────────────────

    def _add_file_to_section(
        self,
        project_id: str,
        section_id: str,
        file_path: str,
        state: str,
        compartment: str,
        notes: str = "",
    ) -> Dict[str, Any]:
        section = self.get_section(project_id, section_id)
        src = Path(file_path)
        if not src.exists():
            raise VaultError(f"File not found: {file_path}")
        if not src.is_file():
            raise VaultError(f"Path is not a file: {file_path}")
        file_id = self._uid()
        dst = self._copy_into(src, self._compartment_dir(project_id, section_id, compartment), file_id)
        record = {
            "id": file_id,
            "name": src.name,
            "original_path": str(src),
            "vault_path": str(dst),
            "project_id": project_id,
            "section_id": section_id,
            "state": state,
            "hash": self._sha256(dst),
            "size_bytes": int(dst.stat().st_size),
            "created_at": self._now(),
            "last_accessed_at": self._now(),
            "last_accessed_by": "system:add_material",
            "last_access_action": "ingest",
            "notes": notes,
            "closed_view_note": notes,
            "access_level": "protected",
            "staged": False,
            "released": False,
            "quarantined": False,
            "banned": False,
            "promoted": False,
            "execution_allowed": False,
            "execution_policy": "never_execute_inside_iteration_wallet",
        }
        section.setdefault("files", []).append(record)
        self._log(
            "RAW_SOURCE_ADDED" if state == "raw" else "CANDIDATE_ADDED",
            f"{src.name} added as {state}",
            project_id=project_id,
            section_id=section_id,
            file_id=file_id,
        )
        return record

    def add_raw_source(self, project_id: str, section_id: str, file_path: str, notes: str = "") -> Dict[str, Any]:
        return self._add_file_to_section(project_id, section_id, file_path, "raw", "raw_sources", notes)

    def add_candidate(self, project_id: str, section_id: str, file_path: str, notes: str = "") -> Dict[str, Any]:
        return self._add_file_to_section(project_id, section_id, file_path, "candidate", "candidates", notes)

    # ─── removal / release / quarantine ceremony ──────────────────────────

    def remove_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        self._require_open_token(ceremony_token, action_key="remove_from_active", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
        record = self._find_file(project_id, section_id, file_id)
        if record.get("released"):
            raise VaultError("File has been released from Iteration Wallet custody")
        if record.get("state") == "staging":
            return record
        if record.get("state") == "prime":
            raise VaultError("Prime cannot be removed directly; promote a replacement or archive first")
        src = Path(record.get("vault_path", ""))
        removed_dir = self._compartment_dir(project_id, section_id, "removed")
        removed_dir.mkdir(parents=True, exist_ok=True)
        if src.exists():
            dst = removed_dir / src.name
            counter = 1
            while dst.exists():
                dst = removed_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            record["vault_path"] = str(dst)
        record["previous_state"] = record.get("state")
        record["state"] = "staging"
        record["staged"] = True
        record["staged_at"] = self._now()
        self._log("FILE_STAGED_FOR_REMOVAL", f"{record['name']} moved to Removed staging", project_id=project_id, section_id=section_id, file_id=file_id)
        return record


    def release_from_custody(
        self,
        project_id: str,
        section_id: str,
        file_id: str,
        ceremony_token: str,
        human_confirmation: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Live-person release from Iteration Wallet custody.

        Release is not destruction. The vault-held copy is preserved and moved
        into the released compartment with a manifest state change. A human must
        explicitly type RELEASE. Iteration Wallet never deletes the file.
        """
        if human_confirmation != "RELEASE":
            raise VaultError("Release requires live-person confirmation: type RELEASE")
        self._require_open_token(ceremony_token, action_key="release_from_custody", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
        record = self._find_file(project_id, section_id, file_id)
        if record.get("state") == "prime":
            raise VaultError("Prime cannot be released directly; relieve it from the Cradle first")
        released_dir = self._compartment_dir(project_id, section_id, "released")
        released_dir.mkdir(parents=True, exist_ok=True)
        src = Path(record.get("vault_path", ""))
        if src.exists() and src.parent != released_dir:
            dst = released_dir / src.name
            counter = 1
            while dst.exists():
                dst = released_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            record["vault_path"] = str(dst)
        record["previous_state"] = record.get("state")
        record["state"] = "released"
        record["released"] = True
        record["released_at"] = self._now()
        self._log("FILE_RELEASED_FROM_CUSTODY", f"{record['name']} released from Iteration Wallet custody by live-person ceremony", project_id=project_id, section_id=section_id, file_id=file_id)
        return record

    def quarantine_file(
        self,
        project_id: str,
        section_id: str,
        file_id: str,
        ceremony_token: str,
        reason: str = "",
        ban: bool = False,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Isolate an item and refuse to open/run/use it. No destruction."""
        self._require_open_token(ceremony_token, action_key="quarantine", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
        record = self._find_file(project_id, section_id, file_id)
        if record.get("state") == "prime":
            raise VaultError("Prime cannot be quarantined directly; relieve it from the Cradle first")
        quarantine_dir = self._compartment_dir(project_id, section_id, "quarantine")
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        src = Path(record.get("vault_path", ""))
        if src.exists() and src.parent != quarantine_dir:
            dst = quarantine_dir / src.name
            counter = 1
            while dst.exists():
                dst = quarantine_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            record["vault_path"] = str(dst)
        record["previous_state"] = record.get("state")
        record["state"] = "banned" if ban else "quarantined"
        record["quarantined"] = True
        record["banned"] = bool(ban)
        record["quarantine_reason"] = reason
        record["quarantined_at"] = self._now()
        self._log("FILE_BANNED" if ban else "FILE_QUARANTINED", f"{record['name']} isolated without deletion", project_id=project_id, section_id=section_id, file_id=file_id, reason=reason)
        return record

    # ─── Prime promotion ──────────────────────────────────────────────────

    def promote_to_prime(
        self,
        project_id: str,
        section_id: str,
        candidate_id: str,
        ceremony_token: str,
        reason: str = "",
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        self._require_open_token(ceremony_token, action_key="promote_candidate_to_prime", session_id=session_id, project_id=project_id, section_id=section_id, object_id=candidate_id, consume=True)
        section = self.get_section(project_id, section_id)
        candidate = self._find_file(project_id, section_id, candidate_id)
        if candidate.get("state") not in ("candidate", "raw"):
            raise VaultError("Only a candidate/raw source can be promoted to Prime")

        old_prime_id = section.get("prime")
        if old_prime_id:
            old_prime = self._find_file(project_id, section_id, old_prime_id)
            old_src = Path(old_prime.get("vault_path", ""))
            archive_dir = self._compartment_dir(project_id, section_id, "archive")
            archive_dir.mkdir(parents=True, exist_ok=True)
            if old_src.exists():
                old_dst = archive_dir / old_src.name
                counter = 1
                while old_dst.exists():
                    old_dst = archive_dir / f"{old_src.stem}_{counter}{old_src.suffix}"
                    counter += 1
                shutil.move(str(old_src), str(old_dst))
                old_prime["vault_path"] = str(old_dst)
            old_prime["state"] = "archived"
            old_prime["archived_at"] = self._now()
            if old_prime_id not in section.setdefault("archive", []):
                section["archive"].append(old_prime_id)

        cand_src = Path(candidate.get("vault_path", ""))
        cradle_dir = self._compartment_dir(project_id, section_id, "cradle")
        cradle_dir.mkdir(parents=True, exist_ok=True)
        if cand_src.exists():
            prime_dst = cradle_dir / cand_src.name
            counter = 1
            while prime_dst.exists():
                prime_dst = cradle_dir / f"{cand_src.stem}_{counter}{cand_src.suffix}"
                counter += 1
            shutil.move(str(cand_src), str(prime_dst))
            candidate["vault_path"] = str(prime_dst)

        candidate["state"] = "prime"
        candidate["promoted"] = True
        candidate["promoted_at"] = self._now()
        candidate["promotion_reason"] = reason
        section["prime"] = candidate_id
        self._log("PRIME_PROMOTED", f"{candidate['name']} promoted to Prime", project_id=project_id, section_id=section_id, file_id=candidate_id, reason=reason)
        return candidate



    def restore_file(self, project_id: str, section_id: str, file_id: str, ceremony_token: str, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Restore a staged Removed file back to its previous compartment.

        Removed is a reversible staging area. Iteration Wallet has no DELETE step.
        Prime is not normally removable, so restore targets raw/candidate/archive.
        """
        self._require_open_token(ceremony_token, action_key="restore_to_active", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
        record = self._find_file(project_id, section_id, file_id)
        if record.get("state") != "staging":
            raise VaultError("Only files in Removed staging can be restored")
        previous = record.get("previous_state") or "candidate"
        compartment = {
            "raw": "raw_sources",
            "candidate": "candidates",
            "archived": "archive",
        }.get(previous, "candidates")
        src = Path(record.get("vault_path", ""))
        target_dir = self._compartment_dir(project_id, section_id, compartment)
        target_dir.mkdir(parents=True, exist_ok=True)
        if src.exists():
            dst = target_dir / src.name
            counter = 1
            while dst.exists():
                dst = target_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            record["vault_path"] = str(dst)
        record["state"] = previous
        record["staged"] = False
        record["restored_at"] = self._now()
        self._log("FILE_RESTORED_FROM_REMOVED", f"{record['name']} restored from Removed", project_id=project_id, section_id=section_id, file_id=file_id)
        return record

    def review_candidate(
        self,
        project_id: str,
        section_id: str,
        candidate_id: str,
        verdict: str,
        summary: str = "",
        strengths: Optional[list[str]] = None,
        risks: Optional[list[str]] = None,
    ) -> Dict[str, Any]:
        """Attach a Prime-readiness review to a Candidate.

        This is the AI/helper lane: evaluate and advise. It never promotes.
        Promotion still requires OPEN + ceremony token + explicit promote_to_prime.
        """
        candidate = self._find_file(project_id, section_id, candidate_id)
        if candidate.get("state") != "candidate":
            raise VaultError("Only Candidates can receive Prime-readiness reviews")
        verdict = (verdict or "needs_review").strip().lower().replace(" ", "_")
        allowed = {"ready", "not_ready", "needs_review", "donor_material"}
        if verdict not in allowed:
            raise VaultError(f"Review verdict must be one of: {', '.join(sorted(allowed))}")
        review = {
            "id": self._uid(),
            "candidate_id": candidate_id,
            "verdict": verdict,
            "summary": summary.strip(),
            "strengths": strengths or [],
            "risks": risks or [],
            "created_at": self._now(),
        }
        candidate.setdefault("reviews", []).append(review)
        candidate["last_review_verdict"] = verdict
        metadata_dir = self._compartment_dir(project_id, section_id, "metadata") / "candidate_reviews"
        metadata_dir.mkdir(parents=True, exist_ok=True)
        (metadata_dir / f"{candidate_id}_{review['id']}.json").write_text(json.dumps(review, indent=2, ensure_ascii=False), encoding="utf-8")
        self._log("CANDIDATE_REVIEWED", f"{candidate['name']} reviewed: {verdict}", project_id=project_id, section_id=section_id, file_id=candidate_id, verdict=verdict)
        return review

    def export_working_copy(self, project_id: str, section_id: str, file_id: str, output_dir: str, ceremony_token: Optional[str] = None, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Copy a vault-held file out to a workspace/sandbox without mutating custody.

        This is how experiments leave the clean-room storage. The Vault keeps its
        controlled copy; the user gets a working copy elsewhere.
        """
        if self.strict_ceremony_tokens:
            self._require_open_token(ceremony_token or "", action_key="export_working_copy", session_id=session_id, project_id=project_id, section_id=section_id, object_id=file_id, consume=True)
        record = self._find_file(project_id, section_id, file_id)
        if record.get("state") in ("staging", "released", "quarantined", "banned"):
            raise VaultError("Cannot export a Removed, released, quarantined, or banned file")
        src = Path(record.get("vault_path", ""))
        if not src.exists():
            raise VaultError("Vault copy is missing")
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        dst = out / record["name"]
        counter = 1
        while dst.exists():
            dst = out / f"{Path(record['name']).stem}_{counter}{Path(record['name']).suffix}"
            counter += 1
        shutil.copy2(src, dst)
        self._touch_access(record, accessed_by="human:export_working_copy", action="export_working_copy")
        self._log("WORKING_COPY_EXPORTED", f"{record['name']} exported as working copy", project_id=project_id, section_id=section_id, file_id=file_id, output_path=str(dst))
        return {"file_id": file_id, "output_path": str(dst), "hash": self._sha256(dst)}


    # ─── execution boundary / observational analysis ───────────────────────

    def attach_external_test_results(
        self,
        project_id: str,
        section_id: str,
        candidate_id: str,
        summary: str,
        passed: Optional[bool] = None,
        source: str = "external",
        artifacts: Optional[list[str]] = None,
    ) -> Dict[str, Any]:
        """Attach externally generated test/build results without running code.

        Iteration Wallet may reason about results created outside the Vault. It
        does not run the candidate, run the project tests, or invoke a sandbox.
        """
        candidate = self._find_file(project_id, section_id, candidate_id)
        if candidate.get("state") not in ("candidate", "prime", "archived", "raw"):
            raise VaultError("External results can only be attached to custodied material")
        result = {
            "id": self._uid(),
            "candidate_id": candidate_id,
            "summary": summary.strip(),
            "passed": passed,
            "source": source.strip() or "external",
            "artifacts": artifacts or [],
            "observational_only": True,
            "created_at": self._now(),
        }
        candidate.setdefault("external_test_results", []).append(result)
        metadata_dir = self._compartment_dir(project_id, section_id, "metadata") / "external_results"
        metadata_dir.mkdir(parents=True, exist_ok=True)
        (metadata_dir / f"{candidate_id}_{result['id']}.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        self._log("EXTERNAL_RESULTS_ATTACHED", f"External results attached for {candidate['name']}", project_id=project_id, section_id=section_id, file_id=candidate_id, source=result["source"])
        return result

    # ─── custody verification / incident detection ──────────────────────────

    def verify_custody_integrity(self) -> Dict[str, Any]:
        """Check stored custody records against files and hashes.

        This method does not repair or delete. It reports suspected custody breaks
        and writes BlackBox violation events when a custodied object is missing or
        changed without a custody ceremony.
        """
        incidents: List[Dict[str, Any]] = []
        for project in self._state.setdefault("projects", []):
            project_id = project.get("id")
            for section in project.setdefault("sections", []):
                section_id = section.get("id")
                prime_id = section.get("prime")
                for record in section.setdefault("files", []):
                    file_id = record.get("id")
                    state = record.get("state")
                    path_text = record.get("vault_path") or ""
                    # Released objects are no longer under IW protection; everything
                    # else with a vault_path is still custody-relevant.
                    if state == "released" or not path_text:
                        continue
                    path = Path(path_text)
                    if not path.exists():
                        event_type = "MISSING_PRIME_OBJECT" if file_id == prime_id else "MISSING_CUSTODY_OBJECT"
                        incident = {
                            "type": event_type,
                            "project_id": project_id,
                            "section_id": section_id,
                            "file_id": file_id,
                            "name": record.get("name"),
                            "state": state,
                            "vault_path": path_text,
                        }
                        incidents.append(incident)
                        self._blackbox_violation_event(
                            event_type,
                            f"Custodied object missing: {record.get('name')}",
                            **incident,
                        )
                        continue
                    expected_hash = record.get("hash")
                    actual_hash = self._sha256(path)
                    if expected_hash and actual_hash != expected_hash:
                        event_type = "PRIME_HASH_MISMATCH" if file_id == prime_id else "HASH_MISMATCH"
                        incident = {
                            "type": event_type,
                            "project_id": project_id,
                            "section_id": section_id,
                            "file_id": file_id,
                            "name": record.get("name"),
                            "state": state,
                            "vault_path": path_text,
                            "expected_hash": expected_hash,
                            "actual_hash": actual_hash,
                        }
                        incidents.append(incident)
                        self._blackbox_violation_event(
                            event_type,
                            f"Custodied object hash mismatch: {record.get('name')}",
                            **incident,
                        )
        return {
            "ok": not incidents,
            "incident_count": len(incidents),
            "incidents": incidents,
        }

    # ─── views ────────────────────────────────────────────────────────────

    def get_section_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
        """Return section view with closed-state privacy enforcement.

        When the Vault is closed, this returns a catalog-only view: names, state,
        size, created/last-accessed metadata, who last accessed, and the explicit
        closed-view note. It must not expose contents, vault paths, original paths,
        file hashes, reviews, external results, or protected action surfaces.

        When the Vault is open, existing callers receive the full compartment view.
        """
        if not self._is_open:
            return self.get_closed_catalog_view(project_id, section_id)
        return self.get_open_section_view(project_id, section_id)

    def get_open_section_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
        section = self.get_section(project_id, section_id)
        files = section.setdefault("files", [])
        archive_ids = set(section.setdefault("archive", []))
        return {
            "project_id": project_id,
            "section_id": section_id,
            "name": section["name"],
            "view_mode": "open_full",
            "protected_contents_visible": True,
            "raw_sources": [f for f in files if f.get("state") == "raw"],
            "candidates": [f for f in files if f.get("state") == "candidate"],
            "cradle": self._find_file(project_id, section_id, section["prime"]) if section.get("prime") else None,
            "archive": [f for f in files if f.get("state") == "archived" or f.get("id") in archive_ids],
            "removed": [f for f in files if f.get("state") == "staging"],
            "quarantine": [f for f in files if f.get("state") in ("quarantined", "banned")],
            "released": [f for f in files if f.get("state") == "released"],
            "metadata": {
                "created_at": section.get("created_at"),
                "description": section.get("description", ""),
                "file_count": len(files),
            },
            "blackbox": self._section_blackbox_summary(project_id, section_id),
            "is_vault_open": self._is_open,
        }

    def get_closed_catalog_view(self, project_id: str, section_id: str) -> Dict[str, Any]:
        section = self.get_section(project_id, section_id)
        files = section.setdefault("files", [])
        archive_ids = set(section.setdefault("archive", []))

        def safe(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            return [self._closed_catalog_record(record) for record in records]

        return {
            "project_id": project_id,
            "section_id": section_id,
            "name": section["name"],
            "view_mode": "closed_catalog",
            "protected_contents_visible": False,
            "closed_view_policy": {
                "allowed_fields": [
                    "id",
                    "name",
                    "state",
                    "size_bytes",
                    "created_at",
                    "last_accessed_at",
                    "last_accessed_by",
                    "closed_view_note",
                    "access_level",
                    "blackbox",
                ],
            },
            "raw_sources": safe([f for f in files if f.get("state") == "raw"]),
            "candidates": safe([f for f in files if f.get("state") == "candidate"]),
            "cradle": self._closed_catalog_record(self._find_file(project_id, section_id, section["prime"])) if section.get("prime") else None,
            "archive": safe([f for f in files if f.get("state") == "archived" or f.get("id") in archive_ids]),
            "removed": safe([f for f in files if f.get("state") == "staging"]),
            "quarantine": safe([f for f in files if f.get("state") in ("quarantined", "banned")]),
            "released": safe([f for f in files if f.get("state") == "released"]),
            "metadata": {
                "created_at": section.get("created_at"),
                "description": section.get("description", ""),
                "file_count": len(files),
            },
            "blackbox": self._section_blackbox_summary(project_id, section_id),
            "is_vault_open": self._is_open,
        }

    def get_state(self) -> Dict[str, Any]:
        return {**self._state, "is_vault_open": self._is_open}
