"""
Iteration Wallet — Vault Engine
================================
Core filesystem logic: projects, canonical copies, archive, staging, events.

© 2024–2025 Josie Curtsey Cobbley / Rear View Foresight LLC
"""

import json
import shutil
import hashlib
import uuid
import platform
from pathlib import Path
from datetime import datetime, date
from typing import List, Optional, Dict, Any

VAULT_ROOT = Path.home() / ".iteration_wallet"
NO_DELETE_RULE = "Iteration Wallet never deletes user-custodied material. Use REMOVE, QUARANTINE/BAN, or live-person RELEASE from custody instead."
NO_EXECUTE_RULE = "Iteration Wallet never executes user-custodied material. Export a working copy and run experiments outside the Vault."


class VaultError(Exception):
    """Raised for expected vault operation failures."""
    pass


class VaultEngine:
    """
    The core engine. One instance per server process.

    Directory layout under VAULT_ROOT:
        state.json                  ← persisted state (projects, files, events)
        projects/
            {project_id}/
                metadata.json
                vault/
                    cradle/
                        {version}/
                            canonical/  ← protected copies live here
                    archive/
                        {version}/      ← demoted versions land here
                removed_files/          ← staging area (REMOVE → here; no delete inside IW)
    """

    def __init__(self, vault_root: Path = VAULT_ROOT):
        self.root = vault_root
        self.state_file = vault_root / "state.json"
        self.root.mkdir(parents=True, exist_ok=True)
        self._state: Dict[str, Any] = self._load()
        self._is_open: bool = False

    # ─── persistence ───────────────────────────────────────────────────────

    def _load(self) -> dict:
        if self.state_file.exists():
            try:
                return json.loads(self.state_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {"projects": [], "files": [], "events": []}

    def _save(self) -> None:
        tmp = self.state_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._state, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.state_file)

    # ─── helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _uid() -> str:
        return uuid.uuid4().hex[:12]

    @staticmethod
    def _today() -> str:
        return date.today().strftime("%-d %b %Y")

    @staticmethod
    def _ts() -> str:
        return datetime.now().strftime("%H:%M:%S")

    @staticmethod
    def _format_size(n: int) -> str:
        if n < 1024:
            return f"{n} B"
        if n < 1024 ** 2:
            return f"{n // 1024} KB"
        return f"{n // 1024 // 1024} MB"

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()[:16]

    def _log(self, event_type: str, desc: str) -> None:
        entry = {"type": event_type, "desc": desc, "ts": self._ts()}
        self._state["events"].insert(0, entry)
        # Keep log bounded
        if len(self._state["events"]) > 500:
            self._state["events"] = self._state["events"][:500]
        self._save()

    def _project_dir(self, project_id: str) -> Path:
        return self.root / "projects" / project_id

    def _cradle_dir(self, project_id: str, version: str) -> Path:
        return self._project_dir(project_id) / "vault" / "cradle" / version / "canonical"

    def _removed_dir(self, project_id: str) -> Path:
        return self._project_dir(project_id) / "removed_files"

    def _released_dir(self, project_id: str) -> Path:
        return self._project_dir(project_id) / "released_from_wallet"

    def _archive_dir(self, project_id: str, version: str) -> Path:
        return self._project_dir(project_id) / "vault" / "archive" / version

    # ─── read state ────────────────────────────────────────────────────────

    def get_state(self) -> dict:
        return {
            "projects": self._state["projects"],
            "files": self._state["files"],
            "events": self._state["events"][:100],
            "vaultOpen": self._is_open,
        }

    # ─── projects ──────────────────────────────────────────────────────────

    def create_project(self, name: str, path: str = "") -> dict:
        name = name.strip()
        if not name:
            raise VaultError("Project name is required.")
        if any(p["name"] == name for p in self._state["projects"]):
            raise VaultError(f'"{name}" already exists.')

        pid = self._uid()
        pdir = self._project_dir(pid)

        # Create full directory tree
        self._cradle_dir(pid, "V1").mkdir(parents=True, exist_ok=True)
        (pdir / "vault" / "archive").mkdir(parents=True, exist_ok=True)
        self._removed_dir(pid).mkdir(parents=True, exist_ok=True)
        (pdir / "metadata").mkdir(parents=True, exist_ok=True)

        project = {
            "id": pid,
            "name": name,
            "path": path.strip() or "(not specified)",
            "version": "V1",
            "createdAt": self._today(),
        }
        (pdir / "metadata" / "project.json").write_text(
            json.dumps(project, indent=2), encoding="utf-8"
        )
        self._state["projects"].append(project)
        self._log("CRADLE_CREATED", f'Cradle created: "{name}"')
        return project

    def get_project(self, project_id: str) -> dict:
        p = next((p for p in self._state["projects"] if p["id"] == project_id), None)
        if not p:
            raise VaultError("Project not found.")
        return p

    def list_projects(self) -> list:
        return self._state["projects"]

    # ─── files ─────────────────────────────────────────────────────────────

    def add_file(self, file_path: str, project_id: str) -> dict:
        project = self.get_project(project_id)
        src = Path(file_path.strip())
        if not src.exists():
            raise VaultError(f"File not found: {file_path}")
        if not src.is_file():
            raise VaultError(f"Path is not a file: {file_path}")

        file_id = self._uid()
        name = src.name
        dst = self._cradle_dir(project_id, project["version"]) / f"{file_id}_{name}"
        shutil.copy2(src, dst)

        record = {
            "id": file_id,
            "name": name,
            "path": str(src),
            "vaultPath": str(dst),
            "project": project_id,
            "version": project["version"],
            "status": "protected",
            "isArchive": False,
            "size": self._format_size(dst.stat().st_size),
            "createdAt": self._today(),
            "removedAt": None,
            "hash": self._sha256(dst),
            "executionAllowed": False,
            "executionPolicy": "never_execute_inside_iteration_wallet",
        }
        self._state["files"].append(record)
        self._log("FILE_ADDED", f'{name} added to "{project["name"]}"')
        return record

    def _find_file(self, file_id: str) -> dict:
        f = next((f for f in self._state["files"] if f["id"] == file_id), None)
        if not f:
            raise VaultError("File not found.")
        return f

    # ─── vault open/lock ───────────────────────────────────────────────────

    def open_vault(self) -> bool:
        self._is_open = True
        self._log("VAULT_OPENED", "Vault opened manually.")
        return True

    def lock_vault(self) -> bool:
        self._is_open = False
        self._log("VAULT_LOCKED", "Vault locked.")
        return True

    # ─── file lifecycle ────────────────────────────────────────────────────

    def remove_file(self, file_id: str) -> dict:
        """Move a protected file to the staging (holding) area."""
        if not self._is_open:
            raise VaultError("Open the Vault first.")
        f = self._find_file(file_id)
        if f["status"] != "protected":
            raise VaultError("Only protected files can be removed.")

        removed_dir = self._removed_dir(f["project"])
        removed_dir.mkdir(parents=True, exist_ok=True)

        src = Path(f["vaultPath"])
        if src.exists():
            dst = removed_dir / src.name
            # Avoid name collision
            counter = 1
            while dst.exists():
                dst = removed_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            f["vaultPath"] = str(dst)

        f["status"] = "staging"
        f["removedAt"] = datetime.now().isoformat()
        self._log("FILE_REMOVED", f'{f["name"]} moved to holding.')
        return f


    def release_file(self, file_id: str, confirmation: str = "") -> dict:
        """Live-person release from Iteration Wallet custody. No destruction."""
        if not self._is_open:
            raise VaultError("Open the Vault first.")
        if confirmation != "RELEASE":
            raise VaultError("Release requires live-person confirmation: type RELEASE")
        f = self._find_file(file_id)
        if f["status"] == "protected":
            raise VaultError("Use REMOVE before release from wallet custody.")
        released_dir = self._released_dir(f["project"])
        released_dir.mkdir(parents=True, exist_ok=True)
        src = Path(f.get("vaultPath", ""))
        if src.exists():
            dst = released_dir / src.name
            counter = 1
            while dst.exists():
                dst = released_dir / f"{src.stem}_{counter}{src.suffix}"
                counter += 1
            shutil.move(str(src), str(dst))
            f["vaultPath"] = str(dst)
        f["status"] = "released"
        f["releasedAt"] = datetime.now().isoformat()
        self._log("FILE_RELEASED_FROM_CUSTODY", f'{f["name"]} released from Iteration Wallet custody by live-person ceremony.')
        return f


    def restore_file(self, file_id: str) -> dict:
        """Restore an archived file back into the active vault."""
        f = self._find_file(file_id)
        if not f.get("isArchive"):
            raise VaultError("File is not in the archive.")

        project = self.get_project(f["project"])
        new_id = self._uid()
        restored_version = f["version"] + "_restored"
        dst_dir = self._cradle_dir(f["project"], project["version"])
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst = dst_dir / f"{new_id}_{f['name']}"

        src = Path(f.get("vaultPath", ""))
        if src.exists():
            shutil.copy2(src, dst)

        restored = {
            **f,
            "id": new_id,
            "isArchive": False,
            "status": "protected",
            "version": restored_version,
            "vaultPath": str(dst),
            "createdAt": self._today(),
            "removedAt": None,
        }
        self._state["files"].append(restored)
        self._log("ARCHIVE_RESTORED", f'{f["name"]} restored from {f["version"]}')
        return restored

    def promote_version(self, project_id: str, new_version: str) -> dict:
        """
        Promote the current version to archive and set a new active version.
        Old canonical files move to archive; future adds go into the new cradle.
        """
        project = self.get_project(project_id)
        old_version = project["version"]

        # Move active files to archive
        archive_dir = self._archive_dir(project_id, old_version)
        archive_dir.mkdir(parents=True, exist_ok=True)

        for f in self._state["files"]:
            if f["project"] == project_id and not f["isArchive"] and f["status"] == "protected":
                src = Path(f.get("vaultPath", ""))
                if src.exists():
                    dst = archive_dir / src.name
                    shutil.copy2(src, dst)
                    f["vaultPath"] = str(dst)
                f["isArchive"] = True
                f["status"] = "archived"

        # Prepare new cradle
        self._cradle_dir(project_id, new_version).mkdir(parents=True, exist_ok=True)
        project["version"] = new_version

        self._log("VERSION_PROMOTED", f'{project["name"]} promoted to {new_version}')
        return project

    # ─── drives ────────────────────────────────────────────────────────────

    def get_drives(self) -> list:
        """Detect external drives and check for vault markers."""
        drives = []
        system = platform.system()

        def check(p: Path, name: str) -> None:
            if p.is_dir():
                marker = p / ".iteration_wallet_vault"
                try:
                    stat = shutil.disk_usage(p)
                    total_gb = round(stat.total / 1024 ** 3, 1)
                    free_gb = round(stat.free / 1024 ** 3, 1)
                except Exception:
                    total_gb = free_gb = 0
                drives.append({
                    "name": name,
                    "path": str(p),
                    "hasVault": marker.exists(),
                    "totalGB": total_gb,
                    "freeGB": free_gb,
                })

        if system == "Darwin":
            for v in Path("/Volumes").iterdir():
                if v.name not in ("Macintosh HD", "Recovery"):
                    check(v, v.name)
        elif system == "Linux":
            media = Path("/media")
            if media.exists():
                for user_dir in media.iterdir():
                    if user_dir.is_dir():
                        for vol in user_dir.iterdir():
                            check(vol, vol.name)
            # Also check /mnt for mounted drives
            mnt = Path("/mnt")
            if mnt.exists():
                for vol in mnt.iterdir():
                    if vol.is_dir() and vol.name not in (".", ".."):
                        check(vol, vol.name)
        elif system == "Windows":
            import string
            for letter in string.ascii_uppercase[2:]:  # skip A, B
                drive = Path(f"{letter}:\\")
                if drive.exists():
                    check(drive, f"{letter}: Drive")

        return drives

    def mark_drive(self, drive_path: str) -> bool:
        """Place a vault marker on an external drive."""
        marker = Path(drive_path) / ".iteration_wallet_vault"
        marker.write_text(
            json.dumps({"created": datetime.now().isoformat(), "version": "1.0"}),
            encoding="utf-8",
        )
        self._log("DRIVE_MARKED", f"Vault marker placed on {drive_path}")
        return True
