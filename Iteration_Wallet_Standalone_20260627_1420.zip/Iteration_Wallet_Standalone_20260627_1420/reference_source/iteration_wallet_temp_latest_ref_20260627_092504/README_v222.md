# Iteration Wallet v2.1.7 — Protected Action Registry Patch

This patch adds the first centralized protected-action registry for the Human Intent Gatekeeper.

## What this patch does

- Adds `iteration_wallet/gatekeeper.py`
- Registers all current protected custody action keys in one place
- Fails closed when a protected action is not registered
- Updates v2.1 protected FastAPI routes to use registry action keys
- Adds `/api/v21/protected-actions` for policy visibility
- Adds tests for registry coverage, bot denial, human ceremony approval, state denial, and server fail-closed behavior

## Current registered protected actions

```text
remove_from_active
restore_to_active
release_from_custody
quarantine
promote_candidate_to_prime
export_working_copy
open_vault
open_cradle
```

## Run tests

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Expected at patch creation:

```text
77 passed
```

## Product meaning

This patch prevents protected custody routes from making their own scattered access decisions.

The rule is:

> If it is a protected custody action, it must be registered. If it is not registered, it fails closed.

## Next task

```text
IW-TASK-003 — Bind roles to an auth/session interface
```

The next patch should stop trusting caller-supplied IDs and introduce a local identity/session object for actor, device, session, role, and verification claims.
