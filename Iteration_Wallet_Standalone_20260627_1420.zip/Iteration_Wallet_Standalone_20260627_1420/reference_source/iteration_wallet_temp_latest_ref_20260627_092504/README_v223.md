# Iteration Wallet v2.1.8 — Identity Session Binding

v2.1.8 implements the internal identity/session interface required by IW-TASK-003.

## What changed

- Added `iteration_wallet.identity`.
- Protected custody routes now require `session_id` at the route gate.
- Approval decisions can be made using `decision_session_id`.
- Human-intent proof is carried by verified session methods.
- Bot/tool/AI sessions still cannot directly perform protected custody actions.
- Invalid, mismatched, or insufficient approval sessions are logged to BlackBox.

## Example local session

```python
identity = human_access.issue_identity_session(
    actor_id="head-user",
    actor_kind="human",
    device_id="laptop-1",
    verified_methods=["human_ceremony"],
)
```

Use `identity.session_id` in protected route requests.

## Protected route expectation

Protected custody routes now expect `session_id` in request bodies.

No session means no protected custody action.

## Verification

```text
82 passed in 13.41s
```

## Next task

IW-TASK-004 — Finish closed catalog view.
