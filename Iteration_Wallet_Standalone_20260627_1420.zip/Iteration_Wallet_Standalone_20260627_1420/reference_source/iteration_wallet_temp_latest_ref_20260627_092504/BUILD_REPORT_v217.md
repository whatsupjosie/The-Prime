# Iteration Wallet v2.1.2 — No-Delete Rule Integration

## Goal

Hard-code the primary product rule: Iteration Wallet does not delete user-custodied material.

## Changed behavior

### v2.1 engine

- Added `NO_DELETE_RULE` constant in `iteration_wallet/vault_v21.py`.
- `delete_file()` is now a disabled compatibility stub that always raises `VaultError`.
- Added `release_from_custody()` as a live-person ceremony requiring exact confirmation `RELEASE`.
- Added `quarantine_file()` to isolate/ban material without destruction.
- `get_section_view()` now exposes `quarantine` and `released` compartments.
- `export_working_copy()` refuses Removed, Released, Quarantined, or Banned files.

### v2 compatibility engine

- `iteration_wallet/vault.py delete_file()` now always fails safely.
- Added `release_file()` for live-person release from custody without destruction.

### API

- Old DELETE routes return HTTP 405 with the no-delete product rule.
- Added release route for legacy v2: `POST /api/files/{file_id}/release`.
- Added v2.1 release route: `POST /api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/release`.
- Added v2.1 quarantine route: `POST /api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/quarantine`.

### UI

- Replaced visible Delete ceremony language with Release ceremony language.
- Staging flow now tells the user that files remain preserved and may be released from custody by live-person action.
- Removed/changed visible Delete button language to Release.

### CLI

- Public `iw delete` parser entry removed.
- A disabled compatibility handler remains internally so old calls fail safely.

## Tests added/updated

- Added `tests/test_vault_v212_no_delete_rule.py`.
- Updated v2.1 tests so the former delete flow now proves delete is disabled and preserves files.
- Updated old v2 tests so delete attempts are expected to fail safely.
- Isolated API tests so they do not depend on the user's existing `~/.iteration_wallet` state.

## Raw test output

```text
python verify_v21.py
Results: 13 passed, 0 failed
✓ All tests passed!

python -m pytest -q
47 passed in 1.10s
```

## Remaining work

- Wire the v2.1 model into the UI as the primary interface.
- Rename any remaining internal compatibility names after the app no longer needs old callers.
- Add explicit Relieve-from-Cradle and Remove-from-Archive ceremonies.
- Add BlackBox records for release/quarantine/ban.
