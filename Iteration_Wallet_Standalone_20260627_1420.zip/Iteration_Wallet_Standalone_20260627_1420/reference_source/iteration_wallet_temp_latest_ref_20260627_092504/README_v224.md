# Iteration Wallet v2.1.9 — BlackBox Extraction + Vault Coupling

v2.1.9 corrects the dependency-order problem identified after v2.1.8: BlackBox is not a later add-on. It is already load-bearing for the Human Intent layer, and Vault custody events must be written into the same evidence chain.

## Product rule

BlackBox is the shared custody evidence layer.

- NotificationManager may create alerts and approval requests.
- VaultEngine may move objects between Raw Sources, Candidates, Cradle, Archive, Removed, Quarantine, Released, and exported working copies.
- Both must write evidence into the same BlackBox hash chain.

## New module

```text
iteration_wallet/blackbox.py
```

It owns:

- hash-chained BlackBox event writing
- chain verification
- incident bundle storage
- request-pressure incident collapse
- custody violation events
- custody evidence reports

## Refactor

`NotificationManager` no longer owns BlackBox mechanics directly. It now accepts or creates a `BlackBox` instance and uses it for:

- protected access request events
- approval events
- identity session events
- request-pressure incident bundles
- chain verification wrappers for compatibility

## Vault coupling

`vault_v21.VaultEngine` now accepts an optional shared `BlackBox` instance.

When attached, its local `_log()` still writes to `state_v21.json`, but also mirrors custody events into BlackBox.

Covered custody events include, among others:

- `PROJECT_CREATED`
- `SECTION_CREATED`
- `RAW_SOURCE_ADDED`
- `CANDIDATE_ADDED`
- `VAULT_OPENED`
- `VAULT_LOCKED`
- `FILE_STAGED_FOR_REMOVAL`
- `FILE_RELEASED_FROM_CUSTODY`
- `FILE_QUARANTINED`
- `FILE_BANNED`
- `PRIME_PROMOTED`
- `FILE_RESTORED_FROM_REMOVED`
- `WORKING_COPY_EXPORTED`
- `EXTERNAL_RESULTS_ATTACHED`

## Custody integrity verification

New method:

```python
VaultEngine.verify_custody_integrity()
```

It checks custodied objects for:

- missing Vault-held files
- missing Prime objects
- hash mismatches
- Prime hash mismatches

It does not repair or delete. It reports suspected custody breaks and writes BlackBox violation events.

## Server wiring

`server.py` now creates one shared BlackBox instance:

```python
blackbox21 = BlackBox(_v21_root)
vault21 = VaultEngineV21(_v21_root, blackbox=blackbox21)
human_access = NotificationManager(_v21_root, blackbox=blackbox21)
```

New diagnostic endpoints:

```text
GET /api/v21/custody/verify
GET /api/v21/blackbox/chain
```

## Tests

New test file:

```text
tests/test_blackbox_v219.py
```

It verifies:

- BlackBox is a standalone module.
- NotificationManager uses the standalone BlackBox.
- Vault custody events write to the same chain.
- NotificationManager and VaultEngine can share one BlackBox.
- Hash mismatches are reported to BlackBox.
- Missing Prime files are reported to BlackBox.
- Server globals share one BlackBox object.

## Verification

Clean compile and test result:

```text
87 passed in 11.23s
```

## Remaining limits

- This is still local tamper-evident storage, not external cryptographic sealing.
- `vault_v21` local state and BlackBox are now coupled, but local state remains mutable JSON.
- Oubliette lab workflow is not implemented in this patch.
- Camera/liveness/email providers are not implemented here.
- Full append-only storage should still be built later.

## Next step

Proceed to closed catalog view or, if staying with the dependency-correct path, add a stronger BlackBox custody report/UI surface before returning to closed view.
