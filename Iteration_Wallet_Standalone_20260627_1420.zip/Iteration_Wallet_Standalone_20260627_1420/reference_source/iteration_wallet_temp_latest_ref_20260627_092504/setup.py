# Iteration Wallet v2.2.3 — Private Alpha Flow + Integration Polish

v2.2.3 proves the current private-alpha path as one coherent product flow rather than a pile of isolated unit-tested pieces.

## What this patch adds

- End-to-end private-alpha workflow test from the public FastAPI v2.1 API surface.
- A private-alpha status endpoint that summarizes readiness without unlocking custody or leaking secrets.
- Verification that closed catalog views remain safe before and after protected custody work.
- Verification that human identity sessions, scoped ceremony tokens, protected actions, receipts, custody integrity, and the shared BlackBox chain work together.

## New API

```text
GET /api/v21/private-alpha/status
```

This is a status-only surface. It does not open the Vault, issue a ceremony token, expose file contents, or authorize any custody action.

It reports:

```text
version
strict_ceremony_tokens
vault_open
blackbox_chain_ok
custody_integrity_ok
receipt_count
receipt_report_chain_ok
protected_action_count
protected_actions
ready_for_private_alpha_flow
```

## New tests

```text
tests/test_private_alpha_flow_v223.py
```

The primary test proves this flow:

1. Create project and section.
2. Add Raw Source and multiple Candidates.
3. Verify closed catalog exposes only safe metadata.
4. Issue a human identity session with intent proof.
5. Open Vault.
6. Issue scoped ceremony tokens.
7. Promote Candidate to Prime.
8. Export a working copy outside the Vault.
9. Remove and restore a Candidate without deletion.
10. Quarantine a Candidate without deletion.
11. Release a Candidate from custody by explicit ceremony.
12. Verify all protected actions produced Human Intent Receipts.
13. Verify every receipt.
14. Verify BlackBox chain integrity.
15. Verify custody integrity.
16. Lock Vault and verify section view returns to closed catalog mode without leaking protected fields.

## Verification

Clean local verification command:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
100 passed in 4.56s
```

## Honest scope

This patch does not add Oubliette integration, camera liveness, email providers, hardware keys, or external cryptographic sealing. It proves the current private-alpha custody chain works as an end-to-end flow and adds a safe status surface for that readiness.
