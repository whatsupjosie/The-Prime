# Iteration Wallet v2.1 Product Model Patch

## What this patch does

This patch adds `iteration_wallet/vault_v21.py`, a Section/Candidate/Prime engine that matches the product model Josie described:

- Vault contains Projects.
- Projects contain Sections.
- Each Section has Raw Sources, Candidates, Cradle/Prime, Archive, Removed, and Metadata.
- Prime means best accepted so far, not newest.
- Candidates are attempts to beat Prime.
- Promotion requires an OPEN ceremony token.
- Removing/deleting requires an OPEN ceremony token.
- Promoting a new Prime archives the old Prime first.
- Simple Wallet Mode remains default: no password is required.

## Files added

- `iteration_wallet/vault_v21.py`
- `tests/test_vault_v21.py`
- `verify_v21.py`
- `BUILD_REPORT_v21.md`

## Files intentionally not changed

- `iteration_wallet/vault.py`
- `iteration_wallet/server.py`
- `iteration_wallet/cli.py`
- `iteration_wallet/static/app.html`

This was deliberate. The patch adds the v2.1 product model non-destructively. It does not break or replace the existing v2 runtime shell.

## Test commands run

```bash
cd /mnt/data/IterationWallet_v2_1_PRODUCT_MODEL_PATCH
python -m py_compile iteration_wallet/vault_v21.py
python verify_v21.py
python -m pytest tests/test_vault_v21.py -q
```

## Raw test results

`python verify_v21.py`:

```text
Results: 13 passed, 0 failed
✓ All tests passed!
```

`python -m pytest tests/test_vault_v21.py -q`:

```text
15 passed in 0.26s
```

## What this proves

- Project creation works.
- Section creation works.
- Raw Source import works.
- Candidate import works.
- OPEN creates a ceremony token.
- LOCK invalidates the token.
- REMOVE requires vault open.
- REMOVE requires valid token.
- RELEASE is disabled by product law; RELEASE requires staging/live-person ceremony.
- Candidate can be promoted to Prime.
- Promoting a new Prime archives the old Prime.
- Section view exposes all compartments.

## What is still not done

- `vault_v21.py` is not wired into the FastAPI server yet.
- The UI still speaks the older v2 file/project language.
- CLI still uses the older v2 API.
- No BlackBox integration in v2.1 yet.
- No Oubliette integration in v2.1 yet.

## Recommended next patch

Wire `vault_v21.py` into the app as v2.1 API endpoints without removing the v2 API:

- `POST /api/v21/projects`
- `POST /api/v21/projects/{project_id}/sections`
- `POST /api/v21/projects/{project_id}/sections/{section_id}/raw-sources`
- `POST /api/v21/projects/{project_id}/sections/{section_id}/candidates`
- `POST /api/v21/vault/open`
- `POST /api/v21/vault/lock`
- `POST /api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/remove`
- `POST /api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/release`
- `POST /api/v21/projects/{project_id}/sections/{section_id}/promote`
- `GET /api/v21/projects/{project_id}/sections/{section_id}`
