# Iteration Wallet v2.2.3 Build Report
## Private Alpha Flow + Integration Polish

## Goal

Implement the next workbook step in a safe two-part shape:

1. Build a real private-alpha end-to-end flow test.
2. Fix or polish integration seams revealed by that flow.

The patch intentionally avoids feature stacking. It does not begin Oubliette, camera/liveness, hardware keys, or email. It proves the current Iteration Wallet path works coherently.

## Implemented

### 1. Private-alpha flow test

Added:

```text
tests/test_private_alpha_flow_v223.py
```

The test exercises the real FastAPI route layer and proves:

- Project and Section creation work.
- Raw Sources and Candidates can enter custody.
- Closed catalog view exposes safe metadata only.
- Human identity sessions with intent proof work.
- Strict ceremony-token mode is active.
- Action-bound ceremony tokens are issued and raw secrets are not exposed in token listing.
- Candidate promotion to Prime works and produces a Human Intent Receipt.
- Working copy export works and produces a Human Intent Receipt.
- Remove and restore work without deletion and produce receipts.
- Quarantine works without deletion and produces a receipt.
- Release from custody requires explicit RELEASE confirmation and produces a receipt.
- Receipt verification passes for every receipt in the flow.
- BlackBox chain verification passes after all events.
- Custody integrity verification passes after all operations.
- Locking the Vault returns section view to closed catalog mode.
- Closed catalog does not leak protected fields after work has happened.

### 2. Private-alpha status endpoint

Added:

```text
GET /api/v21/private-alpha/status
```

This endpoint is status-only. It does not unlock custody or expose secrets.

It reports:

- version
- strict ceremony token status
- current Vault open/closed state
- BlackBox chain status
- custody integrity status
- receipt count
- receipt report chain status
- protected action count
- protected action registry
- ready_for_private_alpha_flow

### 3. Version update

Updated package version to:

```text
2.2.3
```

## Verification

Commands run:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
100 passed in 4.56s
```

## Files changed

```text
iteration_wallet/server.py
iteration_wallet/__init__.py
setup.py
tests/test_private_alpha_flow_v223.py
README_v223.md
BUILD_REPORT_v223.md
DIFF_REPORT_v223.patch
```

## Known limits

- Real authentication is still local session binding, not a production identity provider.
- Oubliette external-lab workflow is not implemented yet.
- Camera/liveness and read-aloud verification are still future work.
- Hash chaining remains local tamper-evident storage, not external cryptographic sealing.
- UI does not yet expose the full private-alpha flow cleanly.

## Next recommended step

Move to the next workbook section only after preserving this test as the regression spine.

Recommended next patch:

```text
v2.2.4 — Private Alpha Flow Runner / Developer Script
```

or, if prioritizing product behavior over tooling:

```text
v2.2.4 — Oubliette Export-Lab-Reimport Adapter Inventory
```

The safer next move is likely a developer script that runs the proven private-alpha flow outside pytest and produces a human-readable report, because that will help unfamiliar builders prove the system before changing it.
