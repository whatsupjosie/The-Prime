# Iteration Wallet v2.1.6 — Human Intent Gatekeeper

This patch strengthens the Human Access / BlackBox Request Control work from v2.1.5.

Core rule:

> AI may request. Humans decide. BlackBox records. Bots do not fetch protected custody.

New in v2.1.6:

- Enforced Head User/admin approval decisions
- Rolling request-window threshold counting
- Request collapse into BlackBox incident bundles
- Hash-chained BlackBox events
- Critical/intrusion alert priority behavior
- Protected v2.1 route gate for remove/restore/release/quarantine/promote/export
- New tests for the above

See `BUILD_REPORT_v216.md` and `DIFF_REPORT_v216.patch`.
