diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore	2026-06-25 05:16:26.304912602 +0000
@@ -0,0 +1,2 @@
+# Created by pytest automatically.
+*
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG	2026-06-25 05:16:26.305115904 +0000
@@ -0,0 +1,4 @@
+Signature: 8a477f597d28d172789f06886806bc55
+# This file is a cache directory tag created by pytest.
+# For information about cache directory tags, see:
+#	https://bford.info/cachedir/spec.html
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md	2026-06-25 05:16:26.304634834 +0000
@@ -0,0 +1,8 @@
+# pytest cache directory #
+
+This directory contains data from the pytest's cache plugin,
+which provides the `--lf` and `--ff` options, as well as the `cache` fixture.
+
+**Do not** commit this to version control.
+
+See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids	2026-06-25 05:19:44.262636397 +0000
@@ -0,0 +1,97 @@
+[
+  "tests/test_blackbox_v219.py::test_blackbox_is_standalone_module_and_notification_manager_uses_it",
+  "tests/test_blackbox_v219.py::test_server_uses_one_shared_blackbox_for_vault_and_human_access",
+  "tests/test_blackbox_v219.py::test_vault_custody_events_write_to_same_blackbox_chain",
+  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_hash_mismatch_to_blackbox",
+  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_missing_prime_to_blackbox",
+  "tests/test_closed_catalog_v220.py::test_closed_catalog_includes_safe_blackbox_evidence_surface",
+  "tests/test_closed_catalog_v220.py::test_closed_catalog_route_returns_safe_view",
+  "tests/test_closed_catalog_v220.py::test_closed_section_view_exposes_catalog_only_and_preserves_closed_note",
+  "tests/test_closed_catalog_v220.py::test_open_section_view_still_returns_full_records_for_authorized_open_vault",
+  "tests/test_human_intent_gatekeeper_v216.py::test_blackbox_events_are_hash_chained_and_tamper_visible",
+  "tests/test_human_intent_gatekeeper_v216.py::test_head_user_or_admin_required_for_approval_decision",
+  "tests/test_human_intent_gatekeeper_v216.py::test_intrusion_alert_can_displace_low_priority_unread_messages",
+  "tests/test_human_intent_gatekeeper_v216.py::test_repeated_requests_collapse_into_incident_bundle",
+  "tests/test_human_intent_gatekeeper_v216.py::test_request_count_uses_time_window",
+  "tests/test_human_intent_receipts_v221.py::test_blackbox_issues_receipt_tied_to_prior_custody_event_hash",
+  "tests/test_human_intent_receipts_v221.py::test_receipt_rejects_bot_or_human_without_intent_proof",
+  "tests/test_human_intent_receipts_v221.py::test_receipt_tamper_detection",
+  "tests/test_human_intent_receipts_v221.py::test_server_protected_remove_route_returns_human_intent_receipt",
+  "tests/test_identity_session_v218.py::test_approval_decision_uses_session_identity_not_arbitrary_string",
+  "tests/test_identity_session_v218.py::test_bot_session_with_head_user_id_cannot_approve_without_human_intent",
+  "tests/test_identity_session_v218.py::test_gatekeeper_accepts_human_identity_session_and_denies_bot_identity",
+  "tests/test_identity_session_v218.py::test_local_identity_session_shape_and_human_intent_methods",
+  "tests/test_identity_session_v218.py::test_server_protected_routes_require_identity_session_when_route_requests_it",
+  "tests/test_notification_manager_v215.py::test_access_request_logs_blackbox_and_sends_capped_alerts",
+  "tests/test_notification_manager_v215.py::test_approval_request_expiration_exists_and_works",
+  "tests/test_notification_manager_v215.py::test_bot_cannot_directly_access_protected_custody",
+  "tests/test_notification_manager_v215.py::test_flood_threshold_causes_emergency_lockout_with_small_config",
+  "tests/test_notification_manager_v215.py::test_head_user_approval_decision_updates_status_and_notifies_requester",
+  "tests/test_notification_manager_v215.py::test_message_length_limit_rejects_long_alert",
+  "tests/test_notification_manager_v215.py::test_per_recipient_limit_is_five_unread_messages",
+  "tests/test_notification_manager_v215.py::test_repeated_bot_requests_become_possible_intrusion_evidence",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1-RequestClassification.NORMAL]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[100-RequestClassification.PROBABLE_INTRUSION]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1000-RequestClassification.ACTIVE_FLOOD]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[20-RequestClassification.UNUSUAL_PRESSURE]",
+  "tests/test_notification_manager_v215.py::test_request_threshold_classification[50-RequestClassification.SUSPICIOUS_PATTERN]",
+  "tests/test_notification_manager_v215.py::test_system_limit_is_two_hundred_messages",
+  "tests/test_protected_action_registry_v217.py::test_registered_action_denies_bot_and_allows_human_ceremony",
+  "tests/test_protected_action_registry_v217.py::test_registry_state_requirements_fail_when_explicitly_false",
+  "tests/test_protected_action_registry_v217.py::test_required_protected_actions_are_registered",
+  "tests/test_protected_action_registry_v217.py::test_server_protected_helper_uses_registry_and_fails_closed",
+  "tests/test_protected_action_registry_v217.py::test_unknown_protected_action_fails_closed",
+  "tests/test_vault.py::TestAPI::test_create_project",
+  "tests/test_vault.py::TestAPI::test_error_handling",
+  "tests/test_vault.py::TestAPI::test_get_drives",
+  "tests/test_vault.py::TestAPI::test_get_events",
+  "tests/test_vault.py::TestAPI::test_get_state",
+  "tests/test_vault.py::TestAPI::test_list_projects",
+  "tests/test_vault.py::TestAPI::test_ui_served",
+  "tests/test_vault.py::TestAPI::test_vault_open_lock",
+  "tests/test_vault.py::TestCommitGuard::test_guard_initialization",
+  "tests/test_vault.py::TestCommitGuard::test_pattern_matching",
+  "tests/test_vault.py::TestIntegration::test_full_workflow",
+  "tests/test_vault.py::TestVaultEngine::test_add_file",
+  "tests/test_vault.py::TestVaultEngine::test_add_nonexistent_file",
+  "tests/test_vault.py::TestVaultEngine::test_create_project",
+  "tests/test_vault.py::TestVaultEngine::test_get_drives",
+  "tests/test_vault.py::TestVaultEngine::test_list_projects",
+  "tests/test_vault.py::TestVaultEngine::test_no_delete_method_surface",
+  "tests/test_vault.py::TestVaultEngine::test_project_duplicate_guard",
+  "tests/test_vault.py::TestVaultEngine::test_promote_version",
+  "tests/test_vault.py::TestVaultEngine::test_remove_file",
+  "tests/test_vault.py::TestVaultEngine::test_restore_file",
+  "tests/test_vault.py::TestVaultEngine::test_state_persistence",
+  "tests/test_vault.py::TestVaultEngine::test_vault_open_close",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_lock_vault_invalidates_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_no_delete_operation_surface_even_with_valid_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_open_vault_generates_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_valid_token",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_vault_open",
+  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_with_valid_token",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_archives_old_prime",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_candidate_to_prime",
+  "tests/test_vault_v21.py::TestPromotion::test_promote_requires_token",
+  "tests/test_vault_v21.py::TestSectionModel::test_add_candidate",
+  "tests/test_vault_v21.py::TestSectionModel::test_add_raw_source",
+  "tests/test_vault_v21.py::TestSectionModel::test_create_project",
+  "tests/test_vault_v21.py::TestSectionModel::test_create_section",
+  "tests/test_vault_v21.py::TestSectionView::test_section_view_shows_all_compartments",
+  "tests/test_vault_v211_improvements.py::test_export_working_copy_does_not_mutate_vault_copy",
+  "tests/test_vault_v211_improvements.py::test_removed_file_cannot_be_exported",
+  "tests/test_vault_v211_improvements.py::test_restore_from_removed_returns_candidate_to_candidates",
+  "tests/test_vault_v211_improvements.py::test_review_candidate_records_metadata_without_promoting",
+  "tests/test_vault_v211_improvements.py::test_review_rejects_invalid_verdict_and_non_candidate",
+  "tests/test_vault_v212_no_delete_rule.py::test_live_person_release_changes_custody_state_without_destroying_file",
+  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_method_exists_and_candidate_copy_is_preserved",
+  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_rule_constant_is_primary_product_law",
+  "tests/test_vault_v212_no_delete_rule.py::test_quarantine_is_isolation_not_deletion",
+  "tests/test_vault_v212_no_delete_rule.py::test_remove_still_preserves_removed_copy_and_no_delete_surface",
+  "tests/test_vault_v213_no_execute_rule.py::test_custodied_candidate_is_marked_non_executable_on_ingest",
+  "tests/test_vault_v213_no_execute_rule.py::test_export_working_copy_is_allowed_but_execution_surface_absent_in_vault",
+  "tests/test_vault_v213_no_execute_rule.py::test_external_results_attach_without_running_candidate",
+  "tests/test_vault_v213_no_execute_rule.py::test_no_execute_rule_constant_is_primary_product_law",
+  "tests/test_vault_v213_no_execute_rule.py::test_no_execution_method_surface_exists",
+  "tests/test_vault_v213_no_execute_rule.py::test_v21_api_refuses_run_execute_open_and_requires_real_release_confirmation"
+]
\ No newline at end of file
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md	2026-06-25 05:20:06.677294334 +0000
@@ -0,0 +1,146 @@
+# Build Report — Iteration Wallet v2.2.1 Human Intent Receipts
+
+## Summary
+
+Built v2.2.1 from v2.2.0 as the next workbook step after the closed catalog and BlackBox evidence surface.
+
+This patch adds durable Human Intent Receipts for protected custody actions. A receipt is an evidence artifact, not an access token. It proves that a protected action completed after a human-intent gate passed, and it binds that action to the immediately preceding BlackBox custody event hash.
+
+## Product rule implemented
+
+AI may request. Humans decide. BlackBox records. Protected custody actions now produce receipts that say which live human session completed the action, what action was completed, what object was affected, and which BlackBox event hash the receipt is tied to.
+
+## Files changed
+
+- `iteration_wallet/blackbox.py`
+- `iteration_wallet/server.py`
+- `iteration_wallet/__init__.py`
+- `setup.py`
+- `tests/test_human_intent_receipts_v221.py`
+
+## Major additions
+
+### BlackBox receipt store
+
+Added receipt storage under:
+
+```text
+<vault_root>/blackbox/receipts/
+```
+
+Each receipt includes:
+
+- `receipt_id`
+- `receipt_type`
+- `issued_at`
+- `action_key`
+- `action_label`
+- `project_id`
+- `section_id`
+- `object_id`
+- `object_name`
+- `custody_state`
+- `actor_id`
+- `actor_kind`
+- `session_id`
+- `device_id`
+- `verified_methods`
+- `linked_blackbox_event_hash`
+- `linked_blackbox_event_id`
+- `receipt_hash`
+- `receipt_event_id`
+- `receipt_event_hash`
+- `result_summary`
+
+The receipt intentionally does not store ceremony tokens or unlock secrets.
+
+### Receipt verification
+
+Added:
+
+```python
+BlackBox.verify_human_intent_receipt(receipt_id)
+```
+
+It verifies:
+
+- the receipt exists
+- the receipt payload hash still matches
+- the linked custody BlackBox event hash exists
+- the receipt-issued BlackBox event hash exists
+- the BlackBox chain verifies
+
+### Receipt reporting
+
+Added:
+
+```python
+BlackBox.list_human_intent_receipts(...)
+BlackBox.get_human_intent_receipt(receipt_id)
+BlackBox.build_human_intent_receipt_report(...)
+```
+
+### Protected route integration
+
+The following protected v2.1 routes now return a `human_intent_receipt` envelope after successful completion:
+
+- remove from active use
+- restore to active use
+- release from custody
+- quarantine
+- promote Candidate to Prime
+- export working copy
+
+The receipt is issued only after the human intent gate passes and the custody action completes.
+
+### Receipt API endpoints
+
+Added:
+
+```text
+GET /api/v21/blackbox/receipts
+GET /api/v21/blackbox/receipts/report
+GET /api/v21/blackbox/receipts/{receipt_id}
+```
+
+## Tests added
+
+Added `tests/test_human_intent_receipts_v221.py`.
+
+Test coverage includes:
+
+- BlackBox issues receipt tied to prior custody event hash
+- receipt rejects bot identity
+- receipt rejects human session without intent proof
+- receipt tamper detection catches changed receipt payload
+- protected remove route returns a verified Human Intent Receipt
+- receipt listing and detail endpoints work
+- ceremony token does not appear in receipt JSON
+
+## Verification
+
+From clean working package:
+
+```bash
+python -m compileall -q iteration_wallet
+PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
+```
+
+Result:
+
+```text
+95 passed in 3.50s
+```
+
+## Remaining limits
+
+- Receipts are local JSON artifacts tied to a local hash chain. They are tamper-evident, not externally sealed.
+- Real authentication providers are still future work; sessions are local provider-neutral records.
+- Receipt route responses now use `{result, human_intent_receipt}` envelopes for protected actions. UI/clients should adapt to this shape.
+- Receipts do not yet have printable/exportable human-facing layouts.
+
+## Next recommended step
+
+IW-TASK-006 — Implement ceremony token lifecycle hardening.
+
+Focus: ensure ceremony tokens are scoped, single-use where appropriate, action-bound, short-lived, and always BlackBox-recorded without storing the raw token.
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md	2026-06-25 03:25:04.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md	2026-06-25 05:20:06.702764468 +0000
@@ -183,4 +183,12 @@
 - Added BlackBox logging for invalid/mismatched/non-human approval sessions.
 - Added identity API endpoints for private-alpha session issuance and lookup.
 - Added v2.1.8 identity/session tests.
-- Verified full suite: 82 passed.
\ No newline at end of file
+- Verified full suite: 82 passed.
+## v2.2.1 — Human Intent Receipts
+
+- Added durable Human Intent Receipts under BlackBox.
+- Receipts bind protected custody actions to the preceding BlackBox custody event hash.
+- Protected custody routes now return receipt envelopes after successful human-approved action completion.
+- Added receipt verification, listing, detail, and report APIs.
+- Added tests for receipt creation, bot rejection, human-without-proof rejection, tamper detection, route integration, and token non-leakage.
+- Verified: 95 passed.
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/DIFF_REPORT_v221.patch iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/DIFF_REPORT_v221.patch
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/DIFF_REPORT_v221.patch	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/DIFF_REPORT_v221.patch	2026-06-25 05:20:13.030634055 +0000
@@ -0,0 +1,296 @@
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore	1970-01-01 00:00:00.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/.gitignore	2026-06-25 05:16:26.304912602 +0000
+@@ -0,0 +1,2 @@
++# Created by pytest automatically.
++*
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG	1970-01-01 00:00:00.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/CACHEDIR.TAG	2026-06-25 05:16:26.305115904 +0000
+@@ -0,0 +1,4 @@
++Signature: 8a477f597d28d172789f06886806bc55
++# This file is a cache directory tag created by pytest.
++# For information about cache directory tags, see:
++#	https://bford.info/cachedir/spec.html
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md	1970-01-01 00:00:00.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/README.md	2026-06-25 05:16:26.304634834 +0000
+@@ -0,0 +1,8 @@
++# pytest cache directory #
++
++This directory contains data from the pytest's cache plugin,
++which provides the `--lf` and `--ff` options, as well as the `cache` fixture.
++
++**Do not** commit this to version control.
++
++See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids	1970-01-01 00:00:00.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/.pytest_cache/v/cache/nodeids	2026-06-25 05:19:44.262636397 +0000
+@@ -0,0 +1,97 @@
++[
++  "tests/test_blackbox_v219.py::test_blackbox_is_standalone_module_and_notification_manager_uses_it",
++  "tests/test_blackbox_v219.py::test_server_uses_one_shared_blackbox_for_vault_and_human_access",
++  "tests/test_blackbox_v219.py::test_vault_custody_events_write_to_same_blackbox_chain",
++  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_hash_mismatch_to_blackbox",
++  "tests/test_blackbox_v219.py::test_vault_integrity_check_reports_missing_prime_to_blackbox",
++  "tests/test_closed_catalog_v220.py::test_closed_catalog_includes_safe_blackbox_evidence_surface",
++  "tests/test_closed_catalog_v220.py::test_closed_catalog_route_returns_safe_view",
++  "tests/test_closed_catalog_v220.py::test_closed_section_view_exposes_catalog_only_and_preserves_closed_note",
++  "tests/test_closed_catalog_v220.py::test_open_section_view_still_returns_full_records_for_authorized_open_vault",
++  "tests/test_human_intent_gatekeeper_v216.py::test_blackbox_events_are_hash_chained_and_tamper_visible",
++  "tests/test_human_intent_gatekeeper_v216.py::test_head_user_or_admin_required_for_approval_decision",
++  "tests/test_human_intent_gatekeeper_v216.py::test_intrusion_alert_can_displace_low_priority_unread_messages",
++  "tests/test_human_intent_gatekeeper_v216.py::test_repeated_requests_collapse_into_incident_bundle",
++  "tests/test_human_intent_gatekeeper_v216.py::test_request_count_uses_time_window",
++  "tests/test_human_intent_receipts_v221.py::test_blackbox_issues_receipt_tied_to_prior_custody_event_hash",
++  "tests/test_human_intent_receipts_v221.py::test_receipt_rejects_bot_or_human_without_intent_proof",
++  "tests/test_human_intent_receipts_v221.py::test_receipt_tamper_detection",
++  "tests/test_human_intent_receipts_v221.py::test_server_protected_remove_route_returns_human_intent_receipt",
++  "tests/test_identity_session_v218.py::test_approval_decision_uses_session_identity_not_arbitrary_string",
++  "tests/test_identity_session_v218.py::test_bot_session_with_head_user_id_cannot_approve_without_human_intent",
++  "tests/test_identity_session_v218.py::test_gatekeeper_accepts_human_identity_session_and_denies_bot_identity",
++  "tests/test_identity_session_v218.py::test_local_identity_session_shape_and_human_intent_methods",
++  "tests/test_identity_session_v218.py::test_server_protected_routes_require_identity_session_when_route_requests_it",
++  "tests/test_notification_manager_v215.py::test_access_request_logs_blackbox_and_sends_capped_alerts",
++  "tests/test_notification_manager_v215.py::test_approval_request_expiration_exists_and_works",
++  "tests/test_notification_manager_v215.py::test_bot_cannot_directly_access_protected_custody",
++  "tests/test_notification_manager_v215.py::test_flood_threshold_causes_emergency_lockout_with_small_config",
++  "tests/test_notification_manager_v215.py::test_head_user_approval_decision_updates_status_and_notifies_requester",
++  "tests/test_notification_manager_v215.py::test_message_length_limit_rejects_long_alert",
++  "tests/test_notification_manager_v215.py::test_per_recipient_limit_is_five_unread_messages",
++  "tests/test_notification_manager_v215.py::test_repeated_bot_requests_become_possible_intrusion_evidence",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1-RequestClassification.NORMAL]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[100-RequestClassification.PROBABLE_INTRUSION]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[1000-RequestClassification.ACTIVE_FLOOD]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[20-RequestClassification.UNUSUAL_PRESSURE]",
++  "tests/test_notification_manager_v215.py::test_request_threshold_classification[50-RequestClassification.SUSPICIOUS_PATTERN]",
++  "tests/test_notification_manager_v215.py::test_system_limit_is_two_hundred_messages",
++  "tests/test_protected_action_registry_v217.py::test_registered_action_denies_bot_and_allows_human_ceremony",
++  "tests/test_protected_action_registry_v217.py::test_registry_state_requirements_fail_when_explicitly_false",
++  "tests/test_protected_action_registry_v217.py::test_required_protected_actions_are_registered",
++  "tests/test_protected_action_registry_v217.py::test_server_protected_helper_uses_registry_and_fails_closed",
++  "tests/test_protected_action_registry_v217.py::test_unknown_protected_action_fails_closed",
++  "tests/test_vault.py::TestAPI::test_create_project",
++  "tests/test_vault.py::TestAPI::test_error_handling",
++  "tests/test_vault.py::TestAPI::test_get_drives",
++  "tests/test_vault.py::TestAPI::test_get_events",
++  "tests/test_vault.py::TestAPI::test_get_state",
++  "tests/test_vault.py::TestAPI::test_list_projects",
++  "tests/test_vault.py::TestAPI::test_ui_served",
++  "tests/test_vault.py::TestAPI::test_vault_open_lock",
++  "tests/test_vault.py::TestCommitGuard::test_guard_initialization",
++  "tests/test_vault.py::TestCommitGuard::test_pattern_matching",
++  "tests/test_vault.py::TestIntegration::test_full_workflow",
++  "tests/test_vault.py::TestVaultEngine::test_add_file",
++  "tests/test_vault.py::TestVaultEngine::test_add_nonexistent_file",
++  "tests/test_vault.py::TestVaultEngine::test_create_project",
++  "tests/test_vault.py::TestVaultEngine::test_get_drives",
++  "tests/test_vault.py::TestVaultEngine::test_list_projects",
++  "tests/test_vault.py::TestVaultEngine::test_no_delete_method_surface",
++  "tests/test_vault.py::TestVaultEngine::test_project_duplicate_guard",
++  "tests/test_vault.py::TestVaultEngine::test_promote_version",
++  "tests/test_vault.py::TestVaultEngine::test_remove_file",
++  "tests/test_vault.py::TestVaultEngine::test_restore_file",
++  "tests/test_vault.py::TestVaultEngine::test_state_persistence",
++  "tests/test_vault.py::TestVaultEngine::test_vault_open_close",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_lock_vault_invalidates_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_no_delete_operation_surface_even_with_valid_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_open_vault_generates_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_valid_token",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_requires_vault_open",
++  "tests/test_vault_v21.py::TestCeremonyTokens::test_remove_with_valid_token",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_archives_old_prime",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_candidate_to_prime",
++  "tests/test_vault_v21.py::TestPromotion::test_promote_requires_token",
++  "tests/test_vault_v21.py::TestSectionModel::test_add_candidate",
++  "tests/test_vault_v21.py::TestSectionModel::test_add_raw_source",
++  "tests/test_vault_v21.py::TestSectionModel::test_create_project",
++  "tests/test_vault_v21.py::TestSectionModel::test_create_section",
++  "tests/test_vault_v21.py::TestSectionView::test_section_view_shows_all_compartments",
++  "tests/test_vault_v211_improvements.py::test_export_working_copy_does_not_mutate_vault_copy",
++  "tests/test_vault_v211_improvements.py::test_removed_file_cannot_be_exported",
++  "tests/test_vault_v211_improvements.py::test_restore_from_removed_returns_candidate_to_candidates",
++  "tests/test_vault_v211_improvements.py::test_review_candidate_records_metadata_without_promoting",
++  "tests/test_vault_v211_improvements.py::test_review_rejects_invalid_verdict_and_non_candidate",
++  "tests/test_vault_v212_no_delete_rule.py::test_live_person_release_changes_custody_state_without_destroying_file",
++  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_method_exists_and_candidate_copy_is_preserved",
++  "tests/test_vault_v212_no_delete_rule.py::test_no_delete_rule_constant_is_primary_product_law",
++  "tests/test_vault_v212_no_delete_rule.py::test_quarantine_is_isolation_not_deletion",
++  "tests/test_vault_v212_no_delete_rule.py::test_remove_still_preserves_removed_copy_and_no_delete_surface",
++  "tests/test_vault_v213_no_execute_rule.py::test_custodied_candidate_is_marked_non_executable_on_ingest",
++  "tests/test_vault_v213_no_execute_rule.py::test_export_working_copy_is_allowed_but_execution_surface_absent_in_vault",
++  "tests/test_vault_v213_no_execute_rule.py::test_external_results_attach_without_running_candidate",
++  "tests/test_vault_v213_no_execute_rule.py::test_no_execute_rule_constant_is_primary_product_law",
++  "tests/test_vault_v213_no_execute_rule.py::test_no_execution_method_surface_exists",
++  "tests/test_vault_v213_no_execute_rule.py::test_v21_api_refuses_run_execute_open_and_requires_real_release_confirmation"
++]
+\ No newline at end of file
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md	1970-01-01 00:00:00.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/BUILD_REPORT_v221.md	2026-06-25 05:20:06.677294334 +0000
+@@ -0,0 +1,146 @@
++# Build Report — Iteration Wallet v2.2.1 Human Intent Receipts
++
++## Summary
++
++Built v2.2.1 from v2.2.0 as the next workbook step after the closed catalog and BlackBox evidence surface.
++
++This patch adds durable Human Intent Receipts for protected custody actions. A receipt is an evidence artifact, not an access token. It proves that a protected action completed after a human-intent gate passed, and it binds that action to the immediately preceding BlackBox custody event hash.
++
++## Product rule implemented
++
++AI may request. Humans decide. BlackBox records. Protected custody actions now produce receipts that say which live human session completed the action, what action was completed, what object was affected, and which BlackBox event hash the receipt is tied to.
++
++## Files changed
++
++- `iteration_wallet/blackbox.py`
++- `iteration_wallet/server.py`
++- `iteration_wallet/__init__.py`
++- `setup.py`
++- `tests/test_human_intent_receipts_v221.py`
++
++## Major additions
++
++### BlackBox receipt store
++
++Added receipt storage under:
++
++```text
++<vault_root>/blackbox/receipts/
++```
++
++Each receipt includes:
++
++- `receipt_id`
++- `receipt_type`
++- `issued_at`
++- `action_key`
++- `action_label`
++- `project_id`
++- `section_id`
++- `object_id`
++- `object_name`
++- `custody_state`
++- `actor_id`
++- `actor_kind`
++- `session_id`
++- `device_id`
++- `verified_methods`
++- `linked_blackbox_event_hash`
++- `linked_blackbox_event_id`
++- `receipt_hash`
++- `receipt_event_id`
++- `receipt_event_hash`
++- `result_summary`
++
++The receipt intentionally does not store ceremony tokens or unlock secrets.
++
++### Receipt verification
++
++Added:
++
++```python
++BlackBox.verify_human_intent_receipt(receipt_id)
++```
++
++It verifies:
++
++- the receipt exists
++- the receipt payload hash still matches
++- the linked custody BlackBox event hash exists
++- the receipt-issued BlackBox event hash exists
++- the BlackBox chain verifies
++
++### Receipt reporting
++
++Added:
++
++```python
++BlackBox.list_human_intent_receipts(...)
++BlackBox.get_human_intent_receipt(receipt_id)
++BlackBox.build_human_intent_receipt_report(...)
++```
++
++### Protected route integration
++
++The following protected v2.1 routes now return a `human_intent_receipt` envelope after successful completion:
++
++- remove from active use
++- restore to active use
++- release from custody
++- quarantine
++- promote Candidate to Prime
++- export working copy
++
++The receipt is issued only after the human intent gate passes and the custody action completes.
++
++### Receipt API endpoints
++
++Added:
++
++```text
++GET /api/v21/blackbox/receipts
++GET /api/v21/blackbox/receipts/report
++GET /api/v21/blackbox/receipts/{receipt_id}
++```
++
++## Tests added
++
++Added `tests/test_human_intent_receipts_v221.py`.
++
++Test coverage includes:
++
++- BlackBox issues receipt tied to prior custody event hash
++- receipt rejects bot identity
++- receipt rejects human session without intent proof
++- receipt tamper detection catches changed receipt payload
++- protected remove route returns a verified Human Intent Receipt
++- receipt listing and detail endpoints work
++- ceremony token does not appear in receipt JSON
++
++## Verification
++
++From clean working package:
++
++```bash
++python -m compileall -q iteration_wallet
++PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
++```
++
++Result:
++
++```text
++95 passed in 3.50s
++```
++
++## Remaining limits
++
++- Receipts are local JSON artifacts tied to a local hash chain. They are tamper-evident, not externally sealed.
++- Real authentication providers are still future work; sessions are local provider-neutral records.
++- Receipt route responses now use `{result, human_intent_receipt}` envelopes for protected actions. UI/clients should adapt to this shape.
++- Receipts do not yet have printable/exportable human-facing layouts.
++
++## Next recommended step
++
++IW-TASK-006 — Implement ceremony token lifecycle hardening.
++
++Focus: ensure ceremony tokens are scoped, single-use where appropriate, action-bound, short-lived, and always BlackBox-recorded without storing the raw token.
+diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md
+--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md	2026-06-25 03:25:04.000000000 +0000
++++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/CHANGELOG.md	2026-06-25 05:20:06.702764468 +0000
+@@ -183,4 +183,12 @@
+ - Added BlackBox logging for invalid/mismatched/non-human approval sessions.
+ - Added identity API endpoints for private-alpha session issuance and lookup.
+ - Added v2.1.8 identity/session tests.
+-- Verified full suite: 82 passed.
+\ No newline at end of file
++- Verified full suite: 82 passed.
++## v2.2.1 — Human Intent Receipts
++
++- Added durable Human Intent Receipts under BlackBox.
++- Receipts bind protected custody actions to the preceding BlackBox custody event hash.
++- Protected custody routes now return receipt envelopes after successful human-approved action completion.
++- Added receipt verification, listing, detail, and report APIs.
++- Added tests for receipt creation, bot rejection, human-without-proof rejection, tamper detection, route integration, and token non-leakage.
++- Verified: 95 passed.
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/README_v221.md iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/README_v221.md
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/README_v221.md	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/README_v221.md	2026-06-25 05:20:06.690086961 +0000
@@ -0,0 +1,54 @@
+# Iteration Wallet v2.2.1 — Human Intent Receipts
+
+v2.2.1 adds durable Human Intent Receipts for protected custody actions.
+
+A receipt is not an unlock key and not permission. It is evidence: a live authorized human session completed a protected custody action, and that receipt is tied to the BlackBox event hash for the custody event that just happened.
+
+## What receipts prove
+
+A receipt records:
+
+- who completed the action
+- which session completed it
+- what human-intent methods were present
+- what protected action completed
+- what object was affected
+- when it happened
+- which BlackBox event hash it is tied to
+- the receipt's own payload hash
+- the BlackBox event that issued the receipt
+
+## Protected actions now issuing receipts
+
+- remove from active use
+- restore to active use
+- release from custody
+- quarantine
+- promote Candidate to Prime
+- export working copy
+
+## New BlackBox APIs
+
+```text
+GET /api/v21/blackbox/receipts
+GET /api/v21/blackbox/receipts/report
+GET /api/v21/blackbox/receipts/{receipt_id}
+```
+
+## Safety properties
+
+- Bots cannot receive human intent receipts.
+- Humans without a verified human-intent method cannot receive receipts.
+- Raw ceremony tokens are not stored in receipts.
+- Receipt tampering is detected by receipt hash verification.
+- Receipt evidence is also represented in the BlackBox event chain.
+
+## Verification
+
+```text
+95 passed in 3.50s
+```
+
+## Next step
+
+IW-TASK-006 — ceremony token lifecycle hardening.
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py	2026-06-25 03:25:01.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__init__.py	2026-06-25 05:19:08.286843397 +0000
@@ -7,11 +7,11 @@
 "Feic Mo Chroí — See My Heart."
 """
 
-__version__ = "2.2.0"
+__version__ = "2.2.1"
 __author__ = "Josie Curtsey Cobbley"
 __license__ = "Proprietary"
 
-# v2.2.0 BlackBox extraction + vault custody coupling
+# v2.2.1 Human Intent Receipts
 try:
     from .identity import ActorIdentity, IdentityError, LocalIdentityProvider
     from .blackbox import BlackBox, BlackBoxError
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/__init__.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/__init__.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/blackbox.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/blackbox.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/cli.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/cli.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/gatekeeper.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/gatekeeper.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/guard.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/guard.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/identity.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/identity.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/notification_manager.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/notification_manager.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/server.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/server.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/vault.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/vault.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/vault_v21.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/__pycache__/vault_v21.cpython-313.pyc differ
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py	2026-06-25 03:18:03.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/blackbox.py	2026-06-25 05:18:23.415182892 +0000
@@ -41,8 +41,9 @@
         self.event_dir = self.blackbox_dir / "events"
         self.incident_dir = self.blackbox_dir / "incidents"
         self.request_dir = self.blackbox_dir / "requests"
+        self.receipt_dir = self.blackbox_dir / "receipts"
         self.chain_file = self.blackbox_dir / "chain_head.json"
-        for directory in (self.blackbox_dir, self.event_dir, self.incident_dir, self.request_dir):
+        for directory in (self.blackbox_dir, self.event_dir, self.incident_dir, self.request_dir, self.receipt_dir):
             directory.mkdir(parents=True, exist_ok=True)
 
     # ─── durable JSON helpers ────────────────────────────────────────────
@@ -225,6 +226,180 @@
         )
 
 
+    # ─── human intent receipts ────────────────────────────────────────────
+
+    @staticmethod
+    def _identity_value(identity: Any, name: str, default: Any = None) -> Any:
+        return getattr(identity, name, default) if identity is not None else default
+
+    @staticmethod
+    def _identity_has_human_intent(identity: Any) -> bool:
+        if identity is None:
+            return False
+        checker = getattr(identity, "has_human_intent_proof", None)
+        if callable(checker):
+            return bool(checker())
+        return False
+
+    @staticmethod
+    def _receipt_core_hash(receipt: Dict[str, Any]) -> str:
+        payload = dict(receipt)
+        payload.pop("receipt_hash", None)
+        payload.pop("receipt_event_id", None)
+        payload.pop("receipt_event_hash", None)
+        return hashlib.sha256(BlackBox._canonical_json(payload).encode("utf-8")).hexdigest()
+
+    def issue_human_intent_receipt(
+        self,
+        *,
+        action_key: str,
+        action_label: str,
+        actor_identity: Any,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+        object_name: Optional[str] = None,
+        custody_state: Optional[str] = None,
+        result_summary: Optional[str] = None,
+        linked_event_hash: Optional[str] = None,
+        linked_event_id: Optional[str] = None,
+        approval_id: Optional[str] = None,
+        request_id: Optional[str] = None,
+        extra: Optional[Dict[str, Any]] = None,
+    ) -> Dict[str, Any]:
+        """Issue a durable Human Intent Receipt for a completed protected action.
+
+        A receipt is not a permission token and does not unlock custody. It is an
+        evidence artifact that says: a named human session with human-intent proof
+        completed a protected custody action, and this receipt is tied to the
+        BlackBox event hash that immediately preceded it.
+        """
+        if not action_key:
+            raise BlackBoxError("receipt action_key is required")
+        if not self._identity_has_human_intent(actor_identity):
+            raise BlackBoxError("human intent receipt requires a valid human identity with intent proof")
+        linked_event_hash = linked_event_hash or self.current_chain_head()
+        if not linked_event_hash or linked_event_hash == "GENESIS":
+            raise BlackBoxError("human intent receipt requires a linked BlackBox event hash")
+
+        receipt_id = uuid.uuid4().hex[:16]
+        verified_methods = list(self._identity_value(actor_identity, "verified_methods", []) or [])
+        receipt = {
+            "receipt_id": receipt_id,
+            "receipt_type": "human_intent_receipt",
+            "issued_at": self.now().isoformat(),
+            "action_key": action_key,
+            "action_label": action_label,
+            "project_id": project_id,
+            "section_id": section_id,
+            "object_id": object_id,
+            "object_name": object_name,
+            "custody_state": custody_state,
+            "actor_id": self._identity_value(actor_identity, "actor_id"),
+            "actor_kind": self._identity_value(actor_identity, "actor_kind"),
+            "session_id": self._identity_value(actor_identity, "session_id"),
+            "device_id": self._identity_value(actor_identity, "device_id"),
+            "verified_methods": verified_methods,
+            "linked_blackbox_event_hash": linked_event_hash,
+            "linked_blackbox_event_id": linked_event_id,
+            "approval_id": approval_id,
+            "request_id": request_id,
+            "result_summary": (result_summary or "")[:300],
+            "protected_action": True,
+            "intent_statement": "A live authorized human completed this protected custody action.",
+        }
+        if extra:
+            # Extra receipt data is deliberately namespaced so it cannot be
+            # mistaken for a custody secret or authority claim.
+            receipt["extra"] = dict(extra)
+        receipt["receipt_hash"] = self._receipt_core_hash(receipt)
+
+        event = self.write_event(
+            "HUMAN_INTENT_RECEIPT_ISSUED",
+            f"Human intent receipt issued for {action_label}",
+            receipt_id=receipt_id,
+            receipt_hash=receipt["receipt_hash"],
+            linked_blackbox_event_hash=linked_event_hash,
+            linked_blackbox_event_id=linked_event_id,
+            action_key=action_key,
+            project_id=project_id,
+            section_id=section_id,
+            file_id=object_id,
+            actor_id=receipt["actor_id"],
+            session_id=receipt["session_id"],
+            receipt_event=True,
+        )
+        receipt["receipt_event_id"] = event["event_id"]
+        receipt["receipt_event_hash"] = event["event_hash"]
+        self._write_json_atomic(self.receipt_dir / f"{receipt_id}.json", receipt)
+        return receipt
+
+    def get_human_intent_receipt(self, receipt_id: str) -> Optional[Dict[str, Any]]:
+        if not receipt_id:
+            return None
+        path = self.receipt_dir / f"{receipt_id}.json"
+        if not path.exists():
+            return None
+        try:
+            return json.loads(path.read_text(encoding="utf-8"))
+        except Exception as exc:
+            raise BlackBoxError(f"unreadable receipt {receipt_id}: {exc}") from exc
+
+    def list_human_intent_receipts(
+        self,
+        *,
+        project_id: Optional[str] = None,
+        section_id: Optional[str] = None,
+        object_id: Optional[str] = None,
+        limit: int = 100,
+    ) -> List[Dict[str, Any]]:
+        receipts: List[Dict[str, Any]] = []
+        for path in self.receipt_dir.glob("*.json"):
+            try:
+                receipt = json.loads(path.read_text(encoding="utf-8"))
+            except Exception as exc:
+                raise BlackBoxError(f"unreadable receipt {path.name}: {exc}") from exc
+            if project_id and receipt.get("project_id") != project_id:
+                continue
+            if section_id and receipt.get("section_id") != section_id:
+                continue
+            if object_id and receipt.get("object_id") != object_id:
+                continue
+            receipts.append(receipt)
+        receipts.sort(key=lambda r: (r.get("issued_at", ""), r.get("receipt_id", "")))
+        return receipts[-max(0, int(limit)):]
+
+    def verify_human_intent_receipt(self, receipt_id: str) -> Dict[str, Any]:
+        receipt = self.get_human_intent_receipt(receipt_id)
+        if not receipt:
+            return {"ok": False, "reason": "receipt not found"}
+        supplied_hash = receipt.get("receipt_hash")
+        expected_hash = self._receipt_core_hash(receipt)
+        if supplied_hash != expected_hash:
+            return {"ok": False, "reason": "receipt hash mismatch", "receipt_id": receipt_id}
+        linked_hash = receipt.get("linked_blackbox_event_hash")
+        receipt_event_hash = receipt.get("receipt_event_hash")
+        event_hashes = {event.get("event_hash") for event in self.iter_events()}
+        if linked_hash not in event_hashes:
+            return {"ok": False, "reason": "linked BlackBox event hash missing", "receipt_id": receipt_id}
+        if receipt_event_hash not in event_hashes:
+            return {"ok": False, "reason": "receipt BlackBox event hash missing", "receipt_id": receipt_id}
+        chain = self.verify_chain()
+        if not chain.get("ok"):
+            return {"ok": False, "reason": "BlackBox chain invalid", "receipt_id": receipt_id, "chain": chain}
+        return {"ok": True, "receipt_id": receipt_id, "receipt_hash": supplied_hash, "chain": chain}
+
+    def build_human_intent_receipt_report(self, limit: int = 100) -> Dict[str, Any]:
+        receipts = self.list_human_intent_receipts(limit=limit)
+        return {
+            "summary": "Human Intent Receipt report",
+            "generated_at": self.now().isoformat(),
+            "receipt_count_included": len(receipts),
+            "receipts": receipts,
+            "chain": self.verify_chain(),
+        }
+
+
     def build_closed_evidence_summary(
         self,
         *,
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py	2026-06-25 03:19:16.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/iteration_wallet/server.py	2026-06-25 05:18:56.309619924 +0000
@@ -313,7 +313,7 @@
     human_ceremony_passed: Optional[bool],
     session_id: Optional[str] = None,
     require_identity_session: bool = False,
-) -> None:
+) -> dict:
     actor_identity = None
     if require_identity_session and not session_id:
         raise HTTPException(403, "Protected custody route requires an identity session.")
@@ -334,6 +334,38 @@
         raise HTTPException(500, str(e))
     if not decision.get("allowed"):
         raise HTTPException(403, decision.get("reason", "Protected custody requires human intent."))
+    decision["_actor_identity"] = actor_identity
+    return decision
+
+
+def issue_human_intent_receipt(
+    *,
+    decision: dict,
+    action_key: str,
+    project_id: str,
+    section_id: str,
+    object_id: str,
+    result: dict,
+    result_summary: str,
+) -> dict:
+    actor_identity = decision.get("_actor_identity")
+    receipt = blackbox21.issue_human_intent_receipt(
+        action_key=action_key,
+        action_label=decision.get("action") or action_key,
+        actor_identity=actor_identity,
+        project_id=project_id,
+        section_id=section_id,
+        object_id=object_id,
+        object_name=(result or {}).get("name"),
+        custody_state=(result or {}).get("state"),
+        result_summary=result_summary,
+        linked_event_hash=blackbox21.current_chain_head(),
+    )
+    return receipt
+
+
+def with_human_intent_receipt(result: dict, receipt: dict) -> dict:
+    return {"result": result, "human_intent_receipt": receipt}
 
 class ExternalResultsRequest(BaseModel):
     summary: str
@@ -430,20 +462,38 @@
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/remove")
 async def v21_remove_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
-        require_human_intent("remove_from_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("remove_from_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         record = vault21.remove_file(project_id, section_id, file_id, req.ceremony_token)
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="remove_from_active",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=file_id,
+            result=record,
+            result_summary="File removed from active use into Removed staging.",
+        )
         await notify("v21_state_updated")
-        return record
+        return with_human_intent_receipt(record, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/restore")
 async def v21_restore_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
-        require_human_intent("restore_to_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("restore_to_active", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         record = vault21.restore_file(project_id, section_id, file_id, req.ceremony_token)
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="restore_to_active",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=file_id,
+            result=record,
+            result_summary="File restored from Removed staging to active custody.",
+        )
         await notify("v21_state_updated")
-        return record
+        return with_human_intent_receipt(record, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
@@ -459,20 +509,38 @@
         # identity-session fallback path. No custody movement happens here.
         if (req.confirmation or "") != "RELEASE":
             raise VaultErrorV21("Release from custody requires you to type RELEASE confirmation.")
-        require_human_intent("release_from_custody", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("release_from_custody", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         record = vault21.release_from_custody(project_id, section_id, file_id, req.ceremony_token, req.confirmation or '')
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="release_from_custody",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=file_id,
+            result=record,
+            result_summary="File released from Iteration Wallet custody by explicit human ceremony.",
+        )
         await notify("v21_state_updated")
-        return record
+        return with_human_intent_receipt(record, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/quarantine")
 async def v21_quarantine_file(project_id: str, section_id: str, file_id: str, req: CeremonyTokenRequest):
     try:
-        require_human_intent("quarantine", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("quarantine", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         record = vault21.quarantine_file(project_id, section_id, file_id, req.ceremony_token, reason="manual quarantine")
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="quarantine",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=file_id,
+            result=record,
+            result_summary="File moved into quarantine without deletion.",
+        )
         await notify("v21_state_updated")
-        return record
+        return with_human_intent_receipt(record, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
@@ -497,20 +565,38 @@
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/candidates/{candidate_id}/promote")
 async def v21_promote_candidate(project_id: str, section_id: str, candidate_id: str, req: PromotePrimeRequest):
     try:
-        require_human_intent("promote_candidate_to_prime", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("promote_candidate_to_prime", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         record = vault21.promote_to_prime(project_id, section_id, candidate_id, req.ceremony_token, req.reason or "")
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="promote_candidate_to_prime",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=candidate_id,
+            result=record,
+            result_summary="Candidate promoted to Prime by human ceremony.",
+        )
         await notify("v21_state_updated")
-        return record
+        return with_human_intent_receipt(record, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
 @app.post("/api/v21/projects/{project_id}/sections/{section_id}/files/{file_id}/export-working-copy")
 async def v21_export_working_copy(project_id: str, section_id: str, file_id: str, req: ExportWorkingCopyRequest):
     try:
-        require_human_intent("export_working_copy", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
+        decision = require_human_intent("export_working_copy", req.actor_kind, req.human_ceremony_passed, req.session_id, require_identity_session=True)
         result = vault21.export_working_copy(project_id, section_id, file_id, req.output_dir)
+        receipt = issue_human_intent_receipt(
+            decision=decision,
+            action_key="export_working_copy",
+            project_id=project_id,
+            section_id=section_id,
+            object_id=file_id,
+            result={"id": file_id, "name": Path(result.get("output_path", "")).name, "state": "exported_working_copy"},
+            result_summary="Working copy exported outside the Vault for external work.",
+        )
         await notify("v21_state_updated")
-        return result
+        return with_human_intent_receipt(result, receipt)
     except VaultErrorV21 as e:
         raise HTTPException(400, str(e))
 
@@ -610,6 +696,22 @@
 async def v215_blackbox_request_report():
     return human_access.build_blackbox_request_report()
 
+@app.get("/api/v21/blackbox/receipts")
+async def v221_list_human_intent_receipts():
+    return {"receipts": blackbox21.list_human_intent_receipts()}
+
+@app.get("/api/v21/blackbox/receipts/report")
+async def v221_human_intent_receipt_report():
+    return blackbox21.build_human_intent_receipt_report()
+
+@app.get("/api/v21/blackbox/receipts/{receipt_id}")
+async def v221_get_human_intent_receipt(receipt_id: str):
+    receipt = blackbox21.get_human_intent_receipt(receipt_id)
+    if not receipt:
+        raise HTTPException(404, "Human Intent Receipt not found")
+    verification = blackbox21.verify_human_intent_receipt(receipt_id)
+    return {"receipt": receipt, "verification": verification}
+
 @app.get("/api/v21/notifications/{recipient_id}")
 async def v215_get_notifications(recipient_id: str):
     return {"notifications": human_access.get_inbox(recipient_id)}
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py	2026-06-25 03:25:01.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/setup.py	2026-06-25 05:19:08.287264545 +0000
@@ -10,7 +10,7 @@
 
 setup(
     name="iteration-wallet",
-    version="2.2.0",
+    version="2.2.1",
     description="Cross-platform project vault for AI developers",
     long_description=long_description,
     long_description_content_type="text/markdown",
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/__init__.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/__init__.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_blackbox_v219.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_blackbox_v219.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_closed_catalog_v220.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_closed_catalog_v220.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_gatekeeper_v216.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_gatekeeper_v216.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_human_intent_receipts_v221.cpython-313.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_identity_session_v218.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_identity_session_v218.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_notification_manager_v215.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_notification_manager_v215.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_protected_action_registry_v217.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_protected_action_registry_v217.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v21.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v21.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v211_improvements.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v211_improvements.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v212_no_delete_rule.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v212_no_delete_rule.cpython-313-pytest-9.0.2.pyc differ
Binary files iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v213_no_execute_rule.cpython-313-pytest-9.0.2.pyc and iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/__pycache__/test_vault_v213_no_execute_rule.cpython-313-pytest-9.0.2.pyc differ
diff -ruN iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/test_human_intent_receipts_v221.py iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/test_human_intent_receipts_v221.py
--- iw220_base_for_diff/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/test_human_intent_receipts_v221.py	1970-01-01 00:00:00.000000000 +0000
+++ iw221_work/IterationWallet_v2_2_0_CLOSED_CATALOG_BLACKBOX_SURFACE_PATCH/tests/test_human_intent_receipts_v221.py	2026-06-25 05:19:29.180585896 +0000
@@ -0,0 +1,171 @@
+import json
+from pathlib import Path
+
+import pytest
+from fastapi.testclient import TestClient
+
+from iteration_wallet.blackbox import BlackBox, BlackBoxError
+from iteration_wallet.identity import LocalIdentityProvider
+from iteration_wallet.notification_manager import ActorKind, NotificationManager
+from iteration_wallet.vault_v21 import VaultEngine
+from iteration_wallet import server
+
+
+def _source(tmp_path: Path, name: str, text: str) -> Path:
+    path = tmp_path / name
+    path.write_text(text, encoding="utf-8")
+    return path
+
+
+def test_blackbox_issues_receipt_tied_to_prior_custody_event_hash(tmp_path: Path):
+    blackbox = BlackBox(tmp_path)
+    provider = LocalIdentityProvider(tmp_path)
+    identity = provider.issue_session(
+        "josie",
+        "human",
+        device_id="laptop-1",
+        verified_methods=["human_ceremony", "typing_challenge"],
+    )
+    custody_event = blackbox.write_custody_event(
+        "WORKING_COPY_EXPORTED",
+        "candidate exported",
+        project_id="project",
+        section_id="section",
+        file_id="file",
+        state="candidate",
+    )
+
+    receipt = blackbox.issue_human_intent_receipt(
+        action_key="export_working_copy",
+        action_label="export working copy",
+        actor_identity=identity,
+        project_id="project",
+        section_id="section",
+        object_id="file",
+        object_name="candidate.py",
+        custody_state="candidate",
+        result_summary="working copy exported for outside experiments",
+        linked_event_hash=custody_event["event_hash"],
+        linked_event_id=custody_event["event_id"],
+    )
+
+    assert receipt["receipt_type"] == "human_intent_receipt"
+    assert receipt["actor_id"] == "josie"
+    assert receipt["session_id"] == identity.session_id
+    assert receipt["linked_blackbox_event_hash"] == custody_event["event_hash"]
+    assert receipt["receipt_hash"]
+    assert blackbox.verify_human_intent_receipt(receipt["receipt_id"])["ok"] is True
+    assert blackbox.verify_chain()["ok"] is True
+
+    receipt_files = list((tmp_path / "blackbox" / "receipts").glob("*.json"))
+    assert len(receipt_files) == 1
+    events = list(blackbox.iter_events())
+    assert any(e["event_type"] == "HUMAN_INTENT_RECEIPT_ISSUED" for e in events)
+
+
+def test_receipt_rejects_bot_or_human_without_intent_proof(tmp_path: Path):
+    blackbox = BlackBox(tmp_path)
+    provider = LocalIdentityProvider(tmp_path)
+    event = blackbox.write_custody_event("FILE_STAGED_FOR_REMOVAL", "removed", file_id="file")
+    bot = provider.issue_session("tool", "bot", verified_methods=["api_token"])
+    unproved_human = provider.issue_session("human", "human", verified_methods=[])
+
+    with pytest.raises(BlackBoxError):
+        blackbox.issue_human_intent_receipt(
+            action_key="remove_from_active",
+            action_label="remove from active use",
+            actor_identity=bot,
+            object_id="file",
+            linked_event_hash=event["event_hash"],
+        )
+
+    with pytest.raises(BlackBoxError):
+        blackbox.issue_human_intent_receipt(
+            action_key="remove_from_active",
+            action_label="remove from active use",
+            actor_identity=unproved_human,
+            object_id="file",
+            linked_event_hash=event["event_hash"],
+        )
+
+    assert blackbox.list_human_intent_receipts() == []
+
+
+def test_receipt_tamper_detection(tmp_path: Path):
+    blackbox = BlackBox(tmp_path)
+    provider = LocalIdentityProvider(tmp_path)
+    identity = provider.issue_session("head", "human", verified_methods=["human_ceremony"])
+    event = blackbox.write_custody_event("FILE_QUARANTINED", "quarantined", file_id="file")
+    receipt = blackbox.issue_human_intent_receipt(
+        action_key="quarantine",
+        action_label="quarantine file",
+        actor_identity=identity,
+        object_id="file",
+        linked_event_hash=event["event_hash"],
+    )
+    path = tmp_path / "blackbox" / "receipts" / f"{receipt['receipt_id']}.json"
+    data = json.loads(path.read_text(encoding="utf-8"))
+    data["actor_id"] = "attacker"
+    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
+
+    result = blackbox.verify_human_intent_receipt(receipt["receipt_id"])
+    assert result["ok"] is False
+    assert result["reason"] == "receipt hash mismatch"
+
+
+def test_server_protected_remove_route_returns_human_intent_receipt(tmp_path: Path):
+    old_vault = server.vault21
+    old_blackbox = server.blackbox21
+    old_human_access = server.human_access
+    try:
+        blackbox = BlackBox(tmp_path)
+        server.blackbox21 = blackbox
+        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox)
+        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
+        client = TestClient(server.app)
+
+        project = client.post("/api/v21/projects", json={"name": "Receipt Project"}).json()
+        section = client.post(f"/api/v21/projects/{project['id']}/sections", json={"name": "Core"}).json()
+        src = _source(tmp_path, "candidate.txt", "receipt protected")
+        candidate = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
+            json={"path": str(src), "notes": "closed note"},
+        ).json()
+        session = server.human_access.issue_identity_session(
+            "josie",
+            ActorKind.HUMAN,
+            device_id="laptop-1",
+            verified_methods=["human_ceremony"],
+        )
+        token = client.post("/api/v21/vault/open").json()["ceremony_token"]
+
+        response = client.post(
+            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{candidate['id']}/remove",
+            json={
+                "ceremony_token": token,
+                "actor_kind": "human",
+                "session_id": session.session_id,
+                "human_ceremony_passed": True,
+            },
+        )
+
+        assert response.status_code == 200, response.text
+        body = response.json()
+        assert body["result"]["state"] == "staging"
+        receipt = body["human_intent_receipt"]
+        assert receipt["action_key"] == "remove_from_active"
+        assert receipt["object_id"] == candidate["id"]
+        assert receipt["actor_id"] == "josie"
+        assert receipt["linked_blackbox_event_hash"]
+        assert receipt["receipt_hash"]
+        assert "ceremony_token" not in json.dumps(receipt)
+        assert blackbox.verify_human_intent_receipt(receipt["receipt_id"])["ok"] is True
+
+        listed = client.get("/api/v21/blackbox/receipts").json()["receipts"]
+        assert len(listed) == 1
+        detail = client.get(f"/api/v21/blackbox/receipts/{receipt['receipt_id']}").json()
+        assert detail["verification"]["ok"] is True
+    finally:
+        server.vault21 = old_vault
+        server.blackbox21 = old_blackbox
+        server.human_access = old_human_access
