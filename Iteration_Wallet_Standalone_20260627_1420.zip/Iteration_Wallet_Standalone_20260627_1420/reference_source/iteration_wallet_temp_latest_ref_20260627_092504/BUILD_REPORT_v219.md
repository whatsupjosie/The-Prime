# Iteration Wallet v2.1.4 — Rule Surface Clean Pass

Purpose: double-check and harden the two primary safety rules:

1. Iteration Wallet never deletes user-custodied material.
2. Iteration Wallet never executes user-custodied material.

## What was found

The v2.1.3 package correctly refused delete/execute attempts, but it still exposed public compatibility surfaces:

- FastAPI DELETE routes that returned 405.
- FastAPI /run, /execute, and /open-file routes that returned 405.
- engine methods named delete_file(), run_file(), execute_file(), launch_file(), and open_file() that only raised errors.
- CLI helper support for HTTP DELETE transport.

Those did not destroy or execute anything, but they contradicted the stronger product rule: Iteration Wallet should not present these as product actions at all.

## What changed

- Removed public DELETE routes from server.py.
- Removed public run/execute/open-file routes from server.py.
- Removed delete_file() compatibility stubs from vault.py and vault_v21.py.
- Removed run_file(), execute_file(), launch_file(), and open_file() compatibility stubs from vault.py and vault_v21.py.
- Removed CLI HTTP DELETE transport path.
- Updated tests so they assert the delete/execution surfaces are absent, not merely disabled.
- Preserved allowed actions: remove, restore, quarantine, ban, release from custody by live-person ceremony, export working copy, and attach external observational test results.

## Verification commands

```bash
python -m py_compile iteration_wallet/vault.py iteration_wallet/vault_v21.py iteration_wallet/server.py iteration_wallet/cli.py
python -m pytest -q
python - <<'PY'
from iteration_wallet.server import app
bad=[]
for r in app.routes:
    path=getattr(r,'path','')
    methods=getattr(r,'methods',set()) or set()
    if 'DELETE' in methods or any(x in path for x in ['/run','/execute','/open-file','delete']):
        bad.append((sorted(methods), path))
print('bad_routes', bad)
print('route_count', len(app.routes))
PY
```

## Results

```text
53 passed in 1.11s
bad_routes []
route_count 35
```

## Remaining wording traces

There are still explanatory comments/docs that say Iteration Wallet has no delete/destruction or no execution. Those are not behavior surfaces. They are rule statements. Product code no longer exposes delete/run/execute/open-file public routes or methods.

## Important exception

Git guard still uses subprocess to call git commands. That is not executing custodied project code. It is tool plumbing for repository inspection. The no-execute rule is about user-custodied objects inside Iteration Wallet.
