# Iteration Wallet v2.2.4 — Private Alpha Flow Runner

v2.2.4 adds a developer-facing private-alpha runner that proves the current Iteration Wallet custody chain outside pytest and leaves behind a human-readable report.

The point is simple: an unfamiliar builder bot or engineer should be able to run one command and see whether the current private-alpha spine still works before changing code.

## New module

```text
iteration_wallet/private_alpha_runner.py
```

## New script

```text
tools/private_alpha_flow_runner.py
```

## New console command

```text
iw-private-alpha-flow
```

## What the runner proves

The runner creates an isolated local runtime and exercises the public v2.1 API layer:

1. Create project and section.
2. Add Raw Source and Candidates.
3. Verify closed catalog does not leak protected fields.
4. Issue a human identity session with intent proof.
5. Open the Vault.
6. Issue scoped, single-use ceremony tokens.
7. Promote Candidate to Prime.
8. Export a working copy outside the Vault.
9. Remove and restore without deletion.
10. Quarantine without deletion.
11. Release from custody with explicit `RELEASE` confirmation.
12. Verify Human Intent Receipts.
13. Verify BlackBox chain integrity.
14. Verify custody integrity.
15. Lock the Vault and verify catalog-only view again.
16. Read private-alpha readiness status.

## Usage

From the project root:

```bash
python -m iteration_wallet.private_alpha_runner --run-root /tmp/iw_private_alpha --report-dir /tmp/iw_private_alpha/report
```

Or with the tool script:

```bash
python tools/private_alpha_flow_runner.py --run-root /tmp/iw_private_alpha --report-dir /tmp/iw_private_alpha/report
```

Or after installation:

```bash
iw-private-alpha-flow --run-root /tmp/iw_private_alpha --report-dir /tmp/iw_private_alpha/report
```

If no `--run-root` is given, the runner creates a persistent temp directory and prints where the report was written.

## Output

The runner writes:

```text
private_alpha_flow_report.json
private_alpha_flow_report.md
```

Reports are intentionally scrubbed. They do not expose raw ceremony-token secrets, protected file contents, protected paths, previews, or hashes.

## Tests

New test file:

```text
tests/test_private_alpha_runner_v224.py
```

Verification command:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
102 passed
```

## Honest scope

This is not Oubliette integration, not camera/liveness, and not production authentication. It is a durable proof runner for the current private-alpha custody flow, so future work starts from evidence instead of vibes.
