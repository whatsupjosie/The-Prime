"""
Iteration Wallet
================
Cross-platform project vault for AI developers.

© 2024–2025 Josie Curtsey Cobbley / Rear View Foresight LLC
"Feic Mo Chroí — See My Heart."
"""

__version__ = "2.2.4"
__author__ = "Josie Curtsey Cobbley"
__license__ = "Proprietary"

# v2.2.4 Private Alpha Flow + Integration Polish
try:
    from .identity import ActorIdentity, IdentityError, LocalIdentityProvider
    from .blackbox import BlackBox, BlackBoxError
    from .notification_manager import (
        ActorKind,
        AccessRequest,
        ApprovalRequest,
        Notification,
        NotificationLevel,
        NotificationManager,
        RequestClassification,
        RequestStatus,
    )
except Exception:  # keep base package import tolerant during partial installs
    pass
