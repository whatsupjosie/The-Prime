import tempfile
from pathlib import Path

import pytest

from iteration_wallet.vault_v21 import VaultEngine, VaultError


def make_file(text='data', suffix='.txt'):
    f = tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False)
    f.write(text)
    f.flush()
    f.close()
    return Path(f.name)


def setup_vault(tmpdir):
    vault = VaultEngine(Path(tmpdir))
    project = vault.create_project('App')
    section = vault.create_section(project['id'], 'Core')
    return vault, project, section


def test_restore_from_removed_returns_candidate_to_candidates():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('candidate')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            token = vault.open_vault()['ceremony_token']
            vault.remove_file(project['id'], section['id'], cand['id'], token)
            assert vault.get_section_view(project['id'], section['id'])['removed']

            restored = vault.restore_file(project['id'], section['id'], cand['id'], token)
            assert restored['state'] == 'candidate'
            assert restored['staged'] is False
            view = vault.get_section_view(project['id'], section['id'])
            assert [f['id'] for f in view['candidates']] == [cand['id']]
            assert view['removed'] == []
            assert Path(restored['vault_path']).exists()
        finally:
            src.unlink(missing_ok=True)


def test_review_candidate_records_metadata_without_promoting():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file("print('v2')", '.py')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            review = vault.review_candidate(
                project['id'], section['id'], cand['id'],
                verdict='needs_review',
                summary='Improves layout but needs tests',
                strengths=['clearer structure'],
                risks=['untested edge cases'],
            )
            assert review['verdict'] == 'needs_review'
            assert cand['state'] == 'candidate'
            assert section['prime'] is None
            assert cand['last_review_verdict'] == 'needs_review'
            metadata_dir = Path(tmpdir) / 'projects' / project['id'] / 'sections' / section['id'] / 'metadata' / 'candidate_reviews'
            assert list(metadata_dir.glob('*.json'))
        finally:
            src.unlink(missing_ok=True)


def test_review_rejects_invalid_verdict_and_non_candidate():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('raw')
        try:
            raw = vault.add_raw_source(project['id'], section['id'], str(src))
            with pytest.raises(VaultError, match='Only Candidates'):
                vault.review_candidate(project['id'], section['id'], raw['id'], 'ready')
        finally:
            src.unlink(missing_ok=True)


def test_export_working_copy_does_not_mutate_vault_copy():
    with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as outdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('hello')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            original_vault_path = cand['vault_path']
            result = vault.export_working_copy(project['id'], section['id'], cand['id'], outdir)
            assert Path(result['output_path']).exists()
            assert Path(original_vault_path).exists()
            assert cand['vault_path'] == original_vault_path
            assert Path(result['output_path']).read_text() == 'hello'
        finally:
            src.unlink(missing_ok=True)


def test_removed_file_cannot_be_exported():
    with tempfile.TemporaryDirectory() as tmpdir, tempfile.TemporaryDirectory() as outdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('gone')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            token = vault.open_vault()['ceremony_token']
            vault.remove_file(project['id'], section['id'], cand['id'], token)
            with pytest.raises(VaultError, match='Cannot export'):
                vault.export_working_copy(project['id'], section['id'], cand['id'], outdir)
        finally:
            src.unlink(missing_ok=True)
