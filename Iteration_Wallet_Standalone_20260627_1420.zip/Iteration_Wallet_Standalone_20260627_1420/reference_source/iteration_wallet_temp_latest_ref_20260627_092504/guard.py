"""
Iteration Wallet v2.2.2 — Ceremony Token Lifecycle
===================================================

Action-bound ceremony tokens are short-lived, session-bound, and single-use.
They are not receipts, passwords, or permissions by themselves. They are the
small intentional-action proof that links a live human session to one protected
custody action.

Product law:
- Protected custody actions must not accept a loose reusable token at the API gate.
- Tokens are scoped to action/session/object context and expire quickly.
- Raw token secrets are never persisted; only token hashes are stored.
- Consumed, expired, revoked, wrong-action, wrong-session, or wrong-object tokens fail closed.
"""

from __future__ import annotations

import hashlib
import json
import secrets
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from iteration_wallet.blackbox import BlackBox


class CeremonyTokenError(Exception):
    """Raised for expected ceremony token lifecycle failures."""


class CeremonyTokenLedger:
    """File-backed ledger for scoped ceremony tokens.

    Token records live under `<vault_root>/ceremony_tokens`. The raw token is
    returned once on issue and is never written to disk. Validation recomputes
    the hash, checks scope, and consumes the token atomically.
    """

    TOKEN_PREFIX = "iwct"

    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None):
        self.vault_root = Path(vault_root)
        self.blackbox = blackbox
        self.token_dir = self.vault_root / "ceremony_tokens"
        self.token_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def now() -> datetime:
        return datetime.now()

    @staticmethod
    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def token_hash(raw_token: str) -> str:
        return hashlib.sha256(str(raw_token).encode("utf-8")).hexdigest()

    @classmethod
    def parse_token_id(cls, raw_token: str) -> str:
        parts = str(raw_token or "").split("_", 2)
        if len(parts) != 3 or parts[0] != cls.TOKEN_PREFIX or not parts[1] or not parts[2]:
            raise CeremonyTokenError("Invalid ceremony token format")
        return parts[1]

    def _path(self, token_id: str) -> Path:
        return self.token_dir / f"{token_id}.json"

    def _load_record(self, token_id: str) -> Dict[str, Any]:
        path = self._path(token_id)
        if not path.exists():
            raise CeremonyTokenError("Unknown ceremony token")
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise CeremonyTokenError(f"Unreadable ceremony token record: {exc}") from exc

    def _save_record(self, record: Dict[str, Any]) -> None:
        self._write_json_atomic(self._path(record["token_id"]), record)

    def write_event(self, event_type: str, summary: str, **extra: Any) -> None:
        if self.blackbox:
            self.blackbox.write_event(event_type, summary, **extra)

    def issue_token(
        self,
        *,
        action_key: str,
        session_id: str,
        open_session_id: str,
        actor_id: Optional[str] = None,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
        ttl_seconds: int = 300,
    ) -> Dict[str, Any]:
        if not action_key:
            raise CeremonyTokenError("action_key is required")
        if not session_id:
            raise CeremonyTokenError("session_id is required")
        if not open_session_id:
            raise CeremonyTokenError("Vault must be open before issuing a ceremony token")
        ttl_seconds = max(5, min(int(ttl_seconds or 300), 900))
        issued_at = self.now()
        expires_at = issued_at + timedelta(seconds=ttl_seconds)
        token_id = uuid.uuid4().hex[:16]
        secret = secrets.token_urlsafe(32)
        raw_token = f"{self.TOKEN_PREFIX}_{token_id}_{secret}"
        record = {
            "token_id": token_id,
            "token_hash": self.token_hash(raw_token),
            "action_key": action_key,
            "session_id": session_id,
            "actor_id": actor_id,
            "project_id": project_id,
            "section_id": section_id,
            "object_id": object_id,
            "open_session_id": open_session_id,
            "issued_at": issued_at.isoformat(),
            "expires_at": expires_at.isoformat(),
            "consumed_at": None,
            "consumed_by_action": None,
            "revoked_at": None,
            "revoked_reason": None,
        }
        self._save_record(record)
        self.write_event(
            "CEREMONY_TOKEN_ISSUED",
            f"Ceremony token issued for {action_key}",
            token_id=token_id,
            action_key=action_key,
            session_id=session_id,
            actor_id=actor_id,
            project_id=project_id,
            section_id=section_id,
            file_id=object_id,
            expires_at=record["expires_at"],
        )
        public = dict(record)
        public.pop("token_hash", None)
        public["ceremony_token"] = raw_token
        return public

    def validate_and_consume(
        self,
        raw_token: str,
        *,
        action_key: str,
        session_id: Optional[str] = None,
        open_session_id: Optional[str] = None,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        object_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        token_id = self.parse_token_id(raw_token)
        record = self._load_record(token_id)
        now = self.now()

        def deny(reason: str) -> None:
            self.write_event(
                "CEREMONY_TOKEN_DENIED",
                f"Ceremony token denied for {action_key}: {reason}",
                token_id=token_id,
                action_key=action_key,
                session_id=session_id,
                project_id=project_id,
                section_id=section_id,
                file_id=object_id,
                reason=reason,
            )
            raise CeremonyTokenError(reason)

        if record.get("token_hash") != self.token_hash(raw_token):
            deny("Ceremony token secret mismatch")
        if record.get("revoked_at"):
            deny("Ceremony token has been revoked")
        if record.get("consumed_at"):
            deny("Ceremony token has already been used")
        expires_at = datetime.fromisoformat(record["expires_at"])
        if now > expires_at:
            deny("Ceremony token has expired")
        if record.get("action_key") != action_key:
            deny("Ceremony token is not valid for this action")
        if session_id and record.get("session_id") != session_id:
            deny("Ceremony token is not valid for this identity session")
        if open_session_id and record.get("open_session_id") != open_session_id:
            deny("Ceremony token is not valid for the current open Vault session")
        for key, expected in (("project_id", project_id), ("section_id", section_id), ("object_id", object_id)):
            recorded = record.get(key)
            if recorded is not None and expected is not None and recorded != expected:
                deny(f"Ceremony token is not valid for this {key}")

        record["consumed_at"] = now.isoformat()
        record["consumed_by_action"] = action_key
        self._save_record(record)
        self.write_event(
            "CEREMONY_TOKEN_CONSUMED",
            f"Ceremony token consumed for {action_key}",
            token_id=token_id,
            action_key=action_key,
            session_id=record.get("session_id"),
            actor_id=record.get("actor_id"),
            project_id=project_id or record.get("project_id"),
            section_id=section_id or record.get("section_id"),
            file_id=object_id or record.get("object_id"),
        )
        safe = dict(record)
        safe.pop("token_hash", None)
        return safe

    def revoke_token(self, raw_token: str, reason: str = "manual revocation") -> Dict[str, Any]:
        token_id = self.parse_token_id(raw_token)
        record = self._load_record(token_id)
        record["revoked_at"] = self.now().isoformat()
        record["revoked_reason"] = reason
        self._save_record(record)
        self.write_event("CEREMONY_TOKEN_REVOKED", f"Ceremony token revoked: {reason}", token_id=token_id, action_key=record.get("action_key"))
        safe = dict(record)
        safe.pop("token_hash", None)
        return safe

    def revoke_for_open_session(self, open_session_id: str, reason: str = "vault locked") -> int:
        if not open_session_id:
            return 0
        count = 0
        for path in self.token_dir.glob("*.json"):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if record.get("open_session_id") != open_session_id:
                continue
            if record.get("consumed_at") or record.get("revoked_at"):
                continue
            record["revoked_at"] = self.now().isoformat()
            record["revoked_reason"] = reason
            self._save_record(record)
            count += 1
        if count:
            self.write_event("CEREMONY_TOKENS_REVOKED", f"{count} ceremony token(s) revoked: {reason}", open_session_id=open_session_id, count=count)
        return count

    def list_tokens(self, *, include_hashes: bool = False) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        for path in self.token_dir.glob("*.json"):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not include_hashes:
                record.pop("token_hash", None)
            records.append(record)
        records.sort(key=lambda r: (r.get("issued_at", ""), r.get("token_id", "")))
        return records
