# Iteration Wallet v2.1.8 — Identity Session Binding Patch

## Purpose

This patch completes IW-TASK-003 from the task book: bind the Human Intent Gatekeeper to an internal auth/session interface so protected decisions no longer have to trust arbitrary caller-provided `user_id` strings.

This is **not** OAuth, passkeys, biometrics, camera verification, or a full authentication provider. It is the local identity/session interface those systems can attach to later.

## Product rule

Protected custody actions should be tied to a resolved actor session:

- actor id
- actor kind: human / bot / ai assistant / tool / script / system / unknown
- session id
- device id
- verified methods
- role claims
- issued/expiry timestamps

For protected routes, no session means no custody action.

## Main changes

### Added `iteration_wallet/identity.py`

Provides:

- `ActorIdentity`
- `LocalIdentityProvider`
- `IdentityError`
- session issuing
- session lookup
- session expiry checks
- session revocation
- human-intent proof checks

The identity object supports verified methods including:

- `human_ceremony`
- `ceremony_token`
- `live_ceremony`
- `manual_ceremony`
- `camera_verification`
- `typing_challenge`
- `read_aloud_challenge`
- `head_user_approval`

### Updated `NotificationManager`

Added:

- `issue_identity_session()`
- `get_identity_session()`
- `require_identity_session()`
- `revoke_identity_session()`

Approval decisions can now use `decision_session_id`.

When a session is supplied:

- the session must exist
- the session must not be expired/revoked
- the session actor must match `decision_by` if `decision_by` is supplied
- the session must include human-intent proof
- the resolved session actor must be Head User or configured admin

Blocked approval attempts are logged into BlackBox.

### Updated direct-access evaluation

`evaluate_direct_access()` can now accept `actor_identity`.

When identity is supplied, actor kind and ceremony proof come from the session. Bot/tool/AI sessions are still denied direct protected custody access.

Denied protected direct-access attempts are written as BlackBox events.

### Updated `gatekeeper.py`

Protected action evaluation now accepts `actor_identity`. Identity overrides raw actor kind when supplied.

This keeps the v2.1.7 protected-action registry intact while binding it to session identity for v2.1.8.

### Updated protected API routes

Protected v2.1 custody routes now require an identity session:

- remove from active
- restore to active
- release from custody
- quarantine
- promote Candidate to Prime
- export working copy

No `session_id` = 403 before custody mutation.

The release route still validates missing/incorrect `RELEASE` confirmation as a 400 ceremony error before identity gating, preserving the no-release safety test and avoiding custody movement.

### Added identity API endpoints

- `POST /api/v21/identity/sessions`
- `GET /api/v21/identity/sessions/{session_id}`

These are local/private-alpha identity endpoints, not a public auth solution.

### Updated package version

- `iteration_wallet.__version__ = 2.1.8`
- `setup.py` version = `2.1.8`

## Tests added

Added `tests/test_identity_session_v218.py`.

Coverage:

1. Local identity session shape and human-intent methods.
2. Approval decision uses session identity, not arbitrary `decision_by` string.
3. Bot session using the Head User actor id cannot approve without human-intent proof.
4. Gatekeeper accepts human identity sessions and denies bot/tool identity sessions.
5. Server protected-route helper requires session identity when route-level enforcement is enabled.

## Verification

Clean compile and full test run:

```text
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
82 passed in 13.41s
```

## What this does not do yet

- Real password login
- OAuth/SSO
- hardware keys
- passkeys
- email/SMS verification providers
- camera/liveness engine
- biometric verification
- database-backed sessions
- external append-only BlackBox sealing

Those now have an interface to attach to.

## Honest status

This closes the specific v2.1.6/v2.1.7 weakness where Head User/admin checks could rely only on arbitrary strings. It does not make Iteration Wallet production-authenticated, but it moves the alpha gatekeeper from “caller says who they are” to “caller presents a local session identity that can carry verified human-intent proof.”
