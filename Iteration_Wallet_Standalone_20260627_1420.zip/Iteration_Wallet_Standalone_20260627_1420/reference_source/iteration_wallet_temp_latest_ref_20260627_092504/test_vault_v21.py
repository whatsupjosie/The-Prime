"""
Iteration Wallet v2.2.3 — Private Alpha Flow Integration Test
==============================================================

This test proves the current private-alpha custody path as one coherent flow:
closed catalog, human identity session, scoped ceremony tokens, protected
custody movement, human intent receipts, shared BlackBox chain, and custody
integrity verification.
"""

from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from iteration_wallet import server
from iteration_wallet.blackbox import BlackBox
from iteration_wallet.notification_manager import NotificationManager
from iteration_wallet.vault_v21 import VaultEngine


PROTECTED_LEAK_FIELDS = {
    "vault_path",
    "original_path",
    "hash",
    "notes",
    "reviews",
    "external_test_results",
    "contents",
    "preview",
    "open_url",
    "export_url",
    "run_url",
}


def _make_source(tmp_path: Path, name: str, text: str) -> Path:
    path = tmp_path / name
    path.write_text(text, encoding="utf-8")
    return path




def _assert_no_secret_token_keys(value):
    if isinstance(value, dict):
        assert "ceremony_token" not in value
        for child in value.values():
            _assert_no_secret_token_keys(child)
    elif isinstance(value, list):
        for child in value:
            _assert_no_secret_token_keys(child)


def _assert_no_closed_view_leaks(value):
    if isinstance(value, dict):
        leaked = PROTECTED_LEAK_FIELDS.intersection(value.keys())
        assert not leaked, f"closed view leaked protected fields: {sorted(leaked)}"
        for child in value.values():
            _assert_no_closed_view_leaks(child)
    elif isinstance(value, list):
        for child in value:
            _assert_no_closed_view_leaks(child)


def test_private_alpha_end_to_end_flow_from_api(tmp_path: Path):
    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
    try:
        blackbox = BlackBox(tmp_path)
        server.blackbox21 = blackbox
        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
        client = TestClient(server.app)

        # 1. Project + section + materials enter custody. No open Vault needed.
        project = client.post("/api/v21/projects", json={"name": "Private Alpha"}).json()
        section = client.post(
            f"/api/v21/projects/{project['id']}/sections",
            json={"name": "Core", "description": "alpha section"},
        ).json()
        raw = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/raw-sources",
            json={"path": str(_make_source(tmp_path, "raw.txt", "original source")), "notes": "closed raw note"},
        ).json()
        promote_candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(_make_source(tmp_path, "prime_candidate.txt", "candidate A")), "notes": "candidate for prime"},
        ).json()
        removable_candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(_make_source(tmp_path, "remove_restore.txt", "candidate B")), "notes": "remove restore candidate"},
        ).json()
        quarantine_candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(_make_source(tmp_path, "quarantine.txt", "candidate C")), "notes": "quarantine candidate"},
        ).json()
        release_candidate = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(_make_source(tmp_path, "release.txt", "candidate D")), "notes": "release candidate"},
        ).json()
        assert raw["state"] == "raw"

        # 2. Closed catalog reveals safe catalog metadata, not contents/paths/hashes.
        closed = client.get(f"/api/v21/projects/{project['id']}/sections/{section['id']}/closed-catalog")
        assert closed.status_code == 200, closed.text
        closed_body = closed.json()
        assert closed_body["view_mode"] == "closed_catalog"
        assert closed_body["protected_contents_visible"] is False
        _assert_no_closed_view_leaks(closed_body)
        assert closed_body["raw_sources"][0]["closed_view_note"] == "closed raw note"

        # 3. A human identity session with intent proof opens the protected path.
        session_resp = client.post(
            "/api/v21/identity/sessions",
            json={
                "actor_id": "josie",
                "actor_kind": "human",
                "device_id": "local-test-device",
                "verified_methods": ["human_ceremony", "typing_challenge"],
                "role_claims": {"head_user": True},
            },
        )
        assert session_resp.status_code == 201, session_resp.text
        session_id = session_resp.json()["session_id"]
        open_resp = client.post("/api/v21/vault/open")
        assert open_resp.status_code == 200, open_resp.text
        assert open_resp.json()["strict_ceremony_tokens"] is True

        def issue_token(action_key: str, object_id: str):
            response = client.post(
                "/api/v21/ceremony/tokens",
                json={
                    "action_key": action_key,
                    "session_id": session_id,
                    "project_id": project["id"],
                    "section_id": section["id"],
                    "object_id": object_id,
                    "ttl_seconds": 300,
                },
            )
            assert response.status_code == 201, response.text
            token_body = response.json()
            assert "ceremony_token" in token_body
            # The raw secret is returned once, but listing must not reveal raw secrets.
            listed = client.get("/api/v21/ceremony/tokens").json()["tokens"]
            assert all("ceremony_token" not in item for item in listed)
            return token_body["ceremony_token"]

        def protected_payload(token: str, **extra):
            body = {
                "ceremony_token": token,
                "actor_kind": "human",
                "session_id": session_id,
                "human_ceremony_passed": True,
            }
            body.update(extra)
            return body

        # 4. Promote a Candidate to Prime; receipt proves human intent.
        promote_token = issue_token("promote_candidate_to_prime", promote_candidate["id"])
        promoted = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates/{promote_candidate['id']}/promote",
            json=protected_payload(promote_token, reason="best accepted so far"),
        )
        assert promoted.status_code == 200, promoted.text
        promoted_body = promoted.json()
        assert promoted_body["result"]["state"] == "prime"
        assert promoted_body["human_intent_receipt"]["action_key"] == "promote_candidate_to_prime"
        assert "ceremony_token" not in json.dumps(promoted_body["human_intent_receipt"])

        # 5. Export Prime outside the Vault; Vault keeps custody, working copy is separate.
        export_dir = tmp_path / "external_workbench"
        export_token = issue_token("export_working_copy", promote_candidate["id"])
        exported = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{promote_candidate['id']}/export-working-copy",
            json=protected_payload(export_token, output_dir=str(export_dir)),
        )
        assert exported.status_code == 200, exported.text
        exported_body = exported.json()
        assert Path(exported_body["result"]["output_path"]).exists()
        assert exported_body["human_intent_receipt"]["action_key"] == "export_working_copy"

        # 6. Remove then restore a separate Candidate; no deletion, both actions receipt.
        remove_token = issue_token("remove_from_active", removable_candidate["id"])
        removed = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{removable_candidate['id']}/remove",
            json=protected_payload(remove_token),
        )
        assert removed.status_code == 200, removed.text
        assert removed.json()["result"]["state"] == "staging"
        restore_token = issue_token("restore_to_active", removable_candidate["id"])
        restored = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{removable_candidate['id']}/restore",
            json=protected_payload(restore_token),
        )
        assert restored.status_code == 200, restored.text
        assert restored.json()["result"]["state"] == "candidate"

        # 7. Quarantine and release separate objects; both are protected custody actions.
        quarantine_token = issue_token("quarantine", quarantine_candidate["id"])
        quarantined = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{quarantine_candidate['id']}/quarantine",
            json=protected_payload(quarantine_token),
        )
        assert quarantined.status_code == 200, quarantined.text
        assert quarantined.json()["result"]["state"] == "quarantined"

        release_token = issue_token("release_from_custody", release_candidate["id"])
        released = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/files/{release_candidate['id']}/release",
            json=protected_payload(release_token, confirmation="RELEASE"),
        )
        assert released.status_code == 200, released.text
        assert released.json()["result"]["state"] == "released"

        # 8. Evidence surfaces prove the flow rather than merely completing actions.
        receipts = client.get("/api/v21/blackbox/receipts").json()["receipts"]
        action_keys = {r["action_key"] for r in receipts}
        assert {
            "promote_candidate_to_prime",
            "export_working_copy",
            "remove_from_active",
            "restore_to_active",
            "quarantine",
            "release_from_custody",
        }.issubset(action_keys)
        for receipt in receipts:
            verification = client.get(f"/api/v21/blackbox/receipts/{receipt['receipt_id']}").json()["verification"]
            assert verification["ok"] is True

        chain = client.get("/api/v21/blackbox/chain").json()
        assert chain["ok"] is True
        custody = client.get("/api/v21/custody/verify").json()
        assert custody["ok"] is True

        # 9. Lock closes the Vault; section view returns catalog-only again.
        lock_resp = client.post("/api/v21/vault/lock")
        assert lock_resp.status_code == 200, lock_resp.text
        closed_again = client.get(f"/api/v21/projects/{project['id']}/sections/{section['id']}").json()
        assert closed_again["view_mode"] == "closed_catalog"
        _assert_no_closed_view_leaks(closed_again)
    finally:
        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human


def test_private_alpha_status_endpoint_reports_readiness_without_unlocking(tmp_path: Path):
    old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
    try:
        blackbox = BlackBox(tmp_path)
        server.blackbox21 = blackbox
        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox, strict_ceremony_tokens=True)
        server.human_access = NotificationManager(tmp_path, blackbox=blackbox)
        client = TestClient(server.app)

        status = client.get("/api/v21/private-alpha/status")
        assert status.status_code == 200, status.text
        body = status.json()
        assert body["status_type"] == "private_alpha_status"
        assert body["version"] == "2.2.4"
        assert body["strict_ceremony_tokens"] is True
        assert body["blackbox_chain_ok"] is True
        assert body["custody_integrity_ok"] is True
        assert body["ready_for_private_alpha_flow"] is True
        _assert_no_secret_token_keys(body)
        assert "promote_candidate_to_prime" in body["protected_actions"]
    finally:
        server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human
