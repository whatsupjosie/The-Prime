# Next Actions After v2.1.1

## Highest-value next fixes

1. Wire `app.html` to `/api/v21` so the UI speaks the real model:
   - Add Raw Source
   - Add Candidate
   - Review Candidate
   - Promote Candidate to Prime
   - View Cradle / Prime
   - View Archive
   - Restore from Removed

2. Add v2.1 CLI commands:
   - `iw section create`
   - `iw source add`
   - `iw candidate add`
   - `iw candidate review`
   - `iw candidate promote`
   - `iw removed restore`

3. Add a v2.1 release self-test that uses the API, not just direct engine calls.

4. Add first BlackBox event chain behind v2.1 events.

5. Add first Oubliette preflight check before export/promote/remove.

## Do not do next

- Do not add mandatory password.
- Do not replace the working v2 shell.
- Do not jump to full Oubliette before the v2.1 UI is speaking the right product language.
