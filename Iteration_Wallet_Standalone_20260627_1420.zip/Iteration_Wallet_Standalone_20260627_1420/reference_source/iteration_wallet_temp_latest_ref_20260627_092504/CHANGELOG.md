# Build Report — Iteration Wallet v2.2.0 Closed Catalog + BlackBox Evidence Surface

## Summary

Built v2.2.0 from v2.1.9 as the next corrected step after BlackBox extraction and vault coupling.

The goal was to make the closed Vault/Cradle state real: when closed, Iteration Wallet exposes only a safe catalog, not protected contents or internal custody paths.

## Implemented

### Closed catalog view

`VaultEngine.get_section_view()` now respects Vault state:

- closed Vault → `get_closed_catalog_view()`
- open Vault → `get_open_section_view()`

Closed catalog records include only:

- `id`
- `name`
- `state`
- `custody_state`
- `size_bytes`
- `created_at`
- `last_accessed_at`
- `last_accessed_by`
- `closed_view_note`
- `access_level`
- `project_id`
- `section_id`
- safe `blackbox` summary

Closed records deliberately omit:

- `vault_path`
- `original_path`
- `hash`
- `notes`
- `reviews`
- `external_test_results`
- `output_path`
- contents/previews

### Last accessed metadata

New ingested records now store:

- `size_bytes`
- `last_accessed_at`
- `last_accessed_by`
- `last_access_action`
- `closed_view_note`
- `access_level`

Exporting a working copy updates access metadata.

### BlackBox closed evidence surface

Added `BlackBox.build_closed_evidence_summary()`.

It returns a safe summary with:

- chain status
- event count
- custody event count
- violation count
- incident count
- last event type/time
- recent event type/time/summary only

It does not expose event hashes, previous hashes, paths, payload details, or protected file hashes.

### API additions

Added:

- `GET /api/v21/projects/{project_id}/sections/{section_id}/closed-catalog`
- `GET /api/v21/projects/{project_id}/sections/{section_id}/blackbox/closed-summary`

### NotificationManager performance repair

The full test suite began timing out in the notification cap test because notification loading was repeatedly scanning JSON files. I added an in-memory notification cache for the manager instance while preserving on-disk JSON persistence.

This was not a product feature, but it was a real little-thing fix needed to keep tests fast and deterministic.

## Tests added

`tests/test_closed_catalog_v220.py`

Covers:

- closed section view exposes catalog-only metadata
- protected strings/fields do not appear in closed view
- open Vault still returns full records for authorized/open state
- closed catalog includes safe BlackBox summary
- closed catalog API route returns safe view

## Verification

Clean working tree test run:

```text
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
91 passed in 6.79s
```

## Remaining limits

- No dedicated polished user interface yet.
- Camera/liveness verification remains future work.
- Oubliette external lab flow remains future work.
- Last-access-by is structurally present but needs stronger session/actor propagation through all routes.
- BlackBox is still local tamper-evident storage, not external sealing.
