# Iteration Wallet v2.1.5 Build Report

## Patch name
`IterationWallet_v2_1_5_HUMAN_ACCESS_BLACKBOX_PATCH`

## What changed
Added a real Human Access / BlackBox Request Control module implementing the conversation feature shape:

- Bots/AI/tools can request but cannot directly fetch protected custody.
- Notification messages are capped at 150 characters.
- Each recipient gets at most 5 unread request messages.
- The whole notification system caps at 200 messages.
- Head User approval requests now work and include the missing `is_expired()` behavior.
- BlackBox request/event logs preserve the full access-request record even when alerts are capped.
- Repeated bot request pressure is classified at 20/50/100/1000 thresholds.
- 100+ request pressure is treated as probable intrusion/runaway automation evidence.
- Flood-level behavior creates emergency lockout classification.
- Added FastAPI routes for request logging, report viewing, inbox viewing, approval decisions, and bot/direct-access evaluation.

## Important product claim
This patch does not allow bots to open/fetch protected custody. It only lets them file logged requests for human decision.

## Test status
Run with:

```bash
cd IterationWallet_v2_1_5_HUMAN_ACCESS_BLACKBOX_PATCH
python -m pytest -q
```

## Verified test run

Command executed:

```bash
python -m pytest -q tests/test_vault.py tests/test_vault_v21.py tests/test_vault_v211_improvements.py tests/test_vault_v212_no_delete_rule.py tests/test_vault_v213_no_execute_rule.py tests/test_notification_manager_v215.py
```

Result:

```text
67 passed in 16.49s
```
