"""
Iteration Wallet v2.1 — Test Suite
===================================
Tests for Section/Candidate/Prime model with ceremony token enforcement.

Run:  pytest test_vault_v21.py -v
"""

import pytest
import tempfile
from pathlib import Path
from iteration_wallet.vault_v21 import VaultEngine, VaultError


class TestSectionModel:
    """Test explicit Section/Candidate/Prime/Archive model."""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Create a fresh vault for each test."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self.vault = VaultEngine(Path(tmpdir))
            yield
    
    def test_create_project(self):
        """Create a project."""
        result = self.vault.create_project("My App")
        assert result["name"] == "My App"
        assert result["id"]
        assert len(self.vault._state["projects"]) == 1
    
    def test_create_section(self):
        """Create a section in a project."""
        project = self.vault.create_project("My App")
        section = self.vault.create_section(project["id"], "Core Engine")
        assert section["name"] == "Core Engine"
        assert section["id"]
    
    def test_add_raw_source(self):
        """Add a file to Raw Sources."""
        project = self.vault.create_project("My App")
        section = self.vault.create_section(project["id"], "Data")
        
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("original data")
            f.flush()
            
            file_record = self.vault.add_raw_source(project["id"], section["id"], f.name)
            
            assert file_record["state"] == "raw"
            assert file_record["name"]
            assert file_record["hash"]
            assert len(section["files"]) == 1
            
            Path(f.name).unlink()
    
    def test_add_candidate(self):
        """Add a file to Candidates."""
        project = self.vault.create_project("My App")
        section = self.vault.create_section(project["id"], "Code")
        
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("print('hello')")
            f.flush()
            
            file_record = self.vault.add_candidate(
                project["id"], section["id"], f.name, 
                notes="Attempt 1: simple version"
            )
            
            assert file_record["state"] == "candidate"
            assert file_record["notes"] == "Attempt 1: simple version"
            assert len(section["files"]) == 1
            
            Path(f.name).unlink()


class TestCeremonyTokens:
    """Test ceremony token enforcement."""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Create a fresh vault for each test."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self.vault = VaultEngine(Path(tmpdir))
            self.project = self.vault.create_project("Test")
            self.section = self.vault.create_section(self.project["id"], "Test Section")
            yield
    
    def test_open_vault_generates_token(self):
        """Opening vault generates a ceremony token."""
        result = self.vault.open_vault()
        assert result["is_open"] is True
        assert result["ceremony_token"]
        assert self.vault._is_open is True
    
    def test_lock_vault_invalidates_token(self):
        """Locking vault invalidates token."""
        self.vault.open_vault()
        self.vault.lock_vault()
        assert self.vault._is_open is False
        assert self.vault._ceremony_token is None
    
    def test_remove_requires_vault_open(self):
        """REMOVE requires vault to be open."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("data")
            f.flush()
            
            file_record = self.vault.add_candidate(self.project["id"], self.section["id"], f.name)
            
            # Try to remove without opening vault
            with pytest.raises(VaultError, match="Vault must be open"):
                self.vault.remove_file(self.project["id"], self.section["id"], file_record["id"], "bad_token")
            
            Path(f.name).unlink()
    
    def test_remove_requires_valid_token(self):
        """REMOVE requires valid ceremony token."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("data")
            f.flush()
            
            file_record = self.vault.add_candidate(self.project["id"], self.section["id"], f.name)
            self.vault.open_vault()
            
            # Try with wrong token
            with pytest.raises(VaultError, match="Invalid ceremony token"):
                self.vault.remove_file(self.project["id"], self.section["id"], file_record["id"], "wrong_token")
            
            Path(f.name).unlink()
    
    def test_remove_with_valid_token(self):
        """REMOVE succeeds with valid token."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("data")
            f.flush()
            
            file_record = self.vault.add_candidate(self.project["id"], self.section["id"], f.name)
            open_result = self.vault.open_vault()
            token = open_result["ceremony_token"]
            
            result = self.vault.remove_file(self.project["id"], self.section["id"], file_record["id"], token)
            
            assert result["state"] == "staging"
            assert result["staged"]
            
            Path(f.name).unlink()
    
    def test_no_delete_operation_surface_even_with_valid_token(self):
        """Iteration Wallet does not expose a delete operation, even after REMOVE."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("data")
            f.flush()
            file_record = self.vault.add_candidate(self.project["id"], self.section["id"], f.name)
            open_result = self.vault.open_vault()
            token = open_result["ceremony_token"]
            vault_path = Path(file_record["vault_path"])
            assert not hasattr(self.vault, "delete_file")
            assert vault_path.exists()
            assert file_record["state"] == "candidate"
            self.vault.remove_file(self.project["id"], self.section["id"], file_record["id"], token)
            staged_path = Path(file_record["vault_path"])
            assert not hasattr(self.vault, "delete_file")
            assert staged_path.exists()
            assert file_record["state"] == "staging"
            Path(f.name).unlink()


class TestPromotion:
    """Test Prime promotion logic."""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Create a fresh vault with a section and candidate."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self.vault = VaultEngine(Path(tmpdir))
            self.project = self.vault.create_project("Test")
            self.section = self.vault.create_section(self.project["id"], "Test Section")
            
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write("print('v1')")
                f.flush()
                self.candidate1_path = f.name
            
            self.candidate1 = self.vault.add_candidate(
                self.project["id"], self.section["id"], self.candidate1_path,
                notes="Version 1"
            )
            
            yield
            
            Path(self.candidate1_path).unlink()
    
    def test_promote_candidate_to_prime(self):
        """Promote a candidate to Prime with valid token."""
        open_result = self.vault.open_vault()
        token = open_result["ceremony_token"]
        
        result = self.vault.promote_to_prime(
            self.project["id"],
            self.section["id"],
            self.candidate1["id"],
            token,
            reason="Stable version"
        )
        
        assert result["state"] == "prime"
        assert result["promoted"]
        assert result["promotion_reason"] == "Stable version"
        assert self.section["prime"] == self.candidate1["id"]
    
    def test_promote_archives_old_prime(self):
        """Promoting new candidate archives the old Prime."""
        # Promote first candidate to Prime
        open_result = self.vault.open_vault()
        token = open_result["ceremony_token"]
        
        self.vault.promote_to_prime(
            self.project["id"],
            self.section["id"],
            self.candidate1["id"],
            token,
            reason="First prime"
        )
        
        self.vault.lock_vault()
        
        # Create and promote second candidate
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("print('v2')")
            f.flush()
            
            candidate2 = self.vault.add_candidate(
                self.project["id"], self.section["id"], f.name,
                notes="Version 2"
            )
            
            open_result = self.vault.open_vault()
            token = open_result["ceremony_token"]
            
            self.vault.promote_to_prime(
                self.project["id"],
                self.section["id"],
                candidate2["id"],
                token,
                reason="Better version"
            )
            
            # Old Prime should be archived
            assert self.candidate1["id"] in self.section["archive"]
            assert self.candidate1["state"] == "archived"
            assert self.section["prime"] == candidate2["id"]
            
            Path(f.name).unlink()
    
    def test_promote_requires_token(self):
        """Promoting to Prime requires valid ceremony token."""
        with pytest.raises(VaultError, match="Vault must be open"):
            self.vault.promote_to_prime(
                self.project["id"],
                self.section["id"],
                self.candidate1["id"],
                "bad_token",
                reason="Test"
            )


class TestSectionView:
    """Test section view that shows all compartments."""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Create a section with files in different states."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self.vault = VaultEngine(Path(tmpdir))
            self.project = self.vault.create_project("Test")
            self.section = self.vault.create_section(self.project["id"], "Test Section")
            
            # Create raw source
            with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
                f.write("raw")
                f.flush()
                self.raw = self.vault.add_raw_source(self.project["id"], self.section["id"], f.name)
                Path(f.name).unlink()
            
            # Create candidate
            with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
                f.write("cand")
                f.flush()
                self.cand = self.vault.add_candidate(self.project["id"], self.section["id"], f.name)
                Path(f.name).unlink()
            
            yield
    
    def test_section_view_shows_all_compartments(self):
        """Section view displays Raw Sources, Candidates, Cradle, Archive, Removed."""
        view = self.vault.get_section_view(self.project["id"], self.section["id"])
        
        assert "raw_sources" in view
        assert "candidates" in view
        assert "cradle" in view
        assert "archive" in view
        assert "removed" in view
        assert view["is_vault_open"] is False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])