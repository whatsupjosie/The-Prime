# Iteration Wallet v2.1.1 — Product Wiring Patch

## What was double-checked

Commands run:

```bash
python -m py_compile iteration_wallet/vault_v21.py verify_v21.py tests/test_vault_v21.py
python verify_v21.py
python -m pytest tests/test_vault_v21.py -q
python -m pytest tests/test_vault_v21.py tests/test_vault_v211_improvements.py -q
python - <<'PY'
from iteration_wallet.server import app
print('server import ok', len(app.routes))
PY
```

Results:

```text
verify_v21.py: 13 passed, 0 failed
pytest original v2.1 tests: 15 passed
pytest v2.1 + v2.1.1 tests: 20 passed
server import: ok, 33 routes
```

## What was improved now

This patch keeps the existing v2 runtime and the v2.1 engine, then adds the next product-facing behaviors:

1. **Restore from Removed**
   - Removed is now reversible staging, not a dead end.
   - `restore_file()` moves staged files back to their previous compartment.

2. **Candidate review without promotion**
   - `review_candidate()` lets AI/user attach Prime-readiness reviews.
   - Verdicts: `ready`, `not_ready`, `needs_review`, `donor_material`.
   - Reviews are written to section metadata.
   - Review never promotes automatically.

3. **Working-copy export**
   - `export_working_copy()` copies material out of the Vault into a workspace/sandbox.
   - Vault copy remains untouched.
   - Removed/released/quarantined files cannot be exported.

4. **Additive v2.1 API routes**
   - `/api/v21/...` routes now expose Projects, Sections, Raw Sources, Candidates, Review, Promote, Restore, Delete, and Export Working Copy.
   - This does not replace the old v2 API; it adds the product-model API alongside it.

## What is still not done

- The UI still speaks mostly v2 language.
- The CLI still speaks mostly v2 language.
- The `/api/v21` routes are backend-ready but not yet wired into app.html.
- BlackBox is not integrated.
- Oubliette is not integrated.
- Candidate review is human/AI notes and verdict storage, not automated code comparison yet.

## Honest status

This is now more than a model-only patch. It is a product-wiring step:

- v2 = runnable app shell
- v2.1 = correct Iteration Wallet model
- v2.1.1 = restores Removed, adds Candidate review, adds working-copy export, exposes v2.1 through FastAPI routes

It is still not a sellable final app, but it is a better working base.
