import json
from pathlib import Path

from fastapi.testclient import TestClient

from iteration_wallet.blackbox import BlackBox
from iteration_wallet.vault_v21 import VaultEngine
from iteration_wallet import server


FORBIDDEN_CLOSED_KEYS = {
    "vault_path",
    "original_path",
    "hash",
    "notes",
    "reviews",
    "external_test_results",
    "output_path",
    "contents",
    "preview",
}


def _source(tmp_path: Path, name: str, text: str) -> Path:
    path = tmp_path / name
    path.write_text(text, encoding="utf-8")
    return path


def _all_catalog_records(view):
    for key in ("raw_sources", "candidates", "archive", "removed", "quarantine", "released"):
        for record in view.get(key) or []:
            yield record
    if view.get("cradle"):
        yield view["cradle"]


def test_closed_section_view_exposes_catalog_only_and_preserves_closed_note(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox)
    project = vault.create_project("Catalog Project")
    section = vault.create_section(project["id"], "Cradle")
    candidate = vault.add_candidate(
        project["id"],
        section["id"],
        str(_source(tmp_path, "candidate.py", "print('hidden')")),
        notes="Safe closed-view note",
    )
    candidate["reviews"] = [{"summary": "protected review"}]
    candidate["external_test_results"] = [{"summary": "protected test result"}]

    view = vault.get_section_view(project["id"], section["id"])

    assert view["view_mode"] == "closed_catalog"
    assert view["protected_contents_visible"] is False
    assert view["is_vault_open"] is False
    record = view["candidates"][0]
    assert record["name"] == "candidate.py"
    assert record["size_bytes"] == len("print('hidden')")
    assert record["created_at"]
    assert record["last_accessed_at"]
    assert record["last_accessed_by"] == "system:add_material"
    assert record["closed_view_note"] == "Safe closed-view note"
    assert FORBIDDEN_CLOSED_KEYS.isdisjoint(record.keys())
    assert "hidden" not in json.dumps(view)
    assert "protected review" not in json.dumps(view)
    assert "protected test result" not in json.dumps(view)
    assert "vault_path" not in json.dumps(view)
    assert "original_path" not in json.dumps(view)


def test_open_section_view_still_returns_full_records_for_authorized_open_vault(tmp_path: Path):
    vault = VaultEngine(tmp_path)
    project = vault.create_project("Open Project")
    section = vault.create_section(project["id"], "Core")
    vault.add_candidate(project["id"], section["id"], str(_source(tmp_path, "candidate.txt", "visible when open")))

    closed = vault.get_section_view(project["id"], section["id"])
    assert "vault_path" not in closed["candidates"][0]

    vault.open_vault()
    open_view = vault.get_section_view(project["id"], section["id"])
    assert open_view["view_mode"] == "open_full"
    assert open_view["protected_contents_visible"] is True
    assert "vault_path" in open_view["candidates"][0]
    assert "hash" in open_view["candidates"][0]


def test_closed_catalog_includes_safe_blackbox_evidence_surface(tmp_path: Path):
    blackbox = BlackBox(tmp_path)
    vault = VaultEngine(tmp_path, blackbox=blackbox)
    project = vault.create_project("Evidence Project")
    section = vault.create_section(project["id"], "Core")
    vault.add_raw_source(project["id"], section["id"], str(_source(tmp_path, "raw.txt", "raw data")))

    view = vault.get_closed_catalog_view(project["id"], section["id"])
    section_bb = view["blackbox"]
    record_bb = view["raw_sources"][0]["blackbox"]

    assert section_bb["chain_ok"] is True
    assert section_bb["event_count"] >= 2
    assert section_bb["custody_event_count"] >= 2
    assert record_bb["chain_ok"] is True
    assert record_bb["event_count"] >= 1
    assert {"event_type", "created_at", "summary"}.issubset(record_bb["recent_events"][0].keys())
    assert "event_hash" not in json.dumps(view)
    assert "previous_event_hash" not in json.dumps(view)
    assert "raw data" not in json.dumps(view)


def test_closed_catalog_route_returns_safe_view(tmp_path: Path):
    old_vault = server.vault21
    old_blackbox = server.blackbox21
    old_human_access = server.human_access
    try:
        blackbox = BlackBox(tmp_path)
        server.blackbox21 = blackbox
        server.vault21 = VaultEngine(tmp_path, blackbox=blackbox)
        if hasattr(old_human_access, "blackbox"):
            server.human_access.blackbox = blackbox
        client = TestClient(server.app)
        project = client.post("/api/v21/projects", json={"name": "API Catalog"}).json()
        section = client.post(f"/api/v21/projects/{project['id']}/sections", json={"name": "Core"}).json()
        src = _source(tmp_path, "api_secret.txt", "do not reveal")
        created = client.post(
            f"/api/v21/projects/{project['id']}/sections/{section['id']}/candidates",
            json={"path": str(src), "notes": "show this note"},
        ).json()
        assert created["id"]

        response = client.get(f"/api/v21/projects/{project['id']}/sections/{section['id']}/closed-catalog")
        assert response.status_code == 200
        view = response.json()
        assert view["view_mode"] == "closed_catalog"
        assert view["candidates"][0]["closed_view_note"] == "show this note"
        assert "do not reveal" not in json.dumps(view)
        assert "vault_path" not in json.dumps(view)
        assert "hash" not in json.dumps(view)
    finally:
        server.vault21 = old_vault
        server.blackbox21 = old_blackbox
        server.human_access = old_human_access
