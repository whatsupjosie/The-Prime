# Iteration Wallet Primary Safety Rules

## Rule 1 — No Delete / No Destruction

Iteration Wallet never deletes user-custodied material.

Inside Iteration Wallet, a live person may perform custody-state changes:

- remove from active use
- relieve from Cradle
- remove from Archive
- move to Removed
- quarantine
- ban
- release from custody by live-person ceremony

But no one — not the AI, not automation, not even the user — deletes or destroys a file while it is inside Iteration Wallet custody.

Deletion/destruction is outside the product.

## Rule 2 — No Execution Inside Iteration Wallet

Iteration Wallet never executes user-custodied material.

The Vault is controlled clean-room custody, not the experiment bench. It stores sources, candidates, Prime, archives, removed material, quarantine, metadata, and external results.

Experiments happen outside Iteration Wallet. Code may be exported as a working copy and run elsewhere. Iteration Wallet can attach externally generated test/build results, but it does not run the custodied object itself.

## Allowed Product Actions

- Add Raw Source
- Add Candidate
- Export Working Copy
- Attach External Test Results
- Review Candidate
- Promote Candidate to Prime
- Relieve from Cradle
- Archive
- Remove
- Restore
- Quarantine
- Ban
- Release from Custody by live-person ceremony

## Forbidden Product Actions

- Delete
- Destroy
- Purge user-custodied material
- Execute custodied objects
- Run custodied programs
- Launch custodied files
- Open a custodied file in a way that may execute it
