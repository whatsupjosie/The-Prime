#!/usr/bin/env python3
"""Run the Iteration Wallet private-alpha flow from a source checkout."""

from iteration_wallet.private_alpha_runner import main

if __name__ == "__main__":
    raise SystemExit(main())
