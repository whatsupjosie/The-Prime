"""
Iteration Wallet v2.2.4 — Private Alpha Flow Runner
====================================================

Developer-facing runner for the private-alpha custody flow.

This is deliberately not a pytest fixture and not a product unlock surface. It
uses the FastAPI route layer in-process to prove that a fresh local Iteration
Wallet instance can complete the private-alpha flow and produce human-readable
receipts, BlackBox verification, and custody integrity evidence.

Product law preserved:
- no deletion
- no execution
- no silent overwrite
- no bot custody
- no raw ceremony token leakage in reports
"""

from __future__ import annotations

import argparse
import json
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi.testclient import TestClient

from iteration_wallet import server
from iteration_wallet.blackbox import BlackBox
from iteration_wallet.notification_manager import NotificationManager
from iteration_wallet.vault_v21 import VaultEngine


PROTECTED_REPORT_KEYS = {
    "ceremony_token",
    "token_secret",
    "raw_token",
    "vault_path",
    "original_path",
    "hash",
    "contents",
    "preview",
    "open_url",
    "export_url",
    "run_url",
}

CLOSED_VIEW_FORBIDDEN_KEYS = {
    "vault_path",
    "original_path",
    "hash",
    "notes",
    "reviews",
    "external_test_results",
    "contents",
    "preview",
    "open_url",
    "export_url",
    "run_url",
}


class PrivateAlphaFlowError(RuntimeError):
    """Raised when the private-alpha flow cannot complete cleanly."""


@dataclass
class FlowStep:
    """One human-readable flow step."""

    name: str
    ok: bool
    detail: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "ok": self.ok,
            "detail": self.detail,
            "evidence": scrub_report_value(self.evidence),
        }


@dataclass
class PrivateAlphaFlowReport:
    """Structured report returned by the runner."""

    ok: bool
    started_at: str
    completed_at: str
    run_root: str
    report_dir: str
    version: str
    steps: List[FlowStep]
    project_id: str
    section_id: str
    receipt_ids: List[str]
    blackbox_chain_ok: bool
    custody_integrity_ok: bool
    closed_catalog_safe: bool
    status: Dict[str, Any]
    json_report_path: Optional[str] = None
    markdown_report_path: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return scrub_report_value(
            {
                "ok": self.ok,
                "started_at": self.started_at,
                "completed_at": self.completed_at,
                "run_root": self.run_root,
                "report_dir": self.report_dir,
                "version": self.version,
                "steps": [s.to_dict() for s in self.steps],
                "project_id": self.project_id,
                "section_id": self.section_id,
                "receipt_ids": self.receipt_ids,
                "blackbox_chain_ok": self.blackbox_chain_ok,
                "custody_integrity_ok": self.custody_integrity_ok,
                "closed_catalog_safe": self.closed_catalog_safe,
                "status": self.status,
                "json_report_path": self.json_report_path,
                "markdown_report_path": self.markdown_report_path,
            }
        )


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def scrub_report_value(value: Any) -> Any:
    """Remove secrets/protected custody internals from reports."""
    if isinstance(value, dict):
        scrubbed: Dict[str, Any] = {}
        for key, child in value.items():
            if key in PROTECTED_REPORT_KEYS:
                scrubbed[key] = "<redacted>"
            else:
                scrubbed[key] = scrub_report_value(child)
        return scrubbed
    if isinstance(value, list):
        return [scrub_report_value(child) for child in value]
    return value


def assert_no_key(value: Any, forbidden: set[str], context: str) -> None:
    if isinstance(value, dict):
        leaked = forbidden.intersection(value.keys())
        if leaked:
            raise PrivateAlphaFlowError(f"{context} leaked protected keys: {sorted(leaked)}")
        for child in value.values():
            assert_no_key(child, forbidden, context)
    elif isinstance(value, list):
        for child in value:
            assert_no_key(child, forbidden, context)


def write_source(root: Path, name: str, text: str) -> Path:
    source_dir = root / "inputs"
    source_dir.mkdir(parents=True, exist_ok=True)
    path = source_dir / name
    path.write_text(text, encoding="utf-8")
    return path


class PrivateAlphaFlowRunner:
    """Runs the private-alpha flow through the public v2.1 API layer."""

    def __init__(self, run_root: Path, report_dir: Optional[Path] = None):
        self.run_root = Path(run_root).resolve()
        self.report_dir = Path(report_dir or (self.run_root / "private_alpha_report")).resolve()
        self.run_root.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.steps: List[FlowStep] = []
        self._raw_token_count = 0

    def step(self, name: str, detail: str = "", **evidence: Any) -> None:
        self.steps.append(FlowStep(name=name, ok=True, detail=detail, evidence=evidence))

    def fail(self, name: str, detail: str, **evidence: Any) -> None:
        self.steps.append(FlowStep(name=name, ok=False, detail=detail, evidence=evidence))
        raise PrivateAlphaFlowError(detail)

    def expect_status(self, response: Any, expected: int, name: str) -> Dict[str, Any]:
        if response.status_code != expected:
            self.fail(name, f"Expected HTTP {expected}, got {response.status_code}: {response.text}")
        try:
            return response.json()
        except Exception as exc:  # pragma: no cover - defensive
            self.fail(name, f"Response was not JSON: {exc}")
        raise AssertionError("unreachable")

    def run(self, *, write_reports: bool = True) -> PrivateAlphaFlowReport:
        started_at = utc_now()
        old_blackbox, old_vault, old_human = server.blackbox21, server.vault21, server.human_access
        receipt_ids: List[str] = []
        project_id = ""
        section_id = ""
        status: Dict[str, Any] = {}
        chain_ok = False
        custody_ok = False
        closed_safe = False

        try:
            blackbox = BlackBox(self.run_root)
            server.blackbox21 = blackbox
            server.vault21 = VaultEngine(self.run_root, blackbox=blackbox, strict_ceremony_tokens=True)
            server.human_access = NotificationManager(self.run_root, blackbox=blackbox)
            client = TestClient(server.app)
            self.step("initialize isolated private-alpha runtime", run_root=str(self.run_root))

            project = self.expect_status(
                client.post("/api/v21/projects", json={"name": "Private Alpha Runner"}),
                201,
                "create project",
            )
            project_id = project["id"]
            section = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections",
                    json={"name": "Core", "description": "runner section"},
                ),
                201,
                "create section",
            )
            section_id = section["id"]
            self.step("create project and section", project_id=project_id, section_id=section_id)

            raw = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/raw-sources",
                    json={"path": str(write_source(self.run_root, "raw.txt", "original source")), "notes": "closed raw note"},
                ),
                201,
                "add raw source",
            )
            promote_candidate = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/candidates",
                    json={"path": str(write_source(self.run_root, "prime_candidate.txt", "candidate A")), "notes": "candidate for prime"},
                ),
                201,
                "add promotion candidate",
            )
            removable_candidate = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/candidates",
                    json={"path": str(write_source(self.run_root, "remove_restore.txt", "candidate B")), "notes": "remove restore candidate"},
                ),
                201,
                "add remove/restore candidate",
            )
            quarantine_candidate = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/candidates",
                    json={"path": str(write_source(self.run_root, "quarantine.txt", "candidate C")), "notes": "quarantine candidate"},
                ),
                201,
                "add quarantine candidate",
            )
            release_candidate = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/candidates",
                    json={"path": str(write_source(self.run_root, "release.txt", "candidate D")), "notes": "release candidate"},
                ),
                201,
                "add release candidate",
            )
            self.step(
                "add raw source and candidates",
                raw_id=raw["id"],
                candidate_count=4,
            )

            closed_body = self.expect_status(
                client.get(f"/api/v21/projects/{project_id}/sections/{section_id}/closed-catalog"),
                200,
                "read closed catalog",
            )
            assert_no_key(closed_body, CLOSED_VIEW_FORBIDDEN_KEYS, "closed catalog")
            closed_safe = True
            self.step("verify closed catalog is safe", view_mode=closed_body.get("view_mode"), item_count=closed_body.get("item_count"))

            session = self.expect_status(
                client.post(
                    "/api/v21/identity/sessions",
                    json={
                        "actor_id": "private-alpha-human",
                        "actor_kind": "human",
                        "device_id": "runner-device",
                        "verified_methods": ["human_ceremony", "typing_challenge"],
                        "role_claims": {"head_user": True},
                    },
                ),
                201,
                "issue human identity session",
            )
            session_id = session["session_id"]
            self.step("issue human identity session", actor_id=session.get("actor_id"), verified_methods=session.get("verified_methods"))

            opened = self.expect_status(client.post("/api/v21/vault/open"), 200, "open vault")
            if not opened.get("is_open"):
                self.fail("open vault", "Vault did not report open state.")
            self.step("open vault", strict_ceremony_tokens=opened.get("strict_ceremony_tokens"))

            def issue_token(action_key: str, object_id: str) -> str:
                response = client.post(
                    "/api/v21/ceremony/tokens",
                    json={
                        "action_key": action_key,
                        "session_id": session_id,
                        "project_id": project_id,
                        "section_id": section_id,
                        "object_id": object_id,
                        "ttl_seconds": 300,
                    },
                )
                body = self.expect_status(response, 201, f"issue ceremony token for {action_key}")
                token = body.get("ceremony_token")
                if not token:
                    self.fail(f"issue ceremony token for {action_key}", "Ceremony token response did not include one-time token.")
                self._raw_token_count += 1
                listed = self.expect_status(client.get("/api/v21/ceremony/tokens"), 200, "list ceremony tokens")
                assert_no_key(listed, {"ceremony_token"}, "ceremony token listing")
                self.step("issue scoped ceremony token", action_key=action_key, object_id=object_id, raw_secret_returned_once=True)
                return token

            def protected_payload(token: str, **extra: Any) -> Dict[str, Any]:
                body = {
                    "ceremony_token": token,
                    "actor_kind": "human",
                    "session_id": session_id,
                    "human_ceremony_passed": True,
                }
                body.update(extra)
                return body

            def capture_receipt(body: Dict[str, Any], expected_action: str, step_name: str) -> None:
                receipt = body.get("human_intent_receipt")
                if not receipt:
                    self.fail(step_name, "Protected action did not return a Human Intent Receipt.")
                if receipt.get("action_key") != expected_action:
                    self.fail(step_name, f"Receipt action mismatch: expected {expected_action}, got {receipt.get('action_key')}")
                assert_no_key(receipt, {"ceremony_token"}, "human intent receipt")
                receipt_ids.append(receipt["receipt_id"])
                verification = self.expect_status(client.get(f"/api/v21/blackbox/receipts/{receipt['receipt_id']}"), 200, f"verify receipt {expected_action}")
                if not verification.get("verification", {}).get("ok"):
                    self.fail(step_name, f"Receipt verification failed: {verification}")

            promote_token = issue_token("promote_candidate_to_prime", promote_candidate["id"])
            promoted = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/candidates/{promote_candidate['id']}/promote",
                    json=protected_payload(promote_token, reason="best accepted so far"),
                ),
                200,
                "promote candidate to prime",
            )
            capture_receipt(promoted, "promote_candidate_to_prime", "promote candidate to prime")
            self.step("promote candidate to Prime", object_id=promote_candidate["id"], state=promoted.get("result", {}).get("state"))

            export_dir = self.run_root / "external_workbench"
            export_token = issue_token("export_working_copy", promote_candidate["id"])
            exported = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/files/{promote_candidate['id']}/export-working-copy",
                    json=protected_payload(export_token, output_dir=str(export_dir)),
                ),
                200,
                "export working copy",
            )
            capture_receipt(exported, "export_working_copy", "export working copy")
            output_path = Path(exported.get("result", {}).get("output_path", ""))
            if not output_path.exists():
                self.fail("export working copy", "Export output path does not exist.", output_path=str(output_path))
            self.step("export working copy outside Vault", output_path=str(output_path))

            remove_token = issue_token("remove_from_active", removable_candidate["id"])
            removed = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/files/{removable_candidate['id']}/remove",
                    json=protected_payload(remove_token),
                ),
                200,
                "remove from active use",
            )
            capture_receipt(removed, "remove_from_active", "remove from active use")
            restore_token = issue_token("restore_to_active", removable_candidate["id"])
            restored = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/files/{removable_candidate['id']}/restore",
                    json=protected_payload(restore_token),
                ),
                200,
                "restore to active use",
            )
            capture_receipt(restored, "restore_to_active", "restore to active use")
            self.step("remove then restore without deletion", object_id=removable_candidate["id"], final_state=restored.get("result", {}).get("state"))

            quarantine_token = issue_token("quarantine", quarantine_candidate["id"])
            quarantined = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/files/{quarantine_candidate['id']}/quarantine",
                    json=protected_payload(quarantine_token),
                ),
                200,
                "quarantine candidate",
            )
            capture_receipt(quarantined, "quarantine", "quarantine candidate")
            self.step("quarantine without deletion", object_id=quarantine_candidate["id"], state=quarantined.get("result", {}).get("state"))

            release_token = issue_token("release_from_custody", release_candidate["id"])
            released = self.expect_status(
                client.post(
                    f"/api/v21/projects/{project_id}/sections/{section_id}/files/{release_candidate['id']}/release",
                    json=protected_payload(release_token, confirmation="RELEASE"),
                ),
                200,
                "release from custody",
            )
            capture_receipt(released, "release_from_custody", "release from custody")
            self.step("release from custody by explicit ceremony", object_id=release_candidate["id"], state=released.get("result", {}).get("state"))

            receipts = self.expect_status(client.get("/api/v21/blackbox/receipts"), 200, "list human intent receipts")
            if len(receipts.get("receipts", [])) < 6:
                self.fail("list human intent receipts", "Expected at least six receipts.")
            self.step("verify Human Intent Receipts", receipt_count=len(receipts.get("receipts", [])), receipt_ids=receipt_ids)

            chain = self.expect_status(client.get("/api/v21/blackbox/chain"), 200, "verify BlackBox chain")
            chain_ok = bool(chain.get("ok"))
            if not chain_ok:
                self.fail("verify BlackBox chain", "BlackBox chain verification failed.", chain=chain)
            custody = self.expect_status(client.get("/api/v21/custody/verify"), 200, "verify custody integrity")
            custody_ok = bool(custody.get("ok"))
            if not custody_ok:
                self.fail("verify custody integrity", "Custody integrity verification failed.", custody=custody)
            self.step("verify BlackBox chain and custody integrity", blackbox_chain_ok=chain_ok, custody_integrity_ok=custody_ok)

            locked = self.expect_status(client.post("/api/v21/vault/lock"), 200, "lock vault")
            if locked.get("is_open") is not False:
                self.fail("lock vault", "Vault did not report closed state.")
            closed_again = self.expect_status(
                client.get(f"/api/v21/projects/{project_id}/sections/{section_id}"),
                200,
                "verify closed view after lock",
            )
            assert_no_key(closed_again, CLOSED_VIEW_FORBIDDEN_KEYS, "closed section view after lock")
            self.step("lock Vault and verify closed catalog again", view_mode=closed_again.get("view_mode"))

            status = self.expect_status(client.get("/api/v21/private-alpha/status"), 200, "read private-alpha status")
            assert_no_key(status, {"ceremony_token"}, "private-alpha status")
            if not status.get("ready_for_private_alpha_flow"):
                self.fail("read private-alpha status", "Private-alpha readiness endpoint did not report ready.", status=status)
            self.step("read private-alpha readiness status", ready=True, receipt_count=status.get("receipt_count"))

        finally:
            server.blackbox21, server.vault21, server.human_access = old_blackbox, old_vault, old_human

        completed_at = utc_now()
        report = PrivateAlphaFlowReport(
            ok=all(step.ok for step in self.steps) and chain_ok and custody_ok and closed_safe,
            started_at=started_at,
            completed_at=completed_at,
            run_root=str(self.run_root),
            report_dir=str(self.report_dir),
            version="2.2.4",
            steps=self.steps,
            project_id=project_id,
            section_id=section_id,
            receipt_ids=receipt_ids,
            blackbox_chain_ok=chain_ok,
            custody_integrity_ok=custody_ok,
            closed_catalog_safe=closed_safe,
            status=status,
        )
        if write_reports:
            self.write_reports(report)
        return report

    def write_reports(self, report: PrivateAlphaFlowReport) -> None:
        json_path = self.report_dir / "private_alpha_flow_report.json"
        md_path = self.report_dir / "private_alpha_flow_report.md"
        json_path.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        md_path.write_text(render_markdown_report(report), encoding="utf-8")
        report.json_report_path = str(json_path)
        report.markdown_report_path = str(md_path)
        # Re-write JSON with paths populated.
        json_path.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")


def render_markdown_report(report: PrivateAlphaFlowReport) -> str:
    lines = [
        "# Iteration Wallet Private Alpha Flow Report",
        "",
        f"**Result:** {'PASS' if report.ok else 'FAIL'}",
        f"**Version:** {report.version}",
        f"**Started:** {report.started_at}",
        f"**Completed:** {report.completed_at}",
        f"**Run root:** `{report.run_root}`",
        "",
        "## Summary",
        "",
        f"- Closed catalog safe: `{report.closed_catalog_safe}`",
        f"- BlackBox chain OK: `{report.blackbox_chain_ok}`",
        f"- Custody integrity OK: `{report.custody_integrity_ok}`",
        f"- Human Intent Receipts: `{len(report.receipt_ids)}`",
        "",
        "## Steps",
        "",
    ]
    for index, step in enumerate(report.steps, 1):
        marker = "PASS" if step.ok else "FAIL"
        lines.append(f"{index}. **{marker} — {step.name}**")
        if step.detail:
            lines.append(f"   - {step.detail}")
        if step.evidence:
            safe_evidence = scrub_report_value(step.evidence)
            lines.append(f"   - Evidence: `{json.dumps(safe_evidence, ensure_ascii=False, sort_keys=True)}`")
    lines.extend(
        [
            "",
            "## Product Guardrails Verified",
            "",
            "- No protected contents are exposed through closed catalog surfaces.",
            "- Protected actions require human identity session and scoped ceremony token.",
            "- Protected actions produce Human Intent Receipts.",
            "- BlackBox chain verification passes after the flow.",
            "- Custody integrity verification passes after the flow.",
            "- Raw ceremony-token secrets are not written into this report.",
            "",
        ]
    )
    return "\n".join(lines)


def run_private_alpha_flow(run_root: Path, report_dir: Optional[Path] = None, *, write_reports: bool = True) -> PrivateAlphaFlowReport:
    runner = PrivateAlphaFlowRunner(run_root=run_root, report_dir=report_dir)
    return runner.run(write_reports=write_reports)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Run the Iteration Wallet private-alpha flow and produce a human-readable report.")
    parser.add_argument("--run-root", type=Path, default=None, help="Directory to use for the isolated private-alpha run.")
    parser.add_argument("--report-dir", type=Path, default=None, help="Directory where JSON/Markdown reports will be written.")
    parser.add_argument("--json", action="store_true", help="Print the structured report JSON to stdout.")
    args = parser.parse_args(argv)

    if args.run_root is None:
        # Use a persistent temp directory, not TemporaryDirectory, because this
        # command's main purpose is to leave a report behind for a human or
        # unfamiliar builder bot to inspect after the process exits.
        temp_dir = Path(tempfile.mkdtemp(prefix="iw_private_alpha_"))
        report = run_private_alpha_flow(temp_dir, args.report_dir or temp_dir / "report", write_reports=True)
        if args.json:
            print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))
        else:
            print(f"Private alpha flow {'PASS' if report.ok else 'FAIL'}")
            print(f"Run root: {report.run_root}")
            print(f"Report: {report.markdown_report_path}")
        return 0 if report.ok else 1

    report = run_private_alpha_flow(args.run_root, args.report_dir, write_reports=True)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))
    else:
        print(f"Private alpha flow {'PASS' if report.ok else 'FAIL'}")
        print(f"Report: {report.markdown_report_path}")
    return 0 if report.ok else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
