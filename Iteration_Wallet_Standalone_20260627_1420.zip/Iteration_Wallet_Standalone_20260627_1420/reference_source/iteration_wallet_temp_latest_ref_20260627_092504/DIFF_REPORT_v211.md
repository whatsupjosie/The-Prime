# Iteration Wallet v2.2.2 — Ceremony Token Lifecycle Hardening

## Purpose

v2.2.2 hardens the ceremony token layer that sits between a verified human session and protected custody actions.

Before this patch, protected HTTP routes required a human identity session, but the custody token itself was still a loose Vault-open token. That was useful for early alpha work, but too reusable and too broad for the Human Intent model.

This patch adds scoped ceremony tokens that are:

- action-bound
- session-bound
- object/context-bound where supplied
- short-lived
- single-use
- revoked on Vault lock
- stored only as hashes, never as raw token secrets
- recorded in BlackBox when issued, consumed, denied, or revoked

## Files Added

- `iteration_wallet/ceremony.py`
- `tests/test_ceremony_tokens_v222.py`
- `BUILD_REPORT_v222.md`
- `README_v222.md`
- `DIFF_REPORT_v222.patch`

## Files Changed

- `iteration_wallet/vault_v21.py`
- `iteration_wallet/server.py`
- `iteration_wallet/__init__.py`
- `setup.py`

## What Changed

### 1. New CeremonyTokenLedger

Added `CeremonyTokenLedger` in `iteration_wallet/ceremony.py`.

It issues action-scoped ceremony tokens in the format:

```text
iwct_<token_id>_<secret>
```

Only the token hash is stored in `ceremony_tokens/<token_id>.json`. The raw secret is returned once and never persisted.

### 2. Strict Ceremony Mode

`VaultEngine` now supports:

```python
VaultEngine(root, blackbox=blackbox, strict_ceremony_tokens=True)
```

The FastAPI v2.1 server uses strict mode. Older direct engine tests keep backward-compatible behavior unless they opt into strict mode.

### 3. Action-Bound Tokens

Tokens are issued for a single `action_key`, such as:

- `remove_from_active`
- `restore_to_active`
- `release_from_custody`
- `quarantine`
- `promote_candidate_to_prime`
- `export_working_copy`

A token issued for one action cannot be used for another.

### 4. Session-Bound Tokens

Tokens are bound to an identity session. A token issued for one session cannot be consumed by another session.

### 5. Object/Context-Bound Tokens

Tokens may be bound to:

- project ID
- section ID
- object/file/candidate ID

If those are supplied, mismatches fail closed.

### 6. Single-Use Consumption

Protected actions consume the token. Reusing the token fails.

### 7. Expiry and Revocation

Tokens expire after a short TTL, defaulting to 300 seconds and capped to a max of 900 seconds.

Locking the Vault revokes unconsumed tokens associated with the current open session.

### 8. API Surface

Added:

```text
POST /api/v21/ceremony/tokens
GET  /api/v21/ceremony/tokens
POST /api/v21/ceremony/tokens/revoke
```

Protected routes now require a scoped token in strict server mode.

### 9. BlackBox Evidence

BlackBox records:

- `CEREMONY_TOKEN_ISSUED`
- `CEREMONY_TOKEN_CONSUMED`
- `CEREMONY_TOKEN_DENIED`
- `CEREMONY_TOKEN_REVOKED`
- `CEREMONY_TOKENS_REVOKED`

## Verification

Clean command run:

```bash
python -m compileall -q iteration_wallet
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
```

Result:

```text
98 passed in 7.15s
```

## Limits Still Present

- This is still a local alpha identity/session layer, not OAuth/passkey/biometric auth.
- The raw ceremony token is shown once at issue time; secure UI handling is still future work.
- The v2.1 direct engine keeps backward-compatible legacy open-token behavior unless strict mode is enabled.
- Full camera/liveness challenge providers are not implemented yet.

## Product Result

This patch makes protected HTTP custody actions meaningfully harder to misuse. A verified human session alone is not enough; the action also needs a short-lived scoped ceremony token that matches the action, session, and object.
