import tempfile
from pathlib import Path

import pytest

from iteration_wallet.vault_v21 import VaultEngine, NO_DELETE_RULE


def make_file(text='data', suffix='.txt'):
    f = tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False)
    f.write(text)
    f.flush()
    f.close()
    return Path(f.name)


def setup_vault(tmpdir):
    vault = VaultEngine(Path(tmpdir))
    project = vault.create_project('App')
    section = vault.create_section(project['id'], 'Core')
    return vault, project, section


def test_no_delete_rule_constant_is_primary_product_law():
    assert 'never deletes' in NO_DELETE_RULE
    assert 'user-custodied material' in NO_DELETE_RULE


def test_no_delete_method_exists_and_candidate_copy_is_preserved():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('candidate')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            vault_copy = Path(cand['vault_path'])
            assert not hasattr(vault, 'delete_file')
            assert vault_copy.exists()
            assert cand['state'] == 'candidate'
        finally:
            src.unlink(missing_ok=True)


def test_remove_still_preserves_removed_copy_and_no_delete_surface():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('candidate')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            token = vault.open_vault()['ceremony_token']
            vault.remove_file(project['id'], section['id'], cand['id'], token)
            removed_copy = Path(cand['vault_path'])
            assert cand['state'] == 'staging'
            assert not hasattr(vault, 'delete_file')
            assert removed_copy.exists()
        finally:
            src.unlink(missing_ok=True)


def test_quarantine_is_isolation_not_deletion():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('suspicious')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            token = vault.open_vault()['ceremony_token']
            result = vault.quarantine_file(project['id'], section['id'], cand['id'], token, reason='suspicious output')
            assert result['state'] == 'quarantined'
            assert result['quarantined'] is True
            assert Path(result['vault_path']).exists()
            with pytest.raises(Exception, match='Cannot export'):
                vault.export_working_copy(project['id'], section['id'], cand['id'], tmpdir)
            view = vault.get_section_view(project['id'], section['id'])
            assert [f['id'] for f in view['quarantine']] == [cand['id']]
        finally:
            src.unlink(missing_ok=True)


def test_live_person_release_changes_custody_state_without_destroying_file():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file('release me')
        try:
            cand = vault.add_candidate(project['id'], section['id'], str(src))
            token = vault.open_vault()['ceremony_token']
            with pytest.raises(Exception, match='type RELEASE'):
                vault.release_from_custody(project['id'], section['id'], cand['id'], token, human_confirmation='yes')
            result = vault.release_from_custody(project['id'], section['id'], cand['id'], token, human_confirmation='RELEASE')
            assert result['state'] == 'released'
            assert result['released'] is True
            assert Path(result['vault_path']).exists()
            view = vault.get_section_view(project['id'], section['id'])
            assert [f['id'] for f in view['released']] == [cand['id']]
        finally:
            src.unlink(missing_ok=True)
