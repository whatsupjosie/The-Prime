# Iteration Wallet — Installation & Quick Start

## Install

```bash
# Clone or download
cd iteration_wallet_v2

# Install dependencies
pip install -r requirements.txt

# Optional: install as a command-line tool
pip install -e .
```

## Quick Start

### Option 1: Web UI (recommended for first-time)

```bash
python app.py
```

Opens http://localhost:7432 automatically. Your browser becomes the vault interface.

### Option 2: CLI (for scripting/automation)

```bash
# Start the server in the background
iw serve &

# Create a project
iw create-project "My AI Models"

# Add a file to protect it
iw add /path/to/model.pth --project <ID>

# Open vault (requires typing OPEN)
iw open

# List everything
iw ls

# Lock vault when done
iw lock
```

## First-Time Setup

1. **Start the server:** `python app.py`
2. **Click "NEW CRADLE"** to create your first project
3. **Add files** by pointing to their paths
4. **Type OPEN** to unlock the vault (must be intentional — typing required)
5. **REMOVE** moves files to holding (reversible)
6. **RELEASE** is a live-person custody transfer; Iteration Wallet never destroys user-custodied files

## Install Git Hook (Optional)

Automatically snapshots your project before each commit:

```bash
cd /path/to/your/git/repo
iw install-hook
```

Pre-commit checks will now run before each commit.

## Vault Location

All files are stored in: `~/.iteration_wallet/`

```
~/.iteration_wallet/
├── state.json
└── projects/
    └── {project_id}/
        ├── vault/
        │   ├── cradle/V1/canonical/    ← protected files
        │   └── archive/V1/              ← old versions
        ├── removed_files/               ← staging area
        └── metadata/
```

## API (for developers)

The server exposes a full REST API at http://localhost:7432/api/

Docs: http://localhost:7432/docs (interactive Swagger UI)

```bash
# Example: create a project
curl -X POST http://localhost:7432/api/projects \
  -H "Content-Type: application/json" \
  -d '{"name": "My Project"}'

# Open vault
curl -X POST http://localhost:7432/api/vault/open

# Get all projects
curl http://localhost:7432/api/projects
```

## Troubleshooting

**"Cannot connect to vault server"**
- Make sure the server is running: `iw serve`

**"Vault is locked"**
- Type `OPEN` in the UI or run `iw open`

**"File not found"**
- Check the full path exists and you have read permissions

**Port already in use (7432)**
- Use a different port: `iw serve --port 8080`

## License

Proprietary commercial software.
Contact: josie@pubcast.ai

