"""Static product-law checks for the standalone Iteration Wallet package.

These checks are intentionally read-only. They do not execute wallet flows,
custodied files, shell commands, or cleanup code.
"""

from pathlib import Path
import unittest


WORKSPACE = Path(__file__).resolve().parents[1]
PACKAGE = WORKSPACE / "iteration_wallet"


class TestProductLawStaticSurface(unittest.TestCase):
    def test_required_product_artifacts_exist(self):
        required = [
            WORKSPACE / "PRODUCT_LAWS.md",
            WORKSPACE / "README.md",
            WORKSPACE / "BLOCKERS.md",
            WORKSPACE / "CHANGELOG.md",
            WORKSPACE / "HANDOFF.md",
            PACKAGE / "__init__.py",
        ]
        missing = [str(path) for path in required if not path.exists()]
        self.assertEqual(missing, [])

    def test_active_package_has_no_direct_destructive_delete_markers(self):
        forbidden = [
            "." + "unlink" + "(",
            "DELETE" + " FROM vault_files",
            "permanently " + "destroy",
            "permanently " + "deleted",
            "No recovery possible",
            "os" + ".system",
            "eval" + "(",
            "exec" + "(",
        ]
        offenders = []
        for path in sorted(PACKAGE.glob("*.py")):
            text = path.read_text(encoding="utf-8", errors="replace")
            for marker in forbidden:
                if marker in text:
                    offenders.append(f"{path.name}: {marker}")
        self.assertEqual(offenders, [])

    def test_misclassified_reference_files_are_not_active_modules(self):
        self.assertFalse((PACKAGE / "private_alpha_flow_runner.py").exists())
        self.assertTrue((WORKSPACE / "docs" / "ceremony_surface_reference.html").exists())
        self.assertTrue((WORKSPACE / "rubish" / "misplaced_package_tests").exists())
        self.assertTrue((WORKSPACE / "rubish" / "misnamed_commit_guard").exists())


if __name__ == "__main__":
    unittest.main()

