# Iteration Wallet Product Laws

These laws are product constraints, not preferences.

1. **No Delete** - Iteration Wallet never deletes custodied user material. Use remove-from-active-use, quarantine, restore, or human-reviewed release instead.
2. **No Silent Overwrite** - Prime, Cradle, Vault, BlackBox, Oubliette, receipts, and custody records are never silently overwritten.
3. **No Execute Inside Vault** - Iteration Wallet does not run, execute, test, launch, or otherwise activate custodied files or code.
4. **Oubliette Is Not A Test Runner** - Oubliette inspects, labels, warns, quarantines, and records. It does not execute.
5. **AI Stays Outside The Yard** - AI may advise from approved summaries. AI cannot open gates, touch custody, promote Prime, release custody, import results, execute code, or operate Oubliette.
6. **Humans Open Gates** - Protected custody decisions require verified human intent.
7. **Engines Do Deterministic Work** - Custody behavior must be deterministic, auditable, and inspectable.
8. **BlackBox Records Everything Important** - Custody events, approvals, denials, incidents, integrity checks, receipts, quarantines, and gate crossings are recorded.
9. **Dangerous Files Can Exist Safely** - Dangerous files are labeled, fenced, warned about, and quarantined. They are not executed and not deleted.
10. **Closed Catalog Is Safe** - Closed views expose safe metadata only. They never expose protected paths, hashes, notes, previews, raw tokens, secrets, private memory, or protected contents.

## Work Standard

This is product work, not practice work.

All changes must be non-destructive, auditable, and backed by artifacts. Claims are not artifacts. No task is complete unless the code/docs exist in the target workspace and proof is recorded.

