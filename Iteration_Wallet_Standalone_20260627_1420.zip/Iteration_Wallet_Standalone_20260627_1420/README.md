# Iteration Wallet Standalone Work Folder

Created: 2026-06-27

This folder is the clean standalone Iteration Wallet product work area.

It was created non-destructively from copied reference material. The original reference intake was not modified.

## Source Inputs

Primary reference copy:

`reference_source\iteration_wallet_temp_latest_ref_20260627_092504`

Additional BlackBox source:

`iteration_wallet\blackbox.py` was copied from the v2.1.9 BlackBox/Vault coupling reference because the latest Temp reference set did not include a standalone `blackbox.py`.

## Current Layout

- `iteration_wallet\` - normalized package source copied from references
- `tests\` - copied development proof files from references
- `docs\` - local documentation
- `handoffs\` - local pass handoffs
- `reference_source\` - copied raw reference material
- `rubish\` - local quarantine/review area; do not delete from here
- `PRODUCT_LAWS.md` - non-negotiable product laws
- `BLOCKERS.md` - known blockers and proof limitations
- `HANDOFF.md` - current local handoff summary

## Safety Rules

- Do not delete files.
- Do not execute custodied user code.
- Do not treat Oubliette as a runner.
- Do not let AI operate inside the custody yard.
- Do not silently overwrite product records.
- Classify external code before using it.
- Record proof before claiming completion.

## Immediate Next Work

1. Scan the normalized package for product-facing delete/execute/run paths.
2. Separate wording-only issues from active product behavior.
3. Patch safe, bounded product-law violations.
4. Keep all changes documented in `HANDOFF.md` and `BLOCKERS.md`.

