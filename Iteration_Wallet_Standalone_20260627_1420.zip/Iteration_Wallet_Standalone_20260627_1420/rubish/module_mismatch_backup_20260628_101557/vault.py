"""
Iteration Wallet v2.1.9 — Human Access, Notification, Approval, and BlackBox Request Control
================================================================================================

This module implements the human-intent notification/request layer for Iteration Wallet. BlackBox evidence storage now lives in iteration_wallet.blackbox.

Product laws implemented here:
- AI/bots/tools may REQUEST protected custody access, but may not directly fetch/open/alter custody.
- Humans / Head Users approve or deny through a logged request flow.
- User-facing alerts are capped: max 5 unread messages per recipient, max 150 characters each.
- System-wide alert burst/storage is capped at 200 notifications.
- BlackBox keeps the full detailed evidence trail even when notifications are capped.
- Repeated bot/agent request pressure is classified at 20/50/100/1000 as unusual/suspicious/intrusion/flood.
- Excessive requests are treated as possible intrusion evidence, not mere noise.

This is intentionally storage-light and local-first: JSON event records on disk,
append-ish BlackBox files, and no network/email provider dependency inside core logic.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from iteration_wallet.identity import ActorIdentity, IdentityError, LocalIdentityProvider
from iteration_wallet.blackbox import BlackBox


class NotificationLevel(Enum):
    """Alert severity levels."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    INTRUSION = "intrusion"


class RequestClassification(Enum):
    """BlackBox interpretation of request pressure."""

    NORMAL = "normal"
    UNUSUAL_PRESSURE = "unusual_access_pressure"          # >= 20
    SUSPICIOUS_PATTERN = "suspicious_access_pattern"      # >= 50
    PROBABLE_INTRUSION = "probable_intrusion_attempt"     # >= 100
    ACTIVE_FLOOD = "active_flood_hostile_access_event"    # >= 1000


class RequestStatus(Enum):
    """Lifecycle state for protected access requests."""

    LOGGED = "logged"
    NOTIFIED = "notified"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    DENIED = "denied"
    EXPIRED = "expired"
    FROZEN = "frozen_pending_head_user_review"
    EMERGENCY_LOCKOUT = "emergency_lockout_abuse_incident"


class ActorKind(Enum):
    """Actor type. Protected custody actions require a human ceremony."""

    HUMAN = "human"
    AI_ASSISTANT = "ai_assistant"
    BOT = "bot"
    TOOL = "tool"
    SCRIPT = "script"
    UNKNOWN = "unknown"


class NotificationError(Exception):
    """Raised for expected NotificationManager failures."""


@dataclass
class Notification:
    """A single short alert message to a recipient."""

    recipient_id: str
    message: str
    level: NotificationLevel
    action_url: Optional[str] = None
    notification_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    created_at: datetime = field(default_factory=datetime.now)
    read_at: Optional[datetime] = None
    action_taken: Optional[str] = None
    blackbox_event_id: Optional[str] = None

    def __post_init__(self) -> None:
        if len(self.message) > NotificationManager.DEFAULT_LIMITS["per_recipient_char_limit"]:
            raise NotificationError("Message must be 150 characters or less.")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "notification_id": self.notification_id,
            "recipient_id": self.recipient_id,
            "message": self.message,
            "level": self.level.value,
            "action_url": self.action_url,
            "created_at": self.created_at.isoformat(),
            "read_at": self.read_at.isoformat() if self.read_at else None,
            "action_taken": self.action_taken,
            "blackbox_event_id": self.blackbox_event_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Notification":
        n = cls(
            recipient_id=data["recipient_id"],
            message=data["message"],
            level=NotificationLevel(data["level"]),
            action_url=data.get("action_url"),
            notification_id=data.get("notification_id", uuid.uuid4().hex[:16]),
            created_at=datetime.fromisoformat(data["created_at"]),
            read_at=datetime.fromisoformat(data["read_at"]) if data.get("read_at") else None,
            action_taken=data.get("action_taken"),
            blackbox_event_id=data.get("blackbox_event_id"),
        )
        return n


@dataclass
class ApprovalRequest:
    """Request for Head User / authorized person approval."""

    vault_id: str
    object_id: str
    action: str
    requester_id: str
    claimed_purpose: str
    head_user_id: str
    approval_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    status: RequestStatus = RequestStatus.PENDING_APPROVAL
    decision_at: Optional[datetime] = None
    decision_by: Optional[str] = None
    decision_reason: Optional[str] = None
    request_id: Optional[str] = None

    def __post_init__(self) -> None:
        if self.expires_at is None:
            self.expires_at = self.created_at + timedelta(hours=24)

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        return (now or datetime.now()) > self.expires_at

    def to_dict(self) -> Dict[str, Any]:
        return {
            "approval_id": self.approval_id,
            "vault_id": self.vault_id,
            "object_id": self.object_id,
            "action": self.action,
            "requester_id": self.requester_id,
            "claimed_purpose": self.claimed_purpose,
            "head_user_id": self.head_user_id,
            "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "status": self.status.value,
            "decision_at": self.decision_at.isoformat() if self.decision_at else None,
            "decision_by": self.decision_by,
            "decision_reason": self.decision_reason,
            "request_id": self.request_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApprovalRequest":
        return cls(
            vault_id=data["vault_id"],
            object_id=data["object_id"],
            action=data["action"],
            requester_id=data["requester_id"],
            claimed_purpose=data["claimed_purpose"],
            head_user_id=data["head_user_id"],
            approval_id=data.get("approval_id", uuid.uuid4().hex[:16]),
            created_at=datetime.fromisoformat(data["created_at"]),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            status=RequestStatus(data.get("status", RequestStatus.PENDING_APPROVAL.value)),
            decision_at=datetime.fromisoformat(data["decision_at"]) if data.get("decision_at") else None,
            decision_by=data.get("decision_by"),
            decision_reason=data.get("decision_reason"),
            request_id=data.get("request_id"),
        )


@dataclass
class AccessRequest:
    """A protected custody access request filed by a human/bot/tool/agent."""

    vault_id: str
    object_id: str
    action: str
    requester_id: str
    claimed_purpose: str
    requester_kind: ActorKind = ActorKind.UNKNOWN
    section_id: Optional[str] = None
    tool_family: Optional[str] = None
    recipients: List[str] = field(default_factory=list)
    head_user_id: Optional[str] = None
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    created_at: datetime = field(default_factory=datetime.now)
    status: RequestStatus = RequestStatus.LOGGED
    classification: RequestClassification = RequestClassification.NORMAL
    matching_request_count: int = 1
    notification_ids: List[str] = field(default_factory=list)
    approval_id: Optional[str] = None
    system_action: str = "logged_only"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "vault_id": self.vault_id,
            "section_id": self.section_id,
            "object_id": self.object_id,
            "action": self.action,
            "requester_id": self.requester_id,
            "requester_kind": self.requester_kind.value,
            "tool_family": self.tool_family,
            "claimed_purpose": self.claimed_purpose,
            "recipients": self.recipients,
            "head_user_id": self.head_user_id,
            "created_at": self.created_at.isoformat(),
            "status": self.status.value,
            "classification": self.classification.value,
            "matching_request_count": self.matching_request_count,
            "notification_ids": self.notification_ids,
            "approval_id": self.approval_id,
            "system_action": self.system_action,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AccessRequest":
        return cls(
            vault_id=data["vault_id"],
            section_id=data.get("section_id"),
            object_id=data["object_id"],
            action=data["action"],
            requester_id=data["requester_id"],
            requester_kind=ActorKind(data.get("requester_kind", ActorKind.UNKNOWN.value)),
            tool_family=data.get("tool_family"),
            claimed_purpose=data.get("claimed_purpose", ""),
            recipients=list(data.get("recipients", [])),
            head_user_id=data.get("head_user_id"),
            request_id=data.get("request_id", uuid.uuid4().hex[:16]),
            created_at=datetime.fromisoformat(data["created_at"]),
            status=RequestStatus(data.get("status", RequestStatus.LOGGED.value)),
            classification=RequestClassification(data.get("classification", RequestClassification.NORMAL.value)),
            matching_request_count=int(data.get("matching_request_count", 1)),
            notification_ids=list(data.get("notification_ids", [])),
            approval_id=data.get("approval_id"),
            system_action=data.get("system_action", "logged_only"),
        )


class NotificationManager:
    """Manages alerts, Head User approval, BlackBox request evidence, and anti-overload limits."""

    DEFAULT_LIMITS: Dict[str, int] = {
        "per_recipient_max": 5,
        "per_recipient_char_limit": 150,
        "total_system_max": 200,
        "warning_threshold": 20,
        "suspicious_threshold": 50,
        "intrusion_threshold": 100,
        "flood_threshold": 1000,
        "request_window_minutes": 60,
    }

    BOT_KINDS = {ActorKind.AI_ASSISTANT, ActorKind.BOT, ActorKind.TOOL, ActorKind.SCRIPT, ActorKind.UNKNOWN}

    def __init__(self, vault_root: Path, blackbox: Optional[BlackBox] = None):
        self.vault_root = Path(vault_root)
        self.notification_dir = self.vault_root / "notifications"
        self.approval_dir = self.vault_root / "approvals"
        self.blackbox = blackbox or BlackBox(self.vault_root)
        self.blackbox_dir = self.blackbox.blackbox_dir
        self.request_dir = self.blackbox.request_dir
        self.event_dir = self.blackbox.event_dir
        self.incident_dir = self.blackbox.incident_dir
        self.role_file = self.vault_root / "roles.json"
        self.chain_file = self.blackbox.chain_file
        self.identity = LocalIdentityProvider(self.vault_root)
        for d in (self.notification_dir, self.approval_dir, self.request_dir, self.event_dir, self.incident_dir):
            d.mkdir(parents=True, exist_ok=True)
        self._limits = self._load_limits()
        self._notification_cache: Optional[List[Notification]] = None

    # ─── basic helpers ──────────────────────────────────────────────────

    def _load_limits(self) -> Dict[str, int]:
        config_file = self.vault_root / "notification_limits.json"
        limits = dict(self.DEFAULT_LIMITS)
        if config_file.exists():
            try:
                configured = json.loads(config_file.read_text(encoding="utf-8"))
                for key, value in configured.items():
                    if key in limits:
                        limits[key] = int(value)
            except Exception:
                # Bad config must not loosen product rules; keep defaults.
                pass
        return limits

    @staticmethod
    def _now() -> datetime:
        return datetime.now()

    @staticmethod
    def _shorten(text: str, limit: int = 150) -> str:
        text = " ".join(str(text).split())
        if len(text) <= limit:
            return text
        return text[: max(0, limit - 1)].rstrip() + "…"

    @staticmethod
    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    def _canonical_json(self, data: Dict[str, Any]) -> str:
        return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def _current_chain_state(self) -> tuple[str, int]:
        return self.blackbox._current_chain_state()

    def _current_chain_head(self) -> str:
        return self.blackbox.current_chain_head()

    def _blackbox_event(self, event_type: str, summary: str, **extra: Any) -> Dict[str, Any]:
        """Compatibility wrapper around the standalone BlackBox module."""
        return self.blackbox.write_event(event_type, summary, **extra)

    def verify_blackbox_chain(self) -> Dict[str, Any]:
        """Verify the shared local BlackBox hash chain."""
        return self.blackbox.verify_chain()

    # ─── local identity / session interface ───────────────────────────────

    def issue_identity_session(
        self,
        actor_id: str,
        actor_kind: ActorKind | str,
        *,
        device_id: Optional[str] = None,
        verified_methods: Optional[Sequence[str]] = None,
        role_claims: Optional[Dict[str, Any]] = None,
        ttl_minutes: int = 480,
        session_id: Optional[str] = None,
    ) -> ActorIdentity:
        kind = actor_kind.value if isinstance(actor_kind, ActorKind) else str(actor_kind)
        identity = self.identity.issue_session(
            actor_id=actor_id,
            actor_kind=kind,
            device_id=device_id,
            verified_methods=verified_methods,
            role_claims=role_claims,
            ttl_minutes=ttl_minutes,
            session_id=session_id,
        )
        self._blackbox_event(
            "IDENTITY_SESSION_ISSUED",
            f"Identity session issued for {actor_id} as {kind}",
            identity={k: v for k, v in identity.to_dict().items() if k != "session_id"},
            session_id=identity.session_id,
        )
        return identity

    def get_identity_session(self, session_id: str) -> Optional[ActorIdentity]:
        return self.identity.get_session(session_id)

    def require_identity_session(self, session_id: str) -> ActorIdentity:
        try:
            return self.identity.require_session(session_id)
        except IdentityError as e:
            self._blackbox_event(
                "IDENTITY_SESSION_INVALID",
                "Invalid identity session rejected",
                session_id=session_id,
                reason=str(e),
            )
            raise

    def revoke_identity_session(self, session_id: str, reason: Optional[str] = None) -> Optional[ActorIdentity]:
        identity = self.identity.revoke_session(session_id, reason)
        if identity:
            self._blackbox_event(
                "IDENTITY_SESSION_REVOKED",
                f"Identity session revoked for {identity.actor_id}",
                session_id=session_id,
                reason=reason,
            )
        return identity

    # ─── role / authority management ───────────────────────────────────────

    def _load_roles(self) -> Dict[str, Any]:
        if not self.role_file.exists():
            return {"vaults": {}}
        try:
            data = json.loads(self.role_file.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return {"vaults": {}}
            data.setdefault("vaults", {})
            return data
        except Exception:
            return {"vaults": {}}

    def configure_vault_roles(
        self,
        vault_id: str,
        head_user_id: str,
        admins: Optional[Sequence[str]] = None,
        authorized_users: Optional[Sequence[str]] = None,
        authorized_agents: Optional[Sequence[str]] = None,
        allowed_fallbacks: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        roles = self._load_roles()
        vault = {
            "vault_id": vault_id,
            "head_user_id": head_user_id,
            "admins": list(dict.fromkeys(admins or [])),
            "authorized_users": list(dict.fromkeys(authorized_users or [])),
            "authorized_agents": list(dict.fromkeys(authorized_agents or [])),
            "allowed_fallbacks": list(dict.fromkeys(allowed_fallbacks or [])),
            "updated_at": self._now().isoformat(),
        }
        roles.setdefault("vaults", {})[vault_id] = vault
        self._write_json_atomic(self.role_file, roles)
        self._blackbox_event("VAULT_ROLES_CONFIGURED", f"Roles configured for vault {vault_id}", vault_roles=vault)
        return vault

    def get_vault_roles(self, vault_id: str) -> Dict[str, Any]:
        return self._load_roles().get("vaults", {}).get(vault_id, {})

    def is_head_user_or_admin(self, vault_id: str, user_id: str, fallback_head_user_id: Optional[str] = None) -> bool:
        roles = self.get_vault_roles(vault_id)
        head = roles.get("head_user_id") or fallback_head_user_id
        admins = set(roles.get("admins") or [])
        return bool(user_id and (user_id == head or user_id in admins))

    # ─── notification management ────────────────────────────────────────

    def _save_notification(self, notification: Notification) -> None:
        self._write_json_atomic(self.notification_dir / f"{notification.notification_id}.json", notification.to_dict())
        if self._notification_cache is not None:
            self._notification_cache = [
                n for n in self._notification_cache if n.notification_id != notification.notification_id
            ]
            self._notification_cache.append(notification)
            self._notification_cache.sort(key=lambda n: n.created_at)

    def _load_notification_file(self, path: Path) -> Optional[Notification]:
        try:
            return Notification.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def _get_all_notifications(self) -> List[Notification]:
        if self._notification_cache is None:
            notifications: List[Notification] = []
            for p in self.notification_dir.glob("*.json"):
                n = self._load_notification_file(p)
                if n:
                    notifications.append(n)
            self._notification_cache = sorted(notifications, key=lambda n: n.created_at)
        return list(self._notification_cache)

    def _get_recipient_notifications(self, recipient_id: str, unread_only: bool = True) -> List[Notification]:
        notes = [n for n in self._get_all_notifications() if n.recipient_id == recipient_id]
        if unread_only:
            notes = [n for n in notes if n.read_at is None]
        return notes

    def _priority_value(self, level: NotificationLevel) -> int:
        return {
            NotificationLevel.INFO: 1,
            NotificationLevel.WARNING: 2,
            NotificationLevel.CRITICAL: 3,
            NotificationLevel.INTRUSION: 4,
        }[level]

    def _make_room_for_priority_notification(self, recipient_id: str, level: NotificationLevel) -> bool:
        """Suppress lower-priority unread alerts so critical/intrusion notices can get through."""
        if self._priority_value(level) < self._priority_value(NotificationLevel.CRITICAL):
            return False
        changed = False
        unread = self._get_recipient_notifications(recipient_id, unread_only=True)
        if len(unread) >= self._limits["per_recipient_max"]:
            lower = [n for n in unread if self._priority_value(n.level) < self._priority_value(level)]
            if lower:
                victim = sorted(lower, key=lambda n: (self._priority_value(n.level), n.created_at))[0]
                victim.read_at = self._now()
                victim.action_taken = f"auto-suppressed for {level.value} alert"
                self._save_notification(victim)
                changed = True
        all_notes = self._get_all_notifications()
        if len(all_notes) >= self._limits["total_system_max"]:
            lower = [n for n in all_notes if self._priority_value(n.level) < self._priority_value(level)]
            if lower:
                victim = sorted(lower, key=lambda n: (self._priority_value(n.level), n.created_at))[0]
                # Quarantine user-facing alert storage; BlackBox event remains the record.
                path = self.notification_dir / f"{victim.notification_id}.json"
                if path.exists():
                    suppressed_dir = self.notification_dir / "rubish_suppressed_notifications"
                    suppressed_dir.mkdir(parents=True, exist_ok=True)
                    target = suppressed_dir / path.name
                    if target.exists():
                        target = suppressed_dir / f"{path.stem}_{uuid.uuid4().hex[:8]}{path.suffix}"
                    path.rename(target)
                    if self._notification_cache is not None:
                        self._notification_cache = [
                            n for n in self._notification_cache if n.notification_id != victim.notification_id
                        ]
                    changed = True
        return changed

    def create_notification(
        self,
        recipient_id: str,
        message: str,
        level: NotificationLevel,
        action_url: Optional[str] = None,
        blackbox_event_id: Optional[str] = None,
    ) -> Optional[Notification]:
        """Create a short user-facing alert if limits allow it.

        Returns None when the alert would exceed length, per-recipient, or
        system-wide limits. Full details should still be in BlackBox. Critical
        and intrusion alerts may suppress lower-priority alerts so serious
        warnings are not lost behind stale low-level messages.
        """
        message = " ".join(str(message).split())
        if len(message) > self._limits["per_recipient_char_limit"]:
            return None
        if len(self._get_recipient_notifications(recipient_id, unread_only=True)) >= self._limits["per_recipient_max"]:
            self._make_room_for_priority_notification(recipient_id, level)
        if len(self._get_recipient_notifications(recipient_id, unread_only=True)) >= self._limits["per_recipient_max"]:
            return None
        if len(self._get_all_notifications()) >= self._limits["total_system_max"]:
            self._make_room_for_priority_notification(recipient_id, level)
        if len(self._get_all_notifications()) >= self._limits["total_system_max"]:
            return None
        notification = Notification(
            recipient_id=recipient_id,
            message=message,
            level=level,
            action_url=action_url,
            blackbox_event_id=blackbox_event_id,
        )
        self._save_notification(notification)
        return notification

    def create_notification_burst(
        self,
        recipient_ids: Sequence[str],
        messages: Sequence[str],
        level: NotificationLevel,
        action_url: Optional[str] = None,
        blackbox_event_id: Optional[str] = None,
    ) -> List[Notification]:
        """Send up to five short messages per recipient, respecting global 200 cap."""
        created: List[Notification] = []
        clipped = [self._shorten(m, self._limits["per_recipient_char_limit"]) for m in list(messages)[: self._limits["per_recipient_max"]]]
        for recipient_id in dict.fromkeys(recipient_ids):  # stable de-dup
            for msg in clipped:
                n = self.create_notification(recipient_id, msg, level, action_url, blackbox_event_id)
                if n:
                    created.append(n)
        return created

    def get_inbox(self, recipient_id: str) -> List[Dict[str, Any]]:
        return [n.to_dict() for n in self._get_recipient_notifications(recipient_id, unread_only=True)]

    def mark_notification_read(self, notification_id: str) -> bool:
        path = self.notification_dir / f"{notification_id}.json"
        n = self._load_notification_file(path) if path.exists() else None
        if not n:
            return False
        n.read_at = self._now()
        self._save_notification(n)
        return True

    def record_notification_action(self, notification_id: str, action: str) -> bool:
        path = self.notification_dir / f"{notification_id}.json"
        n = self._load_notification_file(path) if path.exists() else None
        if not n:
            return False
        n.action_taken = action
        self._save_notification(n)
        return True

    # ─── approval requests ──────────────────────────────────────────────

    def _save_approval_request(self, approval: ApprovalRequest) -> None:
        self._write_json_atomic(self.approval_dir / f"{approval.approval_id}.json", approval.to_dict())

    def get_approval_request(self, approval_id: str) -> Optional[ApprovalRequest]:
        path = self.approval_dir / f"{approval_id}.json"
        if not path.exists():
            return None
        try:
            return ApprovalRequest.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def create_approval_request(
        self,
        vault_id: str,
        object_id: str,
        action: str,
        requester_id: str,
        claimed_purpose: str,
        head_user_id: str,
        request_id: Optional[str] = None,
    ) -> ApprovalRequest:
        approval = ApprovalRequest(
            vault_id=vault_id,
            object_id=object_id,
            action=action,
            requester_id=requester_id,
            claimed_purpose=claimed_purpose,
            head_user_id=head_user_id,
            request_id=request_id,
        )
        self._save_approval_request(approval)
        event = self._blackbox_event(
            "HEAD_USER_APPROVAL_CREATED",
            f"Head User approval requested for {action} on {object_id}",
            approval=approval.to_dict(),
        )
        message = self._shorten(f"Approval needed: {action} on {object_id[:8]}… Reply APPROVE, DENY, or REVIEW.")
        note = self.create_notification(
            head_user_id,
            message,
            NotificationLevel.WARNING,
            action_url=f"/approvals/{approval.approval_id}",
            blackbox_event_id=event["event_id"],
        )
        if note:
            self._blackbox_event(
                "HEAD_USER_APPROVAL_NOTIFICATION_SENT",
                f"Head User notified for approval {approval.approval_id}",
                approval_id=approval.approval_id,
                notification_id=note.notification_id,
                linked_event_id=event["event_id"],
            )
        return approval

    def get_pending_approvals(self, head_user_id: str) -> List[Dict[str, Any]]:
        approvals = []
        for p in self.approval_dir.glob("*.json"):
            try:
                a = ApprovalRequest.from_dict(json.loads(p.read_text(encoding="utf-8")))
                if a.head_user_id == head_user_id and a.status == RequestStatus.PENDING_APPROVAL and not a.is_expired():
                    approvals.append(a.to_dict())
            except Exception:
                pass
        return sorted(approvals, key=lambda a: a["created_at"])

    def submit_approval_decision(
        self,
        approval_id: str,
        approved: bool,
        decision_by: Optional[str] = None,
        reason: Optional[str] = None,
        decision_session_id: Optional[str] = None,
    ) -> Optional[ApprovalRequest]:
        approval = self.get_approval_request(approval_id)
        if not approval:
            return None

        decision_identity: Optional[ActorIdentity] = None
        if decision_session_id:
            try:
                decision_identity = self.require_identity_session(decision_session_id)
            except IdentityError as e:
                self._blackbox_event(
                    "UNAUTHORIZED_APPROVAL_DECISION_BLOCKED",
                    f"Approval decision blocked: invalid session for {approval.action} on {approval.object_id}",
                    approval=approval.to_dict(),
                    attempted_decision_by=decision_by,
                    decision_session_id=decision_session_id,
                    reason=str(e),
                )
                raise NotificationError("Valid Head User/admin identity session required for approval decision.")
            if decision_by and decision_by != decision_identity.actor_id:
                self._blackbox_event(
                    "UNAUTHORIZED_APPROVAL_DECISION_BLOCKED",
                    f"Approval decision blocked: decision_by did not match session identity for {approval.action}",
                    approval=approval.to_dict(),
                    attempted_decision_by=decision_by,
                    session_actor_id=decision_identity.actor_id,
                    decision_session_id=decision_session_id,
                )
                raise NotificationError("decision_by does not match the supplied identity session.")
            if not decision_identity.has_human_intent_proof():
                self._blackbox_event(
                    "UNAUTHORIZED_APPROVAL_DECISION_BLOCKED",
                    f"Approval decision blocked: session lacks human intent proof for {approval.action}",
                    approval=approval.to_dict(),
                    session_actor_id=decision_identity.actor_id,
                    decision_session_id=decision_session_id,
                    session_identity=decision_identity.to_dict(),
                )
                raise NotificationError("Approval decisions require a human identity session with human-intent proof.")
            decision_by = decision_identity.actor_id

        # Legacy compatibility still accepts decision_by, but v2.1.8 routes pass
        # decision_session_id so authority comes from a resolved session identity.
        if not decision_by or not self.is_head_user_or_admin(approval.vault_id, decision_by, approval.head_user_id):
            self._blackbox_event(
                "UNAUTHORIZED_APPROVAL_DECISION_BLOCKED",
                f"Unauthorized approval decision blocked for {approval.action} on {approval.object_id}",
                approval=approval.to_dict(),
                attempted_decision_by=decision_by,
                decision_session_id=decision_session_id,
                session_identity=decision_identity.to_dict() if decision_identity else None,
            )
            raise NotificationError("Only the Head User or configured admin with valid identity may approve this request.")
        if approval.is_expired():
            approval.status = RequestStatus.EXPIRED
        else:
            approval.status = RequestStatus.APPROVED if approved else RequestStatus.DENIED
        approval.decision_at = self._now()
        approval.decision_by = decision_by
        approval.decision_reason = reason
        self._save_approval_request(approval)
        self._blackbox_event(
            "HEAD_USER_APPROVAL_DECISION",
            f"Approval {approval.status.value}: {approval.action} on {approval.object_id}",
            approval=approval.to_dict(),
            decision_session_id=decision_session_id,
            session_identity=decision_identity.to_dict() if decision_identity else None,
        )
        # requester notification is capped and short; BlackBox remains complete.
        decision_word = "approved" if approval.status == RequestStatus.APPROVED else approval.status.value
        self.create_notification(approval.requester_id, self._shorten(f"Your {approval.action} request was {decision_word}."), NotificationLevel.INFO)

        if approval.request_id:
            req = self.get_access_request(approval.request_id)
            if req:
                req.status = approval.status
                self._save_access_request(req)
        return approval

    # ─── access request + BlackBox control ──────────────────────────────

    def _save_access_request(self, request: AccessRequest) -> None:
        self._write_json_atomic(self.request_dir / f"{request.request_id}.json", request.to_dict())

    def get_access_request(self, request_id: str) -> Optional[AccessRequest]:
        path = self.request_dir / f"{request_id}.json"
        if not path.exists():
            return None
        try:
            return AccessRequest.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return None

    def get_all_access_requests(self) -> List[Dict[str, Any]]:
        requests: List[AccessRequest] = []
        for p in self.request_dir.glob("*.json"):
            try:
                requests.append(AccessRequest.from_dict(json.loads(p.read_text(encoding="utf-8"))))
            except Exception:
                pass
        return [r.to_dict() for r in sorted(requests, key=lambda r: r.created_at)]

    def _matching_request_count(self, requester_id: str, tool_family: Optional[str] = None) -> int:
        """Count similar requests inside a rolling time window."""
        count = 0
        window_start = self._now() - timedelta(minutes=int(self._limits.get("request_window_minutes", 60)))
        for r in self.get_all_access_requests():
            try:
                created = datetime.fromisoformat(r.get("created_at"))
            except Exception:
                created = self._now()
            if created < window_start:
                continue
            if r.get("requester_id") == requester_id:
                count += 1
            elif tool_family and r.get("tool_family") == tool_family:
                count += 1
        return count + 1  # include request currently being created

    def _update_incident_bundle(self, request: AccessRequest) -> Dict[str, Any]:
        """Collapse repeated pressure into one BlackBox incident bundle."""
        return self.blackbox.update_request_incident_bundle(request.to_dict())

    def classify_request_pressure(self, count: int) -> RequestClassification:
        if count >= self._limits["flood_threshold"]:
            return RequestClassification.ACTIVE_FLOOD
        if count >= self._limits["intrusion_threshold"]:
            return RequestClassification.PROBABLE_INTRUSION
        if count >= self._limits["suspicious_threshold"]:
            return RequestClassification.SUSPICIOUS_PATTERN
        if count >= self._limits["warning_threshold"]:
            return RequestClassification.UNUSUAL_PRESSURE
        return RequestClassification.NORMAL

    def _classification_level(self, classification: RequestClassification) -> NotificationLevel:
        if classification in (RequestClassification.PROBABLE_INTRUSION, RequestClassification.ACTIVE_FLOOD):
            return NotificationLevel.INTRUSION
        if classification == RequestClassification.SUSPICIOUS_PATTERN:
            return NotificationLevel.CRITICAL
        if classification == RequestClassification.UNUSUAL_PRESSURE:
            return NotificationLevel.WARNING
        return NotificationLevel.INFO

    def _system_action_for_classification(self, classification: RequestClassification) -> tuple[RequestStatus, str]:
        if classification == RequestClassification.ACTIVE_FLOOD:
            return RequestStatus.EMERGENCY_LOCKOUT, "emergency lockout; request flood preserved as possible hostile access evidence"
        if classification == RequestClassification.PROBABLE_INTRUSION:
            return RequestStatus.FROZEN, "bot request stream frozen pending Head User review"
        if classification == RequestClassification.SUSPICIOUS_PATTERN:
            return RequestStatus.FROZEN, "request stream collapsed into suspicious incident; Head User review required"
        if classification == RequestClassification.UNUSUAL_PRESSURE:
            return RequestStatus.FROZEN, "request stream collapsed into unusual-pressure incident; normal approval creation paused"
        return RequestStatus.PENDING_APPROVAL, "request logged; human approval required"

    def build_request_alert_messages(self, request: AccessRequest) -> List[str]:
        """Return max five user-facing alert messages, each capped to 150 chars."""
        if request.classification in (RequestClassification.PROBABLE_INTRUSION, RequestClassification.ACTIVE_FLOOD):
            first = "Possible hacking attempt: repeated protected access requests detected."
        elif request.classification == RequestClassification.SUSPICIOUS_PATTERN:
            first = "Suspicious access pattern: repeated protected requests detected."
        elif request.classification == RequestClassification.UNUSUAL_PRESSURE:
            first = "Unusual access pressure: protected requests are increasing."
        else:
            first = f"{request.requester_kind.value} requests protected access."
        messages = [
            first,
            f"Object: {request.object_id[:24]} Action: {request.action}",
            f"Purpose: {request.claimed_purpose or 'not supplied'}",
            f"Count: {request.matching_request_count} Classification: {request.classification.value}",
            "Reply APPROVE, DENY, or REVIEW. Full record is in BlackBox.",
        ]
        return [self._shorten(m, self._limits["per_recipient_char_limit"]) for m in messages[:5]]

    def create_access_request(
        self,
        vault_id: str,
        object_id: str,
        action: str,
        requester_id: str,
        claimed_purpose: str,
        requester_kind: ActorKind | str = ActorKind.UNKNOWN,
        recipients: Optional[Sequence[str]] = None,
        head_user_id: Optional[str] = None,
        section_id: Optional[str] = None,
        tool_family: Optional[str] = None,
    ) -> AccessRequest:
        """Log a protected access request and notify humans without allowing bot access.

        This method never opens/fetches protected custody material. It only logs,
        classifies, alerts, and optionally creates Head User approval.
        """
        kind = requester_kind if isinstance(requester_kind, ActorKind) else ActorKind(str(requester_kind))
        recipients_list = list(dict.fromkeys([*(recipients or []), *([head_user_id] if head_user_id else [])]))
        count = self._matching_request_count(requester_id, tool_family)
        classification = self.classify_request_pressure(count)
        status, system_action = self._system_action_for_classification(classification)
        request = AccessRequest(
            vault_id=vault_id,
            section_id=section_id,
            object_id=object_id,
            action=action,
            requester_id=requester_id,
            requester_kind=kind,
            tool_family=tool_family,
            claimed_purpose=claimed_purpose,
            recipients=recipients_list,
            head_user_id=head_user_id,
            status=status,
            classification=classification,
            matching_request_count=count,
            system_action=system_action,
        )
        self._save_access_request(request)
        event = self._blackbox_event(
            "PROTECTED_ACCESS_REQUEST_LOGGED",
            f"{kind.value} requested {action} on {object_id}; {classification.value}",
            request=request.to_dict(),
            possible_intrusion=classification in (RequestClassification.PROBABLE_INTRUSION, RequestClassification.ACTIVE_FLOOD),
        )
        # Normal requests create approval. Repeated-pressure requests collapse into an incident
        # bundle so a bot cannot create unlimited approval files or approval chores.
        if classification == RequestClassification.NORMAL and head_user_id:
            approval = self.create_approval_request(vault_id, object_id, action, requester_id, claimed_purpose, head_user_id, request.request_id)
            request.approval_id = approval.approval_id
        elif classification != RequestClassification.NORMAL:
            incident = self._update_incident_bundle(request)
            request.system_action = f"{request.system_action}; incident_bundle={incident['incident_id']}"
        notes = self.create_notification_burst(
            recipients_list,
            self.build_request_alert_messages(request),
            self._classification_level(classification),
            action_url=f"/blackbox/requests/{request.request_id}",
            blackbox_event_id=event["event_id"],
        )
        request.notification_ids = [n.notification_id for n in notes]
        if notes:
            request.status = RequestStatus.NOTIFIED if request.status == RequestStatus.PENDING_APPROVAL else request.status
        self._save_access_request(request)
        return request

    def evaluate_direct_access(
        self,
        actor_kind: ActorKind | str | None,
        action: str,
        protected: bool = True,
        human_ceremony_passed: bool = False,
        actor_identity: Optional[ActorIdentity] = None,
    ) -> Dict[str, Any]:
        """Decision helper: bots cannot directly perform protected custody actions.

        v2.1.8 accepts an ActorIdentity session. When supplied, that session is
        the source of actor kind and human-ceremony proof. Raw actor_kind remains
        only for compatibility and unprotected diagnostics.
        """
        if actor_identity is not None:
            if not actor_identity.is_valid():
                event = self._blackbox_event(
                    "PROTECTED_DIRECT_ACCESS_DENIED",
                    f"Protected access denied: invalid identity session for {action}",
                    action=action,
                    actor_identity=actor_identity.to_dict(),
                    reason="invalid_identity_session",
                )
                return {
                    "allowed": False,
                    "reason": "Valid identity session required for protected custody.",
                    "action": action,
                    "blackbox_event_id": event["event_id"],
                }
            actor_kind = actor_identity.actor_kind
            human_ceremony_passed = bool(human_ceremony_passed or actor_identity.has_human_intent_proof())

        try:
            kind = actor_kind if isinstance(actor_kind, ActorKind) else ActorKind(str(actor_kind or ActorKind.UNKNOWN.value))
        except ValueError:
            kind = ActorKind.UNKNOWN
        if not protected:
            return {"allowed": True, "reason": "unprotected action"}
        if kind in self.BOT_KINDS:
            event = self._blackbox_event(
                "PROTECTED_DIRECT_ACCESS_DENIED",
                f"Bot/tool direct access denied for {action}",
                action=action,
                actor_kind=kind.value,
                actor_identity=actor_identity.to_dict() if actor_identity else None,
                reason="no_bot_direct_access",
            )
            return {
                "allowed": False,
                "reason": "No autonomous bot/AI/tool access to protected custody. Request human approval instead.",
                "action": action,
                "blackbox_event_id": event["event_id"],
            }
        if kind == ActorKind.HUMAN and human_ceremony_passed:
            return {
                "allowed": True,
                "reason": "human identity session ceremony passed" if actor_identity else "human ceremony passed",
                "action": action,
                "actor_id": actor_identity.actor_id if actor_identity else None,
                "session_id": actor_identity.session_id if actor_identity else None,
            }
        event = self._blackbox_event(
            "PROTECTED_DIRECT_ACCESS_DENIED",
            f"Protected access denied: missing human ceremony for {action}",
            action=action,
            actor_kind=kind.value,
            actor_identity=actor_identity.to_dict() if actor_identity else None,
            reason="missing_human_ceremony",
        )
        return {
            "allowed": False,
            "reason": "Protected custody requires live authorized human ceremony.",
            "action": action,
            "blackbox_event_id": event["event_id"],
        }

    # ─── summaries / reports ────────────────────────────────────────────

    def get_notification_status(self) -> Dict[str, Any]:
        all_notifs = self._get_all_notifications()
        pending = []
        for p in self.approval_dir.glob("*.json"):
            try:
                a = ApprovalRequest.from_dict(json.loads(p.read_text(encoding="utf-8")))
                if a.status == RequestStatus.PENDING_APPROVAL and not a.is_expired():
                    pending.append(a)
            except Exception:
                pass
        return {
            "total_notifications": len(all_notifs),
            "unread_notifications": len([n for n in all_notifs if n.read_at is None]),
            "total_capacity": self._limits["total_system_max"],
            "capacity_used": len(all_notifs),
            "capacity_remaining": max(0, self._limits["total_system_max"] - len(all_notifs)),
            "pending_approvals": len(pending),
            "request_count": len(self.get_all_access_requests()),
            "system_status": "normal" if len(all_notifs) < self._limits["total_system_max"] else "at_capacity",
        }

    def build_blackbox_request_report(self, limit: int = 100) -> Dict[str, Any]:
        requests = self.get_all_access_requests()[-limit:]
        counts: Dict[str, int] = {}
        intrusions: List[Dict[str, Any]] = []
        for r in requests:
            key = r.get("requester_id") or "unknown"
            counts[key] = counts.get(key, 0) + 1
            if r.get("classification") in {
                RequestClassification.PROBABLE_INTRUSION.value,
                RequestClassification.ACTIVE_FLOOD.value,
                RequestClassification.SUSPICIOUS_PATTERN.value,
            }:
                intrusions.append(r)
        incidents = []
        for p in self.incident_dir.glob("*.json"):
            try:
                incidents.append(json.loads(p.read_text(encoding="utf-8")))
            except Exception:
                pass
        return {
            "summary": "BlackBox protected access request report",
            "generated_at": self._now().isoformat(),
            "request_count_included": len(requests),
            "counts_by_requester": counts,
            "possible_intrusion_records": intrusions,
            "incident_bundles": sorted(incidents, key=lambda i: i.get("updated_at", "")),
            "blackbox_chain": self.verify_blackbox_chain(),
            "notification_limits": dict(self._limits),
            "requests": requests,
        }

    def is_approaching_limits(self, recipient_id: str) -> bool:
        return len(self._get_recipient_notifications(recipient_id)) >= (self._limits["per_recipient_max"] - 1)

    def suppress_duplicate_alerts(self, recipient_id: str, message_prefix: str) -> bool:
        one_hour_ago = self._now() - timedelta(hours=1)
        for msg in self._get_recipient_notifications(recipient_id):
            if msg.message.startswith(message_prefix) and msg.created_at > one_hour_ago:
                return True
        return False
