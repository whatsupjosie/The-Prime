﻿#!/usr/bin/env python3
"""
Iteration Wallet â€” CLI
=======================
Command-line interface to vault operations.

Usage:
    iw serve [--port 7432]                    Start the server
    iw open                                   Open vault (requires typing OPEN)
    iw lock                                   Lock vault
    iw create-project NAME [--path PATH]      Create a new cradle
    iw ls [--project ID]                      List projects/files
    iw add FILE [--project ID]                Add file to vault
    iw remove FILE_ID                         Move file to holding
    iw remove FILE_ID                         Remove from active custody (no delete)
    iw restore FILE_ID                        Restore from archive
    iw promote [--project ID] --to VERSION    Promote version
    iw drives                                 Show external drives
    iw mark-drive PATH                        Mark a drive for backups
    iw events [--limit 20]                    Show activity log
    iw install-hook [--project NAME]          Install git pre-commit hook
    iw uninstall-hook                         Quarantine git pre-commit hook without deleting
    iw status                                 Check vault health
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import requests

# â”€â”€â”€ config â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

VAULT_API = "http://localhost:7432/api"
TIMEOUT = 5

LOCAL_API_HOSTS = {"localhost", "127.0.0.1", "::1"}


def _assert_local_vault_api(url: str) -> None:
    """Fail closed if the CLI API target is not local loopback."""
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or parsed.hostname not in LOCAL_API_HOSTS:
        raise ValueError(
            "Iteration Wallet CLI only talks to a local loopback vault API. "
            f"Refusing non-local endpoint: {url}"
        )


def _req(method: str, path: str, data=None, timeout=TIMEOUT):
    """Make an API request. Exit cleanly if server is down."""
    _assert_local_vault_api(VAULT_API)
    url = VAULT_API + path
    try:
        if method == "GET":
            r = requests.get(url, timeout=timeout)
        elif method == "POST":
            r = requests.post(url, json=data, timeout=timeout)
        else:
            raise ValueError(f"Unsupported method: {method}; Iteration Wallet has no DELETE transport path")

        if r.status_code >= 400:
            err = r.json().get("detail", "Unknown error")
            print(f"âŒ {err}", file=sys.stderr)
            sys.exit(1)
        return r.json()
    except requests.ConnectionError:
        print(f"âŒ Cannot connect to vault server at {VAULT_API}", file=sys.stderr)
        print(f"   Start it with: iw serve", file=sys.stderr)
        sys.exit(1)
    except requests.Timeout:
        print(f"âŒ Vault server timeout", file=sys.stderr)
        sys.exit(1)


# â”€â”€â”€ commands â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€


def cmd_serve(args):
    """Start the server."""
    from iteration_wallet.server import app
    import uvicorn

    port = args.port or 7432
    host = "127.0.0.1"
    url = f"http://{host}:{port}"

    print()
    print("  âš¿  Iteration Wallet â€” Rear View Foresight")
    print(f"     Vault UI  â†’  {url}")
    print(f"     API docs  â†’  {url}/docs")
    print()

    uvicorn.run(
        "iteration_wallet.server:app",
        host=host,
        port=port,
        log_level="warning",
    )


def cmd_status(args):
    """Check vault health."""
    try:
        state = _req("GET", "/state")
        print()
        print(f"  âœ“ Vault is operational")
        print(f"    Projects: {len(state['projects'])}")
        print(f"    Files: {len(state['files'])}")
        print(f"    Status: {'ðŸ”“ OPEN' if state.get('vaultOpen') else 'ðŸ”’ LOCKED'}")
        print()
    except SystemExit:
        raise


def cmd_open(args):
    """Open the vault."""
    _req("POST", "/vault/open")
    print("ðŸ”“ Vault is open.")


def cmd_lock(args):
    """Lock the vault."""
    _req("POST", "/vault/lock")
    print("ðŸ”’ Vault locked.")


def cmd_create_project(args):
    """Create a new cradle."""
    if not args.name:
        print("âŒ Project name is required.", file=sys.stderr)
        sys.exit(1)

    data = {"name": args.name, "path": args.path or ""}
    result = _req("POST", "/projects", data)
    print(f"âœ“ Created: {result['name']} ({result['id']})")


def cmd_ls(args):
    """List projects or files."""
    state = _req("GET", "/state")

    if not state["projects"]:
        print("(no projects)")
        return

    if args.project:
        # Show files in a specific project
        proj = next((p for p in state["projects"] if p["id"] == args.project), None)
        if not proj:
            print(f"âŒ Project not found: {args.project}", file=sys.stderr)
            sys.exit(1)

        print(f"\nðŸ“ {proj['name']} ({proj['version']})")
        print(f"   Created: {proj.get('createdAt', 'unknown')}")
        print()

        files = [f for f in state["files"] if f["project"] == args.project]
        if not files:
            print("   (no files)")
        else:
            for f in files:
                status_icon = "ðŸ”’" if f["status"] == "protected" else "ðŸ“¦"
                print(
                    f"   {status_icon} {f['name']:40} {f['size']:>8}  {f['status']}"
                )
    else:
        # List all projects
        print("\nðŸ“¦ Projects\n")
        for p in state["projects"]:
            file_count = len([f for f in state["files"] if f["project"] == p["id"]])
            print(f"  {p['name']:30} {p['version']:5}  {file_count} file(s)")
        print()


def cmd_add_file(args):
    """Add a file to the vault."""
    if not args.file:
        print("âŒ File path is required.", file=sys.stderr)
        sys.exit(1)

    path = Path(args.file)
    if not path.exists():
        print(f"âŒ File not found: {args.file}", file=sys.stderr)
        sys.exit(1)

    # Get default project if not specified
    state = _req("GET", "/state")
    project_id = args.project

    if not project_id:
        if not state["projects"]:
            print("âŒ No projects exist. Create one first: iw create-project NAME",
                  file=sys.stderr)
            sys.exit(1)
        project_id = state["projects"][0]["id"]

    data = {"path": str(path.resolve()), "project": project_id}
    result = _req("POST", "/files", data)
    print(f"âœ“ Protected: {result['name']} ({result['size']})")


def cmd_remove_file(args):
    """Move a file to holding."""
    if not args.file_id:
        print("âŒ File ID is required.", file=sys.stderr)
        sys.exit(1)

    result = _req("POST", f"/files/{args.file_id}/remove")
    print(f"âœ“ {result['name']} moved to holding.")


def cmd_delete_file(args):
    """Disabled compatibility command: Iteration Wallet never deletes."""
    print("âœ— Iteration Wallet never deletes user-custodied material.")
    print("  Use remove, quarantine, or live-person release from custody instead.")
    return 2


def cmd_restore_file(args):
    """Restore a file from archive."""
    if not args.file_id:
        print("âŒ File ID is required.", file=sys.stderr)
        sys.exit(1)

    result = _req("POST", f"/files/{args.file_id}/restore")
    print(f"âœ“ Restored: {result['name']}")


def cmd_promote_version(args):
    """Promote to a new version."""
    if not args.to:
        print("âŒ --to VERSION is required.", file=sys.stderr)
        sys.exit(1)

    state = _req("GET", "/state")
    project_id = args.project

    if not project_id:
        if not state["projects"]:
            print("âŒ No projects.", file=sys.stderr)
            sys.exit(1)
        project_id = state["projects"][0]["id"]

    data = {"newVersion": args.to}
    result = _req("POST", f"/projects/{project_id}/promote", data)
    print(f"âœ“ Promoted to {result['version']}")


def cmd_drives(args):
    """Show detected drives."""
    result = _req("GET", "/drives")
    drives = result.get("drives", [])

    print("\nðŸ’¾ External drives\n")
    for d in drives:
        vault_marker = "âœ“" if d.get("hasVault") else " "
        print(f"  [{vault_marker}] {d['name']:30} {d['totalGB']:>5} GB  ({d['freeGB']} GB free)")
    print()


def cmd_mark_drive(args):
    """Mark a drive for vault backups."""
    if not args.path:
        print("âŒ Drive path is required.", file=sys.stderr)
        sys.exit(1)

    data = {"drivePath": args.path}
    _req("POST", "/drives/mark", data)
    print(f"âœ“ Vault marker placed on {args.path}")


def cmd_events(args):
    """Show activity log."""
    result = _req("GET", "/events")
    events = result.get("events", [])[:args.limit]

    if not events:
        print("(no events)")
        return

    print("\nðŸ“ Activity\n")
    for e in events:
        ts = e.get("ts", "??:??:??")
        typ = e.get("type", "?")
        desc = e.get("desc", "")
        print(f"  {ts}  {typ:20}  {desc}")
    print()


def cmd_install_hook(args):
    """Install the git pre-commit hook."""
    from iteration_wallet import guard

    git_dir = Path(".git")
    if not git_dir.exists():
        print("âŒ Not in a git repository.", file=sys.stderr)
        sys.exit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_file = hooks_dir / "pre-commit"

    guard_module = Path(guard.__file__)

    # Create a wrapper script that calls the guard module
    hook_content = f"""#!/bin/bash
# Iteration Wallet â€” Commit Guard
python3 -m iteration_wallet.guard
"""

    hook_file.write_text(hook_content)
    hook_file.chmod(0o755)
    print(f"âœ“ Installed pre-commit hook")


def cmd_uninstall_hook(args):
    """Quarantine the git pre-commit hook without deleting it."""
    git_dir = Path(".git")
    if not git_dir.exists():
        print("âŒ Not in a git repository.", file=sys.stderr)
        sys.exit(1)

    hook_file = git_dir / "hooks" / "pre-commit"
    if hook_file.exists():
        quarantine_dir = hook_file.parent / "rubish_iteration_wallet_hooks"
        quarantine_dir.mkdir(exist_ok=True)
        target = quarantine_dir / hook_file.name
        counter = 1
        while target.exists():
            target = quarantine_dir / f"{hook_file.name}.{counter}"
            counter += 1
        hook_file.rename(target)
        print(f"âœ“ Quarantined pre-commit hook at {target}")
    else:
        print("(hook not installed)")


# â”€â”€â”€ CLI dispatch â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€


def main():
    parser = argparse.ArgumentParser(
        description="Iteration Wallet â€” Project Vault for AI Developers",
        prog="iw",
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # serve
    p = subparsers.add_parser("serve", help="Start the vault server")
    p.add_argument("--port", type=int, default=7432)
    p.set_defaults(func=cmd_serve)

    # status
    p = subparsers.add_parser("status", help="Check vault health")
    p.set_defaults(func=cmd_status)

    # open/lock
    subparsers.add_parser("open", help="Open the vault").set_defaults(func=cmd_open)
    subparsers.add_parser("lock", help="Lock the vault").set_defaults(func=cmd_lock)

    # projects
    p = subparsers.add_parser("create-project", help="Create a new cradle")
    p.add_argument("name")
    p.add_argument("--path", default="")
    p.set_defaults(func=cmd_create_project)

    p = subparsers.add_parser("ls", help="List projects/files")
    p.add_argument("--project", default="")
    p.set_defaults(func=cmd_ls)

    # files
    p = subparsers.add_parser("add", help="Add file to vault")
    p.add_argument("file")
    p.add_argument("--project", default="")
    p.set_defaults(func=cmd_add_file)

    p = subparsers.add_parser("remove", help="Move file to holding")
    p.add_argument("file_id", metavar="FILE_ID")
    p.set_defaults(func=cmd_remove_file)

    # No delete command: Iteration Wallet never deletes user-custodied material.

    p = subparsers.add_parser("restore", help="Restore from archive")
    p.add_argument("file_id", metavar="FILE_ID")
    p.set_defaults(func=cmd_restore_file)

    # versions
    p = subparsers.add_parser("promote", help="Promote to new version")
    p.add_argument("--project", default="")
    p.add_argument("--to", required=True)
    p.set_defaults(func=cmd_promote_version)

    # drives
    subparsers.add_parser("drives", help="Show external drives").set_defaults(
        func=cmd_drives
    )

    p = subparsers.add_parser("mark-drive", help="Mark drive for backups")
    p.add_argument("path")
    p.set_defaults(func=cmd_mark_drive)

    # events
    p = subparsers.add_parser("events", help="Show activity log")
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_events)

    # git hooks
    p = subparsers.add_parser("install-hook", help="Install git pre-commit hook")
    p.add_argument("--project", default="")
    p.set_defaults(func=cmd_install_hook)

    subparsers.add_parser("uninstall-hook", help="Quarantine git pre-commit hook without deleting").set_defaults(
        func=cmd_uninstall_hook
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\n(interrupted)")
        sys.exit(130)
    except Exception as e:
        print(f"âŒ {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()

