"""Static product-law checks for the normalized Iteration Wallet spine."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "iteration_wallet"


def read(name: str) -> str:
    return (PACKAGE / name).read_text(encoding="utf-8")


def test_active_package_has_expected_spine_modules():
    for name in [
        "blackbox.py",
        "ceremony.py",
        "gatekeeper.py",
        "identity.py",
        "key_derivation.py",
        "notification_manager.py",
        "server.py",
        "vault.py",
        "vault_v21.py",
    ]:
        assert (PACKAGE / name).exists(), name


def test_server_exposes_no_delete_route_or_delete_method():
    source = read("server.py").lower()
    assert "@app.delete" not in source
    assert "delete(" not in source
    assert "no_delete" in source


def test_vault_engine_moves_records_without_unlink_or_remove_item():
    source = read("vault_v21.py")
    assert ".unlink(" not in source
    assert "os.remove" not in source
    assert "shutil.rmtree" not in source
    assert "move_to_removed" in source
    assert "quarantine_file" in source


def test_key_derivation_does_not_store_raw_key_in_metadata():
    source = read("key_derivation.py")
    assert "pbkdf2_hmac" in source
    assert "compare_digest" in source
    assert '"key":' not in source
    assert "salt_b64" in source


def test_package_declares_key_derivation_export():
    source = read("__init__.py")
    assert "key_derivation" in source
