"""
Iteration Wallet v2.1.9 — BlackBox Evidence Chain
==================================================

BlackBox is the tamper-evident evidence layer for Iteration Wallet.
It records custody events, human-intent decisions, bot/tool requests,
incident bundles, and verification failures without owning the user-facing
notification workflow.

Product law:
- BlackBox is not optional bookkeeping. It is load-bearing custody evidence.
- Vault custody events and Human Intent gate events must share one evidence chain.
- The chain is local and tamper-evident, not external cryptographic sealing.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


class BlackBoxError(Exception):
    """Raised for expected BlackBox evidence failures."""


class BlackBox:
    """Local tamper-evident BlackBox event store.

    The event chain lives under `<vault_root>/blackbox/events`. Each event records
    the previous event hash, its chain index, and its own hash. Verification
    recomputes every event hash in sequence and reports any mismatch.
    """

    def __init__(self, vault_root: Path):
        self.vault_root = Path(vault_root)
        self.blackbox_dir = self.vault_root / "blackbox"
        self.event_dir = self.blackbox_dir / "events"
        self.incident_dir = self.blackbox_dir / "incidents"
        self.request_dir = self.blackbox_dir / "requests"
        self.chain_file = self.blackbox_dir / "chain_head.json"
        for directory in (self.blackbox_dir, self.event_dir, self.incident_dir, self.request_dir):
            directory.mkdir(parents=True, exist_ok=True)

    # ─── durable JSON helpers ────────────────────────────────────────────

    @staticmethod
    def now() -> datetime:
        return datetime.now()

    @staticmethod
    def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    @staticmethod
    def _canonical_json(data: Dict[str, Any]) -> str:
        return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def _current_chain_state(self) -> tuple[str, int]:
        if not self.chain_file.exists():
            return "GENESIS", 0
        try:
            data = json.loads(self.chain_file.read_text(encoding="utf-8"))
            return str(data.get("event_hash") or "GENESIS"), int(data.get("chain_index", 0))
        except Exception:
            return "GENESIS", 0

    def current_chain_head(self) -> str:
        return self._current_chain_state()[0]

    # ─── events ──────────────────────────────────────────────────────────

    def write_event(self, event_type: str, summary: str, **extra: Any) -> Dict[str, Any]:
        """Write a hash-chained BlackBox event."""
        event_id = uuid.uuid4().hex[:16]
        previous_event_hash, previous_chain_index = self._current_chain_state()
        event = {
            "event_id": event_id,
            "event_type": event_type,
            "summary": summary,
            "created_at": self.now().isoformat(),
            "previous_event_hash": previous_event_hash,
            "chain_index": previous_chain_index + 1,
            **extra,
        }
        event_hash = hashlib.sha256(
            (previous_event_hash + self._canonical_json(event)).encode("utf-8")
        ).hexdigest()
        event["event_hash"] = event_hash
        self._write_json_atomic(self.event_dir / f"{event_id}.json", event)
        self._write_json_atomic(
            self.chain_file,
            {
                "event_id": event_id,
                "event_hash": event_hash,
                "chain_index": event["chain_index"],
                "updated_at": event["created_at"],
            },
        )
        return event

    def iter_events(self) -> Iterable[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        for path in self.event_dir.glob("*.json"):
            try:
                events.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception as exc:
                raise BlackBoxError(f"unreadable event {path.name}: {exc}") from exc
        events.sort(key=lambda e: (int(e.get("chain_index", 0)), e.get("created_at", ""), e.get("event_id", "")))
        return events

    def verify_chain(self) -> Dict[str, Any]:
        """Verify local BlackBox chain integrity."""
        try:
            events = list(self.iter_events())
        except BlackBoxError as exc:
            return {"ok": False, "reason": str(exc)}

        previous = "GENESIS"
        expected_index = 1
        for event in events:
            if int(event.get("chain_index", 0)) != expected_index:
                return {"ok": False, "reason": "chain index gap", "event_id": event.get("event_id")}
            if event.get("previous_event_hash") != previous:
                return {"ok": False, "reason": "broken previous hash", "event_id": event.get("event_id")}
            payload = dict(event)
            supplied_hash = payload.pop("event_hash", None)
            expected_hash = hashlib.sha256((previous + self._canonical_json(payload)).encode("utf-8")).hexdigest()
            if supplied_hash != expected_hash:
                return {"ok": False, "reason": "event hash mismatch", "event_id": event.get("event_id")}
            previous = supplied_hash
            expected_index += 1

        return {"ok": True, "event_count": len(events), "chain_head": previous}

    # ─── request / incident bundles ───────────────────────────────────────

    @staticmethod
    def incident_key(*parts: Optional[str]) -> str:
        raw = "|".join(str(part or "") for part in parts)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def update_request_incident_bundle(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Collapse repeated request pressure into one BlackBox incident bundle."""
        incident_id = self.incident_key(
            request.get("vault_id"),
            request.get("object_id"),
            request.get("action"),
            request.get("requester_id"),
            request.get("tool_family"),
        )
        path = self.incident_dir / f"{incident_id}.json"
        if path.exists():
            try:
                incident = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                incident = {}
        else:
            incident = {
                "incident_id": incident_id,
                "incident_type": "BOT_REQUEST_PRESSURE",
                "created_at": self.now().isoformat(),
                "vault_id": request.get("vault_id"),
                "object_id": request.get("object_id"),
                "action": request.get("action"),
                "requester_id": request.get("requester_id"),
                "tool_family": request.get("tool_family"),
                "raw_request_ids": [],
            }

        classification = str(request.get("classification") or "normal")
        incident["updated_at"] = self.now().isoformat()
        incident["classification"] = classification
        incident["matching_request_count"] = int(request.get("matching_request_count") or 0)
        incident["status"] = request.get("status")
        incident.setdefault("raw_request_ids", []).append(request.get("request_id"))
        incident["summary"] = (
            "Possible hacking attempt / runaway automation"
            if classification in {"probable_intrusion_attempt", "active_flood_hostile_access_event"}
            else "Repeated protected access pressure"
        )
        self._write_json_atomic(path, incident)
        self.write_event("REQUEST_INCIDENT_BUNDLE_UPDATED", incident["summary"], incident=incident)
        return incident

    # ─── custody events / violation evidence ──────────────────────────────

    def write_custody_event(
        self,
        event_type: str,
        summary: str,
        *,
        project_id: Optional[str] = None,
        section_id: Optional[str] = None,
        file_id: Optional[str] = None,
        state: Optional[str] = None,
        **extra: Any,
    ) -> Dict[str, Any]:
        """Write a custody event from vault_v21 into the same BlackBox chain."""
        return self.write_event(
            event_type,
            summary,
            project_id=project_id,
            section_id=section_id,
            file_id=file_id,
            state=state,
            custody_event=True,
            **extra,
        )

    def write_violation_event(self, violation_type: str, summary: str, **extra: Any) -> Dict[str, Any]:
        """Write suspected custody break / violation evidence."""
        return self.write_event(
            violation_type,
            summary,
            custody_violation=True,
            possible_intrusion=True,
            **extra,
        )

    def build_report(self, limit: int = 100) -> Dict[str, Any]:
        events = list(self.iter_events())[-limit:]
        incidents = []
        for path in self.incident_dir.glob("*.json"):
            try:
                incidents.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                pass
        return {
            "summary": "BlackBox custody evidence report",
            "generated_at": self.now().isoformat(),
            "event_count_included": len(events),
            "events": events,
            "incident_bundles": sorted(incidents, key=lambda i: i.get("updated_at", "")),
            "chain": self.verify_chain(),
        }
