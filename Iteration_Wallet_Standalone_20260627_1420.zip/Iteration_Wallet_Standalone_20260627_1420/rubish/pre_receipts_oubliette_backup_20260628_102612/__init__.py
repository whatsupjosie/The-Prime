﻿"""Standalone Iteration Wallet package.

Normalized product spine for the Iteration Wallet, BlackBox, and Oubliette
boundary work. The package laws are no delete, no silent overwrite, no execution
of custodied user material, and AI outside the yard.
"""

__version__ = "2.1-standalone-spine"

__all__ = [
    "blackbox",
    "ceremony",
    "cli",
    "gatekeeper",
    "identity",
    "key_derivation",
    "notification_manager",
    "private_alpha_runner",
    "server",
    "vault",
    "vault_v21",
]
