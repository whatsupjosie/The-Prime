"""Private-alpha proof runner scaffold for Iteration Wallet.

This module intentionally does not execute custodied user code, shell commands,
or external tools. It produces a structured readiness report that can be expanded
as the standalone wallet hardening work becomes safe to run.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List


@dataclass
class ProofItem:
    """One private-alpha proof item."""

    name: str
    status: str
    evidence: str
    blocker: str = ""


@dataclass
class PrivateAlphaReport:
    """Structured private-alpha readiness report."""

    generated_at: str
    workspace: str
    status: str
    items: List[ProofItem] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "workspace": self.workspace,
            "status": self.status,
            "items": [asdict(item) for item in self.items],
        }


def build_private_alpha_report(workspace: str | Path) -> PrivateAlphaReport:
    """Build an honest, non-executing private-alpha readiness report."""
    root = Path(workspace)
    items = [
        ProofItem(
            name="product_laws",
            status="PASS" if (root / "PRODUCT_LAWS.md").exists() else "FAIL",
            evidence="PRODUCT_LAWS.md exists" if (root / "PRODUCT_LAWS.md").exists() else "PRODUCT_LAWS.md missing",
        ),
        ProofItem(
            name="normalized_package",
            status="PASS" if (root / "iteration_wallet" / "__init__.py").exists() else "FAIL",
            evidence="iteration_wallet package marker exists"
            if (root / "iteration_wallet" / "__init__.py").exists()
            else "iteration_wallet package marker missing",
        ),
        ProofItem(
            name="runtime_flow",
            status="NOT_RUN",
            evidence="Runtime private-alpha flow is intentionally not executed by this scaffold.",
            blocker="Runtime flow requires review of copied historical tests and cleanup behavior before safe execution.",
        ),
    ]
    status = "PASS" if all(item.status == "PASS" for item in items) else "PARTIAL"
    return PrivateAlphaReport(
        generated_at=datetime.now().isoformat(),
        workspace=str(root),
        status=status,
        items=items,
    )


__all__ = ["PrivateAlphaReport", "ProofItem", "build_private_alpha_report"]

