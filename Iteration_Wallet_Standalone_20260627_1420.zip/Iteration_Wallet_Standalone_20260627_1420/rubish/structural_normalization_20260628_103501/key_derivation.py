"""Secure key-derivation helpers for Iteration Wallet.

This module deliberately uses only Python's standard library so the standalone
wallet can stay offline and dependency-free. Argon2id remains the preferred
future upgrade, but PBKDF2-HMAC-SHA256 is the safest local implementation we
can ship without installing packages.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from dataclasses import dataclass
from typing import Any, Dict, Optional


ALGORITHM = "pbkdf2_hmac_sha256"
DEFAULT_ITERATIONS = 600_000
DEFAULT_SALT_BYTES = 32
DEFAULT_KEY_BYTES = 32
MIN_ITERATIONS = 310_000


class KeyDerivationError(ValueError):
    """Raised when key-derivation input or metadata is unsafe."""


@dataclass(frozen=True)
class DerivedKeyMaterial:
    """Derived key plus non-secret metadata.

    The raw key is intentionally excluded from repr and from serialization. It
    may be used by a caller for encryption later, but it must never be written
    into receipts, BlackBox events, closed catalogs, or handoff files.
    """

    key: bytes
    salt: bytes
    iterations: int = DEFAULT_ITERATIONS
    algorithm: str = ALGORITHM

    def metadata(self) -> Dict[str, Any]:
        """Return safe metadata that does not expose the derived key."""
        return {
            "algorithm": self.algorithm,
            "iterations": self.iterations,
            "salt_b64": base64.b64encode(self.salt).decode("ascii"),
            "key_bytes": len(self.key),
        }


def _normalize_secret(secret: str | bytes) -> bytes:
    if isinstance(secret, str):
        secret_bytes = secret.encode("utf-8")
    elif isinstance(secret, bytes):
        secret_bytes = secret
    else:
        raise KeyDerivationError("secret must be str or bytes")
    if not secret_bytes:
        raise KeyDerivationError("secret must not be empty")
    return secret_bytes


def _normalize_salt(salt: Optional[bytes]) -> bytes:
    if salt is None:
        return secrets.token_bytes(DEFAULT_SALT_BYTES)
    if not isinstance(salt, bytes):
        raise KeyDerivationError("salt must be bytes")
    if len(salt) < 16:
        raise KeyDerivationError("salt must be at least 16 bytes")
    return salt


def derive_key(
    secret: str | bytes,
    *,
    salt: Optional[bytes] = None,
    iterations: int = DEFAULT_ITERATIONS,
    key_bytes: int = DEFAULT_KEY_BYTES,
) -> DerivedKeyMaterial:
    """Derive key material from a human secret or ceremony passphrase."""
    if int(iterations) < MIN_ITERATIONS:
        raise KeyDerivationError(f"iterations must be at least {MIN_ITERATIONS}")
    if int(key_bytes) < 16:
        raise KeyDerivationError("key_bytes must be at least 16")
    normalized_secret = _normalize_secret(secret)
    normalized_salt = _normalize_salt(salt)
    key = hashlib.pbkdf2_hmac(
        "sha256",
        normalized_secret,
        normalized_salt,
        int(iterations),
        dklen=int(key_bytes),
    )
    return DerivedKeyMaterial(
        key=key,
        salt=normalized_salt,
        iterations=int(iterations),
        algorithm=ALGORITHM,
    )


def create_secret_verifier(
    secret: str | bytes,
    *,
    salt: Optional[bytes] = None,
    iterations: int = DEFAULT_ITERATIONS,
) -> Dict[str, Any]:
    """Create a storage-safe verifier for a secret.

    This is for checking that the same human-held secret was presented again. It
    is not an encryption envelope and it does not store the raw secret.
    """
    material = derive_key(secret, salt=salt, iterations=iterations)
    digest = hashlib.sha256(material.key).hexdigest()
    verifier = material.metadata()
    verifier.update({"verifier_sha256": digest})
    return verifier


def verify_secret(secret: str | bytes, verifier: Dict[str, Any]) -> bool:
    """Verify a secret against a verifier created by create_secret_verifier."""
    try:
        if verifier.get("algorithm") != ALGORITHM:
            return False
        salt = base64.b64decode(str(verifier["salt_b64"]).encode("ascii"))
        iterations = int(verifier["iterations"])
        expected = str(verifier["verifier_sha256"])
        actual = hashlib.sha256(
            derive_key(secret, salt=salt, iterations=iterations).key
        ).hexdigest()
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


__all__ = [
    "ALGORITHM",
    "DEFAULT_ITERATIONS",
    "DEFAULT_KEY_BYTES",
    "DEFAULT_SALT_BYTES",
    "DerivedKeyMaterial",
    "KeyDerivationError",
    "create_secret_verifier",
    "derive_key",
    "verify_secret",
]
