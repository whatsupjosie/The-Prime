# Codex Iteration Wallet Regular App Status - 2026-06-27

## Corrected Target

The active target for this pass is the regular/canonical app:

`C:\Users\hardc\OneDrive\Documents\Playground\Cannon Build PubCast-  Alpha Prime`

This is the folder named by the existing Prime handoffs as the serious-work build. Do not continue this lane in `Pubcast codex run` unless the user explicitly redirects there.

## What Was Found

- Iteration Wallet is present in the canonical app:
  - `modules/vault_engine.py`
  - `modules/vault_engine_hardened.py`
  - `modules/pubcast_vault.py`
  - `docs/PUBCAST_SECURITY_ARCHITECTURE_PLAN.md`
  - `docs/PUBCAST_VAULT_USAGE_GUIDE.md`
- `main.py` imports `PubCastVault` and includes its router during lifespan startup.
- The real canonical vault at `data/vault` exists and was not used for probing.
- Scratch app startup proof used `PUBCAST_DATA_DIR=rubish\route_probe_wallet_20260627`.

## Patch Made

The app was blocked on startup by a Pydantic v1/v2 mismatch:

`ProductionState().model_dump()` failed because the bundled runtime has Pydantic `1.10.15`.

Changes:

- Added `model_to_dict()` to `modules/models.py`.
- Updated `modules/hub.py` to serialize `ProductionState` through `model_to_dict()`.

Backups:

`rubish\backup_pre_pydantic_compat_20260627_0851`

## Verification

Commands run from the canonical app folder:

```powershell
..\Python312\python.exe -m py_compile modules\models.py modules\hub.py
..\Python312\python.exe -m unittest tests.test_pubcast.TestVault -v
```

Results:

- `py_compile`: PASS
- `tests.test_pubcast.TestVault`: PASS, 3 tests
  - add/integrity
  - open requires command
  - OPEN -> REMOVE -> DELETE sequence

Scratch route proof:

- App startup with `PUBCAST_DATA_DIR=rubish\route_probe_wallet_20260627`: PASS
- `/api/vault` route count after lifespan startup: 15
- `GET /api/vault/status`: 200
- Response keys: `events_recent`, `integrity`, `projects`, `vault_open`

## Remaining Notes

- The exact "version 2.8" marker was not confirmed in this pass.
- The canonical app identifies itself as v5.6 in startup logs and v5.5 in README/health metadata.
- The root Git repo sees the canonical app folder as untracked, so normal `git diff` from the root does not show file-level changes inside it.
- Scratch route probe data was intentionally left under `rubish\route_probe_wallet_20260627` instead of deleting it.

## Recommended Next Tasks

1. Continue from the canonical app folder only.
2. Reconcile the user's "version 2.8" reference against archived online/project-folder artifacts before broader changes.
3. Extend the Pydantic compatibility helper to other startup/runtime paths only as each real blocker appears.
4. Add a focused route test for `/api/vault/status` using a scratch `PUBCAST_DATA_DIR`.

## v2.1.9 BlackBox / Vault Coupling Pass

User supplied:

- `C:\Users\hardc\Downloads\IterationWallet_v2_1_9_BLACKBOX_EXTRACTION_VAULT_COUPLING_PATCH.zip`
- `C:\Users\hardc\Downloads\files (49).zip`

The v2.1.9 patch confirms the intended architecture:

- BlackBox is load-bearing custody evidence, not optional bookkeeping.
- Vault local logs remain useful activity views.
- Custody operations must also write into a shared tamper-evident BlackBox chain.
- Oubliette remains later/adjacent and was not merged in this pass.

The zip was copied/extracted only for reference. Original downloads were not changed.

Important correction: the user clarified that `rubish` is the garbage/quarantine can, not the normal Codex reference shelf. New non-trash references/backups for this pass were placed under:

- `codex_backups\backup_pre_wallet_blackbox_coupling_20260627_090010`
- `codex_reference_intake\iteration_wallet_v219_patch_ref_20260627_090043`

Earlier mistaken copies in `rubish` were left in place, not deleted.

## v2.1.9 Changes Adapted Into Regular App

Changed files:

- `blackbox_event_language\schema.py`
- `blackbox_event_language\key.json`
- `blackbox_recorder\pubcast_event_adapter.py`
- `modules\pubcast_vault.py`
- `main.py`
- `tests\test_pubcast_vault_blackbox_coupling.py`

What changed:

- Added `VLT` source code for the Iteration Wallet / Vault custody layer.
- Mapped vault custody events into the compact BlackBox `WLT` channel.
- Added optional shared BlackBox witness support to `PubCastVault`.
- Added `PubCastVault.attach_blackbox()`.
- Added defensive `PubCastVault._record_blackbox_event()`.
- Wired high-value vault operations to BlackBox witness events:
  - `vault.recording_protected`
  - `vault.project_snapshot_protected`
  - `vault.opened`
  - `vault.locked`
  - `vault.file_added_to_custody`
  - `vault.file_removed_from_active_use`
  - `vault.file_delete_requested`
  - `vault.file_deleted_from_custody`
  - `vault.project_created`
  - `vault.prime_promoted`
- Updated `main.py` so lifespan startup constructs `PubCastVault(DATA_DIR / "vault", blackbox=blackbox_witness)`.
- Added a focused unittest proving `protect_recording()` writes a `WLT` BlackBox event from source `VLT`.

This is an adaptation into the regular app's existing BlackBox witness, not a wholesale package drop from the standalone Iteration Wallet zip.

## v2.1.9 Verification

Commands run from:

`C:\Users\hardc\OneDrive\Documents\Playground\Cannon Build PubCast-  Alpha Prime`

```powershell
..\Python312\python.exe -m py_compile blackbox_event_language\schema.py blackbox_recorder\pubcast_event_adapter.py modules\pubcast_vault.py main.py tests\test_pubcast_vault_blackbox_coupling.py
..\Python312\python.exe -m unittest tests.test_pubcast_vault_blackbox_coupling -v
..\Python312\python.exe -m unittest tests.test_pubcast.TestVault -v
..\Python312\python.exe -m pytest tests\test_blackbox_event_language.py tests\test_blackbox_runtime_wiring.py -q
$env:PUBCAST_DATA_DIR = (Join-Path (Resolve-Path '.\codex_backups') 'wallet_blackbox_smoke_data_20260627_0900'); ..\Python312\python.exe -c "import main; print('app_imported', bool(main.app)); print('has_vault_class', bool(main.PubCastVault));"
```

Results:

- Compile touched Python files: PASS
- New vault/BlackBox coupling unittest: PASS, 1 test
- Existing vault unittest group: PASS, 3 tests
- Existing BlackBox pytest group: PASS, 12 tests
- Main app import with scratch data: PASS

Observed non-blocking environment warnings:

- `PUBCAST_JWT_SECRET` is not set; app uses insecure default.
- EVO protocol partial import because `numpy` is unavailable.
- Sculptor falls back because OpenCV/Pillow are unavailable.
- CORS warning remains existing app configuration noise.

## v2.1.9 Remaining Work

- Route-level custody event proof should be added next for `/api/vault/files`, `/api/vault/open`, `/api/vault/lock`, and promotion routes.
- Integrity-violation detection from standalone v2.1.9 (`verify_custody_integrity`) has not yet been ported into the regular app's hardened vault engine.
- NotificationManager/Human Intent coupling from the standalone zip has not yet been integrated into the regular app.
- The standalone v2.1.9 BlackBox JSON event store was not imported because the regular app already has a compact append-only BlackBox witness. Any future merge should decide whether to keep the compact `.bbx` chain, add the JSON custody report layer, or bridge both.
- No delete/cleanup was performed. All work stayed inside the Playground canonical app folder.

## Iteration Wallet Lineage Intake

Additional user-supplied reference zips were copied/extracted under:

`codex_reference_intake\iteration_wallet_lineage_ref_20260627_090807`

Inputs:

- `C:\Users\hardc\Downloads\iteration_wallet_v2_complete.zip`
- `C:\Users\hardc\Downloads\IterationWallet_v2_1_3_NO_EXECUTE_RULE_PATCH.zip`
- `C:\Users\hardc\Downloads\IterationWallet_v2_1_4_RULE_SURFACE_CLEAN_PATCH.zip`
- `C:\Users\hardc\Downloads\IterationWallet_v2_1_6_HUMAN_INTENT_GATEKEEPER_PATCH.zip`
- `C:\Users\hardc\Downloads\IterationWallet_TASKBOOK_FOR_UNFAMILIAR_BOT_v216.zip`
- `C:\Users\hardc\Downloads\IterationWallet_DEPENDENCY_ANALYSIS_BLACKBOX_OUBLIETTE.md`
- `C:\Users\hardc\Downloads\IterationWallet_v216_DELIVERY_AUDIT.md`

Lineage findings:

- v2 complete still had permanent delete language/routes.
- v2.1.3 and v2.1.4 corrected that into a hard no-delete/no-execute rule.
- v2.1.6 hardened Human Intent and BlackBox inside `NotificationManager`.
- The dependency analysis corrected the taskbook order: BlackBox is part of Iteration Wallet and must be wired before Oubliette.
- v2.1.9 extracted/wired BlackBox and vault custody events in the standalone package.

Regular app implication:

- The regular app already had a compact append-only BlackBox witness.
- The regular app did not have Iteration Wallet's no-delete route law at the vault wrapper.
- The regular app now adapts the v2.1.9 custody coupling into the existing witness rather than importing the standalone JSON BlackBox wholesale.

## No-Delete Rule Correction

Changed:

- `modules\pubcast_vault.py`
- `blackbox_recorder\pubcast_event_adapter.py`
- `tests\test_pubcast_vault_blackbox_coupling.py`

Backups:

- `codex_backups\backup_pre_wallet_no_delete_route_20260627_090851`

What changed:

- Added `NO_DELETE_RULE` to `modules\pubcast_vault.py`.
- Changed public `DELETE /api/vault/files/{file_id}` wrapper route so it no longer calls `engine.delete_file()`.
- The route now records `vault.file_delete_blocked_no_delete_rule` to BlackBox and returns HTTP 403.
- Added BlackBox mapping for the blocked delete event as `WLT / DNY / F`.
- Added a route-level test proving the fake destructive engine method is not called.

Important remaining limitation:

- `modules\vault_engine_hardened.py` still contains the old destructive `delete_file()` method and old direct engine tests still cover it. The app wrapper now blocks public use, but a later pass should migrate or quarantine the engine-level destructive path itself and update tests to a no-delete contract.

## Custody Integrity Verification Hook

Changed:

- `modules\pubcast_vault.py`
- `blackbox_recorder\pubcast_event_adapter.py`
- `tests\test_pubcast_vault_blackbox_coupling.py`

Backups:

- `codex_backups\backup_pre_wallet_custody_verify_20260627_090630`

What changed:

- Added `PubCastVault.verify_custody_integrity()`.
- Added authenticated route `POST /api/vault/custody/verify`.
- The hook reads the existing vault integrity report and writes one BlackBox event:
  - `vault.custody_integrity_verified` for healthy reports.
  - `vault.custody_integrity_violation` for unhealthy reports.
- The hook is report-only. It does not repair, delete, overwrite, promote, or move custody files.

## Latest Verification Results

Commands run from the regular app folder:

```powershell
..\Python312\python.exe -m py_compile blackbox_recorder\pubcast_event_adapter.py modules\pubcast_vault.py tests\test_pubcast_vault_blackbox_coupling.py
..\Python312\python.exe -m unittest tests.test_pubcast_vault_blackbox_coupling -v
..\Python312\python.exe -m pytest tests\test_blackbox_event_language.py tests\test_blackbox_runtime_wiring.py -q
```

Results:

- Compile touched files: PASS
- `tests.test_pubcast_vault_blackbox_coupling`: PASS, 3 tests
- Existing BlackBox tests: PASS, 12 tests

Scratch route proof:

```powershell
$env:PUBCAST_DATA_DIR = (Join-Path (Resolve-Path '.\codex_backups') 'wallet_route_smoke_data_20260627_0911')
..\Python312\python.exe -c "from fastapi.testclient import TestClient; import main; c=TestClient(main.app); c.__enter__(); paths=sorted({r.path for r in main.app.routes if r.path.startswith('/api/vault')}); print('vault_route_count', len(paths)); print('has_custody_verify', '/api/vault/custody/verify' in paths); resp=c.post('/api/vault/custody/verify', headers={'X-Client-Id':'owner'}); print('custody_verify_status', resp.status_code); print('custody_verify_keys', sorted(resp.json().keys()) if resp.headers.get('content-type','').startswith('application/json') else 'not_json'); c.__exit__(None,None,None)"
```

Result:

- `vault_route_count`: 14
- `has_custody_verify`: True
- `custody_verify_status`: 200
- response keys: `blackbox_event_id`, `ok`, `report`

Observed non-blocking warnings are still environment/config warnings:

- Missing `PUBCAST_JWT_SECRET`.
- Missing `numpy`, OpenCV, and Pillow optional libraries.
- Existing CORS warning.

## Updated Recommended Next Tasks

1. Remove or disable the destructive `VaultEngine.delete_file()` path itself, not just the public wrapper route.
2. Add a closed catalog / safe metadata view for vault contents.
3. Add Human Intent receipt objects linked to BlackBox event hashes.
4. Add route-level tests for `/api/vault/open`, `/api/vault/lock`, add/remove, promote, custody verify, and blocked delete.
5. Defer Oubliette until the core no-delete/no-execute/BlackBox custody laws are fully proven in the regular app.

## Latest Temp Lineage Intake

User supplied the freshest loose Temp files they could find, copied non-destructively into:

`codex_reference_intake\iteration_wallet_temp_latest_ref_20260627_092504`

74 files were copied from:

`C:\Users\hardc\AppData\Local\Temp`

Important user clarification:

- These files were following a workbook/taskbook originally drafted by Codex and later tweaked by Claude.
- Treat the taskbook as the intent spine.
- Treat the latest tests/reports as evidence of the current implementation contract.

Observed filename/content mismatch:

- Several files named `v220` through `v224` contain older internal report headings (`v2.1.5` through `v2.1.9`).
- The loose Temp set also contains later concepts in code/tests, including private-alpha flow, receipts, scoped ceremony tokens, and closed catalog behavior.
- Therefore, filenames alone are not reliable; use file contents and tests as the source of truth.

Latest contract themes found:

- Closed catalog: closed/public surfaces expose safe metadata only.
- Human Intent Receipts: protected actions produce receipt records linked to BlackBox event hashes.
- Ceremony tokens: protected actions use scoped, short-lived tokens and avoid raw token leakage in reports.
- Private alpha runner: verifies closed catalog safety, no-delete/no-execute behavior, BlackBox chain, custody integrity, receipts, and no raw ceremony-token leakage.

## Closed Catalog Patch In Regular App

Changed:

- `modules\pubcast_vault.py`
- `tests\test_pubcast_vault_blackbox_coupling.py`

Backup:

- `codex_backups\backup_pre_wallet_closed_catalog_20260627_092611`

What changed:

- Added `PubCastVault.closed_catalog()`.
- Added a closed-catalog allowlist serializer.
- `GET /api/vault/files` now returns closed catalog metadata by default.
- Added mod-only `GET /api/vault/files/open` for the full operational record list.
- Closed catalog intentionally hides custody paths, hashes, notes, reviews, previews, output paths, and protected contents.
- Closed catalog also avoids listing the sensitive internal field names themselves; it exposes only omitted field categories and count.

Verification:

```powershell
..\Python312\python.exe -m py_compile modules\pubcast_vault.py tests\test_pubcast_vault_blackbox_coupling.py
..\Python312\python.exe -m unittest tests.test_pubcast_vault_blackbox_coupling -v
..\Python312\python.exe -m pytest tests\test_blackbox_event_language.py tests\test_blackbox_runtime_wiring.py -q
```

Results:

- Compile: PASS
- Vault/BlackBox/closed-catalog unittest file: PASS, 4 tests
- Existing BlackBox pytest file group: PASS, 12 tests

New closed-catalog test proves:

- `/api/vault/files` returns `view_mode: closed_catalog`.
- Protected contents are not exposed.
- Raw custody paths are not exposed.
- Hash/checksum values are not exposed.
- Protected note/preview/content values are not exposed.
- Full operational view remains separate at `/api/vault/files/open`.

## Revised Next Tasks After Temp Intake

1. Remove/disable `VaultEngine.delete_file()` itself and update old direct engine tests away from destructive delete.
2. Add Human Intent Receipt support in the regular app, linked to BlackBox event ids/hashes where available.
3. Add a scoped ceremony-token ledger or adapter for regular-app vault operations.
4. Expand route-level proof for add/remove/open/lock/promote/custody verify/open files view.
5. Build a private-alpha runner for the regular app that checks no-delete, closed catalog, BlackBox chain, receipts, custody integrity, and no raw-token leakage.

## Completion Taskbook Created

Created and expanded:

`docs\ITERATION_WALLET_BLACKBOX_OUBLIETTE_COMPLETION_TASKBOOK_20260627.md`

Purpose:

- Stop one-message-at-a-time drift.
- Treat Iteration Wallet as a standalone portable product.
- Treat PubCast vault code as compatibility/proving surface until the product adapter is ready.
- Finish the three remaining major sections in order:
  1. Standalone Iteration Wallet.
  2. Full BlackBox integration.
  3. Oubliette no-execute/no-delete inspection fence.
- Then integrate the finished trio back into PubCast through a narrow adapter.

The taskbook now includes:

- Product Law.
- Source Basis.
- Three legitimate completion paths.
- Selected hybrid workflow.
- Full phase board.
- Autonomous work queue.
- Section acceptance gates.
- Definition of Done.
- Stop conditions.

Selected path:

Use the hybrid path. Keep the current PubCast wrapper stable, but finish Iteration Wallet as the standalone product and then connect PubCast through an adapter. Do not keep growing the wrapper into a second wallet product.

Immediate next execution point:

1. Disable/quarantine engine-level `VaultEngine.delete_file()` as a product action.
2. Create the clean standalone wallet work folder inside Playground.
3. Normalize the latest Temp/reference intake into a real `iteration_wallet/` package.
4. Add the product law file to that standalone package.
5. Start Human Intent Receipts and ceremony-token wiring after no-delete/no-execute is locked.

## Work Rules And Product Standard Locked

The completion taskbook and continuation kit now explicitly state:

- This is not practice. This is the product.
- Work must be non-destructive.
- No delete.
- If a file appears obsolete, dangerous, duplicated, or unsuitable for active use, put it in a clearly named `rubish` quarantine folder for user review instead of deleting it.
- Prefer copies/backups before permanent edits.
- Do not silently overwrite Prime, Cradle, Vault, BlackBox, Oubliette, taskbook, handoff, or canon files.
- Keep secrets, BYOK material, private memory, and unrelated personal files out of scope.
- Build to a world-class, precedent-setting, gold-standard engineering bar: clear contracts, deterministic engine-first behavior, auditable custody, honest proof, and no fake completion claims.

## Continuation Kit Created

Created portable continuation kit:

`C:\Users\hardc\OneDrive\Documents\Playground\PUBCAST_AI_HANDOFF_KITS\IterationWallet_BlackBox_Oubliette_Continuation_2026-06-27_104004`

Created zip:

`C:\Users\hardc\OneDrive\Documents\Playground\PUBCAST_AI_HANDOFF_KITS\IterationWallet_BlackBox_Oubliette_Continuation_2026-06-27_104004.zip`

Verified:

- Zip exists.
- Size: 1,256,748 bytes / 1.20 MB.
- Zip entries: 320.
- Includes `README_CONTINUE_NOW.md`.
- Includes completion taskbook.
- Includes current handoff.
- Includes focused current app files.
- Includes local reference intake folders.
- Includes explicit work rules: no delete, use `rubish` quarantine, non-destructive work, product-grade engineering standard.

Backup before handoff/rule updates:

`codex_backups\backup_pre_work_rules_gold_standard_20260627_1048`

Backup before kit handoff update:

`codex_backups\backup_pre_continuation_kit_handoff_20260627_1040`

## Standalone Wallet Setup And No-Delete Scan Pass

Created standalone work folder:

`C:\Users\hardc\OneDrive\Documents\Playground\Iteration_Wallet_Standalone_20260627_1420`

Dedicated handoff:

`handoffs\HANDOFF_STANDALONE_WALLET_SETUP_SCAN_20260627.md`

What changed:

- Re-verified IW-001 live engine no-delete patch by static inspection.
- Copied latest reference intake into standalone folder without modifying originals.
- Normalized active `iteration_wallet\` package and `tests\` folder.
- Added `PRODUCT_LAWS.md`, `README.md`, `BLOCKERS.md`, local `HANDOFF.md`, and package `__init__.py`.
- Moved mislabeled HTML `ceremony.py` to `docs\ceremony_surface_reference.html`.
- Added real Python `iteration_wallet\ceremony.py` scoped ceremony-token primitives.
- Patched `iteration_wallet\vault.py` notification suppression from delete/unlink to quarantine move.
- Patched `iteration_wallet\identity.py` hook uninstall from delete/unlink to quarantine move.
- Moved misclassified runner/test files and unsafe copied receipt test into local `rubish` folders.
- Added safe non-executing `iteration_wallet\private_alpha_runner.py` readiness report scaffold.

Proof:

- Standalone package compile: PASS.
- Minimal package import: PASS.
- Active package/tests destructive pattern scan for `unlink`, DB delete, permanent-destroy wording, `os.system`, `eval`, and `exec`: no matches after quarantine/patches.

Honest status:

- Standalone folder and normalized package are real artifacts.
- Standalone package is importable.
- Broad runtime tests were not run because copied historical tests still need no-delete-safe fixture review.
- Human Intent Receipts, ceremony persistence, full BlackBox integration, Oubliette, and PubCast adapter remain incomplete.

## MVP Normalization Proof Checkpoint - 2026-06-28

Completed inside the standalone Iteration Wallet workspace.

Changed/verified:

- Active package filenames now match module responsibilities.
- `app.py`, `guard.py`, and `vault.py` are thin compatibility wrappers only.
- `blackbox.py` owns BlackBox evidence chain and Human Intent receipt primitives.
- `vault_v21.py` owns Vault, Cradle/Prime, Archive, Removed staging, and quarantine records.
- `ceremony.py` owns ceremony token primitives.
- `gatekeeper.py` owns protected-action policy.
- `identity.py` owns actor/session identity shape.
- Temporary/non-MVP active modules `private_alpha_runner.py` and `key_derivation.py` were preserved under `rubish` and removed from active package.
- Added `docs/MVP_ARCHITECTURE_AUDIT_20260628.md`.
- Added/updated `handoffs/HANDOFF_MVP_NORMALIZATION_20260628.md`.
- Updated `tests/test_spine_static.py` for active MVP structure.

Proof run:

```powershell
python -m py_compile iteration_wallet\*.py tests\test_spine_static.py
```

Static marker scan of active `iteration_wallet\*.py`:

- PASS no `.unlink(`
- PASS no `os.remove`
- PASS no `shutil.rmtree`
- PASS no `@app.delete`
- PASS no `subprocess.`
- PASS no `eval(`
- PASS no `exec(`

Generated `__pycache__` folders were moved non-destructively into:

`rubish\generated_pycache_20260628_mvp_proof`

Status: MVP normalization PASS. Feature completion remains PARTIAL until receipt wiring and Oubliette boundary documentation are closed.
