﻿# Safe Defaults And Failure Modes

## Safe Defaults
- No deletion anywhere.
- No original assets overwritten during incorporation planning.
- Mocap off unless explicitly enabled.
- Literal creature retargeting off by default; adapted/species-respecting motion is default.
- Visual patch auto-approve off by default.
- Temporary object adaptations regress after avatar leaves; permanent save requires approval or explicit auto-approve.
- TTS autoplay off by default.
- Spatial audio conservative by default.
- Music ducking enabled conservatively when dialogue is active.
- Mic monitoring off or low by default to avoid feedback.
- Safe Console has no autoplay and no heavy rendering dependency.
- Rust animation engine is do-not-wire-yet until bridge path is stable.

## Failure Modes And Recovery Actions

| Failure | Menu Location | Safe Recovery |
|---|---|---|
| Avatar twisted/wonky | Character > Skeleton/Motion, Help > Recovery | Stop animations, reset pose, pause mocap, rebind skeleton |
| Avatar missing | Character, Help, Safe Console | Reload avatar, check manifest, verify GLB path |
| Manny/Sheila not moving | Performance > Motion Debug | Check mapped bones, smoke payload, registerAvatar call |
| Motion loops | Performance, Help | Clear animation queue, stop motion loop, reset pose |
| Audio loops | Audio, Help, Safe Console | Stop all sounds, clear TTS queue, restart program audio |
| Mic wrong/no signal | Audio > Mic, Help | Re-scan devices, select mic, run preflight |
| Background missing | Scene/Room, Safe Console | Reload assets, fallback background, manifest check |
| Recording stuck | Recording/Show, Help | Emergency save, stop safely, export session summary |
| WebSocket disconnected | Help, Director/Advanced | Reconnect socket, resync state |
| Visual patch bad | Visual Patch Kit | Remove temporary patch, revert to last approved |
| Chair/object adaptation unwanted | Scene/Room, Visual Patch Kit | Regress temporary object, clear cache item, do not save permanently |
| Menu inaccessible | Safe Console | Open minimal recovery page, ask Pub Manager |

## Ready For Incorporation Gate
A system is ready only if it has:
- file present or scaffold explicitly planned
- menu location
- role/permission model
- status/debug view
- recovery action
- test or smoke test
- safe default
- handoff note
