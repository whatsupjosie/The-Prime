﻿# Missing Contracts And Test Plan

## GLB Motion Bridge
Missing/needed:
- window.PubcastGLBMotionConsumer global
- registerAvatar(avatarId, gltfScene, options)
- consumePayload({ avatar_id, commands })
- bindings.get(id).debugStatus()
- event listener for pubcast avatar motion commands
- Manny/Sheila bone aliases matching Root/Pelvis/Spine_01/etc.
- zero-rotation bug fix: do not use value || fallback for rotations

Tests:
- Node syntax check for consumer.
- consumePayload applies head/spine rotation to mocked bones.
- zero rotation returns a bone to neutral.
- unknown bones are ignored without crashing.
- debugStatus reports mapped/missing bones.

## GLB Motion Retargeter
Missing/needed:
- modules/glb_motion_retargeter.py
- canonical bone list
- Manny/Sheila alias table
- clamp unsafe rotations
- drop unknown bones
- normalize command kinds: mocap_pose, overlay, procedural_animation, hold

Tests:
- clamps rotations over configured safe range.
- preserves valid canonical bones.
- drops unknown bones.
- handles empty/malformed payload safely.

## Program Audio Runtime
Missing/needed:
- browser runtime for program audio buses
- dialogue/music/SFX/VTR buses
- spatial/proximity panning from avatar/object position
- music ducking under dialogue
- stop-all-sounds recovery action
- TTS queue status and reset
- output status visible in menu

Tests:
- creates buses without autoplay side effects.
- stopAll clears active sources/queues.
- spatial pan/volume changes with distance.
- ducking lowers music while dialogue active.

## Menu Coverage Contract
Missing/needed:
- machine-readable menu coverage manifest
- every runtime system has menu location, role, debug/status, recovery action

Tests:
- all systems in inclusion list have a menu location.
- fragile systems have recovery actions.
- Help/Recovery and Safe Console are always listed.

## Safe Console
Missing/needed:
- static/safe_console.html or route /safe-console
- no dependency on images/canvas/audio/avatar rendering
- health buttons call safe endpoints

Tests:
- static file exists.
- contains buttons/links for Pub Manager, stop sounds, asset check, server health.
- no required image assets.

## Recording Pipeline
Needed hardening:
- clarify metadata recording vs final mixed audio/video capture.
- status endpoint visible in Help and Recording menus.
- issue report includes active recording id.
- emergency save path is visible.

Tests:
- recording status route works.
- session summary is safe when no session active.
- marker endpoint validates label.

## Pub Manager Recovery
Missing/needed:
- diagnostic intent contract
- safe action allowlist
- status aggregation endpoint
- issue report endpoint

Tests:
- status response includes runtime, avatar, audio, recording, assets.
- unsafe action requires approval.
- safe action returns plain-language result.
