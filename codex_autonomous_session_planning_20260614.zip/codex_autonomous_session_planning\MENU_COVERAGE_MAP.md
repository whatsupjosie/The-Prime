﻿# Player-First Menu Coverage Map

Rule: if a system can affect the show, avatar, audio, recording, room, output, safety, or recovery, it needs a reachable menu/control surface.

## 1. Play / Stage
Audience: player, host, guest

Minimum controls:
- Enter/leave room
- Move avatar
- Sit/stand/walk/emote
- Interact with nearby objects
- Camera view preference
- Basic chat/voice controls

Status/debug:
- Current room
- Network/session state
- Avatar loaded/not loaded
- Audio output active/muted

Recovery:
- Reset my position
- Reset my avatar pose
- Rejoin room
- Reload current view
- Ask Pub Manager

## 2. Character
Audience: player, avatar owner, director

Minimum controls:
- Choose avatar
- Outfit/appearance
- Voice choice
- Animation style
- Inventory
- Creature/body profile allowances

Advanced controls:
- Motion retarget profile
- Literal vs adapted motion toggle
- Body limits/skeleton capabilities
- Tail/wing/nonhuman profile flags

Status/debug:
- GLB loaded
- Skeleton mapped bones
- Current animation source
- Motion confidence

Recovery:
- Reload avatar
- Rebind skeleton
- Stop avatar animations
- Return to neutral pose

## 3. Scene / Room
Audience: player, host, director, admin

Minimum controls:
- Choose room/location
- Lighting preset
- Background image/skybox
- Props/chairs/tables
- Save room setup

Advanced controls:
- Sound zones
- object interaction anchors
- chair/seat adaptation rules
- visual patch objects kept in room

Status/debug:
- Asset load health
- Missing backgrounds
- Missing prop files
- Current room version

Recovery:
- Reload room assets
- Use fallback background
- Rebuild room manifest
- Reset object positions

## 4. Audio
Audience: player, host, audio operator, director

Minimum controls:
- Output mute/volume
- Character voice volume
- Background music volume
- UI/button SFX volume
- Spatial audio toggle

Mic/input controls:
- Mic device
- Mic profile
- EQ/compressor/pitch preset
- Cough gate
- Input monitor

Program audio controls:
- Dialogue bus
- Music bus
- SFX bus
- VTR bus
- Duck music under speech
- Spatial/proximity voice position

Status/debug:
- Mic device selected
- Audio matrix channels
- Program audio active
- Looping/duplicate playback detector

Recovery:
- Stop all sounds
- Restart program audio
- Reset TTS queue
- Disable autoplay TTS
- Recheck mic devices

## 5. Performance
Audience: player, performer, director, avatar AI with permission

Minimum controls:
- Animation presets
- Mocap on/off
- Sit/stand/walk/fall/get-up tests
- Gesture/emote triggers

Advanced controls:
- Motion retarget mode
- Literal vs species-adapted motion
- Layer weights: base, overlay, mocap, hold
- Object contact correction

Status/debug:
- Motion event stream
- Current animation layer stack
- Bone mapping health
- Mocap confidence/dropout

Recovery:
- Stop motion loop
- Clear animation queue
- Pause mocap
- Reset pose
- Rebind GLB consumer

## 6. Visual Patch Kit
Audience: player, director, avatar AI with permission, admin

Minimum controls:
- Highlight problem area
- Describe issue
- 2D/3D mode
- Load related object/avatar file
- Preview temporary patch
- Approve/reject

Advanced controls:
- Auto-approve toggle
- Bake voxel patch to mesh
- Save patch to inventory
- Keep patch in room
- Tail/wing/body-shape allowances
- Object-specific usability adaptation

Status/debug:
- Patch state: proposed, temporary, approved, baked, cached
- Affected avatar/object
- Expiration/regression timer

Recovery:
- Remove temporary patch
- Revert to last approved patch
- Clear failed patch proposal

## 7. Recording / Show
Audience: host, director, recorder, admin

Minimum controls:
- Start/pause/stop recording
- Add marker
- Camera switch
- Program/live status
- Export session data/EDL

Advanced controls:
- Recording profile
- Source selection
- Program audio capture status
- Storage/cache status
- Emergency save

Status/debug:
- Active session id
- Timer
- Markers count
- Camera switches count
- Recording output paths

Recovery:
- Emergency save
- Stop recording safely
- Export issue report
- Check storage
- Rebuild session summary

## 8. Director / Advanced
Audience: director, Pub Manager, admin

Minimum controls:
- Camera/switcher
- Chyron
- Teleprompter
- VTR
- AI director permissions
- Avatar AI permissions

Advanced controls:
- Runtime events
- Automation
- Scene logic
- Debug overlays
- System health

Status/debug:
- Event bus activity
- WebSocket status
- Runtime flags
- Route health

Recovery:
- Reconnect WebSocket
- Re-sync scene state
- Safe mode
- Last known good state

## 9. Help / Recovery
Audience: everyone; always reachable

Minimum controls:
- Ask Pub Manager
- System status
- Stabilize Show
- Stop all sounds
- Stop all animations
- Reset avatar pose
- Reload current room
- Reconnect WebSocket
- Export issue report

Status/debug:
- Recent errors
- Failed asset loads
- Active loops
- Broken subscriptions/events
- Audio/motion/recording status

Safe default:
- Recovery actions are non-destructive and preserve chat/session/recording metadata.

## 10. Settings / Safety
Audience: player, host, admin

Minimum controls:
- Accessibility
- Input devices
- Storage/cache
- Permissions
- Auto-approve settings
- Reset current object/avatar state
- Diagnostics

Status/debug:
- Permission state
- Cache expiration rules
- Storage usage

## 11. Out-of-Session Safe Console
Audience: player, host, admin, Pub Manager

Route/file candidate:
- /safe-console
- /recovery
- static/safe_console.html

Requirements:
- Plain HTML/CSS/minimal JS.
- No images required.
- No audio autoplay required.
- No avatar/canvas dependency.
- Can run when normal game/show view is broken.

Controls:
- Check server health
- Check WebSocket
- Check missing assets
- Check avatar manifest
- Check audio devices
- Stop stuck sounds
- Clear temporary browser session state
- Open recovery-safe stage
- Ask Pub Manager
- Export issue report
