﻿# Build Inclusion List

Purpose: define what should be considered for the next PubCast incorporation pass without wiring risky systems blindly.

## Definitely Include In The Build Spine

### Avatar / Motion / Mocap
- pubcast_codebase/static/avatar_glb_motion_consumer.js
  - Existing lower-level GLB bone motion consumer.
  - Must be upgraded or wrapped into window.PubcastGLBMotionConsumer.
- pubcast_codebase/modules/avatar_skeleton_system.py
  - Canonical PubCast skeleton reference and retargeting vocabulary.
- pubcast_codebase/modules/avatar_performer.py
  - Performer binding, mocap retargeting, smoothing, animation stack, dropout recovery.
- pubcast_codebase/modules/mocap_precision.py
  - High precision webcam mocap provider; optional at runtime, important to preserve.
- pubcast_codebase/modules/mocap_integration.py
  - Mocap streaming API/integration layer.
- pubcast_codebase/static/animation_presets_complete.js
  - Browser-side naturalistic animation vocabulary.
- pubcast_codebase/modules/wired/animation_presets_complete.py
  - Server-side matching animation vocabulary.
- pubcast_codebase/data/avatars/manifest.json
  - Source of truth for Manny and Sheila GLB assets.
- pubcast_codebase/assets/avatar/manny.glb
- pubcast_codebase/assets/avatar/sheila.glb
- pubcast_codebase/tools/audit_glb_rigs.mjs
  - Rig health diagnostic.

### Recording / Studio
- pubcast_codebase/modules/recording.py
  - Recording service/session metadata API.
- pubcast_codebase/modules/recording_pipeline.py
  - Timeline/event/chat/camera/marker logging; writes session.json and EDL.
- pubcast_codebase/modules/recording_pipeline_routes.py
  - Export/status/marker routes.
- pubcast_codebase/modules/capture.py
  - Capture support.
- pubcast_codebase/modules/studio_control.py
  - Preflight, audio matrix, emergency save, studio state.
- pubcast_codebase/modules/studio_websocket.py
  - Studio websocket bridge.
- pubcast_codebase/static/control_stations.js
  - Recording station, station tabs, VTR, chyron, teleprompter, audio station scaffolding.

### Menu / Control / Player Access
- pubcast_codebase/static/control.html
- pubcast_codebase/static/control_room.html
- pubcast_codebase/static/studio_control_room.html
- pubcast_codebase/static/stage.html
- pubcast_codebase/static/stage_3d.html
- pubcast_codebase/static/pubworld_stage.html
- pubcast_codebase/modules/runtime_control_routes.py
- pubcast_codebase/modules/stage_compat_routes.py

### Audio / Voice
- pubcast_codebase/static/audio.js
  - Audio matrix UI helpers and studio websocket connection.
- pubcast_codebase/static/tts.js
  - Browser TTS and optional server TTS call shape.
- pubcast_codebase/static/mic_profiles.js
- pubcast_codebase/static/mic_processor.js
- pubcast_codebase/static/mic_device_picker.js
- pubcast_codebase/modules/mic_routes.py
- pubcast_codebase/modules/audio_devices.py
- pubcast_codebase/modules/evo/voice_characters.py

### Visual Patch / Voxel Support
- pubcast_codebase/modules/visual_patch_approval_bridge.py
- pubcast_codebase/modules/visual_patch_voxel_adapter.py
- pubcast_codebase/modules/voxel_set_contract.py
- pubcast_codebase/modules/voxel_asset_manager.py
- pubcast_codebase/modules/voxel_llm_adapter.py
- pubcast_codebase/modules/voxel_studio_integration.py
- pubcast_codebase/tests/test_visual_patch_approval_bridge.py
- pubcast_codebase/tests/test_voxel_set_contract.py

### Runtime Health / Compatibility
- pubcast_codebase/modules/runtime_compat_bootstrap.py
- pubcast_codebase/modules/session_runtime.py
- pubcast_codebase/tests/test_runtime_compat_bootstrap.py
- pubcast_codebase/tests/test_runtime_control_routes.py
- pubcast_codebase/tests/test_stage_compat_routes.py

## Include As Diagnostics / Support
- pubcast_codebase/static/avatar_walk_test.html
- pubcast_codebase/static/js/avatar_glb_walk.js
  - Proof that Manny/Sheila GLBs can load and move as whole objects. Not skeletal animation.
- pubcast_codebase/tests/test_avatar_manifest_contract.py
- pubcast_codebase/tests/test_choreography_controller_contract.py
- pubcast_codebase/tests/test_choreo_controller.py
- pubcast_codebase/tests/test_cast_staged_integration.py

## Near-Next, Do Not Wire First
- pubcast_codebase/rust_crate/src/skeleton.rs
- pubcast_codebase/rust_crate/src/avatar_animation_system.rs
- pubcast_codebase/rust_crate/src/animation_data_library.rs
- pubcast_codebase/rust_crate/src/avatar_fitting_system.rs
- pubcast_codebase/rust_crate/src/complete_animation_controller.rs

Reason: likely valuable for high-end animation, fitting, blend trees, LOD, and state machines, but should not be force-wired until the JS/Python motion bridge is visibly alive.

## Missing Required Systems
- static/avatar_motion_runtime.js or equivalent browser bridge from PubCast events to GLB consumer.
- modules/glb_motion_retargeter.py with clamp/drop/normalize behavior.
- tests/test_glb_motion_retargeter.py.
- tests/test_avatar_glb_motion_consumer_node.js.
- static/program_audio_runtime.js or equivalent program audio mixer.
- modules/program_audio.py or equivalent server-side program-audio contract.
- tests/test_program_audio_contract.py.
- static/safe_console.html or equivalent out-of-session recovery page.
- Pub Manager diagnostic/recovery interface contract.
- Menu coverage contract test.
