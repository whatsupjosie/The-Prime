﻿# 8-Round Debugging, Troubleshooting, And Hardening Workshop

Scope: non-destructive planning and validation for PubCast BigZip incorporation. No deletes, no installs, no system changes, no original-file rewrites.

## Round 1: File Presence And Provenance
Goal: confirm required files exist or are explicitly missing.

Checks:
- Inventory avatar/mocap/recording/audio/menu/recovery/visual patch files.
- Create provenance map from source build to build inclusion category.
- Mark missing required contracts.

Pass criteria:
- Every known system is classified as include, diagnostic/support, near-next, missing, or do-not-wire-yet.

## Round 2: Runtime Contract Names
Goal: prevent event name mismatches.

Checks:
- Motion event names.
- Studio websocket event names.
- Recording event names.
- Menu button/action ids.
- Pub Manager status/action names.

Pass criteria:
- Each pipeline has a canonical event contract or a listed gap.

## Round 3: Avatar/Motion Skeleton Bridge
Goal: make Manny/Sheila motion visible without breaking rigs.

Checks:
- GLB consumer parses.
- Manny/Sheila GLB rigs audit cleanly.
- Bone aliases match Manny/Sheila joint names.
- zero-rotation handling flagged.
- Missing PubcastGLBMotionConsumer wrapper listed.

Pass criteria:
- Clear path from payload to GLB bones and tests listed.

## Round 4: Recording Pipeline
Goal: separate metadata recording from final program capture.

Checks:
- Recording modules/routes exist.
- Control room recording UI exists.
- EDL/session export path exists.
- Final mixed AV capture gap identified.

Pass criteria:
- Recording status/recovery/menu coverage is defined.

## Round 5: Program Audio And Mic Safety
Goal: include audio without destabilizing fragile mic authority.

Checks:
- Mic input pipeline identified.
- TTS/dialogue pipeline identified.
- Audio matrix identified.
- Missing program audio runtime defined.
- Stop-all-sounds recovery action defined.

Pass criteria:
- Mic/input and program/playback are separate lanes.

## Round 6: Menu Coverage And Safe Console
Goal: every adjustable system has a player-first access point.

Checks:
- Player-first menu map exists.
- Every fragile pipeline has recovery menu item.
- Safe Console requirements defined.
- Help/Pub Manager path defined.

Pass criteria:
- Nothing important is only reachable from console/code.

## Round 7: Visual Patch, Object Adaptation, Cache Rules
Goal: preserve physical-world compensation without permanent accidental changes.

Checks:
- Visual patch modules identified.
- Approval bridge identified.
- Temporary object adaptation rules defined.
- Cache/regression/inventory/keep-in-room behavior documented.

Pass criteria:
- Adaptations are reversible unless explicitly approved.

## Round 8: Final Readiness Gate
Goal: decide what is ready for incorporation.

Checks:
- Inclusion list complete.
- Missing contracts/test plan complete.
- Validation outputs saved.
- Concerns and suggestions recorded.
- Handoff written.

Pass criteria:
A system is ready only if it has:
- file present or scaffold listed
- menu access
- status/debug view
- recovery action
- test/smoke test
- safe default

## Workshop Output Files
- SESSION_LEDGER.md
- BUILD_INCLUSION_LIST.md
- MENU_COVERAGE_MAP.md
- RECOVERY_AND_PUB_MANAGER_CONTRACT.md
- MISSING_CONTRACTS_AND_TEST_PLAN.md
- FILE_PROVENANCE_MAP.md
- SAFE_DEFAULTS_AND_FAILURE_MODES.md
- VALIDATION_SUMMARY.md
- COMPLETE_HANDOFF.md
