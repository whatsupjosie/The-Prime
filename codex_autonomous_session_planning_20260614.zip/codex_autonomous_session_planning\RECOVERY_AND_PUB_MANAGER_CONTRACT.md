﻿# Recovery And Pub Manager Contract

Purpose: make help available both inside the show and outside the broken show.

## Pub Manager Role
The Pub Manager is the top diagnostic/helper bot. It is not a character performer by default. It can explain system state, recommend actions, perform safe recovery, and walk the user through unsafe/manual steps.

## Status Inputs Pub Manager Should See
- Runtime health summary
- WebSocket state
- Current room/stage asset status
- Avatar load state
- GLB skeleton mapping health
- Motion/mocap state
- Animation queue/layer state
- Mic device and cough gate state
- Program audio state
- TTS queue state
- Recording session state
- Visual patch temporary/permanent state
- Storage/cache state
- Recent errors

## Safe Actions Pub Manager Can Perform
- Stop all program sounds
- Stop all animation loops
- Pause mocap input
- Reset avatar pose to neutral
- Reconnect WebSocket
- Reload current room assets
- Reload current avatar
- Run asset manifest check
- Run skeleton mapping check
- Check recording pipeline status
- Add a diagnostic marker to recording session
- Export issue report
- Open safe console

## Actions Requiring User/Admin Approval
- Permanently saving visual patches
- Installing dependencies
- Deleting anything
- Replacing original assets
- Changing system audio settings outside PubCast
- Changing Windows/system settings
- Publishing/uploading/sharing logs externally

## In-Session Help Menu
Always reachable from the main menu and control room.

Controls:
- Ask Pub Manager
- Stabilize Show
- Stop All Sounds
- Stop All Animations
- Reset Avatar Pose
- Reload Room Assets
- Reconnect Network/WebSocket
- Check Recording
- Check Mic
- Check Avatar Skeleton
- Export Issue Report

## Out-of-Session Safe Console
Minimal recovery page or route. It should work even if images, avatar rendering, canvas, fancy CSS, or audio fail.

Controls:
- Server alive?
- WebSocket alive?
- Asset manifest check
- Missing backgrounds/images check
- Manny/Sheila GLB check
- Audio device check
- Stop stuck sounds
- Clear temporary client session state
- Open safe stage
- Open normal stage
- Ask Pub Manager
- Export issue report

## Failure Mode Coverage

### Avatar Goes Wonky
Expose under Character > Skeleton/Motion Status and Help > Recovery.
Safe actions: stop animations, reset pose, pause mocap, rebind skeleton, reload avatar.

### Audio Loops Or Will Not Stop
Expose under Audio > Program Audio and Help > Recovery.
Safe actions: stop all sounds, clear TTS queue, restart program audio, disable autoplay TTS.

### Video/Camera/Stage Fails
Expose under Recording/Show and Help > Recovery.
Safe actions: reload current view, reconnect WebSocket, switch to fallback stage, export issue report.

### Background/Images Do Not Load
Expose under Scene/Room and Safe Console.
Safe actions: reload assets, check manifest, switch fallback background, show missing path.

### Recording Stuck
Expose under Recording/Show and Help > Recovery.
Safe actions: emergency save, stop session, export session.json/EDL, add diagnostic marker.

### Visual Patch Looks Bad
Expose under Visual Patch Kit.
Safe actions: remove temporary patch, revert to last approved patch, keep original object untouched.

### Object Adaptation Stuck Around
Expose under Scene/Room and Visual Patch Kit.
Safe actions: regress temporary object, cache then remove, save permanent only with approval.

## Issue Report Contents
- Timestamp
- Current route/page
- Browser status if available
- Recent frontend errors
- Recent backend status endpoints
- Asset failures
- Active avatar ids
- Active audio buses
- Active recording id
- Recent recovery actions
- Non-sensitive config summary
