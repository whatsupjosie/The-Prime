﻿# File Provenance Map

All source files are from the existing BigZip consolidated codebase unless marked missing. This map is for planning only; no originals were changed.

| System | Source File | Role | Include Status | Notes |
|---|---|---|---|---|
| GLB motion | pubcast_codebase/static/avatar_glb_motion_consumer.js | runtime JS | include but upgrade/wrap | Existing class export; needs window.PubcastGLBMotionConsumer bridge |
| GLB retargeter | modules/glb_motion_retargeter.py | server/tool helper | missing required | Needed for clamp/drop/normalize |
| GLB consumer test | tests/test_avatar_glb_motion_consumer_node.js | test | missing required | Needed for payload-to-bone smoke test |
| GLB retargeter test | tests/test_glb_motion_retargeter.py | test | missing required | Needed for clamp/drop behavior |
| Skeleton reference | pubcast_codebase/modules/avatar_skeleton_system.py | canonical skeleton | include | Standard PubCast skeleton and retargeting names |
| Performer runtime | pubcast_codebase/modules/avatar_performer.py | mocap/retarget/blend | include | Strong hardening notes already present |
| Mocap precision | pubcast_codebase/modules/mocap_precision.py | live capture | include optional runtime | Do not require camera/device to start app |
| Mocap integration | pubcast_codebase/modules/mocap_integration.py | streaming API | include guarded | Must feed canonical motion events |
| Manny GLB | pubcast_codebase/assets/avatar/manny.glb | asset | include | 89-joint skinned rig, no embedded animations |
| Sheila GLB | pubcast_codebase/assets/avatar/sheila.glb | asset | include | Matches Manny joint order |
| Avatar manifest | pubcast_codebase/data/avatars/manifest.json | asset manifest | include | Currently marks skeleton pending retarget map |
| Rig audit | pubcast_codebase/tools/audit_glb_rigs.mjs | diagnostic | include | Useful for build verification |
| Animation presets JS | pubcast_codebase/static/animation_presets_complete.js | browser animation vocab | include | 35 naturalistic presets |
| Animation presets Py | pubcast_codebase/modules/wired/animation_presets_complete.py | server animation vocab | include | AI/director can choose intent |
| Recording service | pubcast_codebase/modules/recording.py | recording metadata | include | Recording profiles/sessions/artifacts |
| Recording pipeline | pubcast_codebase/modules/recording_pipeline.py | session timeline | include | Logs chat/camera/markers/events; writes session.json and EDL |
| Recording routes | pubcast_codebase/modules/recording_pipeline_routes.py | API | include | Export/status/marker endpoints |
| Capture | pubcast_codebase/modules/capture.py | capture support | include | Needs separate validation later |
| Studio control | pubcast_codebase/modules/studio_control.py | control backend | include | Preflight, audio matrix, emergency save |
| Studio websocket | pubcast_codebase/modules/studio_websocket.py | WS bridge | include | Needed for control room/live updates |
| Control HTML | pubcast_codebase/static/control.html | menu/control UI | include | Many controls, needs player-first consolidation |
| Control room | pubcast_codebase/static/control_room.html | control room UI | include | Hotspots, recorder, switcher, audio controls |
| Control stations | pubcast_codebase/static/control_stations.js | station UI JS | include | Recorder/chyron/prompter/VTR/audio station hooks |
| Stage | pubcast_codebase/static/stage.html | stage UI | include | Browser recording fallback only, not final capture |
| Stage 3D | pubcast_codebase/static/stage_3d.html | 3D stage | include diagnostic/runtime | Needs later integration with GLB motion |
| Mic profiles | pubcast_codebase/static/mic_profiles.js | mic UI/client state | include guarded | Fragile authority lane |
| Mic processor | pubcast_codebase/static/mic_processor.js | Web Audio input FX | include guarded | Do not casually rewrite |
| Mic picker | pubcast_codebase/static/mic_device_picker.js | device UI | include | Supports input choice |
| Mic routes | pubcast_codebase/modules/mic_routes.py | mic API | include | Cough gate/profile persistence |
| Audio devices | pubcast_codebase/modules/audio_devices.py | server device API | include optional | sounddevice guarded |
| Audio UI | pubcast_codebase/static/audio.js | audio matrix UI | include | Studio WS/audio meter helpers |
| TTS | pubcast_codebase/static/tts.js | dialogue playback | include | Browser and optional server TTS |
| Voice characters | pubcast_codebase/modules/evo/voice_characters.py | voice metadata | include | Needs more review later |
| Program audio | static/program_audio_runtime.js | runtime mixer | missing required | Dialogue/music/SFX/spatial/ducking/stop-all |
| Program audio server | modules/program_audio.py | API/contract | missing required | Optional but recommended |
| Visual patch approval | pubcast_codebase/modules/visual_patch_approval_bridge.py | approval API | include guarded | Already has tests |
| Visual patch voxel adapter | pubcast_codebase/modules/visual_patch_voxel_adapter.py | voxel patch bridge | include guarded | Do not fully wire until runtime ready |
| Voxel contract | pubcast_codebase/modules/voxel_set_contract.py | data contract | include | Already has tests |
| Voxel asset manager | pubcast_codebase/modules/voxel_asset_manager.py | asset/cache | include guarded | Needs cache menu coverage |
| Safe console | static/safe_console.html | recovery UI | missing required | Must be minimal and independent |
| Pub Manager recovery | TBD | diagnostic AI | missing required | Needs status/action contract |
