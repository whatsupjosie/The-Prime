# Pubcast 2i — Architecture Assessment & Roadmap
## Updated for v26 + Cartridge Model

**Date:** August 13, 2026

---

## A. CURRENT STATE

### WORKING (Status A — functional in browser today)

35 features fully working. The core editor is production-solid:

- Solo Write mode with live typing, line numbers, red margin
- Save/Open via File System Access API with download fallback
- IndexedDB autosave (3-slot rotation, 5-minute interval) + restore modal
- 60-step undo/redo (Ctrl+Z/Y)
- Find & Replace across committed + buffer + solo textarea
- Export to Markdown with chapter headings
- Drag & drop for .2i documents and .txt/.md reference imports
- Full keyboard shortcut set (Ctrl+S/Z/Y/F/E/Enter/G, Escape)
- Collab mode: draft buffer, approve to manuscript, accept/reject AI lines
- Line locking, chapter management, context menu with edit/insert/delete
- Reference archive with modal-based CRUD, search, filter, viewer overlay
- LLM config modal with 4 providers, field switching, test connection
- Playback/read-aloud via SpeechSynthesis with speed slider
- Manuscript intelligence schema (v5) with document migration
- Chapter hash change detection (djb2)
- Continuity flag UI with Dismiss/Flag/Fix lifecycle
- Fuzzy flag dedup with number-aware word similarity
- Auto-resolve when flagged issues disappear
- Background AbortController isolation
- Indexer failure resilience (warning after 3 consecutive)
- PubPartner client identity persistence (localStorage)
- Lantern light, spiral spine, sidebar collapse

### IMPLEMENTED, AWAITING CONFIGURATION (Status B/C)

6 features are fully implemented but need an LLM provider or PubPartner server:

- AI text generation (pool/tick/playback pipeline)
- PubPartner chat (adapter correctly wired to `/api/pubpartner/turns/live`)
- Manuscript indexer (async, one call per dirty chapter, hash-based skip)
- Character/plot/location/timeline extraction (mergeChapterIndex)
- Continuity watchdog (runs after indexer, fuzzy dedup, auto-resolve)
- PubPartner adapter (real API shape: message/history/user_id/session_id/project_id/room_id, friend_response parsing, provider_fallback handling)

**These are NOT unfinished. They are correctly built and awaiting their service dependency.**

### NOT YET IMPLEMENTED (Status E)

4 features from the manuscript intelligence skeleton:

- Style profile generation (analyze writer's prose patterns)
- Voice training (accept/reject capture → few-shot examples)
- Voice-matched generation (style-constrained prompts)
- Cartridge/PubPartner manuscript memory sync

---

## B. ARCHITECTURAL ASSESSMENT

### What is good

**FACT:** The v26 PubPartner adapter is correctly shaped. It sends `message` (not `messages`), includes `user_id`/`session_id`/`project_id`/`room_id`, parses `friend_response`, and surfaces `provider_fallback`. This was confirmed by reading `pubpartner_routes.py` and `pubpartner_core.py` directly.

**FACT:** The manuscript indexer runs in the background without blocking the writer. It uses a separate AbortController for background calls so cancelling a generation doesn't kill an in-flight index. The indexer prompt returns structured JSON that gets type-checked field-by-field before touching state.

**FACT:** The continuity watchdog has fuzzy dedup that accounts for LLM phrasing variance between runs. It uses word-overlap coefficient with a numeric-entity check to prevent "Elena left-handed in ch1" and "Elena left-handed in ch3" from being merged as duplicates.

**FACT:** The .2i file format has a migration path (v4→v5). Old files open and silently upgrade.

**FACT:** 2i and PubPartner are architecturally independent. 2i works fully in solo Write mode with no LLM and no PubPartner. PubPartner is one of four optional LLM providers. This matches the architecture prompt's requirement that products have independent value.

### What is fragile

**FACT:** API keys stored in localStorage. Acceptable for a local-first tool, but XSS on a shared machine would expose them. PubPartner's server-side key management is the long-term answer.

**FACT:** Claude direct-browser CORS depends on `anthropic-dangerous-direct-browser-access`. This is a development convenience, not a production path.

**INFERENCE:** The `newChapter` function uses `prompt()` for title/subtitle. The reference archive was upgraded to a modal; chapters should follow suit.

### What should NOT be changed

- The LLM adapter pattern (provider-neutral, 4 adapters, consistent interface)
- The solo/collab mode duality and toggle behavior
- The PubPartner adapter's API shape (it matches the real server)
- The manuscript intelligence merge logic (type-safe, alias-aware)
- The continuity flag lifecycle (active → deferred → dismissed → resolved)
- The fuzzy dedup with number-aware similarity
- The IndexedDB autosave mechanism
- The .2i file format (extend, don't replace)
- The CSS design token system

### What should eventually be refactored

**RECOMMENDATION:** The generation prompt (in `generateMore`) doesn't use the intelligence data it's already collecting. It should pull character context, active plot threads, and eventually the style profile into the generation prompt. This is the Phase 4 integration point.

**RECOMMENDATION:** Chapter management should become scene management. The reference image shows "Scene 3 of 12" with navigation arrows. Chapters are the right grain for the manuscript index; scenes are the right grain for the writer's working unit.

---

## C. THE CARTRIDGE MODEL

### Architecture (replaces the 3-approach analysis)

```
Writer
  │
  ▼
┌─────────────────────────┐
│  2i (Writer's Room)     │ ← .2i file (text + structure only)
│  - solo editor          │
│  - collab mode          │
│  - playback             │
│  - reference archive    │
└─────────┬───────────────┘
          │ commit digests
          │ voice training data
          │ chat turns
          ▼
┌─────────────────────────┐
│  PubPartner             │ ← persistent friend layer
│  - Alex / custom friend │
│  - turns/live API       │
│  - persistent memory    │
│  - governance           │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Cartridge              │ ← persistent knowledge store
│  - character graph      │    (lives inside PubPartner's
│  - plot thread tracker  │     vessel/data directory)
│  - style profile        │
│  - voice examples       │
│  - continuity log       │
│  - cross-manuscript     │
│    awareness            │
└─────────────────────────┘
```

### What lives where

| Data | Location | Why |
|---|---|---|
| Manuscript text | .2i file | Writer's property. Portable. |
| Chapter structure | .2i file | Structural metadata of the text. |
| Locked lines | .2i file | Editing state. |
| References | .2i file | Project-scoped documents. |
| Intelligence cache | .2i file (lightweight) | Offline fallback only. |
| Character graph | Cartridge | Cross-manuscript, cumulative. |
| Plot threads | Cartridge | Persistent across sessions. |
| Style profile | Cartridge | Per-writer, carries across books. |
| Voice examples | Cartridge | Cumulative training data. |
| Continuity log | Cartridge | Governed corrections. |
| Writer identity | Cartridge | Authority chain for corrections. |

### Contract: 2i → PubPartner

On each commit/save, 2i sends:

```json
POST /api/pubpartner/manuscript/digest
{
  "user_id": "persistent-client-id",
  "project_id": "manuscript-name",
  "chapter_index": 7,
  "chapter_hash": "abc123",
  "digest": {
    "characters_mentioned": [...],
    "plot_events": [...],
    "locations": [...],
    "time_markers": [...]
  }
}
```

PubPartner stores this in the cartridge. Jeremy's context spine includes it in future turn context automatically.

On each generation request, 2i asks PubPartner for enriched context:

```json
POST /api/pubpartner/manuscript/context
{
  "user_id": "persistent-client-id",
  "project_id": "manuscript-name",
  "current_chapter": 7,
  "last_n_lines": 8
}
```

Response includes relevant character data, active plot threads, style constraints, and voice examples — everything the generation prompt needs that the cartridge knows.

### What this changes in the build plan

The skeleton's Phase 5 (sync protocol) collapses. There's no sync because there's one source of truth. 2i pushes digests to PubPartner. PubPartner stores them in the cartridge. The 6-week plan becomes 4 weeks:

- Phase 1-2 (indexer + continuity): **ALREADY BUILT in v26**
- Phase 3 (style profile + voice training): 1-2 weeks
- Phase 4 (cartridge endpoints in PubPartner): 1-2 weeks
- Phase 5 (testing + tuning): 1 week

---

## D. PRIORITIZED ROADMAP

### Phase 0 — Preserve / Baseline (DONE)

v26 IS the baseline. 35 working features, 6 awaiting configuration.

### Phase 1 — Stabilize (1 week)

- [ ] Replace `prompt()` in newChapter with proper modal (consistency with addRef)
- [ ] Wire generation prompt to use intelligence data (characters, plot threads)
- [ ] Add scene navigation (Scene N of M + prev/next in status bar)
- [ ] Visual polish pass: parchment aging, corner ornaments, compass rose (CSS/SVG)
- [ ] Test all features with a real LLM (OpenAI or local Ollama)
- [ ] Test PubPartner adapter against running PubPartner server

### Phase 2 — Voice Training (2 weeks)

- [ ] Capture accept/reject/rewrite data in collab mode
- [ ] Store voice examples in .2i intelligence cache
- [ ] Build style analyzer prompt (run on 3000-word sample)
- [ ] Build composite generation prompt (style + voice + intelligence context)
- [ ] FIFO cap on example arrays (50 accepted, 30 rejected, 30 rewrites)

### Phase 3 — Cartridge Integration (2 weeks)

- [ ] Build `/api/pubpartner/manuscript/digest` endpoint
- [ ] Build `/api/pubpartner/manuscript/context` endpoint
- [ ] Build `/api/pubpartner/voice/profile` endpoint
- [ ] Wire 2i commit flow to push digests when PubPartner is connected
- [ ] Wire generation to pull enriched context from PubPartner
- [ ] Store voice profile in cartridge (cross-manuscript)
- [ ] Fallback: use .2i embedded cache when PubPartner offline

### Phase 4 — Professional Polish (1 week)

- [ ] Loading states for indexer/continuity/generation
- [ ] Error states for LLM failures (clear, actionable messages)
- [ ] Offline state indicator
- [ ] Empty state for new documents (welcome + quickstart)
- [ ] Version info display
- [ ] .docx export (lightweight library)

### Phase 5 — Beta Validation (1 week)

- [ ] Write with a real manuscript (10+ chapters) and verify intelligence
- [ ] Tune indexer prompt for >90% character extraction accuracy
- [ ] Tune continuity prompt for <20% false positive rate
- [ ] Verify voice training improves accept ratio over 50+ generations
- [ ] Verify file format migration (open v4 file in v5 environment)
- [ ] Verify PubPartner cartridge persistence across server restarts

---

## E. RISK REGISTER

| Risk | Severity | Mitigation |
|---|---|---|
| Claude CORS blocks production demo | Critical | Route through PubPartner or tiny proxy |
| Indexer prompt returns unparseable JSON | Medium | Already mitigated — asString/asArray guards, chapter stays dirty |
| Voice training biases toward AI's own patterns | Medium | Use rewrite pairs (human corrections) as primary signal |
| Cartridge data loss on PubPartner crash | Medium | .2i embedded cache provides fallback; PubPartner vessels have backup |
| File format v6 breaks v5 files | Low | migrateDocument pattern already established |
| Large manuscript (50+ chapters) slow to index | Low | Hash-based skip means only changed chapters re-index |

---

## F. STOP LIST — Do Not Touch

- The LLM adapter interface (it works, it's provider-neutral)
- The PubPartner adapter's API shape (matches the real server)
- The solo/collab mode architecture
- The IndexedDB autosave mechanism
- The .2i file format structure (extend only)
- The CSS design token system
- The canvas rendering (lantern + spine)
- The continuity flag fuzzy dedup logic
- The mergeChapterIndex type-safety pattern

---

## G. IMMEDIATE ACTIONS (smallest set that reduces uncertainty)

1. **Test with a real LLM.** Configure OpenAI or local Ollama. Write 3 chapters. Verify indexer runs, continuity flags appear, generation works. This validates the B/C features as genuinely functional.

2. **Test PubPartner connection.** Start PubPartner locally. Configure the adapter. Send chat messages. Verify `friend_response` comes back. Verify `project_id` scoping works.

3. **Wire intelligence into generation.** The indexer is collecting data that generation isn't using yet. One function change: build the generation prompt from intelligence context instead of raw last-8-lines.

Those three actions convert 6 "awaiting configuration" features into verified working features and connect the intelligence pipeline end-to-end.

---

*Assessment by Opus for Rear View Foresight LLC*
*Feic Mo Chroí™*
