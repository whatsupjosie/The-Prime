# Manuscript Intelligence — Hybrid Architecture
## Build Skeleton & Workflow

**Approach C: .2i portable cache + PubPartner deep memory**

---

## Phase 1: .2i File Format v5 (Week 1-2)

### New fields in the .2i document state:

```json
{
  "format": "2i-document",
  "version": 5,
  "title": "The Brass Compass",
  "state": {
    "committed": [],
    "buffer": [],
    "chapters": [],
    "lockedLines": [],
    "coWriting": false,
    "references": [],
    
    "intelligence": {
      "schema_version": 1,
      "last_indexed": "2026-08-12T10:30:00Z",
      "dirty_chapters": [7, 8],
      
      "characters": [
        {
          "id": "elena_locke",
          "name": "Elena Locke",
          "aliases": ["the captain", "E", "Locke"],
          "first_appearance": { "chapter": 0, "line": 4 },
          "appearances": [
            { "chapter": 0, "lines": [4,5,6,12,18] },
            { "chapter": 2, "lines": [1,8,14,22] }
          ],
          "traits": {
            "confirmed": ["left-handed", "skeptical of authority"],
            "inferred": ["protective of crew"],
            "contradictions": []
          },
          "arc_beats": [
            { "chapter": 0, "summary": "Introduced commanding the Daedalus, uneasy about the Convergence" },
            { "chapter": 2, "summary": "Discovers the letter was forged, begins doubting Marcus" }
          ]
        }
      ],
      
      "plot_threads": [
        {
          "id": "forged_letter",
          "label": "The forged letter",
          "status": "unresolved",
          "introduced": { "chapter": 1, "line": 30 },
          "mentions": [
            { "chapter": 1, "line": 30, "context": "Elena finds the letter in the captain's desk" },
            { "chapter": 2, "line": 14, "context": "Elena realizes the handwriting doesn't match" }
          ],
          "depends_on": [],
          "blocks": ["marcus_confrontation"]
        }
      ],
      
      "locations": [
        {
          "id": "the_convergence",
          "name": "The Convergence",
          "description": "An empty circle on maps. A wound in the world.",
          "chapters_present": [0, 3, 5]
        }
      ],
      
      "timeline": [
        { "chapter": 0, "time_marker": "night", "relative": null },
        { "chapter": 1, "time_marker": "next morning", "relative": "chapter_0 + ~8hrs" }
      ],

      "style_profile": {
        "generated_from_words": 12847,
        "avg_sentence_length": 13.6,
        "sentence_variance": "high",
        "paragraph_length": "2-4 sentences typical",
        "vocabulary_register": "plain, Anglo-Saxon roots preferred",
        "constructions_preferred": [
          "Short declarative sentences",
          "Sentence fragments for rhythm",
          "Comma splices used deliberately"
        ],
        "constructions_avoided": [
          "Adverbs on dialogue tags",
          "Said-bookisms (murmured, exclaimed, etc.)",
          "Progressive tense where simple past works"
        ],
        "sensory_bias": "visual and tactile over auditory",
        "dialogue_style": "subtext-heavy, characters deflect",
        "tonal_signature": "dry humor undercutting emotional beats"
      },
      
      "voice_examples": {
        "accepted": [
          "She turned the cup in her hands, not drinking.",
          "The fog didn't lift. It just stopped caring about them."
        ],
        "rejected": [
          "The porcelain cup felt cool against her trembling fingers.",
          "A heavy silence descended upon the room like a shroud."
        ],
        "rewrites": [
          {
            "ai": "His heart ached with the weight of unspoken words.",
            "human": "He didn't say anything. Couldn't, maybe.",
            "lesson": "Avoid abstract emotional description. Show through action or absence."
          }
        ]
      },
      
      "continuity_flags": [
        {
          "severity": "warning",
          "type": "trait_contradiction",
          "message": "Elena picks up the sword right-handed in ch6 line 12, but was established as left-handed in ch1 line 4.",
          "chapters": [1, 6],
          "dismissed": false
        }
      ]
    }
  }
}
```

### Migration function (add to 2i JS):

```javascript
function migrateDocument(doc) {
  if (doc.version < 5) {
    doc.state.intelligence = {
      schema_version: 1,
      last_indexed: null,
      dirty_chapters: doc.state.chapters.map((_, i) => i),
      characters: [],
      plot_threads: [],
      locations: [],
      timeline: [],
      style_profile: null,
      voice_examples: { accepted: [], rejected: [], rewrites: [] },
      continuity_flags: []
    };
    doc.version = 5;
  }
  return doc;
}
```

### Tasks:
- [ ] Add `intelligence` field to `getDocState()` and `loadDocState()`
- [ ] Add `migrateDocument()` to open/load flow
- [ ] Add version check on file open
- [ ] Extend save to include intelligence data
- [ ] Ensure backwards compatibility (v4 files open, upgrade silently)

---

## Phase 2: Manuscript Indexer (Week 2-3)

### The indexer runs on commit, not on every keystroke.

```
TRIGGER: Writer commits a scene (approveBuffer) or saves
    |
    v
DIFF: Which chapters changed since last_indexed?
    |
    v
For each dirty chapter:
    |
    v
SEND to LLM (one call per dirty chapter):
    System: "You are a manuscript indexer. Extract structured data 
    from this chapter. Return JSON only."
    
    User: [chapter text] + [existing character list for reference]
    
    Expected output:
    {
      "characters_mentioned": [
        { "name": "Elena", "actions": ["discovers letter"], "traits_shown": ["suspicious"] }
      ],
      "plot_events": [
        { "description": "Letter revealed as forgery", "thread": "forged_letter", "advances": true }
      ],
      "locations": ["archive room"],
      "time_markers": ["night", "same day as ch6"],
      "setup_or_payoff": [
        { "type": "setup", "element": "Marcus didn't react to the forgery reveal" }
      ]
    }
    |
    v
MERGE into intelligence.characters, .plot_threads, .locations, .timeline
    |
    v
MARK chapter clean in dirty_chapters
    |
    v
SAVE updated intelligence to .2i file
```

### Implementation notes:
- Run async, don't block the writer
- Show "indexing ch7..." in status bar  
- Cache: only re-index chapters whose text hash changed
- Cost: ~1 API call per changed chapter, ~200-400 tokens each
- The indexer prompt is a SYSTEM prompt you tune once and reuse

### Tasks:
- [ ] Hash each chapter's committed text for change detection
- [ ] Write indexer prompt template
- [ ] Write merge logic (new chars merge with existing, don't duplicate)
- [ ] Background async indexing after commit
- [ ] Status bar indicator during indexing
- [ ] Store chapter hashes for change detection

---

## Phase 3: Continuity Watchdog (Week 3-4)

### Runs after indexer completes, not during writing.

```
TRIGGER: Indexer finishes updating a chapter
    |
    v
COMPARE: Updated chapter's data against full index
    |
    v
SEND to LLM (one call):
    System: "You are a continuity editor. Compare these chapter 
    summaries and character records. Find contradictions, orphaned 
    setups, timeline errors. Return only genuine issues, not style 
    preferences. JSON output."
    
    User: [full character list with traits] + 
          [all plot threads with status] +
          [timeline entries] +
          [the updated chapter's events]
    |
    v
PARSE findings into continuity_flags
    |
    v
SURFACE in PubPartner chat (non-intrusive):
    "I noticed Elena uses her right hand in chapter 6 — 
     she was left-handed in chapter 1. Intentional?"
    
    [DISMISS]  [FLAG FOR LATER]  [FIX NOW]
```

### Flag lifecycle:
1. Created by watchdog → status: `active`
2. Writer dismisses → status: `dismissed` (won't re-flag)
3. Writer fixes → watchdog detects fix on next run → status: `resolved`

### Tasks:
- [ ] Write continuity checker prompt template
- [ ] Build flag UI in sidebar or chat
- [ ] Dismiss/acknowledge/resolve flow
- [ ] Don't re-flag dismissed items
- [ ] Severity levels: error (contradiction), warning (orphaned setup), info (parallel noticed)

---

## Phase 4: Style Profile & Voice Training (Week 4-5)

### Initial profile generation (runs once, or on request):

```
TRIGGER: First commit with 2000+ words, or writer requests "analyze my style"
    |
    v
SAMPLE: Pull 3000 words from different sections of manuscript
    |
    v
SEND to LLM:
    System: "You are a literary style analyst. Analyze this prose 
    sample and extract a precise mechanical profile. Focus on 
    measurable patterns, not subjective quality. JSON output."
    
    User: [3000-word sample]
    |
    v
STORE in intelligence.style_profile
```

### Voice training from accept/reject (runs continuously):

```
TRIGGER: Writer accepts or rejects an AI-generated line in collab mode
    |
    v
IF accepted:
    Push to voice_examples.accepted (cap at 50, FIFO)
    
IF rejected:
    Push to voice_examples.rejected (cap at 30, FIFO)
    
IF accepted then immediately edited:
    Capture the pair { ai: original, human: edited }
    Push to voice_examples.rewrites (cap at 30, FIFO)
    |
    v
UPDATE generation prompt to include examples
```

### Updated generation prompt structure:

```
System: You are a prose generator for a manuscript.

STYLE CONSTRAINTS (follow exactly):
- Sentences average {avg_sentence_length} words, high variance
- {vocabulary_register}
- ALWAYS: {constructions_preferred, joined}
- NEVER: {constructions_avoided, joined}
- Dialogue style: {dialogue_style}
- Sensory focus: {sensory_bias}

VOICE EXAMPLES — lines this author accepted:
{voice_examples.accepted, last 5}

VOICE ANTI-EXAMPLES — lines this author rejected:
{voice_examples.rejected, last 5}

VOICE CORRECTIONS — how this author rewrites AI prose:
{voice_examples.rewrites, last 3, formatted as "You wrote: X → Author changed to: Y"}

MANUSCRIPT CONTEXT:
{current chapter summary from index}
{active plot threads}
{characters present in current scene}

CURRENT SCENE:
{last 8 committed lines}
{buffer}

Continue with 2-4 sentences. Match the style constraints and voice 
examples exactly. Each sentence on its own line. No preamble.
```

### Tasks:
- [ ] Style analyzer prompt template
- [ ] Sample selection logic (pick from different chapters for variety)
- [ ] Accept/reject capture in collab mode tick/render flow
- [ ] Edit detection (accepted line modified within 30 seconds = rewrite pair)
- [ ] FIFO capping on example arrays
- [ ] Build the composite generation prompt from profile + examples + index
- [ ] "Analyze my style" button in manuscript control

---

## Phase 5: PubPartner Sync (Week 5-6)

### Sync protocol:

```
ON CONNECT (2i detects PubPartner is running):
    |
    v
PUSH: Send current intelligence cache to PubPartner
    POST /api/pubpartner/manuscript/sync
    Body: { manuscript_id, title, intelligence }
    |
    v
PULL: Receive any PubPartner-side updates
    (voice profile enriched from other manuscripts,
     cross-manuscript character references,
     governed corrections from Pub Manager)
    |
    v
MERGE: PubPartner corrections override .2i cache
    (authority chain: writer > Pub Manager > inference)
    |
    v
CONTINUE: Normal operation with merged intelligence

ON COMMIT (writer approves buffer or saves):
    |
    v
IF PubPartner connected:
    Push incremental update (just the changed chapter digest)
    PubPartner stores in persistent memory via Jeremy
ELSE:
    Queue the update for next sync
    
ON DISCONNECT:
    2i continues using embedded cache
    All changes queued for sync
    Status bar shows "offline — using local cache"
```

### PubPartner endpoints needed:

```
POST /api/pubpartner/manuscript/sync
  - Full intelligence sync on connect
  
POST /api/pubpartner/manuscript/update  
  - Incremental chapter update after commit
  
GET  /api/pubpartner/manuscript/{id}/intelligence
  - Pull current intelligence state
  
POST /api/pubpartner/voice/profile
  - Push/pull cross-manuscript voice profile
  
GET  /api/pubpartner/voice/examples
  - Get accumulated voice examples across all manuscripts
```

### Tasks:
- [ ] Sync-on-connect logic in 2i
- [ ] Queue system for offline changes
- [ ] PubPartner routes (5 endpoints above)
- [ ] Jeremy integration — manuscript intelligence stored in context spine
- [ ] Merge logic with authority precedence
- [ ] Status bar sync indicator
- [ ] Fallback behavior when PubPartner unavailable

---

## Phase 6: Testing & Tuning (Week 6-7)

### What to test:
- [ ] Indexer accuracy: does it correctly extract characters, events, locations?
- [ ] Continuity watchdog: does it find real issues without false positives?
- [ ] Style profile: does it accurately describe the writer's patterns?
- [ ] Voice matching: do accepted lines increase over time? Do rejections decrease?
- [ ] Sync: does offline→online reconciliation work without data loss?
- [ ] Performance: indexing a 20-chapter manuscript — how long, how many tokens?
- [ ] File size: .2i file with full intelligence for a 80K-word novel — acceptable?

### Tuning targets:
- Indexer prompt: tune until character extraction is >90% accurate
- Continuity prompt: tune until false positive rate is <20%
- Style profile: compare against manual analysis by a human editor
- Voice training: track accept/reject ratio over 50+ generations, should trend toward >70% accept

### Cost estimation (Claude Sonnet pricing):
- Initial full index of 20 chapters: ~20 API calls, ~$0.15-0.30
- Per-commit incremental: 1-2 API calls, ~$0.01-0.02
- Continuity check: 1 API call, ~$0.01
- Style analysis: 1 API call, ~$0.02
- Generation with full context: 1 API call, ~$0.01-0.02
- **Monthly cost for active daily writing: roughly $3-8**

---

## Workflow Summary

```
WRITER'S DAILY FLOW:
                                                    
  Open .2i file                                      
       │                                             
       ▼                                             
  2i loads intelligence cache from file               
       │                                             
       ├── PubPartner running? ──YES──► Sync          
       │                               │             
       │                          Merge deep memory   
       │                          with local cache    
       │                               │             
       ▼                               ▼             
  Write (solo or collab mode)                         
       │                                             
       ▼                                             
  Commit scene                                        
       │                                             
       ├──► Indexer runs (async, background)           
       │         │                                    
       │         ▼                                    
       │    Continuity watchdog                       
       │         │                                    
       │         ▼                                    
       │    Flags surface in chat (if any)             
       │                                              
       ├──► Voice examples captured (collab mode)      
       │         │                                    
       │         ▼                                    
       │    Style profile updates                     
       │                                              
       ├──► PubPartner sync (if connected)             
       │                                              
       ▼                                             
  Save .2i (intelligence embedded)                    
       │                                             
       ▼                                             
  File is portable, self-sufficient                   
  PubPartner has deep copy for cross-manuscript work  
```

---

## File Deliverables

When complete, the project consists of:

| File | Purpose |
|---|---|
| `pubcast-2i-writers-room.html` | The writing application (updated with intelligence features) |
| `HANDOFF.md` | Technical documentation |
| PubPartner `manuscript_routes.py` | 5 new API endpoints for sync |
| PubPartner `manuscript_indexer.py` | Indexer and continuity prompts |
| PubPartner `voice_profile.py` | Style analysis and voice matching |
| Prompt templates (3) | Indexer, continuity, style analyzer |

---

*Approach C — Hybrid Architecture*  
*Estimated build: 6-7 focused weeks*  
*Estimated ongoing cost per active writer: $3-8/month at Sonnet pricing*
